package activeMQ;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;

/**
 * 点对点消息模式
 * 
 * @author Administrator
 *
 */
public class MessageQueueProducer {
	// ActiveMq 的默认用户名
	private static final String USERNAME = "admin";
	// ActiveMq 的默认登录密码
	private static final String PASSWORD = "admin";
	// ActiveMQ 的链接地址
	private static final String BROKEN_URL = "tcp://127.0.0.1:61616";

	public static void main(String[] args) throws JMSException {
		ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(USERNAME, PASSWORD, BROKEN_URL);
		Connection connection = connectionFactory.createConnection();
		connection.start();// 开启链接
		Session session = connection.createSession(true, Session.SESSION_TRANSACTED);// 开启事务，并设置事务级别
		// 创建消息队列
		Queue queue = session.createQueue("firstMQ");

		// 消息生产者
		MessageProducer producer = (MessageProducer) session.createProducer(queue);
		for (int i = 0; i < 10; i++) {
			TextMessage message = session.createTextMessage("回话1正在生产消息。。。。。。。。。。。" + i);
			producer.send(message);
		}
		session.commit();

		Session session1 = connection.createSession(true, Session.SESSION_TRANSACTED);// 开启事务，并设置事务级别
		// 创建消息队列
		Queue queue1 = session1.createQueue("firstMQ");
		MessageProducer producer1 = (MessageProducer) session1.createProducer(queue1);
		for (int i = 0; i < 10; i++) {
			TextMessage message1 = session1.createTextMessage("lign正在生产消息1。。。。。。。。。。。" + i);
			producer1.send(message1);
		}

		session1.commit();
	}

}
