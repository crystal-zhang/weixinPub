package activeMQ;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;

import org.apache.activemq.ActiveMQConnectionFactory;

/**
 * 发布订阅模式
 * @author Administrator
 *
 */
public class MessageTopicProducer {
	// ActiveMq 的默认用户名
		private static final String USERNAME = "admin";
		// ActiveMq 的默认登录密码
		private static final String PASSWORD = "admin";
		// ActiveMQ 的链接地址
		private static final String BROKEN_URL = "tcp://127.0.0.1:61616";
		private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	public static void main(String[] args) throws JMSException {
		ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(USERNAME, PASSWORD, BROKEN_URL);
		Connection connection = connectionFactory.createConnection();
		connection.start();// 开启链接
		Session session = connection.createSession(true, Session.SESSION_TRANSACTED);// 开启事务，并设置事务级别
		//创建topic
		Topic topic= session.createTopic("firstTopic"); 
		MessageProducer producer= session.createProducer(topic);
		producer.setDeliveryMode(DeliveryMode.PERSISTENT);
		TextMessage message = session.createTextMessage(sdf.format(new Date()));
		producer.send(message);
		session.commit();
	}

}
