package activeMQ;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;

import org.apache.activemq.ActiveMQConnectionFactory;
/**
 * 消息订阅者
 * @author Administrator
 *
 */
public class MessageSubscriber {
	private ConnectionFactory connectionFactory;
	private Connection connection;
	private Session session;
	private MessageConsumer consumer;
	private Topic topic;
	private String clientId;

	public MessageSubscriber(String clientId) {
		try {
			this.connectionFactory = new ActiveMQConnectionFactory("admin", "admin", "tcp://localhost:61616");
			this.connection = connectionFactory.createConnection();
			connection.setClientID(clientId);
			this.connection.start();
			// 不使用事务
			// 设置客户端签收模式
			this.session = this.connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			this.topic = this.session.createTopic("firstTopic");
			//this.consumer = this.session.createConsumer(destination);
			this.consumer = session.createDurableSubscriber(topic, "qazedc");
		} catch (JMSException e) {
			throw new RuntimeException(e);
		}

	}

	class MyLister implements MessageListener {

		@Override
		public void onMessage(Message message) {
			try {
				if (message instanceof TextMessage) {
					System.out.println(((TextMessage) message).getText());
					message.acknowledge();
				}
			} catch (JMSException e) {
				throw new RuntimeException(e);
			}
		}

	}

	public void receiver() {
		try {
			this.consumer.setMessageListener(new MyLister());
		} catch (JMSException e) {
			throw new RuntimeException(e);
		}
	}

	public static void main(String[] args) {
		MessageSubscriber conmuser = new MessageSubscriber("aaa");
		conmuser.receiver();
		
		MessageSubscriber conmuser1 = new MessageSubscriber("bbb");
		conmuser1.receiver();

	}

}
