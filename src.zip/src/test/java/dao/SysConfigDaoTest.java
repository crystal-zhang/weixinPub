/**
 *
 */
package dao;

import java.math.BigDecimal;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import common.AbstractJunitTest;
import entity.SysConfig;

/**
 *
 * @date 2018年8月16日
 */
public class SysConfigDaoTest extends AbstractJunitTest {
	@Autowired
	private SysConfigDao dao;

	/**
	 * Test method for
	 * {@link dao.SysConfigDao#insertSysConfig(entity.SysConfig)}.
	 */

	public void testInsertSysConfig() {
		SysConfig sysConfig = new SysConfig();
		sysConfig.setSysKey("key2");
		sysConfig.setSysValue("value1");
		sysConfig.setSysComment("测试");
		dao.insertSysConfig(sysConfig);
	}

	/**
	 * Test method for {@link dao.SysConfigDao#findobj(java.math.BigDecimal)}.
	 */

	public void testFindobj() {
		SysConfig sysConfig = dao.findobj(new BigDecimal(5));
		System.out.println(sysConfig);
		// List<Exception> list = new ArrayList<>();
		// list.add(new RuntimeException());
	}

	@Test
	public void testqueryList() {
		SysConfig sysConfig = new SysConfig();
		List<SysConfig> sysConfigList = dao.queryList(sysConfig);
		System.out.println(sysConfigList);
	}

}
