/**
 *
 */
package common;

import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * junit测试抽象类
 *
 * @date 2018年8月16日
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({ "classpath*:config/applicationContext.xml" })
// @Transactional
public abstract class AbstractJunitTest {

}
