package freemarker;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import com.alibaba.fastjson.JSONObject;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
/**
 * freemarker生成jsp文件
 * @author Administrator
 *
 */
public class Test {

	public static void main(String[] args) throws IOException, TemplateException {
		Configuration cfg = new Configuration(Configuration.VERSION_2_3_28);
		cfg.setDefaultEncoding("utf-8");
		cfg.setDirectoryForTemplateLoading(new File(""));
		Template template = cfg.getTemplate("");
		JSONObject json = new JSONObject();
		FileWriter fw = new FileWriter("");
		template.process(json, fw);

	}

}
