/**
 *
 */
package controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

/**
 *
 * @date 2018年9月17日
 */
@Controller
public class RecognizeImageController {
	private static Logger log = LoggerFactory.getLogger(RecognizeImageController.class);

	@PostMapping(value = { "/recognizeText.do" }, produces = { "text/html;charset=UTF-8" })
	@ResponseBody
	private String recognizeText(@RequestParam("testImage") MultipartFile image, HttpServletRequest request,
			ModelMap model) throws Exception {
		Base64 encoder = new Base64();
		String imageStr = encoder.encodeToString(image.getBytes());
		String appkey = "24954177";
		String appcode = "f65bf9d17f874bfdaea460c30cd17e70";
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost post = new HttpPost("https://ocrapi-document.taobao.com/ocrservice/document");
		post.setHeader("Authorization", "APPCODE " + appcode);
		post.setHeader("Content-Type", "application/json; charset=UTF-8");
		post.setHeader("X-Ca-Key", appkey);
		JSONObject json = new JSONObject();
		json.put("img", imageStr);
		StringEntity botyEntity = new StringEntity(json.toJSONString());

		post.setEntity(botyEntity);
		CloseableHttpResponse response = httpclient.execute(post);
		HttpEntity result = response.getEntity();
		String resultStr = EntityUtils.toString(result);
		JSONObject resultJson = JSONObject.parseObject(resultStr);
		JSONArray wordJson = resultJson.getJSONArray("prism_wordsInfo");
		int size = wordJson.size();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < size; i++) {
			JSONObject word = wordJson.getJSONObject(i);
			sb.append(word.getString("word"));
		}
		log.info("图片文字是:{}", sb.toString());
		model.put("text", sb.toString());
		return sb.toString();
	}

	@PostMapping({ "/recognizeCard.do" })
	@ResponseBody
	private String recognizeCard(@RequestParam("testCard") MultipartFile image, HttpServletRequest request,
			ModelMap model) throws Exception {
		Base64 encoder = new Base64();
		String imageStr = encoder.encodeToString(image.getBytes());
		String appkey = "24954177";
		String appcode = "f65bf9d17f874bfdaea460c30cd17e70";
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost post = new HttpPost("http://yhk.market.alicloudapi.com/rest/160601/ocr/ocr_bank_card.json");
		post.setHeader("Authorization", "APPCODE " + appcode);
		post.setHeader("Content-Type", "application/json; charset=UTF-8");
		post.setHeader("X-Ca-Key", appkey);
		JSONObject jsonobj = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		JSONObject json = new JSONObject();
		json.put("dataType", Integer.valueOf(50));
		json.put("dataValue", imageStr);
		JSONObject jsonImage = new JSONObject();
		jsonImage.put("image", json);
		jsonArray.add(jsonImage);
		jsonobj.put("inputs", jsonArray);
		StringEntity botyEntity = new StringEntity(jsonobj.toJSONString());

		post.setEntity(botyEntity);
		CloseableHttpResponse response = httpclient.execute(post);
		HttpEntity result = response.getEntity();
		String resultStr = EntityUtils.toString(result);
		JSONObject resultJSON = JSONObject.parseObject(resultStr);

		String cardStr = resultJSON.getJSONArray("outputs").getJSONObject(0).getJSONObject("outputValue")
				.getString("dataValue");
		String card = JSONObject.parseObject(cardStr).getString("card_num");
		log.info("银行卡号是:{}", card);
		model.put("imageCard", card);
		return card;
	}
}
