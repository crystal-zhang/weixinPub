package controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Map;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.DocumentException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import util.PropertyPlaceholderUtils;
import util.SHAUtil;
import util.XMLUtil;

/**
 *
 * @date 2018年8月14日
 */
@Controller
public class WeixinServiceController {
	/**
	 *
	 */
	private static final Logger log = LoggerFactory.getLogger(WeixinServiceController.class);

	/**
	 * 微信公众号服务器接入认证
	 *
	 * @date 2018年8月14日
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@GetMapping("weixin.do")
	public void getMessage(final HttpServletRequest request, final HttpServletResponse response) throws IOException {
		final PrintWriter out = response.getWriter();
		final String signature = request.getParameter("signature");
		final String timestamp = request.getParameter("timestamp");
		final String nonce = request.getParameter("nonce");
		final String echostr = request.getParameter("echostr");
		final String token = PropertyPlaceholderUtils.getContextProperty("weixin.tocken");
		final String[] paraArray = new String[] { token, timestamp, nonce };
		Arrays.sort(paraArray);
		final StringBuilder sb = new StringBuilder();
		for (int i = 0; i <= 2; i++) {
			sb.append(paraArray[i]);
		}
		final String shaResult = SHAUtil.encode(sb.toString());
		if (signature.equals(shaResult)) {
			out.write(echostr);
		}
		out.close();
	}

	/**
	 * 接收微信公众号消息
	 *
	 * @date 2018年8月14日
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@SuppressWarnings("resource")
	@PostMapping("weixin.do")
	public void postMessage(final HttpServletRequest request, final HttpServletResponse response) throws IOException {
		StringBuilder sb = new StringBuilder();
		String s;
		ServletInputStream inputStream = request.getInputStream();
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
		while ((s = bufferedReader.readLine()) != null) {
			sb.append(s);
		}
		try {
			Map<String, String> paraMap = XMLUtil.xmlToMap(sb.toString());
			String msgType = paraMap.get("MsgType");
			// 事件推送
			if (StringUtils.equals("event", msgType)) {
				String event = paraMap.get("Event");
				switch (event) {
				case "VIEW":
					visitView(paraMap);
					break;
				case "CLICK":
					visitPage(paraMap);
					break;
				default:
					break;
				}
			} else {
				/**
				 * 微信对此类消息不做处理
				 */
				response.getWriter().write("success");
			}

		} catch (DocumentException e) {
			log.error("xml解析异常{}", e);
		}
	}

	/**
	 * 访问自己的主页
	 *
	 * @date 2018年8月31日
	 * @param paraMap
	 */
	private void visitPage(Map<String, String> paraMap) {
		String eventKey = paraMap.get("EventKey");
		if (StringUtils.equals(eventKey, "goHome")) {

		}
	}

	/**
	 * 进入view指定的链接页面
	 *
	 * @date 2018年8月24日
	 * @param paraMap
	 */
	private void visitView(Map<String, String> paraMap) {
		// 设置的跳转URL
		String eventKey = paraMap.get("EventKey");

	}

	/**
	 * @date 2018年9月8日
	 * @param request
	 * @param response
	 */
	public void getPhoneMac(final HttpServletRequest request, final HttpServletResponse response) {
		String ip = request.getRemoteAddr();
		String arpCMD = "arp -a ";
		String macAdd = "";
		try {
			Process process = Runtime.getRuntime().exec("pingCMD + ip");
			String str;
			InputStreamReader inputStreamReader = new InputStreamReader(process.getInputStream());
			LineNumberReader lineNumberReader = new LineNumberReader(inputStreamReader);
			for (int i = 0; i < 100; i++) {
				str = lineNumberReader.readLine();
				if (str != null) {
					if (str.indexOf(ip) > 1) {
						macAdd = str.substring(str.indexOf("at") + 3, str.indexOf("at") + 20);
					}
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
