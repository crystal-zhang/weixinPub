/**
 *
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;

import dao.SysConfigDao;
import entity.SysConfig;

/**
 * 参数配置
 *
 * @date 2018年8月16日
 */
@Controller
public class SysConfigController {
	private Logger log = LoggerFactory.getLogger(SysConfigController.class);
	@Autowired
	private SysConfigDao dao;

	/**
	 * @date 2018年8月16日
	 * @return
	 */
	@GetMapping("/index.do")
	public String index() {
		log.info("访问参数配置页面");
		return "index";
	}

	/**
	 * @date 2018年8月16日
	 * @return
	 */
	@RequestMapping("/querySysConfigList.do")
	@ResponseBody
	public JSONObject queryList() {
		SysConfig sysConfig = new SysConfig();
		List<SysConfig> sysConfigList = dao.queryList(sysConfig);
		JSONObject json = new JSONObject();
		json.put("data", sysConfigList);
		json.put("recordsTotal", sysConfigList.size());
		log.info("json:{}", json);
		return json;
	}
	@RequestMapping("/getContextPath.do")
	
	public void queryContextPath(HttpServletRequest request,HttpServletResponse response) throws IOException {
		JSONObject json = new JSONObject();
		String path1= request.getServletContext().getRealPath("/");
		String path2= request.getServletContext().getResource("/").getFile();
		json.put("path1", path1);
		json.put("json2", path2);
		PrintWriter out = response.getWriter();
		out.write(json.toJSONString());
	}

}
