/**
 *
 */
package controller;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONObject;

import entity.TPtnActiveUser;

/**
 *
 * @date 2018年9月12日
 */
@Controller
public class UploadFileController {
	private static Logger log = LoggerFactory.getLogger(UploadFileController.class);
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private static final String EXCEL_XLS = "xls";
	private static final String EXCEL_XLSX = "xlsx";

	/**
	 * @date 2018年9月13日
	 * @param httpServletResponse
	 * @return
	 */
	@GetMapping("/upload.do")
	public String uploadFile(HttpServletResponse httpServletResponse) {
		// 使用cookie测试
		Cookie cookie = new Cookie("zhang", "customer cookie");
		httpServletResponse.addCookie(cookie);
		return "fileUpload";
	}

	/**
	 * 文件上传
	 *
	 * @date 2018年9月12日
	 * @param file
	 * @throws Exception
	 */
	@PostMapping("/upload.do")
	@ResponseBody
	public JSONObject uploadFile(@RequestParam("file") MultipartFile file, HttpServletResponse httpServletResponse) {
		JSONObject json = new JSONObject();
		log.info("文件名：{}", file.getOriginalFilename());
		List<TPtnActiveUser> result = null;
		try {
			InputStream ins = file.getInputStream();
			String fileName = file.getOriginalFilename();
			result = getCardActiveListByExcel(ins, fileName);
		} catch (Exception e) {
			log.info("文件读取异常");
			json.put("status", "error");
			return json;
		}
		log.info("卡单信息:{}", result);
		json.put("status", "success");
		return json;
	}

	private static Workbook getWorkbok(InputStream in, String filename) throws IOException {
		Workbook wb = null;
		if (filename.endsWith(EXCEL_XLS)) { // Excel&nbsp;2003
			wb = new HSSFWorkbook(in);
		} else if (filename.endsWith(EXCEL_XLSX)) { // Excel 2007/2010
			wb = new XSSFWorkbook(in);
		}
		return wb;
	}

	/**
	 * 根据Excel获得激活卡单列表
	 *
	 * @date 2018年9月13日
	 * @param inStr
	 * @param fileName
	 * @return
	 * @throws Exception
	 */
	public List<TPtnActiveUser> getCardActiveListByExcel(InputStream in, String filename) throws Exception {
		Workbook work = getWorkbok(in, filename);
		Sheet sheet = work.getSheetAt(0);
		Row row = null;
		Cell cell = null;
		List<TPtnActiveUser> result = new ArrayList<>();
		for (int i = sheet.getFirstRowNum() + 1; i < sheet.getLastRowNum() + 1; i++) {
			row = sheet.getRow(i);
			if (row == null) {
				continue;
			}
			TPtnActiveUser activeUser = new TPtnActiveUser();
			activeUser.setCardNo(getCellString(row.getCell(0)));
			activeUser.setActiveName(getCellString(row.getCell(1)));
			activeUser.setActivePhone(getCellString(row.getCell(2)));
			activeUser.setCardType(getCellString(row.getCell(3)));
			activeUser.setIdCardNum(getCellString(row.getCell(4)));
			activeUser.setActiveDate(getCellTimestamp(row.getCell(5)));
			activeUser.setEmail(getCellString(row.getCell(6)));
			result.add(activeUser);
		}
		return result;
	}

	/**
	 * 读取单元格中的日期字段
	 *
	 * @date 2018年9月13日
	 * @param cell
	 * @return
	 */
	private Timestamp getCellTimestamp(Cell cell) {
		return new Timestamp(cell.getDateCellValue().getTime());
	}

	/**
	 * 读取单元格中的字符串
	 *
	 * @date 2018年9月13日
	 * @param cell
	 * @return
	 */
	private String getCellString(Cell cell) {
		cell.setCellType(Cell.CELL_TYPE_STRING);
		return cell.getStringCellValue();
	}
}
