/**
 *
 */
package util;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import com.alibaba.fastjson.JSONObject;

/**
 * 获取微信公众号access_tocken
 *
 * @date 2018年8月14日
 */
public class AccessTockenUtil {

	/**
	 * @date 2018年8月14日
	 * @return
	 * @throws IOException
	 * @throws ParseException
	 */
	public static String getAccessTocken() throws ParseException, IOException {
		String appId = "wxd173c668cb3615e1";
		String appSecret = "e29aac3de18bbdb4eee212e984295c9c";
		String accessTockenUrl = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=APPID&secret=APPSECRET";
		String requestUrl = accessTockenUrl.replace("APPID", appId).replace("APPSECRET", appSecret);
		HttpGet get = new HttpGet(requestUrl);
		CloseableHttpClient client = HttpClients.createDefault();
		CloseableHttpResponse response = null;
		try {
			response = client.execute(get);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		HttpEntity responseEntity = response.getEntity();
		JSONObject jsonObject = JSONObject.parseObject(EntityUtils.toString(responseEntity, "utf-8"));
		String access_tocken = jsonObject.getString("access_token");
		if (StringUtils.isNotEmpty(access_tocken)) {
			return access_tocken;
		}
		return null;
	}
}
