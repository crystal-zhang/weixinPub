/**
 *
 */
package util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

/**
 *
 * @date 2018年8月14日
 */
public class XMLUtil {
	public static Map<String, String> xmlToMap(final String xmlStr) throws DocumentException {
		final Document doc = DocumentHelper.parseText(xmlStr);
		final Map<String, String> result = new HashMap<>();
		final Element root = doc.getRootElement();
		final Iterator<Element> elementIterator = root.elementIterator();
		while (elementIterator.hasNext()) {
			final Element ele = elementIterator.next();
			result.put(ele.getName(), ele.getText());
		}
		return result;
	}

	public static String mapToXML(final Map<String, String> map) {
		final StringBuilder sb = new StringBuilder();
		return sb.toString();
	}

	// public static void main(String[] args) throws DocumentException {
	// String xml =
	// "<xml><ToUserName></ToUserName><FromUserName></FromUserName><CreateTime>1357290913</CreateTime><MsgType></MsgType><MediaId></MediaId><Format></Format><MsgId>1234567890123456</MsgId></xml>";
	// Map<String, String> result = xmlToMap(xml);
	// System.out.println(result.size());
	// }

}
