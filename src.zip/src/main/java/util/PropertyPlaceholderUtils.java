package util;

import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

public class PropertyPlaceholderUtils extends PropertyPlaceholderConfigurer {
	private static final Pattern PATTERN = Pattern.compile("\\$\\{([^\\}]+)\\}");
	private static Properties properties;

	@Override
	protected void processProperties(ConfigurableListableBeanFactory beanFactoryToProcess, Properties props)
			throws BeansException {
		super.processProperties(beanFactoryToProcess, props);
		properties = props;
	}

	public static String getContextProperty(String name) {
		String value = properties.getProperty(name);
		Matcher matcher = PATTERN.matcher(value);
		StringBuffer buffer = new StringBuffer();
		while ((matcher != null) && (matcher.find())) {
			String matcherKey = matcher.group(1);
			String matchervalue = getContextProperty(matcherKey);
			if (matchervalue != null) {
				matcher.appendReplacement(buffer, matchervalue);
			}
		}
		matcher.appendTail(buffer);
		return buffer.toString();
	}

	public static void main(String[] args) {
		PropertyPlaceholderUtils p = new PropertyPlaceholderUtils();
		System.out.println(p);
	}
}
