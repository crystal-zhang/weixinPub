/**
 *
 */
package util;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

/**
 * 公众号菜单创建
 *
 * @date 2018年8月14日
 */
public class CreateMenu {
	/**
	 *
	 */
	private static final Logger log = LoggerFactory.getLogger(CreateMenu.class);

	/**
	 * @date 2018年8月14日
	 * @param args
	 * @throws IOException
	 * @throws ClientProtocolException
	 */
	@SuppressWarnings("resource")
	public static void main(String[] args) throws ClientProtocolException, IOException {
		String createMenuUrl = "https://api.weixin.qq.com/cgi-bin/menu/create?access_token=ACCESS_TOKEN";
		String access_tocken = null;
		try {
			access_tocken = AccessTockenUtil.getAccessTocken();
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String requestUrl = createMenuUrl.replace("ACCESS_TOKEN", access_tocken);
		HttpPost post = new HttpPost(requestUrl);
		CloseableHttpClient client = HttpClients.createDefault();
		StringEntity paramEntity = new StringEntity(createMenu(), "utf-8");
		post.setEntity(paramEntity);
		CloseableHttpResponse response = client.execute(post);
		HttpEntity responseEntity = response.getEntity();
		String result = EntityUtils.toString(responseEntity, "utf-8");

		log.info("菜单创建结果:{}", result);
	}

	/**
	 * @date 2018年8月24日
	 * @return
	 */
	private static String createMenu() {
		JSONObject jsonObject = new JSONObject();
		JSONArray buttonArray = new JSONArray();

		JSONObject button1 = new JSONObject();
		button1.put("type", "view");
		button1.put("name", "百度");
		button1.put("url", "https://www.baidu.com/");
		buttonArray.add(button1);

		JSONObject button2 = new JSONObject();
		button2.put("type", "click");
		button2.put("name", "goodvoice");
		button2.put("key", "V1001_TODAY_MUSIC");
		buttonArray.add(button2);

		jsonObject.put("button", buttonArray);
		return jsonObject.toJSONString();
	}

}
