/**
 *
 */
package weixinEnum;

/**
 * 事件类型
 *
 * @date 2018年8月31日
 */
public enum EventTypeEnum {
	/**
	 * 订阅事件
	 */
	SUBSCRIBE("subscribe"),
	/**
	 * 取消订阅事件
	 */
	UNSUBSCRIBE("unsubscribe");

	/**
	 * @param eventType
	 */
	private EventTypeEnum(String eventType) {
		this.eventType = eventType;
	}

	private String eventType;
}
