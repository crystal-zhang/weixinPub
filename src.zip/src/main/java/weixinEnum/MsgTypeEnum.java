/**
 *
 */
package weixinEnum;

/**
 * 消息类型
 *
 * @date 2018年8月31日
 */
public enum MsgTypeEnum {
	/**
	 * 文本消息
	 */
	TEXT("text"),
	/**
	 * 图片消息
	 */
	IMAGE("image"),
	/**
	 * 语音消息
	 */
	VOICE("voice"),
	/**
	 * 视频消息
	 */
	VIDEO("video"),
	/**
	 * 短视频消息
	 */
	SHORT_VIDEO("shortvideo"),
	/**
	 * 地理位置消息
	 */
	LOCATION("location"),
	/**
	 * 链接消息
	 */
	LINK("link"),
	/**
	 * 事件消息
	 */
	EVENT("event");
	private String value;

	/**
	 * @param value
	 */
	private MsgTypeEnum(String value) {
		this.value = value;
	}

}
