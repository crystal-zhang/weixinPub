package entity;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 客户激活信息实体类
 *
 * @author taop
 * @date 2018年9月4日
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class TPtnActiveUser implements Serializable {
	/**
	 * ID
	 */
	private Long id;

	/**
	 * 卡单编号
	 */
	private String cardNo;

	/**
	 * 激活人姓名
	 */
	private String activeName;

	/**
	 * 手机号
	 */
	private String activePhone;

	/**
	 * 证件类型
	 */
	private String cardType;

	/**
	 * 证件号码
	 */
	private String idCardNum;

	/**
	 * 邮箱
	 */
	private String email;
	/**
	 * 激活时间
	 */
	private Timestamp activeDate;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TPtnActiveUser [id=" + id + ", cardNo=" + cardNo + ", activeName=" + activeName + ", activePhone="
				+ activePhone + ", cardType=" + cardType + ", idCardNum=" + idCardNum + ", email=" + email
				+ ", activeDate=" + activeDate + "]";
	}

}
