/**
 *
 */
package entity;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 参数管理
 *
 * @date 2018年8月16日
 */
@Data
@EqualsAndHashCode
public class SysConfig {
	/**
	 * id
	 */
	public BigDecimal id;
	/**
	 * 参数key
	 */
	public String sysKey;
	/**
	 * 参数value
	 */
	public String sysValue;
	/**
	 * 参数注释
	 */
	public String sysComment;
	/**
	 * 创建时间
	 */
	public Date createTime;
	/**
	 * 上一次修改时间
	 */
	public Date modifyTime;
	/**
	 * 版本号
	 */
	public BigDecimal version;
}
