package listener;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class QueueMessageListener_copy implements MessageListener {
private static Logger log = LoggerFactory.getLogger(QueueMessageListener_copy.class);
	@Override
	public void onMessage(Message message) {
		TextMessage text = (TextMessage) message;
		try {
			log.info("接收消息copy:{}",text.getText());
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
