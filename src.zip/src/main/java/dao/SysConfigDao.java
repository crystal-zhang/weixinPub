/**
 *
 */
package dao;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Repository;

import entity.SysConfig;

/**
 *
 * @date 2018年8月16日
 */
@Repository
public interface SysConfigDao {
	/**
	 * @date 2018年8月16日
	 * @param sysConfig
	 */
	void insertSysConfig(SysConfig sysConfig);

	/**
	 * 根据id查找参数记录
	 *
	 * @date 2018年8月16日
	 * @param id
	 * @return
	 */
	SysConfig findobj(BigDecimal id);

	/**
	 * 查询参数列表
	 * 
	 * @date 2018年8月16日
	 * @param sysConfig
	 * @return
	 */
	List<SysConfig> queryList(SysConfig sysConfig);
}
