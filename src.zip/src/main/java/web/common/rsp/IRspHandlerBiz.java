/**
 *
 */
package web.common.rsp;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import web.common.view.ViewEnumType;

/**
 *
 * @date 2018年9月14日
 */
public interface IRspHandlerBiz {
	public abstract void rspWriterByJson(HttpServletResponse paramHttpServletResponse, Object paramObject)
			throws IOException;

	public abstract void rspWriterArrayByRsp(HttpServletResponse paramHttpServletResponse, List<?> paramList)
			throws IOException;

	public abstract void rspWriterByText(HttpServletResponse paramHttpServletResponse, Object paramObject)
			throws IOException;

	public abstract RspDataBo assembleRspData(ViewEnumType paramViewEnumType, Map<String, ?> paramMap);

	public abstract RspDataBo assembleRspError(ViewEnumType paramViewEnumType, Exception paramException);

	public abstract Map<String, ?> filterModel(Map<String, Object> paramMap);

	public abstract List<?> filterModelOnlyValue(Map<String, Object> paramMap);

	public abstract Map<String, String> assembleErrorBody(Exception paramException) throws IOException;
}
