/**
 *
 */
package web.common.rsp;

import java.util.Map;

/**
 *
 * @date 2018年9月14日
 */
public class RspDataBo {

	private Map<String, String> RSP_HEAD;
	private Map<String, ?> RSP_BODY;

	public void setRSP_HEAD(Map<String, String> RSP_HEAD) {
		this.RSP_HEAD = RSP_HEAD;
	}

	public void setRSP_BODY(Map<String, ?> RSP_BODY) {
		this.RSP_BODY = RSP_BODY;
	}

	@Override
	public String toString() {
		return "RspDataBo(RSP_HEAD=" + getRSP_HEAD() + ", RSP_BODY=" + getRSP_BODY() + ")";
	}

	@Override
	public boolean equals(Object o) {
		if (o == this) {
			return true;
		}
		if (!(o instanceof RspDataBo)) {
			return false;
		}
		RspDataBo other = (RspDataBo) o;
		if (!other.canEqual(this)) {
			return false;
		}
		Object this$RSP_HEAD = getRSP_HEAD();
		Object other$RSP_HEAD = other.getRSP_HEAD();
		if (this$RSP_HEAD == null ? other$RSP_HEAD != null : !this$RSP_HEAD.equals(other$RSP_HEAD)) {
			return false;
		}
		Object this$RSP_BODY = getRSP_BODY();
		Object other$RSP_BODY = other.getRSP_BODY();
		return this$RSP_BODY == null ? other$RSP_BODY == null : this$RSP_BODY.equals(other$RSP_BODY);
	}

	protected boolean canEqual(Object other) {
		return other instanceof RspDataBo;
	}

	@Override
	public int hashCode() {
		int PRIME = 59;
		int result = 1;
		Object $RSP_HEAD = getRSP_HEAD();
		result = result * 59 + ($RSP_HEAD == null ? 43 : $RSP_HEAD.hashCode());
		Object $RSP_BODY = getRSP_BODY();
		result = result * 59 + ($RSP_BODY == null ? 43 : $RSP_BODY.hashCode());
		return result;
	}

	public Map<String, String> getRSP_HEAD() {
		return this.RSP_HEAD;
	}

	public Map<String, ?> getRSP_BODY() {
		return this.RSP_BODY;
	}
}
