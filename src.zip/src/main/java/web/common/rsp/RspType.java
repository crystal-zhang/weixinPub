/**
 *
 */
package web.common.rsp;

/**
 *
 * @date 2018年9月14日
 */
public enum RspType {

	ERROR("0"), SUCCESS("1"), TIMEOUT("2");

	private String typeCode;

	private RspType(String typeCode) {
		this.typeCode = typeCode;
	}

	public String getTypeCode() {
		return this.typeCode;
	}
}
