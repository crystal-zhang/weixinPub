/**
 *
 */
package web.common.rsp;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.validation.BindingResult;

import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import net.sf.json.processors.DefaultValueProcessor;
import web.common.exception.MaxtechException;
import web.common.page.AbstractQueryCondition;
import web.common.page.PageCond;
import web.common.util.BaseBiz;
import web.common.view.ViewEnumType;

/**
 *
 * @date 2018年9月14日
 */
public class RspHandlerBizImpl extends BaseBiz implements IRspHandlerBiz {
	@Override
	public void rspWriterByJson(HttpServletResponse response, Object value) throws IOException {
		try {
			response.setContentType(ViewEnumType.JSON_VIEW.getContentType());
			write(response, value);
		} catch (IOException ex) {
			throw ex;
		}

	}

	@Override
	public RspDataBo assembleRspData(ViewEnumType viewEnumType, Map<String, ?> model) {
		RspDataBo rspDataBo = new RspDataBo();
		Map<String, String> rspHead = new HashMap();
		rspHead.put("Encoding", "UTF-8");
		rspHead.put("ContextType", viewEnumType.getContentType());
		rspHead.put("Type", RspType.SUCCESS.getTypeCode());
		rspDataBo.setRSP_HEAD(rspHead);

		Map<String, Object> rspBody = new HashMap();
		rspBody.put("Data", model);
		rspBody.put("PageCond", getPageCond(model));
		rspDataBo.setRSP_BODY(rspBody);
		return rspDataBo;
	}

	private PageCond getPageCond(Map<String, ?> model) {
		for (Object value : model.values()) {
			if ((value instanceof AbstractQueryCondition)) {
				return ((AbstractQueryCondition) value).getPageCond();
			}
		}
		return null;
	}

	@Override
	public RspDataBo assembleRspError(ViewEnumType viewEnumType, Exception exception) {
		RspDataBo rspDataBo = new RspDataBo();
		Map<String, String> rspHead = new HashMap();
		rspHead.put("Encoding", "UTF-8");
		rspHead.put("ContextType", viewEnumType.getContentType());
		rspHead.put("Type", RspType.ERROR.getTypeCode());
		rspDataBo.setRSP_HEAD(rspHead);

		Map<String, String> rspBody = null;
		try {
			rspBody = assembleErrorBody(exception);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		rspDataBo.setRSP_BODY(rspBody);
		return rspDataBo;
	}

	@Override
	public Map<String, ?> filterModel(Map<String, Object> model) {
		Map<String, Object> result = new HashMap(model.size());
		Iterator<Map.Entry<String, Object>> modelIterator = model.entrySet().iterator();
		while (modelIterator.hasNext()) {
			Map.Entry<String, Object> entry = modelIterator.next();
			if (!(entry.getValue() instanceof BindingResult)) {
				result.put(entry.getKey(), entry.getValue());
			}
		}
		return result;
	}

	@Override
	public Map<String, String> assembleErrorBody(Exception exception) throws IOException {
		Map<String, String> body = new HashMap();
		if ((exception instanceof MaxtechException)) {
			body.put("ErrorCode", ((MaxtechException) exception).getErrorCode());
			body.put("ForwardUrl", ((MaxtechException) exception).getForwardUrl());
			body.put("ErrorType", ((MaxtechException) exception).geErrorType().getTypeName());
			body.put("ErrorStackTrace", ((MaxtechException) exception).getStackTraceStr());
		}
		body.put("ErrorMessage", exception.getMessage());
		return body;
	}

	@Override
	public void rspWriterByText(HttpServletResponse response, Object value) throws IOException {
		try {
			response.setContentType(ViewEnumType.UPLOAD_VIEW.getContentType());
			write(response, value);
		} catch (IOException $ex) {
			throw $ex;
		}

	}

	private void write(HttpServletResponse response, Object value) throws IOException {
		PrintWriter out = response.getWriter();

		out.print(JSONObject.fromObject(value, initJonsConfig()).toString());
		if (null != out) {
			out.flush();
			out.close();
		}
	}

	private void writeArray(HttpServletResponse response, List<?> value) throws IOException {
		PrintWriter out = response.getWriter();
		for (Object object : value) {
			out.println(object.toString());
		}
		if (null != out) {
			out.flush();
			out.close();
		}
	}

	private JsonConfig initJonsConfig() {
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.registerJsonValueProcessor(java.util.Date.class, new JsonDateValueProcessor("yyyy-MM-dd"));
		jsonConfig.registerJsonValueProcessor(java.sql.Date.class, new JsonDateValueProcessor("yyyy-MM-dd HH:mm:ss"));
		jsonConfig.registerJsonValueProcessor(Time.class, new JsonTimeValueProcessor());
		jsonConfig.registerJsonValueProcessor(Timestamp.class, new JsonTimeValueProcessor("yyyy-MM-dd HH:mm:ss"));
		jsonConfig.registerDefaultValueProcessor(Double.class, new DefaultValueProcessor() {
			@Override
			public Object getDefaultValue(Class type) {
				return null;
			}
		});
		jsonConfig.registerDefaultValueProcessor(BigDecimal.class, new DefaultValueProcessor() {
			@Override
			public Object getDefaultValue(Class type) {
				return null;
			}
		});
		jsonConfig.registerDefaultValueProcessor(Integer.class, new DefaultValueProcessor() {
			@Override
			public Object getDefaultValue(Class type) {
				return null;
			}
		});
		jsonConfig.registerDefaultValueProcessor(Long.class, new DefaultValueProcessor() {
			@Override
			public Object getDefaultValue(Class type) {
				return null;
			}
		});
		jsonConfig.registerDefaultValueProcessor(Float.class, new DefaultValueProcessor() {
			@Override
			public Object getDefaultValue(Class type) {
				return null;
			}
		});
		return jsonConfig;
	}

	@Override
	public List<?> filterModelOnlyValue(Map<String, Object> model) {
		List<Object> list = new ArrayList();
		Iterator<Map.Entry<String, Object>> modelIterator = model.entrySet().iterator();
		while (modelIterator.hasNext()) {
			Map.Entry<String, Object> entry = modelIterator.next();
			if (!(entry.getValue() instanceof BindingResult)) {
				list.add(entry.getValue());
			}
		}
		return list;
	}

	@Override
	public void rspWriterArrayByRsp(HttpServletResponse response, List<?> value) throws IOException {
		try {
			response.setContentType(ViewEnumType.JUST_VALUE_VIEW.getContentType());
			writeArray(response, value);
		} catch (IOException ex) {
			throw ex;
		}

	}
}
