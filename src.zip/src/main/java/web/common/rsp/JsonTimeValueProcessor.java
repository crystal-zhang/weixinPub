/**
 *
 */
package web.common.rsp;

import java.sql.Time;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import net.sf.json.JsonConfig;
import net.sf.json.processors.JsonValueProcessor;

/**
 *
 * @date 2018年9月14日
 */
public class JsonTimeValueProcessor implements JsonValueProcessor {
	private String format = "HH:mm:ss";

	public JsonTimeValueProcessor() {
	}

	public JsonTimeValueProcessor(String format) {
		this.format = format;
	}

	@Override
	public Object processArrayValue(Object paramObject, JsonConfig paramJsonConfig) {
		return process(paramObject);
	}

	@Override
	public Object processObjectValue(String paramString, Object paramObject, JsonConfig paramJsonConfig) {
		return process(paramObject);
	}

	private Object process(Object value) {
		if ((value instanceof Date)) {
			SimpleDateFormat sdf = new SimpleDateFormat(this.format, Locale.CHINA);
			return sdf.format(value);
		}
		if ((value instanceof Time)) {
			SimpleDateFormat sdf = new SimpleDateFormat(this.format, Locale.CHINA);
			return sdf.format(value);
		}
		if ((value instanceof Timestamp)) {
			SimpleDateFormat sdf = new SimpleDateFormat(this.format, Locale.CHINA);
			return sdf.format(value);
		}
		return value == null ? "" : value.toString();
	}
}
