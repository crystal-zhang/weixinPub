/**
 *
 */
package web.common.view;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import web.common.rsp.IRspHandlerBiz;
import web.common.rsp.RspDataBo;

/**
 *
 * @date 2018年9月14日
 */
public class JsonView extends BaseView {
	@Autowired
	private IRspHandlerBiz rspHandlerBiz;

	/**
	 *
	 */
	@Override
	public ViewEnumType getViewType() {
		return ViewEnumType.JSON_VIEW;
	}

	/**
	 *
	 */
	@Override
	protected void renderMergedOutputModel(final Map<String, Object> model, final HttpServletRequest request,
			final HttpServletResponse response) throws Exception {
		final Map<String, ?> value = rspHandlerBiz.filterModel(model);
		final RspDataBo rspDataBo = rspHandlerBiz.assembleRspData(getViewType(), value);
		rspHandlerBiz.rspWriterByJson(response, rspDataBo);
	}

}
