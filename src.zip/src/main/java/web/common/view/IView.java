/**
 *
 */
package web.common.view;

/**
 *
 * @date 2018年9月14日
 */
public interface IView {
	/**
	 * 获取试图类型
	 * 
	 * @date 2018年9月14日
	 * @return
	 */
	ViewEnumType getViewType();
}
