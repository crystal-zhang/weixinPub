/**
 *
 */
package web.common.view;

import org.springframework.web.servlet.view.AbstractView;

/**
 *
 * @date 2018年9月14日
 */
public abstract class BaseView extends AbstractView implements IView {
	/**
	 * 构建view
	 */
	public BaseView() {
		setContentType(getViewType().getContentType());
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.rionsoft.roep.web.view.IView#getViewType()
	 */
	@Override
	public abstract ViewEnumType getViewType();
}
