/**
 *
 */
package web.common.view;

/**
 *
 * @date 2018年9月14日
 */
public enum ViewEnumType {
	/**
	 * 
	 */
	JSON_VIEW("jsonView", "application/json"),
	/**
	 *
	 */
	EXPORT_VIEW("exportView", "application/json"),
	/**
	 *
	 */
	APP_VIEW("appView", "application/json"),
	/**
	 *
	 */
	UPLOAD_VIEW("uploadView", "text/plain"),
	/**
	 *
	 */
	JUST_VALUE_VIEW("justValueView", "text/plain"),
	/**
	 *
	 */
	CALLBACK_VIEW("callbackView", "application/json"),
	/**
	 *
	 */
	APP_UPLOAD_VIEW("appUploadView", "text/plain");

	private String viewBeanName;
	private String contentType;

	private ViewEnumType(String viewBeanName, String contentType) {
		this.viewBeanName = viewBeanName;
		this.contentType = contentType;
	}

	@Override
	public String toString() {
		return this.viewBeanName;
	}

	public String getView() {
		return this.viewBeanName;
	}

	public String getContentType() {
		return this.contentType;
	}
}
