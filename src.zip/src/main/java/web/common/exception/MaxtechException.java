/**
 *
 */
package web.common.exception;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.ResourceBundleMessageSource;

import util.PropertyPlaceholderUtils;
import web.common.util.SpringBeanUtils;

/**
 *
 * @date 2018年9月14日
 */
public class MaxtechException extends RuntimeException {
	private static final long serialVersionUID = -1613644328695990831L;
	private final String errorCode;
	private final String forwardUrl;

	public MaxtechException(Enum<?> maxtechExceptionCodeEnum, boolean shouldLocale, String... params) {
		super(getErrorMessage(maxtechExceptionCodeEnum.name(), shouldLocale, params));
		this.errorCode = maxtechExceptionCodeEnum.name();
		this.forwardUrl = null;
	}

	public MaxtechException(String maxtechExceptionUrlEnum, Enum<?> maxtechExceptionCodeEnum, boolean shouldLocale,
			String... params) {
		super(getErrorMessage(maxtechExceptionCodeEnum.name(), shouldLocale, params));
		this.errorCode = maxtechExceptionCodeEnum.name();
		this.forwardUrl = maxtechExceptionUrlEnum;
	}

	public MaxtechException(String maxtechExceptionUrlEnum, Enum<?> maxtechExceptionCodeEnum, boolean shouldLocale,
			Throwable throwable, String... params) {
		super(getErrorMessage(maxtechExceptionCodeEnum.name(), shouldLocale, params), throwable);
		this.errorCode = maxtechExceptionCodeEnum.name();
		this.forwardUrl = maxtechExceptionUrlEnum;
	}

	public MaxtechException(Enum<?> maxtechExceptionCodeEnum, boolean shouldLocale, Throwable throwable,
			String... params) {
		super(getErrorMessage(maxtechExceptionCodeEnum.name(), shouldLocale, params), throwable);
		this.errorCode = maxtechExceptionCodeEnum.name();
		this.forwardUrl = null;
	}

	private static String getErrorMessage(String errorCode, boolean shouldLocale, String... params) {
		String modelMessage = null;
		if (shouldLocale) {
			ResourceBundleMessageSource messageSource = (ResourceBundleMessageSource) SpringBeanUtils
					.getBean("messageSource");
			modelMessage = messageSource.getMessage(errorCode, null, LocaleContextHolder.getLocale());
		} else {
			modelMessage = PropertyPlaceholderUtils.getContextProperty(errorCode);
		}
		if (ArrayUtils.isNotEmpty(params)) {
			for (int idx = 0; idx < params.length; idx++) {
				modelMessage = StringUtils.replace(modelMessage, "{" + idx + "}", params[idx]);
			}
		}
		return modelMessage;
	}

	public String getStackTraceStr() throws IOException {
		try {
			if (getCause() == null) {
				return null;
			}
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			getCause().printStackTrace(pw);
			String printStackTraceStr = sw.toString();
			sw.close();
			pw.close();
			return printStackTraceStr;
		} catch (IOException $ex) {
			throw $ex;
		}
	}

	public ErrorType geErrorType() {
		return ErrorType.getErrorType(StringUtils.substring(this.errorCode, 6, 8));
	}

	public String getErrorCode() {
		return this.errorCode;
	}

	public String getForwardUrl() {
		return this.forwardUrl;
	}
}
