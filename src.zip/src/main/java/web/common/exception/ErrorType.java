/**
 *
 */
package web.common.exception;

/**
 *
 * @date 2018年9月14日
 */
public enum ErrorType {

	BZ("业务级异常"), SY("系统级异常");

	private String typeName;

	private ErrorType(String typeName) {
		this.typeName = typeName;
	}

	public static ErrorType getErrorType(String errorType) {
		return valueOf(errorType.toUpperCase());
	}

	public String getTypeName() {
		return this.typeName;
	}
}
