/**
 *
 */
package web.common.page;

/**
 *
 * @date 2018年9月14日
 */
public class PageCond {
	private static final int DEFAULT_COUNT = 0;
	private static final int DEFAULT_LIMIT = 10;
	private static final int DEFAULT_START = 1;
	private int count;
	private int end;
	private int limit;
	private int start;
	private int lastStart;
	private int lastLimit;

	public void setCount(int count) {
		this.count = count;
	}

	public void setEnd(int end) {
		this.end = end;
	}

	public void setLastStart(int lastStart) {
		this.lastStart = lastStart;
	}

	public void setLastLimit(int lastLimit) {
		this.lastLimit = lastLimit;
	}

	@Override
	public boolean equals(Object o) {
		if (o == this) {
			return true;
		}
		if (!(o instanceof PageCond)) {
			return false;
		}
		PageCond other = (PageCond) o;
		if (!other.canEqual(this)) {
			return false;
		}
		if (getCount() != other.getCount()) {
			return false;
		}
		if (getEnd() != other.getEnd()) {
			return false;
		}
		if (getLimit() != other.getLimit()) {
			return false;
		}
		if (getStart() != other.getStart()) {
			return false;
		}
		if (getLastStart() != other.getLastStart()) {
			return false;
		}
		return getLastLimit() == other.getLastLimit();
	}

	protected boolean canEqual(Object other) {
		return other instanceof PageCond;
	}

	@Override
	public int hashCode() {
		int PRIME = 59;
		int result = 1;
		result = result * 59 + getCount();
		result = result * 59 + getEnd();
		result = result * 59 + getLimit();
		result = result * 59 + getStart();
		result = result * 59 + getLastStart();
		result = result * 59 + getLastLimit();
		return result;
	}

	@Override
	public String toString() {
		return "PageCond(count=" + getCount() + ", end=" + getEnd() + ", limit=" + getLimit() + ", start=" + getStart()
				+ ", lastStart=" + getLastStart() + ", lastLimit=" + getLastLimit() + ")";
	}

	public int getCount() {
		return this.count;
	}

	public int getEnd() {
		return this.end;
	}

	public int getLimit() {
		return this.limit;
	}

	public int getStart() {
		return this.start;
	}

	public int getLastStart() {
		return this.lastStart;
	}

	public int getLastLimit() {
		return this.lastLimit;
	}

	public PageCond() {
		this.start = 1;
		this.limit = 10;
		this.count = 0;
		this.end = (this.start + this.limit - 1);
	}

	public PageCond(int start, int limit) {
		this.start = start;
		this.limit = limit;
		this.end = (start + limit - 1);
	}

	public void setLimit(int limit) {
		this.limit = limit;
		setEnd(this.start + limit - 1);
	}

	public void setStart(int start) {
		this.start = start;
		setEnd(start + this.limit - 1);
	}
}
