/**
 *
 */
package web.common.page;

/**
 *
 * @date 2018年9月14日
 */
public class Auth {
	private String viewName;
	private int rid;
	private String targetColumn;
	private String targetCode;
	private String month;

	public void setViewName(String viewName) {
		this.viewName = viewName;
	}

	public void setRid(int rid) {
		this.rid = rid;
	}

	public void setTargetColumn(String targetColumn) {
		this.targetColumn = targetColumn;
	}

	public void setTargetCode(String targetCode) {
		this.targetCode = targetCode;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	@Override
	public boolean equals(Object o) {
		if (o == this) {
			return true;
		}
		if (!(o instanceof Auth)) {
			return false;
		}
		Auth other = (Auth) o;
		if (!other.canEqual(this)) {
			return false;
		}
		Object this$viewName = getViewName();
		Object other$viewName = other.getViewName();
		if (this$viewName == null ? other$viewName != null : !this$viewName.equals(other$viewName)) {
			return false;
		}
		if (getRid() != other.getRid()) {
			return false;
		}
		Object this$targetColumn = getTargetColumn();
		Object other$targetColumn = other.getTargetColumn();
		if (this$targetColumn == null ? other$targetColumn != null : !this$targetColumn.equals(other$targetColumn)) {
			return false;
		}
		Object this$targetCode = getTargetCode();
		Object other$targetCode = other.getTargetCode();
		if (this$targetCode == null ? other$targetCode != null : !this$targetCode.equals(other$targetCode)) {
			return false;
		}
		Object this$month = getMonth();
		Object other$month = other.getMonth();
		return this$month == null ? other$month == null : this$month.equals(other$month);
	}

	protected boolean canEqual(Object other) {
		return other instanceof Auth;
	}

	@Override
	public int hashCode() {
		int PRIME = 59;
		int result = 1;
		Object $viewName = getViewName();
		result = result * 59 + ($viewName == null ? 43 : $viewName.hashCode());
		result = result * 59 + getRid();
		Object $targetColumn = getTargetColumn();
		result = result * 59 + ($targetColumn == null ? 43 : $targetColumn.hashCode());
		Object $targetCode = getTargetCode();
		result = result * 59 + ($targetCode == null ? 43 : $targetCode.hashCode());
		Object $month = getMonth();
		result = result * 59 + ($month == null ? 43 : $month.hashCode());
		return result;
	}

	@Override
	public String toString() {
		return "Auth(viewName=" + getViewName() + ", rid=" + getRid() + ", targetColumn=" + getTargetColumn()
				+ ", targetCode=" + getTargetCode() + ", month=" + getMonth() + ")";
	}

	public String getViewName() {
		return this.viewName;
	}

	public int getRid() {
		return this.rid;
	}

	public String getTargetColumn() {
		return this.targetColumn;
	}

	public String getTargetCode() {
		return this.targetCode;
	}

	public String getMonth() {
		return this.month;
	}

	public Auth(String viewName, int rid, String month, String targetColumn, String targetCode) {
		this.viewName = viewName;
		this.rid = rid;
		this.month = month;
		this.targetColumn = targetColumn;
		this.targetCode = targetCode;
	}

	Auth() {
	}
}
