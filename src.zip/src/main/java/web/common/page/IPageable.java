/**
 *
 */
package web.common.page;

/**
 *
 * @date 2018年9月14日
 */
public interface IPageable {
	public abstract PageCond extractPageCondition();

	public abstract Auth extractAuth();
}
