/**
 *
 */
package web.common.page;

/**
 *
 * @date 2018年9月14日
 */
public abstract class AbstractQueryCondition implements IPageable {
	protected PageCond pageCond;
	protected Auth auth;

	public void setPageCond(PageCond pageCond) {
		this.pageCond = pageCond;
	}

	public void setAuth(Auth auth) {
		this.auth = auth;
	}

	@Override
	public String toString() {
		return "AbstractQueryCondition(pageCond=" + getPageCond() + ", auth=" + getAuth() + ")";
	}

	@Override
	public boolean equals(Object o) {
		if (o == this) {
			return true;
		}
		if (!(o instanceof AbstractQueryCondition)) {
			return false;
		}
		AbstractQueryCondition other = (AbstractQueryCondition) o;
		if (!other.canEqual(this)) {
			return false;
		}
		Object this$pageCond = getPageCond();
		Object other$pageCond = other.getPageCond();
		if (this$pageCond == null ? other$pageCond != null : !this$pageCond.equals(other$pageCond)) {
			return false;
		}
		Object this$auth = getAuth();
		Object other$auth = other.getAuth();
		return this$auth == null ? other$auth == null : this$auth.equals(other$auth);
	}

	protected boolean canEqual(Object other) {
		return other instanceof AbstractQueryCondition;
	}

	@Override
	public int hashCode() {
		int PRIME = 59;
		int result = 1;
		Object $pageCond = getPageCond();
		result = result * 59 + ($pageCond == null ? 43 : $pageCond.hashCode());
		Object $auth = getAuth();
		result = result * 59 + ($auth == null ? 43 : $auth.hashCode());
		return result;
	}

	public PageCond getPageCond() {
		return this.pageCond;
	}

	public Auth getAuth() {
		return this.auth;
	}

	@Override
	public PageCond extractPageCondition() {
		return this.pageCond;
	}

	@Override
	public Auth extractAuth() {
		return this.auth;
	}
}
