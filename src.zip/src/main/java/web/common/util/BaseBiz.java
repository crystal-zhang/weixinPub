/**
 *
 */
package web.common.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import web.common.baseEntry.ApiBo;
import web.common.baseEntry.IEntry;
import web.common.baseEntry.IListEntry;

/**
 *
 * @date 2018年9月14日
 */
public class BaseBiz {
	@Autowired
	private Mapper mapper;

	protected <T extends IEntry, S extends ApiBo> List<T> mapToEntryList(List<S> sourceList, Class<T> targetInfo) {
		Assert.notNull(sourceList, "不能使用空数据源进行映射");

		List<T> targetList = new ArrayList();
		for (S iEntry : sourceList) {
			targetList.add(this.mapper.map(iEntry, targetInfo));
		}
		return targetList;
	}

	protected <T extends ApiBo, S extends IEntry> List<T> map(List<S> sourceList, Class<T> targetInfo) {
		Assert.notNull(sourceList, "不能使用空数据源进行映射");

		List<T> targetList = new ArrayList();
		for (S iEntry : sourceList) {
			targetList.add(this.mapper.map(iEntry, targetInfo));
		}
		return targetList;
	}

	protected <T extends ApiBo, S extends IListEntry> List<T> mapListEntry(List<S> sourceList, Class<T> targetInfo) {
		Assert.notNull(sourceList, "不能使用空数据源进行映射");

		List<T> targetList = new ArrayList();
		for (S iEntry : sourceList) {
			targetList.add(this.mapper.map(iEntry, targetInfo));
		}
		return targetList;
	}

	protected <T extends ApiBo, S extends Map<String, ?>> List<T> dozerMap(List<S> sourceList, Class<T> targetInfo) {
		Assert.notNull(sourceList, "不能使用空数据源进行映射");

		List<T> targetList = new ArrayList();
		for (S sMap : sourceList) {
			targetList.add(this.mapper.map(sMap, targetInfo));
		}
		return targetList;
	}

	protected <T extends ApiBo, S extends Map<String, ?>> T dozerMap(S sourceEntry, Class<T> targetInfo) {
		Assert.notNull(sourceEntry, "映射的实体对象不能为空");
		return this.mapper.map(sourceEntry, targetInfo);
	}

	protected <T extends ApiBo, S extends IEntry> T map(S sourceEntry, Class<T> targetBoClass) {
		Assert.notNull(sourceEntry, "映射的实体对象不能为空");
		return this.mapper.map(sourceEntry, targetBoClass);
	}

	protected <T extends ApiBo, S extends IListEntry> T map(S sourceEntry, Class<T> targetBoClass) {
		Assert.notNull(sourceEntry, "映射的实体对象不能为空");
		return this.mapper.map(sourceEntry, targetBoClass);
	}

	protected <T extends ApiBo, S extends IEntry> S map(T sourceBo, Class<S> targetEntryClass) {
		Assert.notNull(sourceBo, "映射的实体对象不能为空");
		return this.mapper.map(sourceBo, targetEntryClass);
	}
}
