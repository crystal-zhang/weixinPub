/**
 *
 */
package web.common.util;

import java.lang.annotation.Annotation;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 *
 * @date 2018年9月14日
 */

public class SpringBeanUtils implements ApplicationContextAware {
	private static ApplicationContext context;

	/**
	 * {@link ApplicationContext#getBean(Class)} 获取spring beans
	 *
	 * @param <T>
	 *            T
	 *
	 * @param requiredType
	 *            bean类型
	 * @return 对应的bean
	 *
	 */
	public static <T> T getBean(final Class<T> requiredType) {
		return context.getBean(requiredType);
	}

	/**
	 * {@link ApplicationContext#getBean(Class)} 获取spring beans
	 *
	 * @param <T>
	 *            T
	 *
	 * @param beanName
	 *            beanName
	 * @return 对应的bean
	 *
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getBean(final String beanName) {
		return (T) context.getBean(beanName);
	}

	/**
	 *
	 * @param <T>
	 *            实体
	 *
	 * @param beanName
	 *            beanName
	 * @param requiredType
	 *            bean类型
	 * @return 符合条件的bean
	 */
	public static <T> T getBean(final String beanName, final Class<T> requiredType) {
		return context.getBean(beanName, requiredType);
	}

	/**
	 * {@link ApplicationContext#getBean(Class)} 获取spring beans
	 *
	 * @param <T>
	 *            T
	 *
	 * @param requiredType
	 *            bean类型
	 * @return 对应的bean
	 *
	 */
	public static <T> Map<String, T> getBeans(final Class<T> requiredType) {
		return context.getBeansOfType(requiredType);
	}

	/**
	 * 从annotation提取bean清单
	 *
	 * @param annotationType
	 *            annotation类型
	 * @return 标注了该annotation的beans
	 */
	public static Map<String, Object> getBeansWithAnnotation(final Class<? extends Annotation> annotationType) {
		return context.getBeansWithAnnotation(annotationType);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.springframework.context.ApplicationContextAware#setApplicationContext
	 * (org.springframework.context.ApplicationContext)
	 */
	@Override
	public void setApplicationContext(final ApplicationContext applicationContext) {
		context = applicationContext;
	}

}
