/**
 * 
 */
package web.common.baseEntry;

/**
 * 
 * @date 2018年9月14日
 */
public interface ApiBo {

}
