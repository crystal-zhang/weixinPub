/**
 * 
 */
$(function(){
	$('#example').DataTable({
       "paging":   false,
//        "ordering": false,
//        "info":     false,
        "language": {
            "lengthMenu": "Display _MENU_ records per page",
            "zeroRecords": "没有查到数据!",
            "info": "第 _PAGE_ 页，共 _PAGES_页",
            "infoEmpty": "No records available",
            "infoFiltered": "(filtered from _MAX_ total records)"
        },
        "ajax": 'querySysConfigList.do',
        columns: [
            { data: 'sysKey' },
            { data: 'sysValue' },
            { data: 'sysComment' },
            { data: 'createTime' },
            { data: 'modifyTime' }
        ]
    });
        });