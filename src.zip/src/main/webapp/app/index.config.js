(function() {
    'use strict';

    angular
        .module('app')
        .service('CONFIG', CONFIG);

    /** @ngInject */
    CONFIG.$inject = ['$rootScope'];

    // 基础配置
    function CONFIG($rootScope) {
        // 系统版本号
        this.VERSION = '3.1.0';

        // user agent判断是否微信内置浏览器
        var ua = navigator.userAgent.toLowerCase();
        if (ua.match(/MicroMessenger/i) == 'micromessenger') {
             this.SALE_CHANNEL = $rootScope.SALE_CHANNEL = '811';
             this.WECHAT = $rootScope.WECHAT = true;
        } else {
            this.SALE_CHANNEL = $rootScope.SALE_CHANNEL = '812';
            this.HLIFE = $rootScope.HLIFE = true;
            $rootScope.TITLEBAR = true;
        }

        this.NEW_SALE_CHANNEL = this.SALE_CHANNEL;

        // 请求超时时间设定60秒
        this.REQUEST_TIMEOUT = 60 * 1000;

        // 用户登录超时设定
        this.LOGIN_TIMEOUT = 30 * 60 * 1000;

        // 提示信息延时时间3s
        this.TIPS_DURATION = 3 * 1000;

        //微信生产环境开关
        this.wxSwitch = true;
        // 服务域名
         this.DOMAIN = 'http://localhost:8080/elife_wx/'; // 微信营销推广

        // 核心接口解耦
        this.CORE_DECOUPLING = true;
        // 核心接口解耦间隔时间
        this.CORE_DECOUPLING_DURATION = 10 * 1000;
        // 核心接口解耦间隔次数
        this.CORE_DECOUPLING_TIMES = 6;
        // 推送电子保单解耦间隔时间
        this.PUSH_EPOLICY_DURANTION = 3*1000;
        // 推送电子保单解耦间隔次数
        this.PUSH_EPOLICY_TIMES = 10;
        // 保费计算接口解耦间隔时间
        this.CALCEXP_DECOUPLING_DURATION = 300;
        // 保费计算接口解耦间隔次数
        this.CALCEXP_DECOUPLING_TIMES = 5;
        // 团险核心接口解耦间隔时间
        this.GROUP_CORE_DECOUPLING_DURATION = 3 * 1000;
        // 团险核心接口解耦间隔次数
        this.GROUP_CORE_DECOUPLING_TIMES = 20;

        // 轮播图查询
        this.QUERY_BANNER_LIST = {
            url: this.DOMAIN + 'queryBannerList.json',
            method: 'POST'
        };
          
        
      
        /**
         ** 需要前端缓存的接口
         ** url 访问地址
         ** sessionName 缓存前缀
         ** requestCode 请求区分的字段,多个字段用','分隔
         **/
        this.SESSION_LIST = [];
    }

})();