/*
 ** COMMON 全局共用数据
 **
 ** Created By Cheney Hu (cheney@gmail.com) 2016/06/24
 */

(function() {
    'use strict';

    angular
        .module('app')
        .service('COMMON', COMMON);

    COMMON.$inject = ['CommonRequest', 'CONFIG', '$ionicModal', '$rootScope'];

    /** @ngInject */
    function COMMON(CommonRequest, CONFIG, $ionicModal, $rootScope) {
        // 获取共用数据
        this.getCommonData = function() {
            return {
                //故障类型
                'TROUBLE_TYPES': [{
                    label: '支付失败',
                    value: 'P'
                }],
                // 证件类型
                'ID_TYPES': [{
                    label: '身份证',
                    value: 'A'
                }, {
                    label: '护照',
                    value: 'I'
                }, {
                    label: '港澳台通行证',
                    value: 'G'
                },{
                    label: '外国人永久居留身份证',
                    value: 'N'
                }],
                // 国籍
                'NATIONALITIES': [{
                    label: '中国',
                    value: '0156'
                }, {
                    label: '中国香港',
                    value: '0344'
                }, {
                    label: '中国台湾',
                    value: '0158'
                }, {
                    label: '中国澳门',
                    value: '0446'
                }, {
                    label: '其它地区',
                    value: '0999'
                }],
                // 银行代码
                'BANK_CODE': [{
                    label: '建设银行',
                    value: '0000051'
                }, {
                    label: '工商银行',
                    value: '0000021'
                }, {
                    label: '农业银行',
                    value: '0000031'
                }, {
                    label: '中国银行',
                    value: '0000041'
                }, {
                    label: '交通银行',
                    value: '0000061'
                }, {
                    label: '中信银行',
                    value: '0000081'
                }, {
                    label: '招商银行',
                    value: '0000091'
                }, {
                    label: '中国邮政储蓄银行',
                    value: '0000341'
                }],
                // 职业代码
                'OCCUPATION_CODE': [{
                     label:'其他从业人员',
                    value:'Y0000'
                }, {
                    label: '国家机关、党群组织、企业、事业单位负责人',
                    value: 'A0000'
                }, {
                    label: '专业技术人员',
                    value: 'B0000'
                }, {
                    label: '办事人员和有关人员',
                    value: 'C0000'
                }, {
                    label: '商业、服务业人员',
                    value: 'D0000'
                }, {
                    label: '农、林、牧、渔、水利业生产人员',
                    value: 'E0000'
                }, {
                    label: '生产、运输设备操作人员及有关人员',
                    value: 'F0000'
                }],
                // 证件有效期
                'ID_EXPIRES': [{
                    label: '长期有效',
                    value: '1'
                }, {
                    label: '有效期',
                    value: '2'
                }],
                // 性别
                'GENDERS': [{
                    label: '男',
                    value: '1'
                }, {
                    label: '女',
                    value: '2'
                }],
                // 关系
                'RELATIONS': [{
                    label: '本人',
                    value: '01'
                // }, {
                //     label: '丈夫',
                //     value: '02'
                // }, {
                //     label: '妻子',
                //     value: '03'
                // }, {
                //     label: '父亲',
                //     value: '04'
                // }, {
                //     label: '母亲',
                //     value: '05'
                }, {
                    label: '儿子',
                    value: '06'
                }, {
                    label: '女儿',
                    value: '07'
                }],
                // 缴费方式
                'PAYMENTS': [{
                    label: '不定期交',
                    value: -1
                }, {
                    label: '趸交',
                    value: 0
                }, {
                    label: '月交',
                    value: 1
                }, {
                    label: '季交',
                    value: 3
                }, {
                    label: '半年交',
                    value: 6
                }, {
                    label: '年交',
                    value: 12
                }, {
                    label: '交至某确定年龄',
                    value: 98
                }, {
                    label: '终生交费',
                    value: 99
                }],
                // 支付方式
                'PAYWAYS': [{
                    label: '通联支付',
                    value: '01'
                }, {
                    label: '建行网银',
                    value: '02'
                }, {
                    label: '微信',
                    value: '03'
                }, {
                    label: '授权转账',
                    value: '109'
                }],
                // 账户建立日
                'ACCOUNT_ESTANLISH': [{
                    label: '生效后立即建立',
                    value: 1
                }, {
                    label: '犹豫期后建立',
                    value: 2
                }],
                // 具体地区
                'DISTRICT': [{
                    label: '城镇',
                    value: '0'
                }, {
                    label: '农村',
                    value: '1'
                }],
                // 争议的处理方式
                'DISPUTESHANGING': [{
                    label: '诉讼向被告住所地的人民法院起诉',
                    value: 1
                }, {
                    label: '提交仲裁委员会仲裁',
                    value: 2
                }],
                //解除合同原因
                'WITHDRAW': [{
                    label: '缴费压力大',
                    value: 1
                }, {
                    label: '急需用钱',
                    value: 2
                }, {
                    label: '保障不满意',
                    value: 3
                }, {
                    label: '收益不满意',
                    value: 4
                }, {
                    label: '对代理人服务不满意',
                    value: 5
                }, {
                    label: '对公司服务不满意',
                    value: 6
                }, {
                    label: '家人不支持',
                    value: 7
                }, {
                    label: '其它',
                    value: 8
                }],
                // 订单状态
                // 1-草稿;5-资料审核中;10-待核保;11-提交核保中;12-核保通过;13-待人工审核；14-人工审核中；15-核保不通过；16-自核不通过待资料上传;21-支付中;22-支付成功;23-支付失败;31-承保中;32-承保成功;33-承保失败;41-订单失效;42-订单取消
                'ORDER_STATUS': [{
                    label: '草稿',
                    value: 1
                }, {
                    label: '资料审核中',
                    value: 5
                }, {
                    label: '待核保',
                    value: 10
                }, {
                    label: '提交核保中',
                    value: 11
                }, {
                    label: '核保通过',
                    value: 12
                }, {
                    label: '待人工审核',
                    value: 13
                }, {
                    label: '人工审核中',
                    value: 14
                }, {
                    label: '核保不通过',
                    value: 15
                // }, {
                //     label: '核保不通过', // 暂时处理
                //     value: 16
                }, {
                    label: '自核不通过待资料上传',
                    value: 16
                }, {
                    label: '支付中',
                    value: 21
                }, {
                    label: '支付成功',
                    value: 22
                }, {
                    label: '支付失败',
                    value: 23
                }, {
                    label: '承保中',
                    value: 31
                }, {
                    label: '承保成功',
                    value: 32
                }, {
                    label: '承保失败',
                    value: 33
                }, {
                    label: '订单失效',
                    value: 41
                }, {
                    label: '订单取消',
                    value: 42
                }, {
                    label: '核保已完成',
                    value: 110
                }, {
                    label: '待人工核保',
                    value: 111
                }, {
                    label: '不需人工核保',
                    value: 112
                }],
                // 支付状态
                // 1-支付中;2-支付成功;3-支付失败
                'PAY_STATUS': [{
                    label: '支付中',
                    value: 1
                }, {
                    label: '支付成功',
                    value: 2
                }, {
                    label: '支付失败',
                    value: 3
                }],
                // 红利领取方式 1-现金 2-抵缴保费 3-累积生息
                'BENEFIT_ACCOUNT': [{
                    label: '现金',
                    value: 1
                }, {
                    label: '抵缴保费',
                    value: 2
                }, {
                    label: '累积生息',
                    value: 4
                }],
                // 保全变更状态
                'POLICY_QUERY': [{
                    label: '变更申请',
                    value: '1'
                }, {
                    label: '受理中',
                    value: '2'
                }, {
                    label: '受理失败',
                    value: '3'
                }, {
                    label: '受理成功',
                    value: '4'
                }, {
                    label: '受理成功转账中',
                    value: '5'
                }, {
                    label: '转账成功',
                    value: '6'
                }, {
                    label: '转账失败',
                    value: '7'
                }],
                // 理赔销售渠道
                'SALA_CHANNAL': [{
                    label: '代理人营销',
                    value: '1'
                }, {
                    label: '团体代理',
                    value: '2'
                }, {
                    label: '银行代理',
                    value: '3'
                }, {
                    label: '经纪代理',
                    value: '7'
                }, {
                    label: '网络销售',
                    value: '8'
                }, {
                    label: '高端代理',
                    value: '9'
                }, {
                    label: '经代业务',
                    value: 'A'
                }, {
                    label: '银保业务',
                    value: 'B'
                }, {
                    label: '个人业务',
                    value: 'P'
                }, {
                    label: '电销业务',
                    value: 'T'
                }],
                // 理赔类型
                'CLAIMS_TYPE': [{
                    label: '意外医疗',
                    value: '100'
                }, {
                    label: '意外伤残',
                    value: '101'
                }, {
                    label: '意外死亡',
                    value: '102'
                }, {
                    label: '意外高残',
                    value: '103'
                }, {
                    label: '意外大病',
                    value: '104'
                }, {
                    label: '意外特种疾病',
                    value: '105'
                }, {
                    label: '意外失业失能',
                    value: '106'
                }, {
                    label: '意外生命末期',
                    value: '107'
                }, {
                    label: '意外豁免',
                    value: '109'
                }, {
                    label: '疾病医疗',
                    value: '200'
                }, {
                    label: '疾病伤残',
                    value: '201'
                }, {
                    label: '疾病死亡',
                    value: '202'
                }, {
                    label: '疾病高残',
                    value: '203'
                }, {
                    label: '疾病大病',
                    value: '204'
                }, {
                    label: '疾病特种疾病',
                    value: '205'
                }, {
                    label: '疾病失业失能',
                    value: '206'
                }, {
                    label: '疾病生命末期',
                    value: '207'
                }, {
                    label: '疾病豁免',
                    value: '209'
                }],
                // 受益人类别
                'BENEFIT_CUST_TYPE': [{
                    label: '生存金',
                    value: '0'
                }, {
                    label: '身故金',
                    value: '1'
                }, {
                    label: '红利金',
                    value: '2'
                }, {
                    label: '满期金',
                    value: '3'
                }, {
                    label: '年金',
                    value: '5'
                }, {
                    label: '贺喜金',
                    value: '6'
                }],
                // 渠道过滤
                'CHANNAL_CODE': [{
                    label: '官网',
                    value: '800'
                }, {
                    label: '网销手工单',
                    value: '801'
                }, {
                    label: '建行网银',
                    value: '802'
                }, {
                    label: '建行手机银行',
                    value: '803'
                }, {
                    label: '建行自助终端',
                    value: '804'
                }, {
                    label: '导入件',
                    value: '805'
                }, {
                    label: '悦生活',
                    value: '808'
                }, {
                    label: '微信',
                    value: '811'
                }, {
                    label: '手机悦生活',
                    value: '812'
                }, {
                    label: '建信人寿手机APP',
                    value: '813'
                }, {
                    label: '招财宝',
                    value: '814'
                }, {
                    label: '代理人营销',
                    value: '1'
                }, {
                    label: '电销B通道',
                    value: '12'
                }, {
                    label: '电销业务',
                    value: 'T'
                }, {
                    label: '高端代理',
                    value: '9'
                }, {
                    label: '个人业务',
                    value: 'P'
                }, {
                    label: '经代业务',
                    value: 'A'
                }, {
                    label: '经纪代理',
                    value: '7'
                }, {
                    label: '团体代理',
                    value: '2'
                }, {
                    label: '网络销售',
                    value: '8'
                }, {
                    label: '银保业务',
                    value: 'B'
                }, {
                    label: '银行代理',
                    value: '3'
                }],
                // 保全变更类型
                'POLICYCHANGE_TYPE': [{
                    label: '联系方式变更',
                    value: 'CD'
                }, {
                    label: '续期银行账号变更',
                    value: 'PC'
                }, {
                    label: '给付授权账号变更',
                    value: 'GC'
                }, {
                    label: '保期逾期未付选择变更',
                    value: 'AP'
                }, {
                    label: '红利选择权变更',
                    value: 'BM'
                }, {
                    label: '定时定额追加保险费',
                    value: 'FP'
                }, {
                    label: '投连账户转换',
                    value: 'TI'
                }, {
                    label: '投资比例变更',
                    value: 'PA'
                }, {
                    label: '退保',
                    value: 'CT'
                }, {
                    label: '撤单',
                    value: 'WXCD'
                }, {
                    label: '不同意续保变更',
                    value: 'BX'
                }, {
                    label: '保单质押贷款',
                    value: 'LN'
                }, {
                    label: '客户证件信息变更',
                    value: 'CM'
                }, {
                    label: '增补告知',
                    value: 'HI'
                }, {
                    label: '客户信息授权变更',
                    value: 'CA'
                }, {
                    label: '万能险部分领取',
                    value: 'OP'
                }, {
                    label: '增加保额',
                    value: 'AA'
                }, {
                    label: '万能险追加保费',
                    value: 'AM'
                }, {
                    label: '特殊复效',
                    value: 'SR'
                }, {
                    label: '恢复交费',
                    value: 'HJ'
                }, {
                    label: '争议处理方式变更',
                    value: 'DC'
                }, {
                    label: '保险费溢缴转下期的选择变更',
                    value: 'ON'
                }, {
                    label: '复缴',
                    value: 'TR'
                }, {
                    label: '新增附加险',
                    value: 'NS'
                }, {
                    label: '复效',
                    value: 'RE'
                }, {
                    label: '减额付清',
                    value: 'PU'
                }, {
                    label: '保单还款',
                    value: 'RF'
                }, {
                    label: '保险费缴付方式变更',
                    value: 'FQ'
                }, {
                    label: '缴费年期变更',
                    value: 'FT'
                }, {
                    label: '险种变更',
                    value: 'RC'
                }, {
                    label: '公司解约',
                    value: 'EA'
                }, {
                    label: '投保人职业变更',
                    value: 'AO'
                }, {
                    label: '投保人变更',
                    value: 'AE'
                }, {
                    label: '受益人变更',
                    value: 'BC'
                }, {
                    label: '被保人职业变更',
                    value: 'IO'
                }, {
                    label: '补发保单',
                    value: 'LR'
                }, {
                    label: '减少保额',
                    value: 'PT'
                }, {
                    label: '协议退保',
                    value: 'XT'
                }, {
                    label: '签名变更',
                    value: 'PS'
                }, {
                    label: '投连险部分领取',
                    value: 'AR'
                }, {
                    label: '投连险追加保费',
                    value: 'IP'
                }, {
                    label: '计划别变更',
                    value: 'CL'
                }, {
                    label: '年金领取方式变更',
                    value: 'YG'
                }, {
                    label: '自垫回退',
                    value: 'BA'
                }, {
                    label: '税延离职转保留',
                    value: 'LB'
                }, {
                    label: '税延提前领取',
                    value: 'TL'
                }, {
                    label: '保单移出',
                    value: 'SO'
                }, {
                    label: '税延险种变更',
                    value: 'XC'
                }, {
                    label: '保险金领取',
                    value: 'LQ'
                }, {
                    label: '保险金领取方式变更',
                    value: 'LC'
                }, {
                    label: '稅延犹豫期退保',
                    value: 'ST'
                }, {
                    label: '投保单位信息变更',
                    value: 'TN'
                }, {
                    label: '保全强制撤销',
                    value: 'ZY'
                }, {
                    label: '单位信息变更',
                    value: 'UC'
                }, {
                    label: '冻结保单',
                    value: 'DJ  '
                }, {
                    label: '给付审核',
                    value: 'LA'
                }, {
                    label: '客户信息授权变更',
                    value: 'CA'
                }, {
                    label: '身份证号批量升级',
                    value: 'SJ'
                }],
                'CLAIMS_ANS': [{
                    label: '给付',
                    value: '0'
                }, {
                    label: '拒付',
                    value: '1'
                }, {
                    label: '暂缓处理',
                    value: '3'
                }],
                'CLAIMS_MAIN_STATUS': [{
                    label: '申请',
                    value: '2'
                }, {
                    label: '审核中',
                    value: '1'
                }, {
                    label: '结案',
                    value: '0'
                }],
                'CLAIMS_DETAIL_STATUS': [{
                    label: '赔付',
                    value: '0'
                }, {
                    label: '拒付',
                    value: '1'
                }, {
                    label: '暂缓处理',
                    value: '3'
                }, {
                    label: '撤件',
                    value: '2'
                }],
                // 查询订单
                'CHECK_ORDER_BY_DAY': [{
                    label: '全部',
                    value: '0'
                }, {
                    label: '一周内',
                    value: '7'
                }, {
                    label: '近一个月',
                    value: '30'
                }, {
                    label: '近三个月',
                    value: '90'
                }, {
                    label: '一年内',
                    value: '365'
                }],
                'POLICY_DETAIL_STATUS': [{
                    label: '有效-缴费期内',
                    value: '101'
                }, {
                    label: '有效-缴费期满',
                    value: '102'
                }, {
                    label: '有效-APL垫满',
                    value: '103'
                }, {
                    label: '有效-APL中',
                    value: '104'
                }, {
                    label: '有效-减额交清',
                    value: '105'
                }, {
                    label: '有效-保费豁免',
                    value: '106'
                }, {
                    label: '有效-生命末期',
                    value: '107'
                }, {
                    label: '有效-自动缓交',
                    value: '108'
                }, {
                    label: '有效-离职转保留',
                    value: '109'
                }, {
                    label: '有效-银行质押贷款',
                    value: '110'
                }, {
                    label: '停效-未经APL停效',
                    value: '201'
                }, {
                    label: '停效-APL结束停效',
                    value: '202'
                }, {
                    label: '停效-中断APL停效',
                    value: '203'
                }, {
                    label: '停效-贷款停效',
                    value: '204'
                }, {
                    label: '终止-理赔(死亡)',
                    value: '301'
                }, {
                    label: '终止-理赔(全残)',
                    value: '302'
                }, {
                    label: '终止-理赔(重疾)',
                    value: '303'
                }, {
                    label: '终止-理赔(生命末期)',
                    value: '304'
                }, {
                    label: '终止-满期',
                    value: '305'
                }, {
                    label: '终止-客户退保',
                    value: '306'
                }, {
                    label: '终止-公司解约',
                    value: '307'
                }, {
                    label: '终止-失效终止',
                    value: '308'
                }, {
                    label: '终止-提前领取',
                    value: '309'
                }, {
                    label: '终止—保单移出',
                    value: '310'
                }, {
                    label: '无效-拒绝投保',
                    value: '401'
                }, {
                    label: '无效-延期投保',
                    value: '402'
                }, {
                    label: '无效-取消投保',
                    value: '403'
                }, {
                    label: '无效-犹豫期退保',
                    value: '404'
                }, {
                    label: '无效-当日撤单',
                    value: '405'
                }],
                'CLAIMS_REASON_STATUS': [{
                    label: '意外',
                    value: '1'
                }, {
                    label: '疾病',
                    value: '2'
                }],
                //配偶或子女
                'Mate_Child':[{
                    label:'配偶',
                    value:'03'
                },{
                    label:'儿子',
                    value:'06'
                },{
                    label:'女儿',
                    value:'07'
                }],
                //有无社保医疗
                'SOCIAL_STATUS':[{
                    label:'有',
                    value:'1'
                },{
                    label:'无',
                    value:'2'
                }]
            };
        };

        // 根据证件类型获取国籍选项
        this.getNationalitiesByCertType = function(certType) {
            var self = this;

            var commonNationalities = self.getCommonData().NATIONALITIES,
                nationalities = [];
            for (var i = 0; i < commonNationalities.length; i++) {
                if (certType == 'A') {
                    nationalities = self.getNationalitiesByCode('0156');
                    break;
                } else if (certType == 'I'||certType == 'N') {
                    nationalities = self.getNationalitiesByCode('0999');
                    break;
                } else if (certType == 'G') {
                    nationalities = self.getNationalitiesByCode('0344');
                    break;
                }
            }

            return nationalities;
        };
        // 根据国籍代码获取国籍数据
        this.getNationalitiesByCode = function(code) {
            var self = this;

            var commonNationalities = self.getCommonData().NATIONALITIES,
                nationalities = [];
            for (var i = 0; i < commonNationalities.length; i++) {
                var nationality = commonNationalities[i];
                if (code == '0344') {
                    if (nationality.value == '0344' || nationality.value == '0158' || nationality.value == '0446') {
                        nationalities.push(nationality);
                    }
                } else if (code == nationality.value) {
                    nationalities.push(nationality);
                    break;
                }
            }

            return nationalities;
        };

        // 根据国籍代码获取证件类型数据
        this.getCertTypesByNationality = function(nationality) {
            var certTypes = [];
            if (!nationality) {
                certTypes = this.getCommonData().ID_TYPES;
            }

            if (nationality == '0156') {
                certTypes = [{
                    label: '身份证',
                    value: 'A'
                }];
            } else if (nationality == '0999') {
                certTypes = [{
                    label: '护照',
                    value: 'I'
                },{
                    label: '外国人永久居留身份证',
                    value: 'N'
                }];
            } else {
                certTypes = [{
                    label: '港澳台通行证',
                    value: 'G'
                }];
            }

            return certTypes;
        };

        // 根据证件类型代码获取证件类型数据
        this.getCertTypesByCode = function(code) {
            var self = this;

            var commonCertTypes = self.getCommonData().ID_TYPES,
                certTypes = [];
            for (var i = 0; i < commonCertTypes.length; i++) {
                var certType = commonCertTypes[i];
                if (code == certType.value) {
                    certTypes.push(certType);
                    break;
                }
            }

            return certTypes;
        };

        // 获取银行列表
        this.getCommonBank = function(comCode, bankAccountType, callback) {
            var params = {
                comCode: comCode,
                bankAccountType: bankAccountType
            };
            var config = {
                    url: '../statics/product/banks/'+comCode+'_'+bankAccountType+'.json',
                    method: 'GET'
            };
            CommonRequest.request(params, config, function(result) {
                // if (result.status == 1) {
                    var data = result;
                    if (data && data.length > 0) {
                        angular.isFunction(callback) && callback(result);
                    }

                // }
            });
        };

        // 获取码表内容
        this.getDictInfo = function(typeCode, callback) {
            var params = {
                typeCode: typeCode
            };
            if (typeCode == 'country') {
                CommonRequest.request(params, CONFIG.GET_DICT_COUNTRY_SERVICE, function(result) {
                    if (result.status == 1) {
                        var data = result.data,
                            distData = [];
                        if (data && data.length > 0) {
                            for (var i = data.length - 1; i >= 0; i--) {
                                var item = data[i];
                                distData.push({
                                    label: item.dictName,
                                    value: item.dictCode
                                });
                            }
                        }
                        angular.isFunction(callback) && callback(distData);
                    }
                });
            } else if (typeCode == 'occupations') {
                CommonRequest.request(params, CONFIG.GET_DICT_OCCUPATIONS_SERVICE, function(result) {
                    if (result.status == 1) {
                        var data = result.data,
                            distData = [];
                        if (data && data.length > 0) {
                            for (var i = data.length - 1; i >= 0; i--) {
                                var item = data[i];
                                distData.push({
                                    label: item.dictName,
                                    value: item.dictCode
                                });
                            }
                        }
                        angular.isFunction(callback) && callback(distData);
                    }
                });
            }
        };

        // 显示模态框
        this.showModal = function(url, animation) {
            var self = this;

            $ionicModal.fromTemplateUrl(url, {
                scope: $rootScope,
                animation: animation || 'slide-in-up',
                backdropClickToClose: false
            }).then(function(modal) {
                self.modal = modal;
                self.modal.show();
            });
        };

        // 隐藏模态框
        this.hideModal = function() {
            var self = this;
            if (this.modal) {
                this.modal.hide();
                this.modal.remove();
            }
        };
    }

})();