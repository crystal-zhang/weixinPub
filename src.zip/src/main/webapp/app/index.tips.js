/*
 ** TIPS 全局提示消息配置，按页面模块划分为：客户、产品、帮助中心、首页
 **
 ** Created By Cheney Hu (cheney@gmail.com) 2016/06/24
 */

(function() {
    'use strict';

    angular
        .module('app')
        .service('TIPS', TIPS);

    /** @ngInject */
    function TIPS() {
        this.getTips = function(callback) {
            angular.isFunction(callback) && callback();
            return {
                // 通用提示，用于用户输入校验
                'COMMON': {
                    'REQUIRED': '必填项信息不能为空或不正确',

                    'INVALID_STRING': '请勿输入非法字符',

                    'USER_NAME_INVALID': '您输入的真实姓名格式不正确',
                    'USER_NAME_LENGTH_ERROR': '您输入的真实姓名过长（最多支持30个汉字）',

                    'ID_LENGTH_ERROR': '您输入的证件号码过长',
                    'ID_INVALID': '您输入的证件号码格式不正确',
                    'ID_INVALID2': '请输入正确的证件号码',

                    'PASSWORD_LENGTH_ERROR': '密码长度最少8位，最长16位',
                    'PASSWORD_INVALID': '密码必须包含大写英文字母、小写英文字母、特殊字符、数字中的两种或以上',
                    'PASSWORD_SAME': '两次输入的密码必须保持一致',
                    'PASSWORD_FIRST': '请先设定登录密码',

                    'EMAIL_INVALID': '您输入的电子邮箱格式不正确',

                    'PHONE_INVALID': '您输入的手机号码格式不正确',
                    'PHONECODE_INVALID': '您输入的验证码格式不正确',
                    'PHONECODE_LENGTH_ERROR': '您输入的验证码长度不符',

                    'ZIPCODE_INVALID': '您输入的邮政编码格式不正确',

                    'BANKNO_INVALID': '您输入的银行账号格式不正确',
                    'BANKNO_LENGTH_ERROR': '您输入的银行账号长度不符',
                    'BANKNO_SAME': '必须和银行账号保持一致',
                    'BANKNO_FIRST': '请先设定银行账号',

                    'GENDER_INVALID': '性别不能为空',

                    'MONEY_NEED': '输入金额格式不正确',
                    'MONEY_FORMAT': '输入的金额必须为{money}的倍数',
                    'MONEY_MIN': '输入的金额必须大于等于{money}',
                    'MONEY_MAX': '输入的金额必须小于等于{money}',
                    'MONEY_OUTOFSIZE': '输入的金额超过了最高可借款金额',

                    'REFERRALNO_INVALID': '您输入的工号格式不正确',
                    'REFERRALNO_LENGTH_ERROR': '您输入的工号长度过长',

                    'ADDRESS_INVALID': '您输入的地址格式不正确',
                    'ADDRESS_LENGTH_ERROR': '您输入的地址长度不符',
                    'ADDRESS_NUMBER_ERROR': '您输入的地址不能全为数字',

                    'UPLOAD_FILE_MAX_SIZE_ERROR': '您上传的图片过大，单个文件应小于2MB',
                    'UPLOAD_FILE_TYPE_ERROR': '您上传的图片类型错误，只能上传png、jpg',

                    'JOBCODE_ERROR': '暂不支持该职业类型',

                    'DATE_LINE_MAX': '选择的日期应该小于{max}',
                    'DATE_LINE_MIN': '选择的日期应该大于{min}'
                },
                // 系统错误
                'SYSTEM': {
                    'INVALID_OPERATION': '非法操作',
                    'TIMEOUT': '系统繁忙，请稍后重试',
                    'REQUEST_ERROR': '服务请求异常，请稍后重试',
                    'NETWORK_ERROR': '网络环境不太流畅，请检查网络后重新尝试',
                    'REQUEST_DENIED': '请求操作被拒绝'
                },
                // 客户中心
                'USER': {
                    // 登录相关错误提示
                    'LOGIN': {
                        'USER_NAME_ERROR': '用户名输入错误',
                        'USER_PASSWORD_ERROR': '密码输入错误'
                    },
                    // 注册相关错误提示
                    'REGIST': {
                        'USER_REGIST_SUCCESS': '注册成功，请前往登录'
                    },
                    // 登出
                    'LOGOUT': {
                        'USER_LOGOUT_CONFIRM': '确认退出登录吗？'
                    },
                    // 安全
                    'SECURITY': {
                        'CHANGE_PHONE': '修改手机号成功！',
                        'CHANGE_PASSWORD': '修改密码成功！',
                        'OLD_PASSWORD_SAME': '新密码与旧密码不能相同'
                    },
                    // 订单
                    'ORDER': {
                        'NO_ORDER': '您暂时还没有订单'
                    },
                    'CONTACT': {
                        'REMOVE_CONFIRM': '确认删除联系人？'
                    },
                    // 绑定
                    'BIND': {
                        'NON_CERTIFICATE': '您的微信账号还未绑定身份信息',
                        'BIND_SUCCESS': '身份绑定成功'
                    }
                },
                // 产品投保
                'PRODUCT': {
                    'NEED_VALID_CODE': '请先获取验证码',
                    'RISK_FAILED': '您的评估得分未达到投保要求，请重新勾选',
                    'RISK_NOT_FINISHED': '题目未完成',
                    'IPAHA_SELECTED_LIMIT': '时间段最多只能添加5个',
                    'IPAHA_SELECTED_REPEAT':'该日期时间段已重复，请重新选择',
                    'ILCL_TOTAL_ERROR': '投资总金额必须等于购买金额',
                    'RECACULATE': '被保险人生日、性别与测算信息不符，确认更新将重新计算保费',
                    'RECACULATED': '由于您的被保人信息进行了变更，保费变化为：',
                    'RECACULATED_AMOUNT': '由于您的被保人信息进行了变更，基本保额变化为：',
                    'HEALTHY_INVALID': '尊敬的客户您好，您选择的告知事项内容，不符合我们的投保要求，请采用其他渠道购买本产品，谢谢您对我们的支持',
                    'UPLOAD_ANOTHER_PHOTO': '需要证件正反面照片，请上传另外一张证件照片',
                    'UPLOAD_PHOTOS': '请继续上传申请资料',
                    'INFORMATION_CHECK': '您的资料正在审核中，我们会在2-3个工作日告知您结果',
                    'PRESELL_SUCCESS': '预售申请成功，您的申请资料正在审核，我们会在2-3个工作日告知您结果',
                    'POLICY_QUERY_FAILED': '您的投保信息正在处理中，您可稍后前往“我的订单”中查询结果~',
                    'HOLD_POLICY_SUCCESS': '承保成功！',
                    'CARD_NOT_EXIST': '该活动卡券不存在！',
                    'CARD_UNAVAILABLE': '该活动卡券已被使用或已失效！',
                    'NO_POLICY': '正在努力承保中，请稍后再试',
                    'TAC_CERTTYPE_FAILED': '本产品仅限身份证投保!',
                    'GETEXPFROMCORE_CALCULATE_FAILED': '从核心获取保费失败，请您稍后重试',
		    'PREPARE_SALE_PRD':'预售成功，请等待正式销售后确认订单结果，谢谢！',
                    'BIRTHDAY_ERROR':'投保人或被保险人生日与测算信息不符，请重新进行保费测算',
                    'MATE_SEX_ERROR':'投被保人关系为配偶时，投保人和被保险人的性别不能相同，请重新选择',
                    'CHILD_SEX_ERROR':'被保险人的性别与保费测算时填写的性别不一致，测算保费可能发生变化，请重新进行保费测算',
                    'MATE_OCC_ERROR':'被保人职业为拒保职业，请选择其他职业类型或更换被保人'
                },
                // 帮助中心
                'HELP_CENTER': {

                },
                // 首页
                'HOME': {

                },
                'CLAIMS': {
                    'NODATA': '您暂时还没有理赔数据'
                },
                'POLICY_CHANGE': {
                    'NODATA': '暂时没有查询到保单',
                    'CHANGE_ID': '您本次申请变更的证件信息，将同步更新您名下所有保单相关的证件信息，请确认是否继续操作？',
                    'NOCHANGE_QUERY': '您暂时还没有进行过变更',
                    'NO_FINSH_CHANGE': '您暂时还没有变更完成的保单',
                    'NO_IN_CHANGE': '您暂时还没有变更中的保单',
                    'NOT_SMALL': '变更前信息不能与变更后一致',
                    'ERROR_ID': '该证件信息与投保时的信息不符！',
                    'UPDATE_FILE': '请先上传证件资料',
                    'MISS_DATA': '申请失效，请重新再试',
                    'NULL_RATIO': '投资比例不能为空',
                    'RATIO_FULL': '各投资账户的投资比例总和应为100%',
                    'RATIO_NUMBER': '每个投资账户比例应为5%的整数倍',
                    'CHOOSE_ONE': '请至少选择一项',
                    'MISS_TYPE': '缺少保全类型，请补充',
                    'MISS_CUSTOMER': '客户信息有误，请重新登陆',
                    'NO_SUPPORT_POILCY': '您暂时还没有保单支持此变更',
                    'UPDATE_ONEPHOTO': '需要证件正反面照片，请上传另外一张证件照片',
                    'WITHDRAW_FAILED': '退保申请失败'
                }
            };
        };
    }

})();