// ELIFE APP

(function() {
    'use strict';

    // angular.module is a global place for creating, registering and retrieving Angular modules
    angular
        .module('app')
        .run(runBlock);

    runBlock.$inject = ['$state', '$location', '$ionicPlatform', 'COMMON', 'TIPS', '$rootScope', 'PendingRequestsService', 'PolicyService', 'CommonRequest', 'CONFIG', '$timeout', 'TipService', 'LoginService', '$ionicLoading'];

    /** @ngInject */
    function runBlock($state, $location, $ionicPlatform, COMMON, TIPS, $rootScope, PendingRequestsService, PolicyService, CommonRequest, CONFIG, $timeout, TipService, LoginService, $ionicLoading) {

        $ionicPlatform.ready(function() {
            if (window.cordova && window.cordova.plugins.Keyboard) {
                // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
                // for form inputs)
                cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);

                // Don't remove this line unless you know what you are doing. It stops the viewport
                // from snapping when text inputs are focused. Ionic handles this internally for
                // a much nicer keyboard experience.
                cordova.plugins.Keyboard.disableScroll(true);
            }

            if (window.StatusBar) {
                StatusBar.styleDefault();
            }

            // 公共数据绑定
            $rootScope.COMMON_DATA = COMMON.getCommonData();
            // 异步数据绑定
            $timeout(function() {
//                COMMON.getDictInfo('country', function(data) {
//                    if (data && data.length > 0) {
//                        $rootScope.COMMON_DATA.NATIONALITIES = data;
//                    }
//                });
//                COMMON.getDictInfo('occupations', function(data) {
//                    if (data && data.length > 0) {
//                        $rootScope.COMMON_DATA.OCCUPATION_CODE = data;
//                    }
//                });
            }, 1000);
            // 错误消息，绑定至rootScope
            $rootScope.TIPS = TIPS.getTips(function() {
                $rootScope.loadingPage = true;
            });

            // 测试openid
            // $rootScope.openid = 'TestOpenID_' + Math.round(Math.random()*10000);

            // 默认非登录状态
            $rootScope.isLogin = false;

            // 从session获取登录状态和用户信息
            if (sessionStorage) {
                var sessionLogin = sessionStorage.getItem('elife-login');
                if (sessionLogin == 1) {
                    $rootScope.isLogin = true;
                    $rootScope.userData = angular.fromJson(sessionStorage.getItem('elife-userData'));
                }

                // 获取openid
                var sessionOpenID = sessionStorage.getItem('elife-openid');

                if (sessionOpenID) {
                    $rootScope.openid = sessionOpenID;
                }
            } else {
                $log.warn('sessionStorage is not working');
            }

            // 需要登录的页面
            var needsLoginStates = [
                'my-order', // 我的订单
                'my-order-detail', // 我的订单详情

                'my-policy', // 我的保单
                'my-policy-detail', // 我的保单详情

                'my-contacts', // 常用联系人
                'my-contact-edit', // 常用联系人
                'my-contact-add', // 常用联系人

                'my-info', // 个人资料
                'my-info-edit', // 个人资料修改

                // 'claims-guide', // 理赔指南
                'claims-query', // 理赔查询
                'claims-detail', // 理赔查询详情
                'claims-select',//我的理赔

                'policy-service', // 保单服务
                'policy-change-query', // 保单变更查询

                'policy-change-query', // 变更查询
                'policy-service-list', // 保单列表
                'policy-change-id', // 证件信息变更
                'policy-change-contact', // 联系方式变更
                'policy-change-renewal', // 续期
                'policy-change-withdraw', // 退保
                'policy-order-withdraw', // 预约退保
                'policy-change-bonus-account', // 续期银行账号

                'cert-unbind', // 身份解绑
                'jianbao-life' // 悦健康
            ];

            // 投保相关页面
            var policyStates = [
                'product-detail',
                'product-content',
                'product-purchase-calculate-bane',
                'product-purchase-calculate-beny',
                'product-purchase-calculate-bwlc',
                'product-purchase-calculate-cwla',
                'product-purchase-calculate-bwld',
                'product-purchase-calculate-enjl',
                'product-purchase-calculate-enjp',
                'product-purchase-calculate-buls',
                'product-purchase-calculate-benx',
                'product-purchase-calculate-fsb',
                'product-purchase-calculate-ilcl',
                'product-purchase-calculate-ipah',
                'product-purchase-calculate-ipaha',
                'product-purchase-calculate-ipahaactivity',
                'product-purchase-calculate-ipahj',

                'product-purchase-calculate-band',
                'product-purchase-calculate-ulpl',
                'product-purchase-calculate-ulnl',
                'product-purchase-calculate-bddg',
                'product-purchase-calculate-banf',
                'product-purchase-calculate-enll',
                'product-purchase-calculate-cena',
                'product-purchase-calculate-bedd',
                'product-purchase-calculate-tac',
                'product-purchase-calculate-taca',
                'product-purchase-calculate-ipam',
                'product-purchase-calculate-bulu',
                'product-purchase-calculate-tld',
                'product-purchase-calculate-ghmb',
                'product-purchase-calculate-hmra',
                'product-purchase-calculate-bano',
                'check-identity',
                'calculate-risk',
                'product-purchase-policy-info',
                'product-purchase-group-policy-info',
                'product-purchase-policy-contact',
                'product-purchase-group-policy-contact',
                'product-purchase-policy-agreement',
                'product-purchase-group-policy-agreement',
                'product-purchase-policy-notice',
                'product-purchase-group-policy-notice',
                'product-purchase-confirm',
                'product-purchase-group-confirm',
                'product-pay',
                'product-pay-success',
                'product-presale-pay-success'
            ];

            // 页面跳转事件监听
            var rootScope = $rootScope;
            rootScope.$on('$stateChangeStart', function(event, toState) {
                // 页面切换关闭pending请求
                // PendingRequestsService.cancelAll();

                // 当路由不对时弹框消失
                COMMON.hideModal();

                var name = toState.name; // 去往的页面
                // fromName = fromState.name; // 来的页面

                // 需要登录的页面处理
                if (needsLoginStates.indexOf(name) != -1) {
                    // 微信处理
                    if (CONFIG.WECHAT && !$rootScope.isLogin) {
                        event.preventDefault();
                        $rootScope.loginGo = name;
                        if (!$rootScope.wechatLoginProcess) {
                            COMMON.showModal('app/module/user/cert-bind/cert-bind.html');
                        } else {
                            $state.go('tab.user');
                        }
                    }

                    // 其它渠道如悦生活app处理，未登录弹出登录框
                    if (!CONFIG.WECHAT && !$rootScope.isLogin) {
                        event.preventDefault();
                        COMMON.showModal('app/module/user/login/login.html');
                        $rootScope.loginGo = name;
                    }
                }

                // 投保相关页面的session处理
                if (policyStates.indexOf(name) == -1) {
                    PolicyService.control({
                        control: 'data'
                    });
                }
            });

            // 首次进入时调用微信登录
            $timeout(function() {
                if (CONFIG.WECHAT && !$rootScope.isLogin) {
                    // 正在处理微信登录
                    $rootScope.wechatLoginProcess = true;
                    // 先获取openid再进行登录
                    LoginService.getOpenID(function(openid) {
                        LoginService.loginByWechat(openid);
                    });
                }
            }, 10);
        });

    }
})();