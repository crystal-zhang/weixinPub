(function() {
  'use strict';

  angular
    .module('app')
    .controller('GroupPolicyNoticeController', GroupPolicyNoticeController);

  GroupPolicyNoticeController.$inject = ['$state', 'CONFIG', '$rootScope', 'VALIDATION', '$scope', 'COMMON', '$filter', 'TipService', 'GroupPolicyService', 'CommonRequest', '$ionicPopup', '$timeout'];

  /** @ngInject */
  function GroupPolicyNoticeController($state, CONFIG, $rootScope, VALIDATION, $scope, COMMON, $filter, TipService, GroupPolicyService, CommonRequest, $ionicPopup, $timeout) {
    var vm = this,
      sessionData = GroupPolicyService.getSessionData();
    return vm.productData = sessionData.productData, vm.productData ? (vm.insureData = sessionData.insureData, vm.policyData = sessionData.policyData, vm.PbInsuExp = vm.insureData.PbInsuExp, vm.healthTag = "", vm.materials = vm.productData.materials, vm.materialDetail = function(ma) {
      if (ma) {
        var materialTypeDesc = ma.materialTypeDesc,
          materialType = ma.materialType,
          params = {
            prdId: vm.productData.prd_id,
            materialType: materialType,
            materialTypeDesc: materialTypeDesc
          };
        GroupPolicyService.getMaterialDetail(params)
      }
    }, vm.dataCheck = function() {
      return "0" != vm.healthTag ? (TipService.showMsg($rootScope.TIPS.PRODUCT.HEALTHY_INVALID), !1) : !0
    }, vm.getPolicyData = function() {
      for (var insuredLsit = [{
          rcgnNm: vm.policyData.PbHoldName,
          rcgnGndCd: vm.policyData.PbHoldSex,
          rcgnBrthDt: vm.policyData.PbHoldBirdy,
          rcgnCrdtTpCd: vm.policyData.PbHoldIdType,
          rcgnCrdtNo: vm.policyData.PbHoldId,
          rcgnExpirationType: vm.policyData.PbHoldExpireType,
          rcgnCrdtExpDt: vm.policyData.PbIdEndDate || "20991231",
          rcgnNatCd: vm.policyData.PbNationality,
          rcgnCommAdr: vm.policyData.PbHoldAddress,
          rcgnZipECD: vm.policyData.PbHoldZipCode,
          rcgnMoveTelNo: vm.policyData.PbHoldMobl,
          rcgnOcpCd: vm.policyData.PbHoldOccupCode,
          insuredSSflag: vm.policyData.PbHoldMedic,
          insuredAppntRela: "01",
          cvrNum: "1",
          busiList: [{
            cvrID: vm.insureData.plans.planCode,
            cvrNm: vm.productData.prd_title,
            mainAndAdlInsInd: "1",
            insCps: "1",
            insPremAmt: vm.insureData.plans.insuredAmount,
            insScmInf: vm.insureData.plans.planCode,
            insYrPrdCgyCd: vm.insureData.plans.insuYearFlag,
            insDdln: vm.insureData.plans.insuYear,
            autoRnwCvInd: "Y" == vm.productData.basicProfile.P010 ? "1" : "0"
          }]
        }], i = 0; i < vm.policyData.LiRcgnList.length; i++) insuredLsit.push({
        rcgnNm: vm.policyData.LiRcgnList[i].LiRcgnName,
        rcgnGndCd: vm.policyData.LiRcgnList[i].LiRcgnSex,
        rcgnBrthDt: vm.policyData.LiRcgnList[i].LiRcgnBirdy,
        rcgnCrdtTpCd: vm.policyData.LiRcgnList[i].LiRcgnIdType,
        rcgnCrdtNo: vm.policyData.LiRcgnList[i].LiRcgnId,
        rcgnExpirationType: vm.policyData.LiRcgnList[i].LiRcgnExpireType,
        rcgnCrdtExpDt: vm.policyData.LiRcgnList[i].LiIdEndDate || "20991231",
        rcgnNatCd: vm.policyData.LiRcgnList[i].LiNationality,
        rcgnCommAdr: vm.policyData.LiRcgnList[i].LiRcgnAddress,
        rcgnZipECD: vm.policyData.LiRcgnList[i].LiRcgnZipCode,
        rcgnMoveTelNo: vm.policyData.LiRcgnList[i].LiRcgnMobl,
        rcgnOcpCd: vm.policyData.LiRcgnList[i].LiRcgnOccupCode,
        insuredSSflag: vm.policyData.LiRcgnList[i].LiRcgnMedic,
        insuredAppntRela: vm.policyData.LiRcgnList[i].confirmRela,
        cvrNum: "1",
        busiList: [{
          cvrID: vm.insureData.plans.planCode,
          cvrNm: vm.productData.prd_title,
          mainAndAdlInsInd: "1",
          insCps: "1",
          insPremAmt: vm.insureData.plans.insuredAmount,
          insScmInf: vm.insureData.plans.planCode,
          insYrPrdCgyCd: vm.insureData.plans.insuYearFlag,
          insDdln: vm.insureData.plans.insuYear,
          autoRnwCvInd: "Y" == vm.productData.basicProfile.P010 ? "1" : "0"
        }]
      });
      var params = {
        realTotalPremium: vm.policyData.totalInsCvr,
        paymentCode: vm.productData.payment_type,
        payAge: vm.productData.pay_age,
        payAgeUnit: vm.productData.payTypeConfigs.payAgeUnit,
        insuredNum: vm.insureData.insuredList.length,
        insBlPrtNo: vm.PbApplNo[0],
        sellTypeDetail: CONFIG.SALE_CHANNEL,
        CCBInsID: vm.policyData.BkBrchNo,
        lv1BrNo: vm.policyData.bankCodeLV1,
        orderCode: vm.productData.orderCode,
        channelCode: CONFIG.SALE_CHANNEL,
        orgCode: vm.policyData.BkBrchNo,
        isMobileCheck: "Y" == vm.productData.basicProfile.P005 ? "1" : "0",
        isCalculate: "Y" == vm.productData.basicProfile.P001 ? "1" : "0",
        isRiskTest: "Y" == vm.productData.basicProfile.P007 ? "1" : "0",
        isAuthentication: "Y" == vm.productData.basicProfile.P002 ? "1" : "0",
        isSpecialCheck: "Y" == vm.productData.basicProfile.P004 ? "1" : "0",
        prdSaleCode: vm.productData.prdSaleCode,
        prdId: vm.productData.prd_id,
        planId: vm.insureData.plans.planId,
        planCode: vm.insureData.plans.planCode,
        planName: vm.insureData.plans.planName,
        districtCodeP: vm.policyData.PlchdProvCd,
        districtCode: vm.policyData.PlchdCityCd,
        districtCodeD: vm.policyData.PlchdDstcCd,
        checkPolicyGroupApp: {
          plchdNm: vm.policyData.PbHoldName,
          plchdGndCd: vm.policyData.PbHoldSex,
          plchdBrthDt: vm.policyData.PbHoldBirdy,
          plchdCrdtTpCd: vm.policyData.PbHoldIdType,
          plchdCrdtNo: vm.policyData.PbHoldId,
          expirationType: vm.policyData.PbHoldExpireType,
          plchdCrdtExpDt: vm.policyData.PbIdEndDate || "20991231",
          plchdNatCd: vm.policyData.PbNationality,
          plchdCommAdr: vm.policyData.PbHoldAddress,
          plchdZipECD: vm.policyData.PbHoldZipCode,
          plchdMoveTelNo: vm.policyData.PbHoldMobl,
          plchdEmailAdr: vm.policyData.PbHoldEmail,
          plchdOcpCd: vm.policyData.PbHoldOccupCode,
          plchdYrIncmAm: vm.policyData.PbHoldAmount,
          rsdntTpCd: vm.policyData.PbHoldDistrict,
          appntSsflag: vm.policyData.PbHoldMedic,
          insuredNum: vm.insureData.insuredList.length,
          insBlPrtNo: vm.PbApplNo[0],
          ntfItmInd: "0",
          dsptPcsgMtdCd: vm.policyData.PiZyzcfs,
          dsptArbtrInstNm: vm.policyData.PiZcinst,
          cCBInsID: vm.policyData.BkBrchNo,
          lv1BrNo: vm.policyData.bankCodeLV1,
          bONm: vm.policyData.allWebsite,
          bOSaleStffNm: vm.policyData.angentName,
          bOSaleStffID: vm.policyData.agentCode,
          plchdProvCd: vm.policyData.districtCode,
          plchdCityCd: vm.policyData.liveProvince,
          plchdCntyAndDstcCd: vm.policyData.liveDistrict,
          specAuditFlag: "Y" == vm.productData.basicProfile.P004 ? "1" : "0",
          insRecommendId: vm.policyData.referrerCode,
          insRecommendNm: vm.policyData.referrerName,
          insSaleId: vm.policyData.agentCode,
          insSaleNm: vm.policyData.angentName,
          insSaleGrp: vm.policyData.BkBrchNo,
          insuredList: insuredLsit
        }
      };
      return params
    }, vm.checkPolicy = function() {
      var policyData = vm.getPolicyData();
      policyData && (GroupPolicyService.control({
        state: $state.current.name,
        control: "data",
        data: policyData
      }), GroupPolicyService.control({
        state: $state.current.name,
        control: "process"
      }))
    }, void(vm.submit = function() {
      vm.dataCheck() && GroupPolicyService.createPbApplNo(vm.policyData.BkBrchNo, function(pbApplNoList) {
        vm.PbApplNo = pbApplNoList, vm.checkPolicy()
      })
    })) : void $state.go("tab.mall")
  }
})();