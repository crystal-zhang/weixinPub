(function() {
    'use strict';

    angular
        .module('app')
        .controller('ProductPayController', ProductPayController);

    ProductPayController.$inject = ['$rootScope', '$scope', '$state', 'CONFIG', 'CommonRequest', '$log', 'PolicyService', 'TipService', '$window', 'COMMON'];
    /** @ngInject */
    function ProductPayController($rootScope, $scope, $state, CONFIG, CommonRequest, $log, PolicyService, TipService, $window, COMMON) {
        var vm = this;

        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        vm.productData = sessionData.productData,
        vm.policyData = sessionData.policyData;

        if (!vm.productData || !vm.policyData || !vm.policyData.orderCode) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        // 订单号
        vm.orderCode = vm.policyData.orderCode;

        vm.payways = vm.productData.payType;
        vm.hasDiscount = vm.productData.hasDiscount;
        
        if (vm.payways.indexOf('109') != -1) {
            vm.newPayMode = '7';
        }
        // vm.payAmount = vm.policyData.allInsuExp;
        vm.payAmount = vm.policyData.itemOrderRealPayAmt;
        vm.BkBrchNo = vm.policyData.BkBrchNo;
        vm.newGetAccName = vm.policyData.PbHoldName ? vm.policyData.PbHoldName : sessionData.userData.customerName;
        //投保人姓名
        if (vm.policyData.checkPolicyGroupApp) {
            vm.plchdNm = vm.policyData.checkPolicyGroupApp.plchdNm;
        }
        // 支付异常的弹窗
        vm.showModal = function() {
            var modalInstance = $uibModal.open({
                templateUrl: 'app/module/product/product-pay/pay-modal/pay-modal.html',
                controller: 'PayModalController',
                controllerAs: 'payModal',
                size: 'md',
                scope: $scope
            });

            modalInstance.result.then(function(check) {
                vm.checkContract = check;
            }, function() {
                $log.info('Modal dismissed at: ' + new Date());
            });
        };

        // 确认支付
        vm.pay = function() {
            var ua = navigator.userAgent.toLowerCase();
            var platForm;
            if (ua.indexOf('android') != -1) {
                platForm = 'android';
            } else if (ua.indexOf('iphone') != -1) {
                platForm = 'iPhone';
            } else {
                platForm = 'pc';
            }

            var params = {
                customerId: $rootScope.isLogin ? $rootScope.userData.cusId : '', // 客户号
                branchCode: vm.BkBrchNo,
                orderCode: vm.orderCode, // 订单号
                payAmount: vm.payAmount, // 订单金额
                payType: vm.payment, // 支付方式
                platForm: platForm, // 终端
                payChannel: CONFIG.SALE_CHANNEL // 渠道
            };

            CommonRequest.request(params, CONFIG.PAY_SERVICE, function(result) {
                if (result.status == 1) {
                    // vm.showModal();
                    $window.location.href = CONFIG.PAY_SERVICE_ADDRESS + result.data.payUrl + '?tokenId=' + result.data.tokenId + '&platForm=' + params.platForm + '&payChannel=' + params.payChannel + '&orderCode=' + vm.orderCode + '&payAmount=' + vm.payAmount + '&payType=' + vm.payment + '&branchCode=' + vm.BkBrchNo + '&openid=' + $rootScope.openid;
                }
            });
        };

        // 获取开户行
        COMMON.getCommonBank(vm.BkBrchNo, '1', function(bankList) {
            vm.bankList = bankList;
            vm.newGetBk = vm.bankList[0];
        });

        // 授权转账请求
        vm.paytra = function() {
            var params = {
                accountName: vm.newGetAccName,
                bankCode: vm.newGetBk.bankCode,
                bankName: vm.newGetBk.bankName,
                accountNumber: vm.newGetAccCode,
                orderCode: vm.orderCode,
                payType: vm.newPayMode,
                pbApplName: vm.newGetAccName
            };
            CommonRequest.request(params, CONFIG.ACCREDIT_TRANSFER_SERVICE, function(result) {
                if (result.status == 1) {
                    if (result.data.holdStatus == '1') {
                        $state.go('product-pay-success', {
                            orderCode: vm.orderCode,
                            payResult: '5'
                        });
                    } else if (result.data.holdStatus == '2') {
                        $state.go('product-pay-success', {
                            orderCode: vm.orderCode,
                            payResult: '4'
                        });
                    } else if (result.data.holdStatus == '3') {
                        $state.go('product-pay-success', {
                            orderCode: vm.orderCode,
                            payResult: '5'
                        });
                    } else if (result.data.holdStatus == '0') {
                        $state.go('product-pay-success', {
                            orderCode: vm.orderCode,
                            payResult: '6'
                        });
                    }
                } else if (result.status == 0 && result.error.code == "Y1200044014") {
                    $state.go('product-pay-success', {
                        orderCode: vm.orderCode,
                        payResult: '8'
                    });
                }
            });
        };


        // 支付选择
        vm.ensurePay = function(payment) {
            if (payment == '109') {
                vm.paytra();
            } else {
                vm.pay();
            }
        }
    }
})();