(function() {
    'use strict';

    angular
        .module('app')
        .controller('CalculateRiskController', CalculateRiskController);

    CalculateRiskController.$inject = ['$state', 'CONFIG', 'CommonRequest', '$document', 'TipService', 'PolicyService', '$rootScope'];
    /** @ngInject */
    function CalculateRiskController($state, CONFIG, CommonRequest, $document, TipService, PolicyService, $rootScope) {
        var vm = this;

        vm.button = true;

        vm.check = function() {
            vm.button = !vm.button;
        };

        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        var prodata = vm.prodata = sessionData.productData;
        if (!prodata) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('home');
            return;
        }

        // 用户问卷信息
        var userdata = sessionData.userData;

        // 用户登录状态
        var login = sessionData.login;

        // 获取问卷题目
        vm.getQuestions = function() {
            var params = {
                prdId: prodata.prd_id
            };
            CommonRequest.request(params, CONFIG.PRODUCT_RISK_INFO_SERVICE, function(result) {
                if (result.status == 1) {
                    vm.questions = result.data.datas;
                }

            });
        };
        vm.getQuestions();

        // 监听选择题目
        vm.selecte = function(answer, code) {
            vm.questions.forEach(function(item) {
                if (item.subjectCode == code) {
                    var titles = item.titles;
                    titles.forEach(function(item) {
                        if (item.titleCode == answer.titleCode) {
                            item.selected = true;
                        } else {
                            item.selected = false;
                        }
                    });
                }
            });
        };

        // 提交问卷
        vm.submit = function() {
            var riskForm = $document[0].riskForm;

            var score = []; //每题得分
            var totalScore = 0; //总得分

            for (var i = 0; i < vm.questions.length; i++) {
                score.push(vm.questions[i].value);
            }

            // 判断题目是否都填写
            var flag = true;

            for (var i = 0; i < score.length; i++) {
                if (score[i] == '') {
                    flag = false;
                }
            }

            if (flag) {
                for (var j = 0; j < score.length; j++) {
                    totalScore += parseInt(score[j]);
                }
                // 判断分数是否为小于6
                if (totalScore <= 6) {
                    TipService.showMsg($rootScope.TIPS.PRODUCT.RISK_FAILED);
                } else {
                    // 发送得分给后台
                    var params = {
                        totalScore: totalScore,
                        insurer_cer_type: userdata.cretType,
                        insurer_cer_id: userdata.cretNo,
                        customer_name: userdata.customerName,
                        prdId: prodata.prd_id,
                        orderCode: prodata.orderCode
                    };
                    CommonRequest.request(params, CONFIG.PRODUCT_RISK_SUBMIT_SERVICE, function(result) {
                        if (result.status == 1) {
                            // 流程跳转
                            PolicyService.control({
                                state: $state.current.name,
                                control: 'process'
                            });
                        }
                    });
                }
            } else {
                TipService.showMsg($rootScope.TIPS.PRODUCT.RISK_NOT_FINISHED);
            }
        };
    }
})();