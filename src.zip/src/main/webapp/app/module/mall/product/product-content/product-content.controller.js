(function() {
    'use strict';

    angular
        .module('app')
        .controller('ProductContentController', ProductContentController);

    ProductContentController.$inject = ['$state', '$filter', 'CommonRequest', 'PolicyService'];

    /** @ngInject */
    function ProductContentController($state, $filter, CommonRequest, PolicyService) {
        var vm = this;

        var sessionData = PolicyService.getSessionData();

        var productData = vm.productData = sessionData.productData;


        if (!productData) {
            $state.go('tab.mall');
        } else {
            vm.tabs = productData.tabs;
        }

        if (productData.buttonShow == 'false') {
            vm.nextButton = false;
        }else{
            vm.nextButton = true;
        }
        // 默认选择第一个选项
        vm.tab = 0;

        // 切换tab
        vm.select = function(index) {
            vm.tab = index;
            //  vm.getHtmlContent(vm.tabs[index], index);
        };

        // 处理tab内容中的html
        // vm.getHtmlContent = function(tab, index) {
        //     if (tab && tab.content_type == '2') {
        //         var htmlLink = tab.html_file_link;

        //         if (htmlLink && htmlLink != 'null') {
        //             CommonRequest.request({}, {
        //                 url: $filter('imageFix')(htmlLink),
        //                 method: 'GET'
        //             }, function(result) {
        //                 angular.element(document.querySelector('#tab' + index)).html(result);
        //             });
        //         }
        //     }
        // };
        // if (vm.tabs) {
        //     if (vm.tabs.length > 0) {
        //         vm.getHtmlContent(vm.tabs[0], 0);
        //     }
        // }


        //读取产品页签嵌入到产品内容
        vm.getHtml = function() {
            CommonRequest.request({}, {
                url: $filter('iframeFilter')(vm.productData.prd_id),
                method: 'GET'
            }, function(result) {
                if(result){
                    var regBody = /<body[^>]*>([\s\S]*)<\/body>/;
                    var bodyContent = regBody.exec(result);
                    if (bodyContent && bodyContent.length == 2) {
                        bodyContent = bodyContent[1];
                    }
                    angular.element(document.querySelector('#content')).html(bodyContent);
                    evalFun(bodyContent);    
                }
                
            });

        };
        vm.getHtml();

        // 将字符串变为js
        function evalFun(bodyContent) {
            var regDetectJs = /<script(.|\n)*?>(.|\n|\r\n)*?<\/script>/ig;
            var jsContained = bodyContent.match(regDetectJs);

            // 第二步：如果包含js，则一段一段的取出js再加载执行
            if (jsContained) {
                // 分段取出js正则
                var regGetJS = /<script(.|\n)*?>((.|\n|\r\n)*)?<\/script>/im;

                // 按顺序分段执行js
                var jsNums = jsContained.length;
                for (var i = 0; i < jsNums; i++) {
                    var jsSection = jsContained[i].match(regGetJS);

                    if (jsSection[2]) {
                        if (window.execScript) {
                            // 给IE的特殊待遇
                            window.execScript(jsSection[2]);
                        } else {
                            // 给其他大部分浏览器用的
                            window.eval(jsSection[2]);

                        }
                    }
                }
            }
        }

        // 流程跳转
        vm.process = function() {
            PolicyService.control({
                state: 'product-detail',
                control: 'process'
            });
        };
    }
})();