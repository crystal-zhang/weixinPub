(function() {
    'use strict';

    angular
        .module('app')
        .controller('IpahjController', IpahjController);

    IpahjController.$inject = ['$state', '$scope', 'CONFIG', 'CommonRequest', 'PolicyService', 'TipService', '$filter', 'VALIDATION', '$rootScope'];
    /** @ngInject */
    function IpahjController($state, $scope, CONFIG, CommonRequest, PolicyService, TipService, $filter, VALIDATION, $rootScope) {
        var vm = this;

        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        vm.productData = sessionData.productData;
        // 非法操作：1. 未获取产品数据 2. 要求做而未做手机验证
        if (!vm.productData || (sessionData.loginStatus != 2 && vm.productData.basicProfile['P005'] == 'Y' && !vm.productData.phoneValid)) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        // 主险数据
        vm.mainPlan = {
            rate: 0,
            amount: 0,
            exp: 0
        };

        // 用户选择的数据
        vm.user = {};
        vm.user.sex = '';
        vm.user.birthday = null;

        // 投被保人年龄
        var payTypeConfigs = vm.productData.payTypeConfigs;
        if (payTypeConfigs && payTypeConfigs.length > 0) {
            var payTypeConfig = payTypeConfigs[0];

            vm.minAge = payTypeConfig.min_app_age;
            vm.maxAge = payTypeConfig.max_app_age;
            vm.minHolderAge = payTypeConfig.minHolderAge;
            vm.maxHolderAge = payTypeConfig.maxHolderAge;

            vm.minStartDate = VALIDATION.getDateByAge(vm.maxAge); // 年龄最小开始日期
            vm.maxEndDate = VALIDATION.getDateByAge(vm.minAge); // 年龄最大结束日期
            vm.holderStartDate = VALIDATION.getDateByAge(vm.maxHolderAge); // 投保人年龄最小开始日期
            vm.holderEndDate = VALIDATION.getDateByAge(vm.minHolderAge); // 投保人年龄最大结束日期
        }

        // 缴费方式，年缴
        vm.paymentType = vm.productData.payment_type;

        // 监听
        $scope.$watch('ipahj.selectedPlan.insuredAmount', function() {
            if (vm.selectedPlan) {
                vm.mainPlan.amount = vm.selectedPlan.insuredAmount;
            }
        }, true);

        // 默认航空B
        vm.types = [{
            key: 'B',
            value: '航空'
        }, {
            key: 'C',
            value: '高铁'
        }, {
            key: 'A',
            value: '私家车'
        }];
        vm.type = vm.types[0].key;

        // 根据组合类别获取计划列表
        vm.getPlansByType = function(type) {
            if (type) {
                vm.showPlans = []; // 选择的组合计划
                vm.planOptions = []; // 显示的计划
                vm.selectedPlanCode = null;
                vm.selectedPlan = null; // 选择的计划

                var plans = vm.productData.plans; // 所有计划
                for (var i = plans.length - 1; i >= 0; i--) {
                    var plan = plans[i];
                    if (plan.planCode.indexOf(type) != -1) {
                        vm.showPlans.push(plan);
                        vm.planOptions.push({
                            label: plan.planName,
                            value: plan.planCode
                        });
                    }
                }
                // 默认选择列表中第一个计划
                if (vm.planOptions && vm.planOptions.length > 0) {
                    vm.selectedPlan = vm.showPlans[0];
                    vm.selectedPlanCode = vm.planOptions[0].value;

                }
            }
        };

        // 切换组合 私家车A 航空B 高铁C 
        vm.checkType = function() {
            // 获取计划列表
            vm.getPlansByType(vm.type);
        };
        // vm.checkType();

        // 获取卡券
        if (vm.productData.token) {
            PolicyService.getCardInfo(vm.productData.token, function(data) {
                var plId, // 该产品的计划id 
                    duties = data.prmLotDutySetModels; // 计划的责任数组
                if (duties && duties.length > 0) {
                    plId = duties[0].planId;
                }
                if (vm.productData.plans && vm.productData.plans.length > 0) {
                    for (var k = 0; k < vm.productData.plans.length; k++) {
                        var plan = vm.productData.plans[k],
                            planCode;
                        if (plId == plan.planId) {
                            var l1 = duties.length,
                                l2 = plan.dutys.length;
                            if (l1 != l2) {
                                var ilId = duties[0].ilId;
                                for (var m = 0; m < plan.dutys.length; m++) {
                                    if (ilId == plan.dutys[m].dutyId) {
                                        plan.dutys = [plan.dutys[m]];
                                    }
                                }
                            }
                            vm.productData.plans = vm.productData.plans = [plan];
                            break;
                        }
                    }

                    // 过滤组合类型
                    for (var m = 0; m < vm.types.length; m++) {
                        if (vm.productData.plans[0].planCode.indexOf(vm.types[m].key) != -1) {
                            vm.types = [vm.types[m]];
                            break;
                        }
                    }

                    vm.type = vm.types[0].key;
                    vm.checkType();
                }
            });
        } else {
            vm.checkType();
        }

        // 选择计划
        vm.changePlan = function() {
            vm.selectedPlanCode;
            for (var i = vm.showPlans.length - 1; i >= 0; i--) {
                var plan = vm.showPlans[i];
                if (plan.planCode == vm.selectedPlanCode) {
                    vm.selectedPlan = plan;
                    break;
                }
            }
        };

        // 保险生效日期，不小于当前时间
        var nowDate = new Date();
        vm.minDate = nowDate;
        if (vm.productData.prdSaleCode == 2 && vm.productData.planSaleTime) {
            var planSaleTime = vm.productData.planSaleTime;
            planSaleTime = planSaleTime.substr(0, 4) + '-' + planSaleTime.substr(4, 2) + '-' + planSaleTime.substr(6, 2);
            planSaleTime = new Date(planSaleTime);
            if (planSaleTime.getTime() > nowDate.getTime()) {
                vm.minDate = planSaleTime;
            }
        }

        // 保险失效日期，不大于当前日期+1年-1天
        vm.maxDate = new Date(vm.minDate.getTime() + 364 * 24 * 60 * 60 * 1000);

        vm.startTime = vm.minDate;

        // 日期选择回调
        vm.startCallback = function(val) {
            if (val) {
                vm.startTime = val;
            }
        };

        // 跳转投保页面
        vm.goPolicy = function() {
            var params = {
                prdId: vm.productData.prd_id,
                sex: vm.user.sex,
                insurerBirthDay: $filter('date')(vm.user.birthday, 'yyyyMMdd'),
                planId: vm.selectedPlan.planId,
                premiumResult: vm.selectedPlan.normalPrice,
                orderCode: vm.productData.orderCode || ''
            };

            PolicyService.doCalc(params, function() {
                // 数据处理
                vm.mainPlan.exp = vm.selectedPlan.normalPrice;
                vm.mainPlan.amount = vm.selectedPlan.insuredAmount;
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'data',
                    data: {
                        // birthday: vm.user.birthday, // 被保人生日
                        // sex: vm.user.sex, // 被保人性别
                        // selectedPlan: vm.user.selectedPlan, //是否选择附加险
                        mainPlan: angular.extend(vm.mainPlan, vm.selectedPlan),
                        // 主险
                        // addPlan: vm.addPlan, // 附加险
                        payendyear: 1, // 缴费期间
                        paymentType: vm.paymentType, // 缴费方式
                        PbBeginDate: vm.startTime, // 保险生效时间
                        PbInsuAmt: vm.mainPlan.insuredAmount, // 主险保额
                        PbInsuExp: vm.productData.token ? 0 : vm.mainPlan.normalPrice, // 主险保费
                        pbApplNoNum: 1,
                        isWholeSale: vm.paymentType == '0' ? true : false,
                        minAge: vm.minAge,
                        maxAge: vm.maxAge,
                        minHolderAge: vm.minHolderAge,
                        maxHolderAge: vm.maxHolderAge,
                        oldPrice: vm.selectedPlan.normalPrice // 赠险前原价
                    }
                });
                // 流程跳转
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'process'
                });
            });
        };
    }
})();