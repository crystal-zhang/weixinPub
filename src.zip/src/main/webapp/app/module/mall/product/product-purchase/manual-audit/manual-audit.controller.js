(function() {
    'use strict';

    angular
        .module('app')
        .controller('ManualAuditController', ManualAuditController);

    ManualAuditController.$inject = ['$rootScope', '$location', 'Upload', 'CONFIG', '$scope', 'TipService', 'PolicyService', 'COMMON', '$ionicLoading', '$timeout'];
    /** @ngInject */
    function ManualAuditController($rootScope, $location, Upload, CONFIG, $scope, TipService, PolicyService, COMMON, $ionicLoading, $timeout) {
        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        var policydata = $scope.policydata = sessionData.policyData,
            prodata = $scope.prodata = sessionData.productData;
        var uploadImgInOrder = sessionData.uploadImgInOrder;

        if (!prodata.orderCode) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $scope.close();
            return;
        }

        // 初始化
        $scope.files = {};
        $scope.files.file1 = '';
        $scope.files.file2 = '';
        $scope.files.file3 = '';
        $scope.files.file4 = '';

        // 存放图片的数组
        $scope.imageList = [];

        // 上传成功的数量
        $scope.uploaded = 0;

        // 上传条件初始化
        $scope.uploadNum = 0; // 需要上传的图片数量
        // 人工审核返回值
        var auditParams = prodata.auditParams;
        if (auditParams && auditParams.uploadType) {
            var uploadType = auditParams.uploadType;
            //上传的照片类型， 三位标识符，1为需要上传，0为不上传，第一位、身份证正反面，第二位、银行流水证明，第三位、财务证明
            $scope.uploadType = uploadType.split('');
            $scope.uploadID = $scope.uploadType[0] == '1' ? true : false;
            $scope.uploadFinnace = $scope.uploadType[1] == '1' ? true : false;
            $scope.uploadSeq = $scope.uploadType[2] == '1' ? true : false;

            if ($scope.uploadID) {
                $scope.uploadNum += 2;
            }
            if ($scope.uploadFinnace) {
                $scope.uploadNum++;
            }
            if ($scope.uploadSeq) {
                $scope.uploadNum++;
            }
        }

        // 获取用户影像件资料
        if (sessionData.login == 1) {
            PolicyService.getCustPhoto(auditParams.uploadType, function(images) {
                // imageFlag F001/F002/F003/F004
                for (var i = images.length - 1; i >= 0; i--) {
                    var image = images[i],
                        flag = image.imageFlag;
                    if (flag == 'F001') {
                        // 身份证正面
                        $scope.image1 = $scope.files.file1 = image.imagePath;
                    } else if (flag == 'F002') {
                        // 身份证反面
                        $scope.image2 = $scope.files.file2 = image.imagePath;
                    } else if (flag == 'F003') {
                        // 身份证反面
                        $scope.image3 = $scope.files.file3 = image.imagePath;
                    } else if (flag == 'F004') {
                        // 身份证反面
                        $scope.image4 = $scope.files.file4 = image.imagePath;
                    }
                }
            });
        }

        // 关闭弹框
        $scope.cancel = function() {
            COMMON.hideModal();
        };

        // 支付银行列表,1代表公司收款
        var BkBrchNo = policydata ? policydata.BkBrchNo : '';
        if (BkBrchNo) {
            COMMON.getCommonBank(BkBrchNo, '1', function(bankList) {
                $scope.bankList = bankList;
                if ($scope.bankList && $scope.bankList.length > 0) {
                    $scope.newGet.newGetBk = $scope.bankList[0]; // 授权转帐银行
                }
            });
        }

        // 初始化姓名
        $scope.name = policydata ? policydata.PbHoldName : '';

        $scope.newGet = {};
        $scope.newGet.newPayMode = '7';
        $scope.newGet.newGetAccName = policydata ? policydata.PbHoldName : '';
        $scope.newGet.newGetAccCode = '';

        // upload later on form submit or something similar
        $scope.submit = function() {
            // 无需上传
            if ($scope.uploadNum == 0 || $scope.uploaded == $scope.uploadNum) {
                $scope.process();
                return;
            }
            var self = this,
                file1 = self.files.file1,
                file2 = self.files.file2,
                file3 = self.files.file3,
                file4 = self.files.file4,
                image1 = self.image1,
                image2 = self.image2,
                image3 = self.image3,
                image4 = self.image4;

            $scope.imageList = [];
            if ($scope.uploadID) {
                if (!file1 || !file2) {
                    return;
                } else {
                    $scope.imageList.push({
                        F001: file1,
                        uploadType: '1000'

                    }, {
                        F002: file2,
                        uploadType: '0100'
                    });
                }
            }
            if ($scope.uploadFinnace) {
                if (!file3) {
                    return;
                } else {
                    $scope.imageList.push({
                        F003: file3,
                        uploadType: '0010'
                    });
                }
            }
            if ($scope.uploadSeq) {
                if (!file4) {
                    return;
                } else {
                    $scope.imageList.push({
                        F004: file4,
                        uploadType: '0001'

                    });
                }
            }

            // 必须上传另一张证件照的判断
            if ($scope.uploadID && image1 && image2) {
                if ((file1 == image1 && file2 != image2) || (file1 != image1 && file2 == image2)) {
                    TipService.showMsg($rootScope.TIPS.PRODUCT.UPLOAD_ANOTHER_PHOTO);
                    return;
                }
            }

            // 需要判断是否允许上传
            PolicyService.isAllowUpload($scope.imageList.length, function() {
                $scope.checkUpload($scope.uploaded);
            });
        };

        // 准备上传
        $scope.checkUpload = function(uploaded) {
            var data = {
                custId: sessionData.userData ? sessionData.userData.cusId : '',
                token: sessionData.userData ? sessionData.userData.token : '',
                channelCode: CONFIG.SALE_CHANNEL,
                orderCode: prodata.orderCode,
                txCode: 'CCBSB107',
                srCode: auditParams.srCode // 规则编码
            };
            $scope.upload(angular.extend($scope.imageList[uploaded], data),
                function() {
                    $scope.uploaded++;
                });
        };

        // 上传成功后的处理
        $scope.process = function() {
            // $uibModalInstance.close(true);

            var params = {};

            if ($scope.newGet.newGetAccCode) {
                params = {
                    NewPayMode: $scope.newGet.newPayMode || '7', // 首期收费方式 
                    NewGetAccName: $scope.newGet.newGetAccName, //首期缴费账号名称
                    NewGetBkCode: $scope.newGet.newGetBk.bankCode, //首期缴费银行编码
                    NewGetBkName: $scope.newGet.newGetBk.bankName, // 首期缴费银行名称
                    NewGetAccCode: $scope.newGet.newGetAccCode, //首期缴费账号
                    orderCode: prodata.orderCode,
                    insureCheckFlg: auditParams.insureCheckFlg // 是否人工审核
                };

                params = angular.extend(policydata, params);

                PolicyService.control({
                    state: 'manual-audit',
                    control: 'data',
                    data: angular.extend(params, {
                        isManualAudited: true
                    })
                });
            } else {
                params = policydata;
            }

            if (uploadImgInOrder) {
                PolicyService.checkPolicy(params, 'afterupload', function() {
                    console.log("影像上传成功！");
                    PolicyService.removeSessionData(['uploadImgInOrder']);
                    $rootScope.$broadcast('img-uploadsuccess',{
                            result:true
                    });
                    COMMON.hideModal();
                });
            } else {
                PolicyService.checkPolicy(params, 'single', function() {
                    PolicyService.control({
                        state: 'manual-audit',
                        control: 'process'
                    });
                });
            }
        };

        // upload on file select or drop
        $scope.upload = function(data, callback) {
            $ionicLoading.show({
                template: '<ion-spinner icon="bubbles"></ion-spinner>'
            });

            Upload.upload({
                url: CONFIG.UPLOAD_SERVICE.url,
                data: data
            }).then(function(result) {
                $ionicLoading.hide();
                if (result.data.status == '1') {
                    $scope.uploadMsg = '上传成功！';
                    angular.isFunction(callback) && callback();
                } else {
                    TipService.showMsg(result.data.error.message + result.data.error.code);
                    $scope.uploadMsg = '上传失败';
                }

            }, function(resp) {
                $ionicLoading.hide();
                $scope.uploadMsg = '上传失败，错误代码: ' + resp.status;
            }, function(evt) {
                var progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
                $scope.uploadMsg = '上传进度: ' + progressPercentage + '%';
            });
        };

        // 上传成功的通知
        $scope.notify = function() {
            var params = {
                channelCode: CONFIG.SALE_CHANNEL,
                orderCode: prodata.orderCode,
                txCode: 'CCBSB107',
                uploadType: auditParams.uploadType
            };
            PolicyService.CertUploadDone(params, function(data) {
                if (data) {
                    $scope.process();
                }
            });
        };

        // 监听上传成功
        $scope.$watch('uploaded', function(newValue, oldValue) {
            if (newValue) {
                if (newValue != oldValue && newValue < $scope.uploadNum) {
                    $scope.checkUpload(newValue);
                } else if (newValue == $scope.uploadNum) {
                    $scope.notify();
                }
            }
        });
    }

})();