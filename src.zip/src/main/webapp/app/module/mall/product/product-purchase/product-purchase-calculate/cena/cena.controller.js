(function() {
    'use strict';

    angular
        .module('app')
        .controller('CenaController', CenaController);

    CenaController.$inject = ['$state', 'CONFIG', 'CommonRequest', '$scope', 'VALIDATION', '$rootScope', 'PolicyService', 'TipService', '$filter'];
    /** @ngInject */
    function CenaController($state, CONFIG, CommonRequest, $scope, VALIDATION, $rootScope, PolicyService, TipService, $filter ) {
        var vm = this;

        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        vm.productData = sessionData.productData;
        // 非法操作：1. 未获取产品数据 2. 要求做而未做手机验证
        if (!vm.productData || (sessionData.loginStatus != 2 && vm.productData.basicProfile['P005'] == 'Y' && !vm.productData.phoneValid)) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        // 初始化数据
        vm.user = {
            sex : '1',
            birthday : null
            // birthday : new Date('1990-3-2')
        };
        vm.nextStepValide = false;
        
        // 日期选择回调
        vm.birthdayCallback = function(val) {
            if (val) {
                vm.user.birthday = val;
            }
        };


        //设置投保人最大最小年龄
        var setMinAndMaxAges = function(obj){
            vm.maxAge = obj.max_app_age;
            vm.minAge = obj.min_app_age;
            vm.minHolderAge = obj.minHolderAge;
            vm.maxHolderAge = obj.maxHolderAge;
            
            vm.minStartDate = VALIDATION.getDateByAge(vm.maxAge); // 年龄最小开始日期
            vm.maxEndDate = VALIDATION.getDateByAge(vm.minAge); // 年龄最大结束日期
            vm.holderStartDate = VALIDATION.getDateByAge(vm.maxHolderAge); // 投保人年龄最小开始日期
            vm.holderEndDate = VALIDATION.getDateByAge(vm.minHolderAge); // 投保人年龄最大结束日期
        };

        // 初始化投被保人年龄
        var payTypeConfigs = vm.productData.payTypeConfigs;
        if (payTypeConfigs && payTypeConfigs.length > 0) {
            setMinAndMaxAges(payTypeConfigs[0]);
        }

        // 主险数据
        vm.mainPlan = {
            rate: 0,
            amount: 50000,
            exp: ""
        };

        // 附加险数据
        vm.addPlan = {
            rate: 0,
            amount: "",
            exp: "",
            selectedPlan : false
        };

        // 初始化附加险保额可选项
        vm.addAmountList = [{
            value: 100,
            label: 100
        },{ 
            value: 200,
            label: 200
        },{ 
            value: 300,
            label: 300
        }];

        // 总保额
        vm.totalAmount = vm.mainPlan.amount + vm.addPlan.amount;
        // 总保费
        vm.totalExp = vm.mainPlan.exp + vm.addPlan.exp;

        // 获取产品计划
        vm.getPlan = function() {
            var plan = vm.productData.plans,
                len = plan.length;

            for (var i = len - 1; i >= 0; i--) {
                var item = plan[i];
                if (item.planType == '1') {
                    // 获取主险
                    angular.extend(vm.mainPlan, item);
                } else if (item.planType == '2') {
                    // 获取附加险
                    angular.extend(vm.addPlan, item);
                }
            }
        };
        vm.getPlan();

        // 获取缴费方式
        vm.getPayWay = function() {
            var payment_value = [],
                payage = [];

            vm.payWays = [];

            if (vm.productData.payment_type) {
                payment_value = vm.productData.payment_type.split(',');
            }
            if (vm.productData.pay_age) {
                payage = vm.productData.pay_age.split(',');
            }
            // 从小到大排序缴费年期
            payage.sort(function(a,b){
                return a-b});
            if (payment_value && payment_value.length > 0) {
                for (var i = 0; i < payment_value.length; i++) {
                    var label;
                    if (payment_value[i] == 12) {
                        label = payage[i] + '年交';
                    } else if (payment_value[i] == 0) {
                        label = '趸交';
                    } else if (payment_value[i] == 1) {
                        label = '月交';
                    } else if (payment_value[i] == 3) {
                        label = '季交';
                    } else if (payment_value[i] == 6) {
                        label = '半年交';
                    }
                    vm.payWays.push({
                        label: label,
                        value: payage[i]
                    });
                }
                vm.paymentType = payment_value[0];
            }
            vm.payWaysShow = vm.payWays;
            //缴费期间映射缴费方式及投被保人年龄限制
            vm.payWayObjs = {};
            if (payTypeConfigs && payTypeConfigs.length > 0) {
                for (var i = 0; i < payTypeConfigs.length; i++) {
                    vm.payWayObjs[payTypeConfigs[i].pay_age] = {
                        pay_age: payTypeConfigs[i].pay_age,
                        map: {
                            maxHolderAge: payTypeConfigs[i].maxHolderAge,
                            max_app_age: payTypeConfigs[i].max_app_age,
                            minHolderAge: payTypeConfigs[i].minHolderAge,
                            min_app_age: payTypeConfigs[i].min_app_age,
                            payment_type: payTypeConfigs[i].payment_type,
                        }
                    };
                }
            }
            // console.log("----- vm.payWayObjs ------");
            // console.log(vm.payWayObjs);
        };
        vm.getPayWay();

        // 默认缴费期间为第一个
        vm.payendyear = vm.payWays[0].value;

        //校验输入金额是否正确
        var validateAmount = function(){
            var validateFlag = true;
                //选择附加险则进行严格校验，未选择则不做校验
                if (vm.addPlan.selectedPlan) {
                    if (vm.addPlan.amount) {
                        validateFlag = true;
                    } else {
                        validateFlag = false;
                    }                
                }

            return validateFlag;
        }

        //校验页面输入项是否合法，并调用计算保费方法
        var validateInfoAndCalc = function(){
            // console.log("validateAmount():"+validateAmount());
            if(vm.user.birthday && vm.user.sex && vm.payendyear && validateAmount()){
                //下一步按钮是否可用
                vm.nextStepValide = true;

                //调用保费计算方法
                vm.calc(vm);

            } else {
                vm.nextStepValide = false;
            }
        }

        //-------------------监听部分----------START-------------
        // 监听用户年龄改变，筛选可选择的交费期间
        $scope.$watch('cena.user', function(newValue) {
            if (newValue) {
                var user = newValue;
                if (user.sex && user.birthday) {
                    var age = VALIDATION.getAgeByBirth(vm.user.birthday);

                    // 重置可用缴费期间列表
                    var payAgeNow = [];
                    var payAgeNowStr = [];
                    for (var i = 0; i < vm.payWays.length; i++) {
                        var mapNow = vm.payWayObjs[vm.payWays[i].value];
                        if (mapNow.map.min_app_age <= age && mapNow.map.max_app_age >= age) {
                            payAgeNow.push(vm.payWays[i]);
                            payAgeNowStr.push(vm.payWays[i].value);
                        }
                    }
                    vm.payWaysShow = payAgeNow;

                    // 如果当前选择的交费期间已不可用，则重新设置默认缴费期间
                    if (vm.payendyear && payAgeNowStr && payAgeNowStr.indexOf(vm.payendyear) == -1) {
                        vm.payendyear = payAgeNowStr[0];
                    }

                    // 重置可用附加险保额列表
                    if (age >= 18 && age <= 40) {
                        vm.addAmountList = [{
                            value: 100,
                            label: 100
                        },{ 
                            value: 200,
                            label: 200
                        },{ 
                            value: 300,
                            label: 300
                        }];
                    } else if (age >= 41 && age <= 50) {
                        vm.addAmountList = [{
                            value: 100,
                            label: 100
                        },{ 
                            value: 200,
                            label: 200
                        }];
                    } else if (age >= 51 && age <= 60) {
                        vm.addAmountList = [{
                            value: 100,
                            label: 100
                        }];
                    }

                    // 如果当前选择的附加险保额已不可用，则附加险保额重置为空
                    var addAmountListArr = [];
                    for (var i = 0; i < vm.addAmountList.length; i++) {
                        addAmountListArr.push(vm.addAmountList[i].value);
                    }
                    if (vm.addPlan.amount && addAmountListArr.indexOf(vm.addPlan.amount) == -1) {
                        vm.addPlan.amount = "";
                        //附加险保额重置后，下一步按钮设置无效，强行重算保费
                        vm.nextStepValide = false;
                        vm.calc(vm);
                    }

                    // console.log("--- payAgeNow ---- payAgeNowStr --addAmountList--");
                    // console.log(payAgeNow);
                    // console.log(payAgeNowStr);
                    // console.log(vm.addAmountList);
                    // console.log(addAmountListArr);
                    // console.log("------------------------------------");

                    //校验页面输入项是否合法，并调用计算保费方法
                    validateInfoAndCalc();
                }
            }
        }, true);

        // 监听保险期间
        $scope.$watch('cena.payendyear', function(newValue) {
            if (newValue) {
                //根据当前用户选择的缴费期间设置可选的投被保人年龄
                if (vm.payendyear && vm.payWayObjs[vm.payendyear]) {
                    setMinAndMaxAges(vm.payWayObjs[vm.payendyear].map);
                }

                //校验页面输入项是否合法，并调用计算保费方法
                validateInfoAndCalc();
            }            
        }, true);

        // 监听主险保额
        $scope.$watch('cena.mainPlan.amount', function(newValue) {
            if (newValue) {
                //校验页面输入项是否合法，并调用计算保费方法
                validateInfoAndCalc();
            }else {
                // 重置保费
                vm.totalExp = 0;
                vm.nextStepValide = false;
            }
        }, true);

        // 监听附加险选择按钮
        $scope.$watch('cena.addPlan.selectedPlan', function(newValue) {
            if (!newValue) {
                vm.addPlan.amount = "";
            }

            //校验页面输入项是否合法，并调用计算保费方法
            validateInfoAndCalc();
        }, true);

        // 监听附加险保额
        $scope.$watch('cena.addPlan.amount', function() {
            //校验页面输入项是否合法，并调用计算保费方法
            validateInfoAndCalc();
        }, true);
        //-------------------监控部分-----------END--------------


        // 计算保费方法
        vm.calc = function(vm, callback) {
            var user = vm.user,
                age = VALIDATION.getAgeByBirth(user.birthday),
                selectedPlan = vm.addPlan.selectedPlan;

            // 获取费率
            var params = {
                prdId: vm.productData.prd_id,
                age: age,
                sex: user.sex,
                payEndYear: vm.payendyear
            };

            CommonRequest.request(params, CONFIG.PRODUCT_PURCHASE_CALCULATE_SERVICE, function(result) {
                if (result.status == 1) {
                    var rateTable = result.data,
                        mainRate = [], // 主险费率表
                        addRate = []; //附加险费率表

                    // 重置保费
                    vm.mainPlan.exp = 0;
                    vm.addPlan.exp = 0;

                    if (rateTable && rateTable.length > 0) {
                        for (var i = 0; i < rateTable.length; i++) {
                            if (rateTable[i].planType == '1') {
                                mainRate.push(rateTable[i]);
                            } else if (rateTable[i].planType == '2') {
                                addRate.push(rateTable[i]);
                            }
                        }

                        //主险费率和保费计算
                        if (mainRate && mainRate.length > 0) {
                            //弱体等级为A时是否有费率，没有则取费率列表第一个
                            var isRisk = false;
                            for (var i = 0; i < mainRate.length; i++) {
                                if (mainRate[i].suppriskscore == "A") {
                                    vm.mainPlan.rate = mainRate[i].rate;
                                    isRisk = true;
                                }
                            }
                            if (!isRisk) {
                                vm.mainPlan.rate = mainRate[0].rate;
                            }

                            //计算主险保费
                            if(vm.mainPlan.rate){
                                vm.mainPlan.exp = vm.mainPlan.amount/vm.mainPlan.insuredAmount * vm.mainPlan.rate;
                            }else{
                                TipService.showMsg(vm.mainPlan.planName + "费率为空！");
                            }
                        }

                        //如果勾选附加险，则进行附加险费率和保费计算
                        if (vm.addPlan.selectedPlan && addRate && addRate.length > 0) {
                            var isRisk = false;
                            for (var i = 0; i < addRate.length; i++) {
                                if (addRate[i].suppriskscore == "A") {
                                    vm.addPlan.rate = addRate[i].rate;
                                    isRisk = true;
                                }
                            }
                            if (!isRisk) {
                                vm.addPlan.rate = addRate[0].rate;
                            }

                            //计算附加险保费
                            if(vm.addPlan.rate){
                                vm.addPlan.exp = vm.addPlan.amount/vm.addPlan.insuredAmount * (vm.addPlan.rate*10)/10;
                            }else{
                                TipService.showMsg(vm.addPlan.planName + "费率为空！");
                            }
                        }
                    } else {
                        TipService.showMsg("费率为空！");
                    }

                    vm.totalAmount = Number(vm.mainPlan.amount) + Number(vm.addPlan.amount);
                    vm.totalExp = Number(vm.mainPlan.exp) + Number(vm.addPlan.exp);

                    callback && callback({
                        exp: vm.totalExp,
                        mainPlan: vm.mainPlan,
                        addPlan: vm.addPlan.selectedPlan == true ? vm.addPlan : null
                    });
                }
            });
        };

        // 跳转投保页面
        vm.goPolicy = function() {

            var params = {
                prdId: vm.productData.prd_id,
                sex: vm.user.sex,
                insurerBirthDay: $filter('date')(vm.user.birthday, 'yyyyMMdd'),
                planId: vm.mainPlan.planId,
                extraPlanId: vm.addPlan.selectedPlan ? vm.addPlan.planId : 0,
                premiumResult: vm.totalExp,
                orderCode: vm.productData.orderCode || ''
            };

            PolicyService.doCalc(params, function() {
                // 数据处理
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'data',
                    data: {
                        birthday: vm.user.birthday, // 被保人生日
                        sex: vm.user.sex, // 被保人性别
                        selectedPlan: vm.addPlan.selectedPlan, //是否选择附加险
                        mainPlan: vm.mainPlan, // 主险
                        addPlan: vm.addPlan.selectedPlan ? vm.addPlan : null, // 附加险
                        payendyear: vm.payendyear, // 缴费期间
                        paymentType: vm.paymentType, // 缴费方式
                        PbInsuAmt: vm.totalAmount, // 保险总保额 
                        PbInsuExp: vm.totalExp, // 保险总保费
                        pbApplNoNum: 1,
                        isWholeSale: vm.paymentType == '0' ? true : false,
                        minAge: vm.minAge,
                        maxAge: vm.maxAge,
                        minHolderAge: vm.minHolderAge,
                        maxHolderAge: vm.maxHolderAge,
                        calc: vm.calc.toString(),
                        calcCtrl: vm
                    }
                });
                // 流程跳转
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'process'
                });
            });
        };
    }

})();