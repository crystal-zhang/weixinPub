(function() {
    'use strict';

    angular
        .module('app')
        .controller('PolicyContactController', PolicyContactController);

    PolicyContactController.$inject = ['$state', 'CommonRequest', 'CONFIG', 'PolicyService', '$scope', '$rootScope', 'TipService'];

    /** @ngInject */
    function PolicyContactController($state, CommonRequest, CONFIG, PolicyService, $scope, $rootScope, TipService) {
        var vm = this;
        vm.iscrossArea = false;
        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        var prodata = vm.prodata = sessionData.productData;

        var insuredata = vm.insureData = sessionData.insureData;

        var policydata = sessionData.policyData;

        if (!prodata) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        // 如果是TAC学生惠产品，则不显示年收入
        // by lixianzhang 2017年5月8日
        vm.yearIncomeShow = true;
        vm.referrerButton = false;
        vm.saleNetAdress = false;
        if (prodata.templateCode == "TAC") {
            vm.yearIncomeShow = false;
        }

        vm.getSalerName = function(salesId) {
            var params = {
                salerId: salesId
            };
            CommonRequest.request(params, CONFIG.GET_SALER_NAME, function(result) {
                if (result.status == 1) {
                    vm.referrerName = result.data.salerName;
                    vm.referrerButton = true;
                }else{
                    vm.referrerName = '';
                    vm.referrerButton = false;
                }
            });
        };

        if (prodata.newSaleChnl && prodata.salesId) {
            vm.salerInfoChanged = false;
            vm.referrerCode = prodata.salesId;
            vm.getSalerName(prodata.salesId);
        }else{
            vm.salerInfoChanged = true;
        }


        // 折扣
        vm.checkDiscount = function(orgCode) {
            if (policydata.configType == '2' || policydata.configType == '3') {
                var params = {
                    prdId: prodata.prd_id,
                    planId: insuredata.mainPlan.planId,
                    channelCode: CONFIG.SALE_CHANNEL,
                    orgCode: orgCode || ''
                };
                PolicyService.getProductDiscount(params, function(result) {
                    vm.discount = result.discount;
                    vm.disActivityId = result.disActivityId;
                    vm.configType = result.configType;
                    vm.hasDiscount = result.hasDiscount;

                    // 更新产品中的是否有折扣标志位-----支付页面用于判断是否支持授权转账
                    sessionData.productData = result.hasDiscount;
                });
            }
        };

        // 选择地区后
        $scope.$on('select-prdarea-close', function(event, result) {
            vm.province = result[0];
            vm.city = result[1];
            vm.district = result[2];

            vm.branch = '';

            if (!vm.province.areaCode) {
                return;
            }

            // 获取一级销售区域
            var code;
            if (vm.city.singletonFlag == '1') {
                code = vm.city.areaCode; // 单列市使用二级地区查询
            } else {
                code = vm.city.parentAreaCode; // 非单列市使用一级地区查询
            }
            vm.usCode = code;
            var config = {
                url: '../statics/product/netpoints/0/netpoint.json',
                method: 'GET'
            };
            CommonRequest.request({}, config, function(result) {
                // if (result.status == 1) {
                var provinceNetList = result;
                if (provinceNetList && provinceNetList.length > 0) {
                    for (var i = 0; i < provinceNetList.length; i++) {
                        if (provinceNetList[i].netCode == code) {
                            vm.branch = provinceNetList[i].netName;
                            vm.provinceNet = provinceNetList[i];
                        }
                    }
                }
                // }
            });

            // 跨区域标识
            if (vm.district.crossAreaFlag == '1') {
                vm.isCrossArea = true;
            } else {
                vm.isCrossArea = false;
            }

            // 代理人
            var params = {
                areaCode: vm.district.areaCode
            };
            var config = {
                url: '../statics/product/proxys/' + vm.district.areaCode + '.json',
                method: 'GET'
            };
            CommonRequest.request(params, config, function(result) {
                // 乡村年平均收入averageIncomeCounty
                // 城镇年平均收入averageIncome
                // 代理人工号staffId
                // 所属机构编码staffOrgCode
                var data = result;

                vm.staffId = data.staffId;
                vm.averageIncome = data.averageIncome;
                vm.averageIncomeCounty = data.averageIncomeCounty;
                vm.staffOrgCode = data.staffOrgCode;

                vm.checkDiscount(vm.staffOrgCode);

                // 默认年收入
                vm.yearIncome = vm.averageIncome;
                if (vm.livePlace == 0) {
                    vm.yearIncome = vm.averageIncome;
                } else if (vm.livePlace == 1) {
                    vm.yearIncome = vm.averageIncomeCounty;
                }
            });
        });

        // 销售网点
        vm.provinceNet = {};
        vm.cityNet = {}
        vm.districtNet = {};

        // 选择销售网点后
        $scope.$on('select-branch-close', function(event, result) {
            vm.provinceNet = result[0];
            vm.cityNet = result[1];
            vm.districtNet = result[2];
        });

        // 具体地区
        vm.livePlace = '0';

        // 监听具体地区变化，获取年收入
        $scope.$watch('policyContact.livePlace', function(newValue) {
            if (newValue == '0') {
                vm.yearIncome = vm.averageIncome;
            } else {
                vm.yearIncome = vm.averageIncomeCounty;
            }
        }, true);

        // 下一步
        vm.next = function() {
            // 所有网点
            if (vm.provinceNet && vm.cityNet && vm.districtNet) {
                var provinceName = vm.provinceNet.netName ? vm.provinceNet.netName : '',
                    cityName = vm.cityNet.netName ? '-' + vm.cityNet.netName : '',
                    districtName = vm.districtNet.netName ? '-' + vm.districtNet.netName : '';
                vm.allWebsite = provinceName + cityName + districtName;
            }

            if (CONFIG.SALE_CHANNEL == "812" || prodata.newSaleChnl == '821') {
                if (vm.provinceNet.netName && vm.cityNet.netName && vm.districtNet.netName) {
                    vm.saleNetAdress = true;
                }
                if (!(vm.saleNetAdress || vm.referrerCode)) {
                    TipService.showMsg("请填写销售网点或推荐人工号！");
                    return;
                }
            }

            // 核心系统要求，TAC学生惠产品年收入字段传比较大的值以绕过规则
            // by lixianzhang 2017年5月31日
            if (prodata.templateCode == "TAC") {
                vm.yearIncome = 500000;
            }

            //年收入前端校验
            if (vm.insureData.isWholeSale) {
                //趸交保费不得超过家庭年收入的4倍。
                if (vm.insureData.PbInsuExp > vm.yearIncome * 4) {
                    TipService.showMsg('趸交保费超过投保人个人年收入的4倍');
                    return;
                };
            } else {
                //非趸交不得超过家庭年收入的20%。
                if (vm.insureData.PbInsuExp > vm.yearIncome / 5) {
                    TipService.showMsg('年期交保费超过投保人个人年收入的20%');
                    return;
                };
            };

            // 数据处理
            PolicyService.control({
                state: 'product-purchase-policy-contact',
                control: 'data',
                data: {
                    agentCode: vm.staffId,
                    BkBrchNo: vm.staffOrgCode, // 机构代码, 根据销售区域获取？？？
                    PbHoldAddr: vm.province.areaCode + ',' + vm.city.areaCode, // 投保人（单位）所在省市区县代码
                    PbHoldPost: vm.zipCode, // 投保人（单位）邮政编码
                    PbHoldOfficTele: '', // 投保人单位联系电话
                    PbHoldHomeAddr: vm.address,
                    PbHoldHomePost: vm.zipCode, // 投保人家庭地址邮政编码
                    PbLivePlace: vm.livePlace, // 居住地区
                    PbYearIncome: vm.yearIncome, // 年收入
                    PbWebsiteCode: vm.districtNet.netCode || '', // 银行网点代码
                    PbWebsiteName: vm.districtNet.netName || '', // 网点名称
                    PbOtherProvinceCode: vm.isCrossArea ? vm.province.areaCode : '', // 所在省代码
                    LiRcgnAddr: vm.address, // 被保人通讯地址
                    LiRcgnPost: vm.zipCode, // 被保人邮政编码
                    bankCodeLV1: vm.provinceNet.netCode || '', //一级分行
                    bankCodeLV2: vm.cityNet.netCode || '', //二级分行
                    bankCodeLV3: vm.districtNet.netCode || '', //三级分行
                    districtCode: vm.province ? vm.province.areaCode : '', // 地区编号
                    liveProvince: vm.province ? vm.province.areaName : '', // 居住省市
                    liveDistrict: vm.city ? vm.city.areaName : '', // 居住地区
                    allWebsite: vm.allWebsite, // 所在网点
                    referrerCode: vm.referrerCode, // 推荐人工号
                    referrerName: vm.referrerName, // 推荐人姓名
                    PlchdProvCd: vm.province.areaCode,
                    PlchdCityCd: vm.city.areaCode,
                    PlchdDstcCd: vm.district.areaCode,
                    liveDstc: vm.district.areaName || '', // 居住区/县
                    crossAreaFlag: vm.isCrossArea ? '1' : '0', // 是否跨区域标识
                    discount: vm.discount || 1,
                    disActivityId: vm.disActivityId || '',
                    configType: vm.configType || '',
                    hasDiscount: vm.hasDiscount || '0'
                }
            });
            // 流程跳转
            PolicyService.control({
                state: 'product-purchase-policy-contact',
                control: 'process'
            });
        };
    }
})();