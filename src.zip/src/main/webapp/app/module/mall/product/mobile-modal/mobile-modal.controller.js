(function() {
    'use strict';

    angular
        .module('app')
        .controller('MobileModalController', MobileModalController);

    MobileModalController.$inject = ['$state', '$rootScope', '$location', 'CONFIG', 'CommonRequest', '$scope', 'COMMON', 'PolicyService', '$document'];
    /** @ngInject */
    function MobileModalController($state, $rootScope, $location, CONFIG, CommonRequest, $scope, COMMON, PolicyService, $document) {

        $scope.phone = '';
        $scope.phoneCode = '';
        $scope.txCode = 'CCBSB100';
        var rootScope = $rootScope;
        // 会员手机登录则带入手机号并不可更改
        var sessionData = PolicyService.getSessionData(),
            productData = sessionData.productData;

        if (sessionData.userData) {
            $scope.phone = sessionData.userData.phoneNo;
        }

        // 关闭弹框
        $scope.cancel = function() {
            COMMON.hideModal();
        };

        // 图形验证码
        $scope.random = Date.parse(new Date()) + Math.random(8);
        $scope.imgpath = CONFIG.SERVICE_ADDRESS + 'new/ImgVerifyCode?random=' + $scope.random;
        $scope.getimg = function() {
            $scope.random = Date.parse(new Date()) + Math.random(8);
            $scope.imgpath = CONFIG.SERVICE_ADDRESS + 'new/ImgVerifyCode?random=' + $scope.random;
        };
        // 监听图形验证码返回结果
        rootScope.$on('send-result',function(erent,data){
            var flag = data.result;
            if(!flag){
                $scope.getimg();
            }
        });
        // 获取验证码
        // $scope.getValidateCode = function() {
        //     var phone = this.phone;
        //     if (phone) {
        //         var params = {
        //             mobileNo: phone,
        //             imageCode: this.code,
        //             random: $scope.random,
        //             txCode: 'CCBSB100'
        //         };
        //         CommonRequest.request(params, CONFIG.SEND_FORGET_MSG_SERVICE, function(result) {
        //             if (result.status != 1) {
        //                 $scope.getimg();
        //             }
        //         });
        //     }
        // };

        // 提交
        $scope.submit = function() {
            var phone = this.phone,
                phoneCode = this.phoneCode;

            if (phone && phoneCode) {
                var params = {
                    prdId: productData.prd_id,
                    mobileNo: phone,
                    smsCode: phoneCode
                };

                CommonRequest.request(params, CONFIG.VALIDATE_CPHONE_SERVICE, function(result) {
                    if (result.status == 1) {
                        var orderCode = result.data.orderCode;
                        // 订单号存入产品数据
                        PolicyService.setSessionData({
                            productData: {
                                orderCode: orderCode,
                                phoneValid: true
                            }
                        });

                        // 数据处理
                        PolicyService.control({
                            state: 'mobile-modal',
                            control: 'data',
                            data: {
                                phoneNo: phone
                            }
                        });
                        // 流程跳转
                        PolicyService.control({
                            state: 'mobile-modal',
                            control: 'process'
                        });

                        COMMON.hideModal();
                    }
                });
            }
        };
    }
})();