(function() {
    'use strict';

    angular
        .module('app')
        .controller('BwlcController', BwlcController);

    BwlcController.$inject = ['$state', 'CONFIG', 'CommonRequest', '$scope', 'VALIDATION', '$rootScope', 'PolicyService', 'TipService', '$filter', '$timeout'];
    /** @ngInject */
    function BwlcController($state, CONFIG, CommonRequest, $scope, VALIDATION, $rootScope, PolicyService, TipService, $filter, $timeout) {
        var vm = this;

        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        vm.productData = sessionData.productData;
        // 非法操作：1. 未获取产品数据 2. 要求做而未做手机验证
        if (!vm.productData || (sessionData.loginStatus != 2 && vm.productData.basicProfile['P005'] == 'Y' && !vm.productData.phoneValid)) {
            TipService.showMsg('非法操作！');
            $state.go('tab.mall');
            return;
        }

        // 初始化开始

        // 用户选择的数据
        vm.user = {};
        vm.user.sex = '1';
        vm.user.birthday = null;
        vm.user.payendyear = '1';
        
        // 日期选择回调
        vm.birthdayCallback = function(val) {
            if (val) {
                vm.user.birthday = val;
                vm.changeConfig();
            }
        };

        // 投被保人年龄
        var payTypeConfigs = vm.productData.payTypeConfigs;
        if (payTypeConfigs && payTypeConfigs.length > 0) {
            var payTypeConfig = payTypeConfigs[0];

            vm.minAge = payTypeConfig.min_app_age;
            vm.maxAge = payTypeConfig.max_app_age;
            vm.minHolderAge = payTypeConfig.minHolderAge;
            vm.maxHolderAge = payTypeConfig.maxHolderAge;

            vm.minStartDate = VALIDATION.getDateByAge(vm.maxAge); // 年龄最小开始日期
            vm.maxEndDate = VALIDATION.getDateByAge(vm.minAge); // 年龄最大结束日期
            vm.holderStartDate = VALIDATION.getDateByAge(vm.maxHolderAge); // 投保人年龄最小开始日期
            vm.holderEndDate = VALIDATION.getDateByAge(vm.minHolderAge); // 投保人年龄最大结束日期
        }

        // 主险数据
        vm.mainPlan = {
            rate: 0,
            amount: '',
            exp: ''
        };

        // 获取产品计划
        vm.getPlan = function() {
            var plan = vm.productData.plans,
                len = plan.length;
            if (plan && plan.length > 0) {
                for (var i = len - 1; i >= 0; i--) {
                    var item = plan[i];
                    if (item.planType == '1') {
                        // 获取主险CNM
                        angular.extend(vm.mainPlan, item);
                    } else if (item.planType == '2') {
                        // 获取附加险MLGB
                        angular.extend(vm.addPlan, item);
                    }
                }

            }

        };
        vm.getPlan();

        // 获取缴费方式
        vm.getPayWay = function() {
            var payment_value = [],
                payage = [];

            vm.payWays = [];

            if (vm.productData.payment_type) {
                payment_value = vm.productData.payment_type.split(',');
            }
            if (vm.productData.pay_age) {
                payage = vm.productData.pay_age.split(',');
            }
            // 从小到大排序缴费年期
            payage.sort(function(a,b){
                return a-b});
            // console.log(payage);

            if (payment_value && payment_value.length > 0) {
                for (var i = 0; i < payment_value.length; i++) {
                    var label;
                    if (payment_value[i] == 12) {
                        label = payage[i] + '年交';
                    } else if (payment_value[i] == 0) {
                        label = '趸交';
                    } else if (payment_value[i] == 1) {
                        label = '月交';
                    } else if (payment_value[i] == 3) {
                        label = '季交';
                    } else if (payment_value[i] == 6) {
                        label = '半年交';
                    }
                    vm.payWays.push({
                        label: label,
                        value: payage[i]
                    });
                }
            }
        };

        // 执行
        vm.getPayWay();

        // 默认缴费期间为第一个
        vm.user.payendyear = vm.payWays[0].value;

        // 不同的缴费方式不同的年龄段
        vm.changeConfig = function() {
            var age = VALIDATION.getAgeByBirth(vm.user.birthday);
            var paymentValue = vm.user.payendyear;
            for (var i = payTypeConfigs.length - 1; i >= 0; i--) {
                if (payTypeConfigs[i].pay_age == paymentValue) {
                    vm.minStartDate = VALIDATION.getDateByAge(payTypeConfigs[i].max_app_age);
                    vm.maxEndDate = VALIDATION.getDateByAge(payTypeConfigs[i].min_app_age);
                    if (payTypeConfigs[i].min_app_age > age || age > payTypeConfigs[i].max_app_age) {
                        var checkMinAge = payTypeConfigs[i].min_app_age == 0 ? '30天' : payTypeConfigs[i].min_app_age + '周岁',
                            checkMaxAge = payTypeConfigs[i].max_app_age == 0 ? '30天' : payTypeConfigs[i].max_app_age + '周岁（包含）';

                        if (paymentValue == '1' && payTypeConfigs[i].payment_type == '0') {
                            TipService.showMsg('趸交：出生满' + checkMinAge + ' -' + checkMaxAge);
                            return false;
                        } else {
                            TipService.showMsg(paymentValue + '年交：出生满' + checkMinAge + ' -' + checkMaxAge);
                            return false;
                        }
                    } else {
                        vm.minAge = payTypeConfigs[i].min_app_age;
                        vm.maxAge = payTypeConfigs[i].max_app_age;
                        vm.minHolderAge = payTypeConfigs[i].minHolderAge;
                        vm.maxHolderAge = payTypeConfigs[i].maxHolderAge;
                        vm.holderStartDate = VALIDATION.getDateByAge(payTypeConfigs[i].maxHolderAge);
                        vm.holderEndDate = VALIDATION.getDateByAge(payTypeConfigs[i].minHolderAge);
                        return true;
                    }
                }
            }
        };

        /**
         *  获取费率表
         *
         *  sex 性别[1-男;2-女];
         *  age 被保人年龄
         *  duration 保单年度
         *  payendyear 缴费期间[1-趸交、5-5年交、10-10年交]
         *  payendyearflag 缴费期间单位[Y-年 M-月 D-日 A-年龄]
         *  payintv 缴费间隔[即缴费频率：0-趸缴、12-年缴、6-半年缴、3-季缴,1-月缴]
         *  getyear 领取期间[被保险人生存至保险期满或约定领取年龄、约定领取时间]
         *  getyearflag 领取期间单位[Y-年;M-月;D-日;A-年龄]
         *  getintv 领取方式[即领取频率：12-年领、6-半年领;3-季领;1-月领]
         *  insuyear 保险期间
         *  nsuyearflag 保险期间单位[Y-年;M-月;D-日;A-年龄]
         *  job 职业等级
         *  suppriskscore 弱体等级[A-0,B-50,C-75,D-100,E-125,F-150,H-200,J-250,L-300,N-350,P-400]
         *  leavemonths 本附加合同最后一期已缴保险费未到期的月数
         *  age01 第一被保人年龄
         *  age02 第二被保人年龄  
         *  rate 费率
         */

        // 监听获取费率
        $scope.$watch('bwlc.user', function() {
            $timeout(function() {
                if ($scope.bwlcForm.$valid) {
                    vm.calc(vm);
                } else {
                    vm.mainPlan.exp = 0;
                }
            }, 100);
        }, true);
        $scope.$watch('bwlc.user.payendyear', function(newValue) {
            if (newValue) {
                if (vm.user.payendyear == '1') {
                    vm.paymentType = '0';
                } else {
                    vm.paymentType = '12';
                }
            }
        }, true);
        $scope.$watch('bwlc.mainPlan.amount', function() {
            $timeout(function() {
                if ($scope.bwlcForm.$valid) {
                    vm.calc(vm);
                } else {
                    vm.mainPlan.exp = 0;
                }
            }, 100);
        }, true);

        // 计算保费方法
        vm.calc = function(vm, callback) {
            var user = vm.user,
                age = VALIDATION.getAgeByBirth(user.birthday);

            // 获取费率
            var params = {
                prdId: vm.productData.prd_id,
                age: age,
                sex: user.sex,
                payEndYear: user.payendyear
            };

            CommonRequest.request(params, CONFIG.PRODUCT_PURCHASE_CALCULATE_SERVICE, function(result) {
                if (result.status == 1) {
                    var rateTable = result.data,
                        mainRate1 = [], // 主险费率表（等级A）
                        mainRate2 = []; // 主险费率表（非等级A）
                    // 重置保费
                    vm.mainPlan.exp = 0;

                    if (rateTable && rateTable.length > 0) {
                        for (var i = 0; i < rateTable.length; i++) {
                            if (rateTable[i].planType == '1') {
                                if (rateTable[i].suppriskscore == 'A') {
                                    mainRate1.push(rateTable[i]);

                                } else {
                                    mainRate2.push(rateTable[i]);
                                }
                            }
                        }

                        if (mainRate1 && mainRate1.length > 0) {
                            // 主险费率
                            vm.mainPlan.rate = mainRate1[0].rate;
                        } else if (mainRate2 && mainRate2.length > 0) {
                            // 主险费率
                            vm.mainPlan.rate = mainRate2[0].rate;
                        }
                        // 计算主险保费
                        vm.mainPlan.exp = ((vm.mainPlan.amount / vm.mainPlan.insuredAmount * vm.mainPlan.rate * 100) / 100).toFixed(2);

                        callback && callback({
                            exp: vm.mainPlan.exp,
                            mainPlan: vm.mainPlan
                        });
                    }
                }
            });
        };

        // 保费校验
        vm.checkExp = function() {
            var exp = vm.mainPlan.exp;
            if (exp) {
                if (exp < 10000 && vm.user.payendyear == '1') {
                    TipService.showMsg('该产品趸交保费不得低于10000元人民币');
                    return false;
                } else if (exp < 5000 && vm.user.payendyear == '3' && vm.productData.prd_code == "CWLA") {
                    TipService.showMsg('该产品3年交保费不得低于5000元人民币');
                    return false;
                } else if (exp < 5000 && vm.user.payendyear == '5') {
                    TipService.showMsg('该产品5年交保费不得低于5000元人民币');
                    return false;
                } else if (exp < 3000 && (vm.user.payendyear == '10' || vm.user.payendyear == '15' || vm.user.payendyear == '20')) {
                    TipService.showMsg('该产品10年、15年、20年交保费不得低于3000元人民币');
                    return false;
                } else {
                    return true;
                }
            }
        };


        // 跳转投保页面
        vm.goPolicy = function() {
            if (!vm.changeConfig()) {
                return;
            }
            if (!vm.checkExp()) {
                return;
            }
            var params = {
                prdId: vm.productData.prd_id,
                sex: vm.user.sex,
                insurerBirthDay: $filter('date')(vm.user.birthday, 'yyyyMMdd'),
                planId: vm.mainPlan.planId,
                premiumResult: vm.mainPlan.exp,
                orderCode: vm.productData.orderCode || ''
            };

            PolicyService.doCalc(params, function() {
                // 数据处理
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'data',
                    data: {
                        birthday: vm.user.birthday, // 被保人生日
                        sex: vm.user.sex, // 被保人性别
                        // selectedPlan: vm.user.selectedPlan, //是否选择附加险
                        mainPlan: vm.mainPlan, // 主险
                        //addPlan: vm.addPlan, // 附加险
                        payendyear: vm.user.payendyear, // 缴费期间
                        paymentType: vm.paymentType, // 缴费方式
                        PbInsuAmt: vm.mainPlan.amount, // 保险总保额 
                        PbInsuExp: vm.mainPlan.exp, // 保险总保费
                        pbApplNoNum: 1,
                        isWholeSale: vm.paymentType == '0' ? true : false,
                        minAge: vm.minAge,
                        maxAge: vm.maxAge,
                        minHolderAge: vm.minHolderAge,
                        maxHolderAge: vm.maxHolderAge,
                        calc: vm.calc.toString(),
                        calcCtrl: vm
                    }
                });
                // 流程跳转
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'process'
                });
            });

        };
    }
})();