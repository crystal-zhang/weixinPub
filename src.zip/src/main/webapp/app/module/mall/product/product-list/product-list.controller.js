(function() {
    'use strict';

    angular
        .module('app')
        .controller('ProductListController', ProductListController);

    ProductListController.$inject = ['$state', '$rootScope', 'CommonRequest', 'CONFIG','$filter','$timeout'];

    /** @ngInject */
    function ProductListController($state, $rootScope, CommonRequest, CONFIG,$filter,$timeout) {
        var vm = this;

        // 默认是"全部保险"
        vm.tag = $state.params.tag || 1;

        // 获取产品列表
        vm.getList = function(tag) {
            vm.products = [];

            if (tag) {
                vm.tag = tag;
                var prdTagCode = 'TAG000' + vm.tag;
                var params = {
                    prdTagCode: 'TAG000' + vm.tag,
                    beginPage: vm.currentPage
                };
                CommonRequest.request(params, CONFIG.PRODUCT_LIST_SERVICE, function(result) {
                    if (result.status == 1) {
                        // vm.products = result.data;
                        var list = result.data;
                        for (var i = 0; i < list.length; i++) {
                            var tagCodeList = list[i].tag_code;
                            for (var j = 0; j < tagCodeList.length; j++) {
                                if (prdTagCode == tagCodeList[j]) {
                                    vm.products.push(list[i]);
                                }
                            }
                        }
                        // if (vm.products.length > 0) {
                        //     vm.getPrdStatus(vm.products);
                        // }
                    }
                    $rootScope.$broadcast('scroll.refreshComplete');
                });
            }
            vm.getPrepareSalePrd();
        };
        // 活动折扣字段获取 PRD_STATUS_SERVICE
        vm.getPrdStatus = function(prdList) {
            var prdIdList = [];
            for (var k = 0; k < prdList.length; k++) {
                prdIdList.push(prdList[k].id);
            }
            var params = {
                prdIds: prdIdList
            }
            CommonRequest.request(params, CONFIG.PRD_STATUS_SERVICE, function(result) {
                if (result.status == 1) {
                    var prdStatusList = result.data;
                    for (var m = 0; m < prdStatusList.length; m++) {
                        for (var n = 0; n < vm.products.length; n++) {
                            if (prdStatusList[m].prdId == vm.products[n].id) {
                                vm.products[n].hasDiscount = prdStatusList[m].hasDiscount;
                                vm.products[n].prd_sale_code = prdStatusList[m].prdSaleCode;
                                vm.products[n].saleAvailFlag = prdStatusList[m].saleAvailFlag;
                            }
                        }
                    }
                }
            });
        };
        vm.getListWithoutCache = function(tag) {
            if (tag) {
                vm.tag = tag;

                var params = {
                    prdTagCode: 'TAG000' + vm.tag,
                    beginPage: vm.currentPage
                };
                CommonRequest.requestWithoutCache(params, CONFIG.PRODUCT_LIST_SERVICE, function(result) {
                    if (result.status == 1) {
                        vm.products = result.data;
                    }
                    $rootScope.$broadcast('scroll.refreshComplete');
                });
            }
        };
	
	 vm.getPrepareSalePrd = function() {
            var params = {};
            CommonRequest.request(params, CONFIG.NEW_SYSPARAM_PREPARESALEPRD, function(result) {
                if (result.status == 1 && result.data) {
                    for (var m = 0; m < result.data.length; m++) {
                        for (var n = 0; n < vm.products.length; n++) {
                            if (result.data[m].prdId == vm.products[n].id) {
                                var date = $filter('date')(new Date(), 'yyyyMMdd');
                                if (date - result.data[m].effectiveTime < 0) {
                                    vm.products[n].prepareSalePrd = '1';
                                }
                            }

                        }
                    }
                }

            });
        }
        vm.loadingPage = function() {
            $timeout(function() {
                if ($rootScope.loadingPage) {
                    vm.getList(vm.tag);
                } else {
                    vm.loadingPage();
                }
            }, 100);
        };
        vm.loadingPage();
    }
})();