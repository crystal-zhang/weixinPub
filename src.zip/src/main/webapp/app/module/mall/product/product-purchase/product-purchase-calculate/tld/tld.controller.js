(function() {
    'use strict';

    angular
        .module('app')
        .controller('TldController', TldController);

    TldController.$inject = ['$state', 'CONFIG', 'CommonRequest', 'VALIDATION', '$scope', '$rootScope', 'PolicyService', 'TipService', '$filter', '$timeout'];
    /** @ngInject */
    function TldController($state, CONFIG, CommonRequest, VALIDATION, $scope, $rootScope, PolicyService, TipService, $filter, $timeout) {
        var vm = this;

        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        vm.productData = sessionData.productData;
        // 非法操作：1. 未获取产品数据 2. 要求做而未做手机验证
        if (!vm.productData || (sessionData.loginStatus != 2 && vm.productData.basicProfile['P005'] == 'Y' && !vm.productData.phoneValid)) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        // 初始化开始

        // 用户选择的数据
        vm.user = {};
        // vm.user.sex = '1';
        vm.user.birthday = null;
        vm.nextStep = true;
        
        // 日期选择回调
        vm.birthdayCallback = function(val) {
            if (val) {
                vm.user.birthday = val;
            }
        };

        // 投被保人年龄
        var payTypeConfigs = vm.productData.payTypeConfigs;
        if (payTypeConfigs && payTypeConfigs.length > 0) {
            var payTypeConfig = payTypeConfigs[0];

            vm.minAge = payTypeConfig.min_app_age;
            vm.maxAge = payTypeConfig.max_app_age;
            vm.minHolderAge = payTypeConfig.minHolderAge;
            vm.maxHolderAge = payTypeConfig.maxHolderAge;

            vm.minStartDate = VALIDATION.getDateByAge(vm.maxAge); // 年龄最小开始日期
            vm.maxEndDate = VALIDATION.getDateByAge(vm.minAge); // 年龄最大结束日期
            vm.holderStartDate = VALIDATION.getDateByAge(vm.maxHolderAge); // 投保人年龄最小开始日期
            vm.holderEndDate = VALIDATION.getDateByAge(vm.minHolderAge); // 投保人年龄最大结束日期
        }

        // 主险数据
        vm.mainPlan = {
            rate: 0,
            amount: '',
            exp: ''
        };

        // 总保额
        vm.totalAmount = vm.mainPlan.amount;
        // 总保费
        vm.totalExp = vm.mainPlan.exp;

        // 获取产品计划
        vm.getPlan = function() {
            var plan = vm.productData.plans,
                len = plan.length;

            for (var i = len - 1; i >= 0; i--) {
                var item = plan[i];
                if (item.planType == '1') {
                    // 获取主险CNM
                    angular.extend(vm.mainPlan, item);
                } else if (item.planType == '2') {
                    // 获取附加险MLGB
                    angular.extend(vm.addPlan, item);
                }
            }
        };
        vm.getPlan();

        // 缴费方式，年缴
        vm.paymentType = vm.productData.payment_type;

        // 缴费期间
        vm.payAge = vm.productData.pay_age;


        // 监听获取费率
        $scope.$watch('tld.user.birthday', function(newvalue) {
            if (newvalue) {
                vm.user.birthdayfm = $filter('date')(vm.user.birthday, 'yyyyMMdd'); //生日
                if (vm.mainPlan.amount && vm.user.sex) {
                    vm.calc(vm);
                }
            }
        }, true);

        $scope.$watch('tld.user.sex', function(newvalue) {
            if (newvalue) {
                if (vm.mainPlan.amount && vm.user.birthday) {
                    vm.calc(vm);
                }
            }
        }, true);

        // 监听用户选择投保保额
        $scope.$watch('tld.insuredAmount', function(newvalue) {
            if (newvalue) {
                vm.amountStr = newvalue;
                vm.newAmount = vm.amountStr.substring(0,2)
                vm.mainPlan.amount = vm.newAmount * 10000;
            }
            if (vm.user.birthday && vm.user.sex) {
                vm.calc(vm);
            }
        }, true);


        //计算保费方法
        vm.calc = function(vm, callback) {
            vm.askPractise = 0;
            var askPractise = function() {
                    vm.askPractise++;
                    if (vm.askPractise > CONFIG.CALCEXP_DECOUPLING_TIMES) {
                        vm.askPractise = 0;
                        TipService.showMsg($rootScope.TIPS.PRODUCT.GETEXPFROMCORE_CALCULATE_FAILED);
                        vm.nextStep = true;
                        return;
                    }

                    var checkPremiumParams = {
                        redisKey: vm.redisKey
                    };

                    CommonRequest.request(checkPremiumParams, CONFIG.PRODUCT_GETEXPFROMREDIS_CALCULATE_SERVICE, function(result) {

                        if (result.status == 1) {

                            var data = result.data;
                            if (data.redisKey) {
                                vm.mainPlan.exp = "";
                                $timeout(function() {
                                    askPractise();
                                }, CONFIG.CALCEXP_DECOUPLING_DURATION);
                                return;
                            }

                            if (data.premiumResult) {
                                var amountExpStr = data.premiumResult;
                                var amountExp = amountExpStr.split(':');
                                vm.askPractise = 0;
                                vm.mainPlan.exp = amountExp[0];
                                // vm.mainPlan.amount = amountExp[1];
                                vm.nextStep = false;
                                callback && callback({
                                    exp: vm.mainPlan.exp,
                                    mainPlan: vm.mainPlan
                                });
                                return;
                            }
                        }
                    });
                }
                // console.log(vm.mainPlan.insuYear);
                // 获取费率
            var calcParams = {
                prdCode: vm.productData.prd_code, //产品code
                prdName: vm.productData.prd_title, //产品名称
                insurerBirthDay: vm.user.birthdayfm, //生日
                sex: vm.user.sex, //性别
                PbInsuAmt: vm.mainPlan.amount, //保额
                insuredDays: vm.mainPlan.insuYear, // 用户选择保障期间的数值
                insuYearFlag: vm.mainPlan.insuYearFlag, //用户选择保障期间单位
                planCode: vm.mainPlan.planCode,
                payendyear: vm.payAge, //缴费期间
                paymentType: vm.paymentType, //缴费方式
                // copies: copies,
                channel: CONFIG.SALE_CHANNEL
            };

            CommonRequest.request(calcParams, CONFIG.PRODUCT_GETEXPFROMCORE_CALCULATE_SERVICE, function(result) {
                if (result.status == 1) {
                    var data = result.data;
                    if (data.redisKey) {
                        vm.redisKey = data.redisKey;
                        askPractise();
                        return;
                    }

                    if (data.premiumResult) {
                        var amountExpStr = data.premiumResult;
                        var amountExp = amountExpStr.split(':');
                        vm.mainPlan.exp = amountExp[0];
                        // vm.mainPlan.amount = amountExp[1];
                        vm.nextStep = false;
                    }

                    callback && callback({
                        exp: vm.mainPlan.exp,
                        mainPlan: vm.mainPlan
                    });

                } else {
                    vm.nextStep = true;
                    return;
                }
            })
        };


        // 跳转投保页面
        vm.goPolicy = function() {
            var params = {
                prdId: vm.productData.prd_id,
                sex: vm.user.sex,
                insurerBirthDay: $filter('date')(vm.user.birthday, 'yyyyMMdd'),
                planId: vm.mainPlan.planId,
                premiumResult: vm.mainPlan.exp,
                orderCode: vm.productData.orderCode || ''
            };

            PolicyService.doCalc(params, function() {
                // 数据处理
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'data',
                    data: {
                        birthday: vm.user.birthday, // 被保人生日
                        sex: vm.user.sex, // 被保人性别
                        //selectedPlan: vm.user.selectedPlan, //是否选择附加险
                        mainPlan: vm.mainPlan, // 主险
                        // addPlan: vm.addPlan, // 附加险
                        payendyear: vm.payAge, // 缴费期间
                        paymentType: vm.paymentType, // 缴费方式
                        //  PbBeginDate: vm.startTime, // 保险生效时间
                        PbInsuAmt: vm.mainPlan.amount, // 保险总保额 
                        PbInsuExp: vm.mainPlan.exp, // 保险总保费
                        pbApplNoNum: 1,
                        isWholeSale: vm.paymentType == '0' ? true : false,
                        minAge: vm.minAge,
                        maxAge: vm.maxAge,
                        minHolderAge: vm.minHolderAge,
                        maxHolderAge: vm.maxHolderAge,
                        calc: vm.calc.toString(),
                        calcCtrl: vm
                    }
                });
                // 流程跳转
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'process'
                });
            });
        };
    }
})();