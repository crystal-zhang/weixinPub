(function() {
    'use strict';

    angular
        .module('app')
        .controller('GroupPolicyAgreementController', GroupPolicyAgreementController);

    GroupPolicyAgreementController.$inject = ['$state', 'GroupPolicyService', 'COMMON', '$scope', '$rootScope'];

    /** @ngInject */
    function GroupPolicyAgreementController($state, GroupPolicyService, COMMON, $scope, $rootScope) {
        var vm = this,
            sessionData = GroupPolicyService.getSessionData();
        vm.productData = sessionData.productData; 
        vm.insureData = sessionData.insureData; 
        vm.policyData = sessionData.policyData; 
        vm.disputeHanding = 1;//默认争议仲裁方式 1：诉讼；2：仲裁
        vm.next = function() {
            GroupPolicyService.control({
                state: "product-purchase-group-policy-agreement",
                control: "data",
                data: {
                    PiZyzcfs: vm.disputeHanding,// 争议仲裁方式 1：诉讼；2：仲裁
                    PiZcinst: vm.disputeGroupName// 仲裁机构名称
                }
            }), GroupPolicyService.control({
                state: "product-purchase-group-policy-agreement",
                control: "process"
            })
        }
    }
})();