(function() {
    'use strict';

    angular
        .module('app')
        .controller('FsbController', FsbController);

    FsbController.$inject = ['$state', 'CONFIG', 'CommonRequest', 'VALIDATION', '$scope', 'PolicyService', 'TipService', '$filter', '$rootScope'];
    /** @ngInject */
    function FsbController($state, CONFIG, CommonRequest, VALIDATION, $scope, PolicyService, TipService, $filter, $rootScope) {
        var vm = this;

        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        vm.productData = sessionData.productData;
        // 非法操作：1. 未获取产品数据 2. 要求做而未做手机验证
        if (!vm.productData || (sessionData.loginStatus != 2 && vm.productData.basicProfile['P005'] == 'Y' && !vm.productData.phoneValid)) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        // 初始化开始

        // 用户选择的数据
        vm.user = {};
        vm.user.sex = '';
        vm.user.birthday = null;

        // 投被保人年龄
        var payTypeConfigs = vm.productData.payTypeConfigs;
        if (payTypeConfigs && payTypeConfigs.length > 0) {
            var payTypeConfig = payTypeConfigs[0];

            vm.minAge = payTypeConfig.min_app_age;
            vm.maxAge = payTypeConfig.max_app_age;
            vm.minHolderAge = payTypeConfig.minHolderAge;
            vm.maxHolderAge = payTypeConfig.maxHolderAge;

            vm.minStartDate = VALIDATION.getDateByAge(vm.maxAge); // 年龄最小开始日期
            vm.maxEndDate = VALIDATION.getDateByAge(vm.minAge); // 年龄最大结束日期
            vm.holderStartDate = VALIDATION.getDateByAge(vm.maxHolderAge); // 投保人年龄最小开始日期
            vm.holderEndDate = VALIDATION.getDateByAge(vm.minHolderAge); // 投保人年龄最大结束日期
        }

        // 主险数据
        vm.mainPlan = {
            rate: 0,
            amount: 0,
            exp: 0
        };

        // 缴费方式，年缴
        vm.paymentType = vm.productData.payment_type;

        // 缴费期间
        vm.payAge = vm.productData.pay_age;

        // 默认保险开始时间
        vm.startTime = new Date();

        // 保险生效日期，不小于当前时间
        var nowDate = new Date();
        vm.minDate = nowDate;
        if (vm.productData.prdSaleCode == 2 && vm.productData.planSaleTime) {
            var planSaleTime = vm.productData.planSaleTime;
            planSaleTime = planSaleTime.substr(0, 4) + '-' + planSaleTime.substr(4, 2) + '-' + planSaleTime.substr(6, 2);
            planSaleTime = new Date(planSaleTime);
            if (planSaleTime.getTime() > nowDate.getTime()) {
                vm.minDate = planSaleTime;
                vm.startTime = planSaleTime;
            }
        }
        // 保险失效日期，不大于当前日期+1年-1天
        vm.maxDate = new Date(vm.minDate.getTime() + 364 * 24 * 60 * 60 * 1000);

        vm.startTime = vm.minDate;

        // 日期选择回调
        vm.startCallback = function(val) {
            if (val) {
                vm.startTime = val;
            }
        };

        // 计算保险截止日期
        vm.getEndTime = function(plan) {
            if (plan) {
                var insuYear = plan.insuYear,
                    insuYearFlag = plan.insuYearFlag,
                    temp;

                if (insuYear && insuYearFlag) {
                    // insuYearFlag Y-年、M-月、D-天、A-年龄
                    switch (insuYearFlag) {
                        case 'Y':
                            temp = parseInt(insuYear) * 365 * 24 * 60 * 60 * 1000;
                            break;
                        case 'M':
                            temp = parseInt(insuYear) * 30 * 24 * 60 * 60 * 1000;
                            break;
                        case 'D':
                            temp = parseInt(insuYear) * 24 * 60 * 60 * 1000;
                            break;
                        case 'A':
                            temp = parseInt(insuYear) * 365 * 24 * 60 * 60 * 1000;
                            break;
                    }

                    vm.endTime = new Date(vm.startTime.getTime() + temp);
                }
            }
        };

        // 选择计划
        vm.selectPlan = function(planId) {
            if (vm.productData.plans && vm.productData.plans.length > 0) {
                for (var i = 0; i < vm.productData.plans.length; i++) {
                    if (vm.productData.plans[i].planId == planId) {
                        vm.selectedPlans = vm.productData.plans[i];

                        vm.getEndTime();
                    }
                }
            }

            // 保费
            vm.mainPlan.exp = vm.selectedPlans.normalPrice;
            // 保额
            vm.mainPlan.amount = vm.selectedPlans.insuredAmount;

            // 此处与官网代码不同
            vm.user.selectedPlan = vm.selectedPlans.planId;
        };

        if (vm.productData.token) {
            PolicyService.getCardInfo(vm.productData.token, function(data) {
                var plId, // 该产品的计划id 
                    duties = data.prmLotDutySetModels; // 计划的责任数组
                if (duties && duties.length > 0) {
                    plId = duties[0].planId;
                }
                if (vm.productData.plans && vm.productData.plans.length > 0) {
                    for (var k = 0; k < vm.productData.plans.length; k++) {
                        var plan = vm.productData.plans[k];
                        // plan.dutys=[];
                        if (plId == plan.planId) {
                            var l1 = duties.length,
                                l2 = plan.dutys.length;
                            if (l1 != l2) {
                                var ilId = duties[0].ilId;
                                for (var m = 0; m < plan.dutys.length; m++) {
                                    if (ilId == plan.dutys[m].dutyId) {
                                        plan.dutys = [plan.dutys[m]];
                                    }
                                }
                            }
                            vm.productData.plans = vm.productData.plans = [plan];
                            break;
                        }
                    }
                    vm.user.selectedPlan = vm.productData.plans[0].planId;
                    vm.selectPlan(vm.user.selectedPlan);
                }
            });
        } else {
            vm.user.selectedPlan = vm.productData.plans[0].planId;
            vm.selectPlan(vm.user.selectedPlan);
        }


        // 监听生效日期，计算截止日期
        $scope.$watch('fsb.startTime', function(newValue) {
            if (newValue) {
                vm.getEndTime(vm.selectedPlans);
            }
        });

        // 监听选择的计划
        $scope.$watch('fsb.user.selectedPlan', function(newValue) {
            if (newValue) {
                vm.plans = []; // 在确认页面显示
                if (vm.productData.plans && vm.productData.plans.length > 0) {
                    for (var i = 0; i < vm.productData.plans.length; i++) {
                        // 此处与官网代码不同
                        if (vm.productData.plans[i].planId == newValue) {
                            vm.selectedPlans = vm.productData.plans[i];
                            angular.extend(vm.mainPlan, vm.selectedPlans);

                            vm.getEndTime();
                        }
                    }
                }
            }
        });

        // 跳转投保页面
        vm.goPolicy = function() {
            var params = {
                prdId: vm.productData.prd_id,
                sex: vm.user.sex,
                insurerBirthDay: $filter('date')(vm.user.birthday, 'yyyyMMdd'),
                planId: vm.selectedPlans.planId,
                premiumResult: vm.mainPlan.exp,
                orderCode: vm.productData.orderCode || ''
            };

            PolicyService.doCalc(params, function() {
                // 数据处理
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'data',
                    data: {
                        // birthday: vm.user.birthday, // 被保人生日
                        // sex: vm.user.sex, // 被保人性别
                        selectedPlan: vm.user.selectedPlan, //是否选择附加险
                        mainPlan: vm.mainPlan, // 主险
                        // addPlan: vm.addPlan, // 附加险
                        payendyear: vm.payAge, // 缴费期间
                        paymentType: vm.paymentType, // 缴费方式
                        PbBeginDate: vm.startTime, // 保险生效时间
                        PbInsuAmt: vm.mainPlan.amount, // 保险总保额 
                        PbInsuExp: vm.productData.token ? 0 : vm.mainPlan.exp, // 保险总保费
                        pbApplNoNum: 1,
                        isWholeSale: vm.paymentType == '0' ? true : false,
                        minAge: vm.minAge,
                        maxAge: vm.maxAge,
                        minHolderAge: vm.minHolderAge,
                        maxHolderAge: vm.maxHolderAge,
                        oldPrice: vm.mainPlan.exp // 赠险前原价
                    }
                });
                // 流程跳转
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'process'
                });
            });
        };
    }
})();