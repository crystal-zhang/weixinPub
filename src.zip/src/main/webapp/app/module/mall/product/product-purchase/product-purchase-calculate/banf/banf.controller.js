(function() {
	'use strict';

	angular
		.module('app')
		.controller('BanfController', BanfController);

	BanfController.$inject = ['$state', 'CONFIG', 'CommonRequest', '$scope', 'VALIDATION', '$rootScope', 'PolicyService', 'TipService', '$filter', '$timeout'];
	/** @ngInject */
	function BanfController($state, CONFIG, CommonRequest, $scope, VALIDATION, $rootScope, PolicyService, TipService, $filter, $timeout) {
		var vm = this;

		var sessionData = PolicyService.getSessionData();

		// 所选产品信息
		vm.productData = sessionData.productData;
        if (!vm.productData || (sessionData.loginStatus != 2 && vm.productData.basicProfile['P005'] == 'Y' && !vm.productData.phoneValid)) {
			// TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
			$state.go('tab.mall');
			return;
		}

		// 用户选择的数据
		vm.user = {
			sex: '1',
			birthday: null
		};
        
        // 日期选择回调
        vm.birthdayCallback = function(val) {
            if (val) {
                vm.user.birthday = val;
            }
        };

	   	// 投被保人年龄
		var payTypeConfigs = vm.productData.payTypeConfigs;
		if (payTypeConfigs && payTypeConfigs.length > 0) {
			var payTypeConfig = payTypeConfigs[0];

			vm.minAge = payTypeConfig.min_app_age;
			vm.maxAge = payTypeConfig.max_app_age;
			vm.minHolderAge = payTypeConfig.minHolderAge;
			vm.maxHolderAge = payTypeConfig.maxHolderAge;
			
			vm.minStartDate = VALIDATION.getDateByAge(vm.maxAge); // 年龄最小开始日期
			vm.maxEndDate = VALIDATION.getDateByAge(vm.minAge); // 年龄最大结束日期
			vm.holderStartDate = VALIDATION.getDateByAge(vm.maxHolderAge); // 投保人年龄最小开始日期
			vm.holderEndDate = VALIDATION.getDateByAge(vm.minHolderAge); // 投保人年龄最大结束日期
		}
		//设置投保人最大最小年龄
		var setMinAndMaxAges = function(obj){
			vm.maxAge = obj.max_app_age;
			vm.minAge = obj.min_app_age;
			vm.minHolderAge = obj.minHolderAge;
			vm.maxHolderAge = obj.maxHolderAge;
			
			vm.minStartDate = VALIDATION.getDateByAge(vm.maxAge); // 年龄最小开始日期
			vm.maxEndDate = VALIDATION.getDateByAge(vm.minAge); // 年龄最大结束日期
			vm.holderStartDate = VALIDATION.getDateByAge(vm.maxHolderAge); // 投保人年龄最小开始日期
			vm.holderEndDate = VALIDATION.getDateByAge(vm.minHolderAge); // 投保人年龄最大结束日期
		};

		// 总保费
		vm.totalExp = "";
		// 总保额
		vm.totalAmount = "";

		// 主险数据
		vm.mainPlan = {
			rate: 0,
			amount: "",
			exp: ""
		};
		// 附加险数据
		vm.addPlan = {
			"BULLPlan": {
				planId:"",
				planCode: "BULL",
				label: "",
				rate: 0,
				amount: 0,
				exp: 0,
				selectedPlan: false
			},
			"BTLAPlan": {
				planId:"",
				planCode: "BTLA",
				label: "",
				rate: 0,
				amount: "",
				exp: "",
				selectedPlan: false
			},
			"BDDHPlan": {
				planId:"",
				planCode: "BDDH",
				label: "",
				rate: 0,
				amount: "",
				exp: "",
				selectedPlan: false
			}
		};


		// 获取产品计划 和 保险期间
		vm.getPlan = function() {
			var plan = vm.productData.plans;
			vm.mainPlanObjs = {};
			vm.securityAgeObjs = [];

			//保险期间单位
            var insuYearLable = {
                "Y":"年",
                "M":"月",
                "D":"天",
                "A":"年龄"
            };

			for (var i = 0; i < plan.length; i++) {
				var item = plan[i];
				if (item.planType == '1') {
					// 以保险期间封装主险对象
					vm.mainPlanObjs[item.insuYear] = {
						insuYear: item.insuYear,
						planObj: item
					};

					// 封装保险期间对象
					vm.securityAgeObjs.push({
						insuYear: item.insuYear,
						label: item.insuYear+insuYearLable[item.insuYearFlag]
					});
				} else if (item.planType == '2') {
					// 获取附加险
					if (item.planCode == "BULL") {
						angular.extend(vm.addPlan.BULLPlan, item);
						vm.addPlan.BULLPlan.label = item.planName;
						vm.addPlan.BULLPlan.planId = item.planId;						
					} else if (item.planCode == "BTLA") {
						angular.extend(vm.addPlan.BTLAPlan, item);
						vm.addPlan.BTLAPlan.label = item.planName;
						vm.addPlan.BTLAPlan.planId = item.planId;						
					} else if (item.planCode == "BDDH") {
						angular.extend(vm.addPlan.BDDHPlan, item);
						vm.addPlan.BDDHPlan.label = item.planName;
						vm.addPlan.BDDHPlan.planId = item.planId;						
					}
				}
			}
		};
		vm.getPlan();


		// 获取缴费方式
		vm.getPayWay = function() {
			var payment_value = [],
				payage = [];
			vm.payWays = [];

			if (vm.productData.payment_type) {
				payment_value = vm.productData.payment_type.split(',');
			}
			if (vm.productData.pay_age) {
				payage = vm.productData.pay_age.split(',');
			}
			if (payment_value && payment_value.length > 0) {
				for (var i = 0; i < payment_value.length; i++) {
					var label;
					if (payment_value[i] == 12) {
						label = payage[i] + '年交';
					} else if (payment_value[i] == 0) {
						label = '趸交';
					} else if (payment_value[i] == 1) {
						label = '月交';
					} else if (payment_value[i] == 3) {
						label = '季交';
					} else if (payment_value[i] == 6) {
						label = '半年交';
					}
					vm.payWays.push({
						label: label,
						value: payage[i]
					});
				}
			}

			//缴费期间映射缴费方式及被保人年龄限制
			var pay_age = [];
			vm.payWayObjs = {};
			if (payTypeConfigs && payTypeConfigs.length > 0) {
				for (var i = 0; i < payTypeConfigs.length; i++) {
					vm.payWayObjs[payTypeConfigs[i].pay_age] = {
						pay_age: payTypeConfigs[i].pay_age,
						map: {
							maxHolderAge: payTypeConfigs[i].maxHolderAge,
							max_app_age: payTypeConfigs[i].max_app_age,
							minHolderAge: payTypeConfigs[i].minHolderAge,
							min_app_age: payTypeConfigs[i].min_app_age,
							payment_type: payTypeConfigs[i].payment_type,
						}
					};
				}
			}
			//console.log(vm.payWayObjs);
		};
		vm.getPayWay();
		//设置默认缴费方式
		vm.user.payendyear = vm.payWays[0].value;


		// 根据缴费年期获取保险期间
		var getSecurityAgesByPayAges = function(payendyear){
			var securityArr = [];
			if (payendyear == "3") {
				for (var i = 0; i < vm.securityAgeObjs.length; i++) {
					if (vm.securityAgeObjs[i].insuYear == "10") {
						securityArr.push(vm.securityAgeObjs[i]);
					}
				}
			} else if (payendyear == "5") {
				for (var i = 0; i < vm.securityAgeObjs.length; i++) {
					if (vm.securityAgeObjs[i].insuYear == "18") {
						securityArr.push(vm.securityAgeObjs[i]);
					}
				}
			} else if (payendyear == "10") {
				for (var i = 0; i < vm.securityAgeObjs.length; i++) {
					if (vm.securityAgeObjs[i].insuYear == "20" || vm.securityAgeObjs[i].insuYear == "30") {
						securityArr.push(vm.securityAgeObjs[i]);
					}
				}
			}

			if (securityArr && securityArr.length>0) {
				vm.user.securityAges = securityArr;
				vm.user.securityAge = securityArr[0].insuYear;
			}
		}
		getSecurityAgesByPayAges(vm.user.payendyear);
		// 设置默认主险数据
		vm.mainPlan = vm.mainPlanObjs[vm.user.securityAge].planObj;


		//根据被保人年龄和主险保费，设置附加险是否可选及其保额最大值和最小值
		var getMinAndMax = function(){
			var user = vm.user;
			if(user.sex && user.birthday){
				var age = VALIDATION.getAgeByBirth(user.birthday);

				if (vm.mainPlan.exp) {
					if (age>=0 && age<18) {
						var maxNum = vm.mainPlan.exp*50 <= 500000 ? vm.mainPlan.exp*50/1000 : "500";
						vm.addPlan.BDDHPlan.maxBuyQautity = maxNum;
						//小于18岁，则BTLA不可选
						vm.addPlan.BTLAPlan.selectedPlan = false;
						vm.addPlan.BTLAPlan.isDisabled = true;
						vm.addPlan.BULLPlan.isDisabled = false;
						vm.addPlan.BDDHPlan.isDisabled = false;
					} else if (age>=18 && age<=40) {
						var maxNum1 = vm.mainPlan.exp*30 <= 400000 ? vm.mainPlan.exp*30/1000 : "400";
						var maxNum2 = vm.mainPlan.exp*50 <= 500000 ? vm.mainPlan.exp*50/1000 : "500";
						vm.addPlan.BTLAPlan.maxBuyQautity = maxNum1;
						vm.addPlan.BDDHPlan.maxBuyQautity = maxNum2;
						vm.addPlan.BTLAPlan.isDisabled = false;
						vm.addPlan.BULLPlan.isDisabled = false;
						vm.addPlan.BDDHPlan.isDisabled = false;
					} else if (age>=41 && age<=50) {
						var maxNum1 = vm.mainPlan.exp*30 <= 300000 ? vm.mainPlan.exp*30/1000 : "300";
						var maxNum2 = vm.mainPlan.exp*50 <= 300000 ? vm.mainPlan.exp*50/1000 : "300";
						vm.addPlan.BTLAPlan.maxBuyQautity = maxNum1;
						vm.addPlan.BDDHPlan.maxBuyQautity = maxNum2;
						vm.addPlan.BTLAPlan.isDisabled = false;
						vm.addPlan.BULLPlan.isDisabled = false;
						vm.addPlan.BDDHPlan.isDisabled = false;
					} else if (age>=51 && age<=60) {
						var maxNum1 = vm.mainPlan.exp*30 <= 200000 ? vm.mainPlan.exp*30/1000 : "200";
						var maxNum2 = vm.mainPlan.exp*50 <= 200000 ? vm.mainPlan.exp*50/1000 : "200";
						vm.addPlan.BTLAPlan.maxBuyQautity = maxNum1;
						vm.addPlan.BDDHPlan.maxBuyQautity = maxNum2;
						vm.addPlan.BTLAPlan.isDisabled = false;
						vm.addPlan.BULLPlan.isDisabled = false;
						vm.addPlan.BDDHPlan.isDisabled = false;
					}else{
						//如果用户年龄大于60岁，则附加险不可选
						vm.addPlan.BULLPlan.selectedPlan = false;
						vm.addPlan.BULLPlan.isDisabled = true;
						vm.addPlan.BTLAPlan.selectedPlan = false;
						vm.addPlan.BTLAPlan.isDisabled = true;
						vm.addPlan.BDDHPlan.selectedPlan = false;
						vm.addPlan.BDDHPlan.isDisabled = true;
					}
				}else{
					//如果主险没有输入保费，则附加险不可选
					vm.addPlan.BULLPlan.selectedPlan = false;
					vm.addPlan.BULLPlan.isDisabled = true;
					vm.addPlan.BTLAPlan.selectedPlan = false;
					vm.addPlan.BTLAPlan.isDisabled = true;
					vm.addPlan.BDDHPlan.selectedPlan = false;
					vm.addPlan.BDDHPlan.isDisabled = true;
				}
			} else {
				//如果用户没有选择生日，则附加险不可选
				vm.addPlan.BULLPlan.selectedPlan = false;
				vm.addPlan.BULLPlan.isDisabled = true;
				vm.addPlan.BTLAPlan.selectedPlan = false;
				vm.addPlan.BTLAPlan.isDisabled = true;
				vm.addPlan.BDDHPlan.selectedPlan = false;
				vm.addPlan.BDDHPlan.isDisabled = true;
			}
		}
		getMinAndMax();


		//判断生日是否有效合法
		var validateBirthday = function(){
			if (vm.user.birthday &&　vm.user.payendyear) {
				var age = VALIDATION.getAgeByBirth(vm.user.birthday);
				if (vm.user.payendyear == "10") {
					//10年缴，主险/附加险最大年龄都为50岁
					if (age>=0 && age<=50) {
						return true;
					}else{
						return false;
					}
				} else if (vm.user.payendyear == "5"){
					//5年缴，主险/附加险最大年龄都为60岁
					if (age>=0 && age<=60) {
						return true;
					}else{
						return false;
					}
				} else if (vm.user.payendyear == "3"){
					//3年缴，主险最大年龄都为65岁，附加险最大年龄都为60岁
					if (vm.addPlan.BTLAPlan.selectedPlan || vm.addPlan.BDDHPlan.selectedPlan) {
						//选择了附加险，则最大只能选60岁
						if (age>=0 && age<=60) {
							return true;
						}else{
							return false;
						}
					} else {
						//不选附加险，则最大可以选到65岁
						if (age>=0 && age<=65) {
							return true;
						}else{
							return false;
						}
					}
				}
			} else {
				return false;
			}
		}

		//验证主险保费和附加险保额是否有效合法
		var validateMoney = function(){
			var moneyFlag = false;

			var user = vm.user;
			if(user.sex && user.birthday){
				//主险保费
				if (vm.mainPlan.exp && vm.mainPlan.exp >= vm.mainPlan.normalPrice * vm.mainPlan.minBuyQautity) {
					moneyFlag = true;

					//附加险保额
					var age = VALIDATION.getAgeByBirth(user.birthday);
					var maxNumBTLA = 0;
					var maxNumBDDH = 0;

					if (age>=0 && age<18) {
						maxNumBDDH = vm.mainPlan.exp*50 <= 500000 ? vm.mainPlan.exp*50 : 500000;
						vm.addPlan.BDDHPlan.maxBuyQautity = maxNumBDDH/1000;
					} else if (age>=18 && age<=40) {
						maxNumBTLA = vm.mainPlan.exp*30 <= 400000 ? vm.mainPlan.exp*30 : 400000;
						maxNumBDDH = vm.mainPlan.exp*50 <= 500000 ? vm.mainPlan.exp*50 : 500000;
						vm.addPlan.BTLAPlan.maxBuyQautity = maxNumBTLA/1000;
						vm.addPlan.BDDHPlan.maxBuyQautity = maxNumBDDH/1000;
					} else if (age>=41 && age<=50) {
						maxNumBTLA = vm.mainPlan.exp*30 <= 300000 ? vm.mainPlan.exp*30 : 300000;
						maxNumBDDH = vm.mainPlan.exp*50 <= 300000 ? vm.mainPlan.exp*50 : 300000;
						vm.addPlan.BTLAPlan.maxBuyQautity = maxNumBTLA/1000;
						vm.addPlan.BDDHPlan.maxBuyQautity = maxNumBDDH/1000;
					} else if (age>=51 && age<=60) {
						maxNumBTLA = vm.mainPlan.exp*30 <= 200000 ? vm.mainPlan.exp*30 : 200000;
						maxNumBDDH = vm.mainPlan.exp*50 <= 200000 ? vm.mainPlan.exp*50 : 200000;
						vm.addPlan.BTLAPlan.maxBuyQautity = maxNumBTLA/1000;
						vm.addPlan.BDDHPlan.maxBuyQautity = maxNumBDDH/1000;
					}

					var amountBTLA = Number(vm.addPlan.BTLAPlan.amount);
					var amountBDDH = Number(vm.addPlan.BDDHPlan.amount);
					if (vm.addPlan.BTLAPlan.selectedPlan) {
						if (amountBTLA && (amountBTLA >= vm.addPlan.BTLAPlan.insuredAmount*vm.addPlan.BTLAPlan.minBuyQautity) && (amountBTLA <= maxNumBTLA)) {
							moneyFlag = true;
						}else{
							moneyFlag = false;
						}
					}
					//console.log("age:"+age +"    amountBTLA:"+amountBTLA +"    maxNumBTLA:"+maxNumBTLA);
					if (vm.addPlan.BDDHPlan.selectedPlan) {
						if (amountBDDH && (amountBDDH >= vm.addPlan.BDDHPlan.insuredAmount*vm.addPlan.BDDHPlan.minBuyQautity) && (amountBDDH <= maxNumBDDH)) {
							moneyFlag = true;
						}else{
							moneyFlag = false;
						}
					}
					//console.log("age:"+age +"    amountBDDH:"+amountBDDH +"    maxNumBDDH:"+maxNumBDDH);
				}else{
					moneyFlag = false;
				}
			}else{
				moneyFlag = false;
			}
			//console.log("moneyFlag:"+moneyFlag);
			return moneyFlag;
		}		

		// 下一步按钮是否可用-默认不可用
		vm.nextStepValide = true;
		// 验证下一步按钮是否可用
		var isNextStepValide = function(){
			//主险信息完整则可用
			if (vm.user.birthday && validateBirthday() && vm.user.sex && vm.mainPlan.exp && validateMoney()) {
				vm.nextStepValide = false;
			}else{
				vm.nextStepValide = true;
			}

			//附加险选择情况下，保额有效则可用（18岁以下不可选择BTLA）
			if (vm.addPlan.BTLAPlan.selectedPlan) {
				if (vm.addPlan.BTLAPlan.amount && VALIDATION.getAgeByBirth(vm.user.birthday)>=18 && validateMoney()) {
					vm.nextStepValide = false;
				} else {
					vm.nextStepValide = true;
				}
			}
			if (vm.addPlan.BDDHPlan.selectedPlan) {
				if (vm.addPlan.BDDHPlan.amount && validateMoney()) {
					vm.nextStepValide = false;
				} else {
					vm.nextStepValide = true;
				}
			}
		}


		//--------------监听页面数据动态变化-----------------------
		// 监听主险-缴费期间
		$scope.$watch('banf.user.payendyear', function(newValue) {
			//console.log("payendyear --- " + newValue);
			if (newValue) {
				//动态设置有效生日期间（设置投保人和被保人最大最小年龄）
				//console.log(vm.payWayObjs[newValue].map);
				setMinAndMaxAges(vm.payWayObjs[newValue].map);

				//更新保险期间可选项
				getSecurityAgesByPayAges(newValue);

				//设置当前主险，同时动态设置最低保费
				//console.log(vm.mainPlanObjs[vm.user.securityAge].planObj);
				var expTemp = vm.mainPlan ? vm.mainPlan.exp : "";
				vm.mainPlan = vm.mainPlanObjs[vm.user.securityAge].planObj;
				vm.mainPlan.exp = expTemp;

				if (vm.user.birthday && validateBirthday() && vm.user.sex && vm.mainPlan.exp && validateMoney()) {
					vm.calcAll(vm);
				}else{
					vm.totalExp = "";
				}
			}
		}, true);

		// 监听主险-保险期间
		$scope.$watch('banf.user.securityAge', function(newValue) {
			//console.log("securityAge --- " + newValue);
			if (newValue && vm.user.payendyear=="10") {
				//设置当前主险，同时动态设置最低保费
				//console.log(vm.mainPlanObjs[vm.user.securityAge].planObj);
				var expTemp = vm.mainPlan ? vm.mainPlan.exp : "";
				vm.mainPlan = vm.mainPlanObjs[vm.user.securityAge].planObj;
				vm.mainPlan.exp = expTemp;

				// 计算保费(payendyear为3/5时，上个监听已执行计算保费方法)
				if (vm.user.birthday && validateBirthday() && vm.user.sex && vm.mainPlan.exp && validateMoney()) {
					vm.calcAll(vm);
				}else{
					vm.totalExp = "";
				}
			}
			
		}, true);

		// 监听获取用户信息
		$scope.$watch('banf.user', function(newValue) {
			var user = newValue;
			if(user.sex && user.birthday){
				var age = VALIDATION.getAgeByBirth(user.birthday);
				
				//根据被保人年龄和主险保费，设置附加险是否可选及其保额最大值和最小值
				getMinAndMax();

				//更新缴费期间列表，大于等于51岁不可选择10年缴
				if (age>=0 && age<=50) {
					vm.getPayWay();
				} else if (age>=51 && age<=60){
					var payment_value = [],
						payage = [];

					vm.payWays = [];

					if (vm.productData.payment_type) {
						payment_value = vm.productData.payment_type.split(',');
					}
					if (vm.productData.pay_age) {
						payage = vm.productData.pay_age.split(',');
					}
					if (payment_value && payment_value.length > 0) {
						for (var i = 0; i < payment_value.length; i++) {
							var label;
							if (payment_value[i] == 12) {
								if(payage[i] != 10){
									label = payage[i] + '年交';
								}
							}
							if(payage[i] != 10){
								vm.payWays.push({
									label: label,
									value: payage[i]
								});
							}
						}

						if (vm.user.payendyear == "10") {
							//设置有效的缴费期间
							vm.user.payendyear = vm.payWays[0].value;
							//设置投保人和被保人最大最小年龄
							setMinAndMaxAges(vm.payWayObjs[vm.payWays[0].value].map);

							//设置保险期间
							getSecurityAgesByPayAges(vm.user.payendyear);
							// 设置默认主险数据
							vm.mainPlan = vm.mainPlanObjs[vm.user.securityAge].planObj;
						}
					}
				}

				//计算保费
				if (vm.user.birthday && validateBirthday() && vm.user.sex && vm.mainPlan.exp && validateMoney()) {
					vm.calcAll(vm);
				}else{
					vm.totalExp = "";
				}
			}
		}, true);

		// 监听主险-用户输入的保费
		$scope.$watch('banf.mainPlan.exp', function(newValue) {
			if (newValue) {
				//根据被保人年龄和主险保费，获取附加险保额最大值和最小值
				getMinAndMax();

				// 计算保费
				if (vm.user.birthday && validateBirthday() && vm.user.sex && vm.mainPlan.exp && validateMoney()) {
					vm.calcAll(vm);
				}else{
					vm.totalExp = "";
				}

				// 验证下一步按钮是否可用
				isNextStepValide();
			}
		}, true);


		// 监听附加险BTLA-用户点击选择按钮
		$scope.$watch('banf.addPlan.BTLAPlan.selectedPlan', function(newValue) {
			if (!vm.addPlan.BTLAPlan.selectedPlan) {
				vm.addPlan.BTLAPlan.amount = "";
				// 计算保费
				if (vm.user.birthday && validateBirthday() && vm.user.sex && vm.mainPlan.exp && validateMoney()) {
					vm.calcAll(vm);
				}else{
					vm.totalExp = "";
				}
			}

			// 验证下一步按钮是否可用
			isNextStepValide();
		}, true);

		// 监听附加险BTLA-用户输入的保额
		$scope.$watch('banf.addPlan.BTLAPlan.amount', function(newValue) {
			if (newValue) {
				if (!vm.addPlan.BTLAPlan.selectedPlan) {
					vm.addPlan.BTLAPlan.amount = "";
				}
				// 计算保费
				if (vm.addPlan.BTLAPlan.selectedPlan && vm.addPlan.BTLAPlan.amount) {
					vm.calcAll(vm);
				}
			}

			// 验证下一步按钮是否可用
			isNextStepValide();				
		}, true);


		// 监听附加险BDDH-用户点击选择按钮
		$scope.$watch('banf.addPlan.BDDHPlan.selectedPlan', function(newValue) {
			//校验页面所有表单数据有效性
			if (!vm.addPlan.BDDHPlan.selectedPlan) {
				vm.addPlan.BDDHPlan.amount = "";
				// 计算保费
				if (vm.user.birthday && validateBirthday() && vm.user.sex && vm.mainPlan.exp && validateMoney()) {
					vm.calcAll(vm);
				}else{
					vm.totalExp = "";
				}
			}

			// 验证下一步按钮是否可用
			isNextStepValide();
		}, true);

		// 监听附加险BDDH-用户输入的保额
		$scope.$watch('banf.addPlan.BDDHPlan.amount', function(newValue) {
			if (newValue) {
				if (!vm.addPlan.BDDHPlan.selectedPlan) {
					vm.addPlan.BDDHPlan.amount = "";
				}
				// 计算保费
				if (vm.addPlan.BDDHPlan.selectedPlan && vm.addPlan.BDDHPlan.amount) {
					vm.calcAll(vm);
				}
			}
			
			// 验证下一步按钮是否可用
			isNextStepValide();
		}, true);
		//--------------监听页面数据动态变化---------END--------------


		// 计算保费方法
		vm.calcAll = function(vm) {

			// 验证下一步按钮是否可用
			isNextStepValide();

            var user = vm.user,
                age = VALIDATION.getAgeByBirth(user.birthday);

			// 获取费率
			var params = {
				prdId: vm.productData.prd_id,
				age: age,
				sex: user.sex,
				payEndYear: vm.user.payendyear
			};

			CommonRequest.request(params, CONFIG.PRODUCT_PURCHASE_CALCULATE_SERVICE, function(result) {
				//console.log(result);
				if (result.status == 1) {
					var rateTable = result.data,
						mainRate = [], // 主险费率表
						BTLAAddRate = [], //附加险BTLA费率表
						BDDHAddRate = []; //附加险BDDH费率表

					//重置总保额和总保费
					vm.totalAmount = "";
					vm.totalExp = "";

					if (rateTable && rateTable.length > 0) {
						for (var i = 0; i < rateTable.length; i++) {
							if (rateTable[i].planType == '1' && 
								rateTable[i].payendyear == vm.user.payendyear && 
								rateTable[i].insuyear == vm.user.securityAge) {
								mainRate.push(rateTable[i]);
							} else if (rateTable[i].planType == '2') {
								if (rateTable[i].planCode == "BTLA" && 
									rateTable[i].payendyear == vm.user.payendyear && 
									rateTable[i].insuyear == vm.user.securityAge) {
									BTLAAddRate.push(rateTable[i]);
								} else if (rateTable[i].planCode == "BDDH" && 
									rateTable[i].payendyear == vm.user.payendyear && 
									rateTable[i].insuyear == vm.user.securityAge) {
									BDDHAddRate.push(rateTable[i]);
								}
							}
						}

						// 获取主险费率，计算主险保额
						if (mainRate && mainRate.length > 0) {
							//弱体等级为A时是否有费率，没有则取费率列表第一个
							var isRisk = false;
							for (var i = 0; i < mainRate.length; i++) {
                                if (mainRate[i].suppriskscore == "A") {
                                    vm.mainPlan.rate = mainRate[i].rate;
                                    isRisk = true;
                                }
							}
							if (!isRisk) {
								vm.mainPlan.rate = mainRate[0].rate;
							}

							//计算主险保额
							if (vm.mainPlan && vm.user.birthday && validateBirthday() && vm.user.sex && vm.mainPlan.exp && validateMoney()) {
								vm.mainPlan.amount = vm.mainPlan.exp / vm.mainPlan.normalPrice * vm.mainPlan.rate;
							}
						}

						// 获取附加险BTLA费率，计算附加险BTLA保费
						if (BTLAAddRate && BTLAAddRate.length > 0) {
							//弱体等级为A时是否有费率，没有则取费率列表第一个
							var isRisk = false;
							for (var i = 0; i < BTLAAddRate.length; i++) {
                                if (BTLAAddRate[i].suppriskscore == "A") {
                                    vm.addPlan.BTLAPlan.rate = BTLAAddRate[i].rate;
                                    isRisk = true;
                                }
							}
							if (!isRisk) {
								vm.addPlan.BTLAPlan.rate = BTLAAddRate[0].rate;
							}

							//计算附加险BTLA保费
							if (vm.addPlan.BTLAPlan.selectedPlan && vm.addPlan.BTLAPlan.amount) {
								vm.addPlan.BTLAPlan.exp = (parseInt(10 * vm.addPlan.BTLAPlan.rate * 1.000 + 0.5) / 10 * (vm.addPlan.BTLAPlan.amount / vm.addPlan.BTLAPlan.insuredAmount)).toFixed(2);
							} else {
								vm.addPlan.BTLAPlan.exp = 0;
							}
						}else{
						   if(vm.addPlan.BTLAPlan.amount) {
								TipService.showMsg("附加龙行富贵定期寿险费率为空！");
							} 
						}

						// 获取附加险BDDH费率，计算附加险BDDH保费
						if (BDDHAddRate && BDDHAddRate.length > 0) {
							//弱体等级为A时是否有费率，没有则取费率列表第一个
							var isRisk = false;
							for (var i = 0; i < BDDHAddRate.length; i++) {
                                if (BDDHAddRate[i].suppriskscore == "A") {
                                    vm.addPlan.BDDHPlan.rate = BDDHAddRate[i].rate;
                                    isRisk = true;
                                }
							}
							if (!isRisk) {
								vm.addPlan.BDDHPlan.rate = BDDHAddRate[0].rate;
							}

							//计算附加险BDDH保费
							if (vm.addPlan.BDDHPlan.selectedPlan && vm.addPlan.BDDHPlan.amount) {
								vm.addPlan.BDDHPlan.exp = (parseInt(10 * vm.addPlan.BDDHPlan.rate * 1.000 + 0.5) / 10 * (vm.addPlan.BDDHPlan.amount / vm.addPlan.BDDHPlan.insuredAmount)).toFixed(2);
							} else {
								vm.addPlan.BDDHPlan.exp = 0;
							}
						}else{
							if(vm.addPlan.BDDHPlan.amount) {
								TipService.showMsg("附加龙行富贵重大疾病保险条款费率为空！");
							}
						}
					}
					//console.log("--------------------------");
					//console.log("vm.mainPlan.rate:"+vm.mainPlan.rate);
					//console.log("vm.addPlan.BTLAPlan.rate:"+vm.addPlan.BTLAPlan.rate);
					//console.log("vm.addPlan.BDDHPlan.rate:"+vm.addPlan.BDDHPlan.rate);

					vm.totalAmount = Number(vm.mainPlan.amount) + Number(vm.addPlan.BTLAPlan.amount) + Number(vm.addPlan.BDDHPlan.amount);
					vm.totalExp = Number(vm.mainPlan.exp) + Number(vm.addPlan.BTLAPlan.exp) + Number(vm.addPlan.BDDHPlan.exp);
					//console.log("totalAmount:"+vm.totalAmount);
					//console.log("totalExp:"+vm.totalExp);
				}
			});
		};

		// 跳转投保页面
		vm.goPolicy = function() {
			var extraPlanIdArr = [];
			var isSelectAddPlan = false;
			var selectAddPlanObjs = [];
			if (vm.addPlan.BULLPlan.selectedPlan || vm.addPlan.BTLAPlan.selectedPlan || vm.addPlan.BDDHPlan.selectedPlan) {
				if (vm.addPlan.BULLPlan.selectedPlan) {
					isSelectAddPlan = true;
					extraPlanIdArr.push(vm.addPlan.BULLPlan.planId);
					selectAddPlanObjs.push(vm.addPlan.BULLPlan);
				} 
				if (vm.addPlan.BTLAPlan.selectedPlan) {
					isSelectAddPlan = true;
					extraPlanIdArr.push(vm.addPlan.BTLAPlan.planId);
					selectAddPlanObjs.push(vm.addPlan.BTLAPlan);
				} 
				if (vm.addPlan.BDDHPlan.selectedPlan) {
					isSelectAddPlan = true;
					extraPlanIdArr.push(vm.addPlan.BDDHPlan.planId);
					selectAddPlanObjs.push(vm.addPlan.BDDHPlan);
				}
			} else{
				isSelectAddPlan = false;
			}

            vm.mainPlan.exp = vm.mainPlan.exp.toString();
            vm.mainPlan.amount = vm.mainPlan.amount.toString();
			var params = {
				prdId: vm.productData.prd_id,
				sex: vm.user.sex,
				insurerBirthDay: $filter('date')(vm.user.birthday, 'yyyyMMdd'),
				planId: vm.mainPlan.planId,
				extraPlanId: extraPlanIdArr ? extraPlanIdArr : 0,
				premiumResult: vm.totalExp,
				orderCode: vm.productData.orderCode || ''
			};

			PolicyService.doCalc(params, function() {
				// 数据处理
				PolicyService.control({
					state: 'product-purchase-calculate',
					control: 'data',
					data: {
						birthday: $filter('date')(vm.user.birthday, 'yyyy-MM-dd'), // 被保人生日
						sex: vm.user.sex, // 被保人性别
						selectedPlan: isSelectAddPlan, //vm.user.selectedPlan, //是否选择附加险
						mainPlan: vm.mainPlan, // 主险
						addPlan: selectAddPlanObjs,  //vm.addPlan, // 附加险
						payendyear: vm.user.payendyear, // 缴费期间
						paymentType: "12", // 缴费方式
						PbInsuAmt: vm.totalAmount, // 保险总保额
						PbInsuExp: vm.totalExp, // 保险总保费
						pbApplNoNum: 1,
						isWholeSale: vm.paymentType == '0' ? true : false,
						minAge: vm.minAge,
						maxAge: vm.maxAge,
						minHolderAge: vm.minHolderAge,
						maxHolderAge: vm.maxHolderAge,
						calc: vm.calcForInfo.toString(),
                        calcCtrl: vm
					}
				});
				// 流程跳转
				PolicyService.control({
					state: 'product-purchase-calculate',
					control: 'process'
				});
			});
		};
		

		/*
		 * 为投保信息页面重新测算保费提供计算方法
		 */
		vm.calcForInfo = function(vm, callback){
			vm.mainPlan.rate = 0;
			vm.addPlan.BTLAPlan.rate = 0;
			vm.addPlan.BDDHPlan.rate = 0;

			//根据被保人年龄和主险保费，验证附加险保额最大值和最小值是否合法
			var validateMinAndMaxAmount = function(){
				var user = vm.user;
				if(user.sex && user.birthday){
					var age = VALIDATION.getAgeByBirth(user.birthday);
					var maxNumBTLA = "";
					var maxNumBDDH = "";

					if (age>=0 && age<18) {
						maxNumBDDH = vm.mainPlan.exp*50 <= 500000 ? vm.mainPlan.exp*50 : "500000";
					} else if (age>=18 && age<=40) {
						maxNumBTLA = vm.mainPlan.exp*30 <= 400000 ? vm.mainPlan.exp*30 : "400000";
						maxNumBDDH = vm.mainPlan.exp*50 <= 500000 ? vm.mainPlan.exp*30 : "500000";
					} else if (age>=41 && age<=50) {
						maxNumBTLA = vm.mainPlan.exp*30 <= 300000 ? vm.mainPlan.exp*30 : "300000";
						maxNumBDDH = vm.mainPlan.exp*50 <= 300000 ? vm.mainPlan.exp*30 : "300000";
					} else if (age>=51 && age<=60) {
						maxNumBTLA = vm.mainPlan.exp*30 <= 200000 ? vm.mainPlan.exp*30 : "200000";
						maxNumBDDH = vm.mainPlan.exp*50 <= 200000 ? vm.mainPlan.exp*30 : "200000";
					}

					var amountBTLA = vm.addPlan.BTLAPlan.amount;
					var amountBDDH = vm.addPlan.BDDHPlan.amount;
					//console.log("age:"+age +"    amountBTLA:"+amountBTLA +"    maxNumBTLA:"+maxNumBTLA);
					if (vm.addPlan.BTLAPlan.selectedPlan && (age>0 && age<18)) {
                        $ionicPopup.alert({
                            title: '温馨提示',
                            template: "投保附加龙行富贵定期寿险时，投保人最小年龄为18岁！",
                            okText: '我知道了'
                        });
                        return false;
					}else{
						return true;
					}
					if (vm.addPlan.BTLAPlan.selectedPlan && (amountBTLA > maxNumBTLA)) {
                        $ionicPopup.alert({
                            title: '温馨提示',
                            template: "当被保人为" + age + "岁时，附加龙行富贵定期寿险最大保额为" + maxNumBTLA + "元！",
                            okText: '我知道了'
                        });
                        return false;
					}else{
						return true;
					}
					//console.log("age:"+age +"    amountBDDH:"+amountBDDH +"    maxNumBDDH:"+maxNumBDDH);
					if (vm.addPlan.BDDHPlan.selectedPlan && (amountBDDH > maxNumBDDH)) {
                        $ionicPopup.alert({
                            title: '温馨提示',
                            template: "当被保人为" + age + "岁时，附加龙行富贵重大疾病保险最大保额为" + maxNumBDDH + "元！",
                            okText: '我知道了'
                        });
                        return false;
					}else{
						return true;
					}
				}
			}
			//验证
			if(!validateMinAndMaxAmount()){
				return false;
			}

			//封装已选择的附加险数组对象
			var selectAddPlanObjs = [];
			if (vm.addPlan.BULLPlan.selectedPlan) {
				selectAddPlanObjs.push(vm.addPlan.BULLPlan);
			} 
			if (vm.addPlan.BTLAPlan.selectedPlan) {
				selectAddPlanObjs.push(vm.addPlan.BTLAPlan);
			} 
			if (vm.addPlan.BDDHPlan.selectedPlan) {
				selectAddPlanObjs.push(vm.addPlan.BDDHPlan);
			}

			//计算
			var calcAll = function(vm, callback){
	            var user = vm.user,
	                age = VALIDATION.getAgeByBirth(user.birthday);

				// 获取费率
				var params = {
					prdId: vm.productData.prd_id,
					age: age,
					sex: user.sex,
					payEndYear: vm.user.payendyear
				};

				CommonRequest.request(params, CONFIG.PRODUCT_PURCHASE_CALCULATE_SERVICE, function(result) {
					//console.log(result);
					if (result.status == 1) {
						var rateTable = result.data,
							mainRate = [], // 主险费率表
							BTLAAddRate = [], //附加险BTLA费率表
							BDDHAddRate = []; //附加险BDDH费率表

						//重置总保额和总保费
						vm.totalAmount = "";
						vm.totalExp = "";

						if (rateTable && rateTable.length > 0) {
							for (var i = 0; i < rateTable.length; i++) {
								if (rateTable[i].planType == '1' && 
									rateTable[i].payendyear == vm.user.payendyear && 
									rateTable[i].insuyear == vm.user.securityAge) {
									mainRate.push(rateTable[i]);
								} else if (rateTable[i].planType == '2') {
									if (rateTable[i].planCode == "BTLA" && 
										rateTable[i].payendyear == vm.user.payendyear && 
										rateTable[i].insuyear == vm.user.securityAge) {
										BTLAAddRate.push(rateTable[i]);
									} else if (rateTable[i].planCode == "BDDH" && 
										rateTable[i].payendyear == vm.user.payendyear && 
										rateTable[i].insuyear == vm.user.securityAge) {
										BDDHAddRate.push(rateTable[i]);
									}
								}
							}

							// 获取主险费率，计算主险保额
							if (mainRate && mainRate.length > 0) {
								//弱体等级为A时是否有费率，没有则取费率列表第一个
								var isRisk = false;
								for (var i = 0; i < mainRate.length; i++) {
	                                if (mainRate[i].suppriskscore == "A") {
	                                    vm.mainPlan.rate = mainRate[i].rate;
	                                    isRisk = true;
	                                }
								}
								if (!isRisk) {
									vm.mainPlan.rate = mainRate[0].rate;
								}

								//计算主险保额
								if (vm.mainPlan && vm.user.birthday && vm.user.sex && vm.mainPlan.exp) {
									vm.mainPlan.amount = vm.mainPlan.exp / vm.mainPlan.normalPrice * vm.mainPlan.rate;
								}
							}

							// 获取附加险BTLA费率，计算附加险BTLA保费
							if (BTLAAddRate && BTLAAddRate.length > 0) {
								//弱体等级为A时是否有费率，没有则取费率列表第一个
								var isRisk = false;
								for (var i = 0; i < BTLAAddRate.length; i++) {
	                                if (BTLAAddRate[i].suppriskscore == "A") {
	                                    vm.addPlan.BTLAPlan.rate = BTLAAddRate[i].rate;
	                                    isRisk = true;
	                                }
								}
								if (!isRisk) {
									vm.addPlan.BTLAPlan.rate = BTLAAddRate[0].rate;
								}

								//计算附加险BTLA保费
								if (vm.addPlan.BTLAPlan.selectedPlan && vm.addPlan.BTLAPlan.amount) {
									vm.addPlan.BTLAPlan.exp = (parseInt(10 * vm.addPlan.BTLAPlan.rate * 1.000 + 0.5) / 10 * (vm.addPlan.BTLAPlan.amount / vm.addPlan.BTLAPlan.insuredAmount)).toFixed(2);
								} else {
									vm.addPlan.BTLAPlan.exp = 0;
								}
							}else{
							   if(vm.addPlan.BTLAPlan.amount) {
									TipService.showMsg("附加龙行富贵定期寿险费率为空！");
								} 
							}

							// 获取附加险BDDH费率，计算附加险BDDH保费
							if (BDDHAddRate && BDDHAddRate.length > 0) {
								//弱体等级为A时是否有费率，没有则取费率列表第一个
								var isRisk = false;
								for (var i = 0; i < BDDHAddRate.length; i++) {
	                                if (BDDHAddRate[i].suppriskscore == "A") {
	                                    vm.addPlan.BDDHPlan.rate = BDDHAddRate[i].rate;
	                                    isRisk = true;
	                                }
								}
								if (!isRisk) {
									vm.addPlan.BDDHPlan.rate = BDDHAddRate[0].rate;
								}

								//计算附加险BDDH保费
								if (vm.addPlan.BDDHPlan.selectedPlan && vm.addPlan.BDDHPlan.amount) {
									vm.addPlan.BDDHPlan.exp = (parseInt(10 * vm.addPlan.BDDHPlan.rate * 1.000 + 0.5) / 10 * (vm.addPlan.BDDHPlan.amount / vm.addPlan.BDDHPlan.insuredAmount)).toFixed(2);
								} else {
									vm.addPlan.BDDHPlan.exp = 0;
								}
							}else{
								if(vm.addPlan.BDDHPlan.amount) {
									TipService.showMsg("附加龙行富贵重大疾病保险条款费率为空！");
								}
							}
						}
						//console.log("--------------------------");
						//console.log("vm.mainPlan.rate:"+vm.mainPlan.rate);
						//console.log("vm.addPlan.BTLAPlan.rate:"+vm.addPlan.BTLAPlan.rate);
						//console.log("vm.addPlan.BDDHPlan.rate:"+vm.addPlan.BDDHPlan.rate);

						vm.totalAmount = Number(vm.mainPlan.amount) + Number(vm.addPlan.BTLAPlan.amount) + Number(vm.addPlan.BDDHPlan.amount);
						vm.totalExp = Number(vm.mainPlan.exp) + Number(vm.addPlan.BTLAPlan.exp) + Number(vm.addPlan.BDDHPlan.exp);
						//console.log("totalAmount:"+vm.totalAmount);
						//console.log("totalExp:"+vm.totalExp);

						callback(vm.totalAmount, vm.totalExp);
					}
				});
			}
			calcAll(vm, function(totalAmount, totalExp){
				//console.log("-----------callback---------------");
				callback({
					exp: totalExp,
					amount: totalAmount,
					mainPlan: vm.mainPlan,
					addPlan: selectAddPlanObjs
				});
			});
		};
	}
})();
