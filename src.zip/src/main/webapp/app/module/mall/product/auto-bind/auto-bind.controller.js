(function() {
    'use strict';

    angular
        .module('app')
        .controller('AutoBindController', AutoBindController);

    AutoBindController.$inject = ['$state', '$rootScope', '$location', 'CONFIG', 'CommonRequest', '$scope', 'COMMON', 'PolicyService', 'VALIDATION'];
    /** @ngInject */
    function AutoBindController($state, $rootScope, $location, CONFIG, CommonRequest, $scope, COMMON, PolicyService, VALIDATION) {

        $scope.phone = '';
        $scope.phoneCode = '';
        $scope.txCode = 'CCBSB109';

        var rootScope = $rootScope;
        var sessionData = PolicyService.getSessionData()

        if (sessionData.policyData) {
            $scope.policyData = sessionData.policyData;
            $scope.phone = $scope.policyData.PbHoldMobl;
        }

        // 关闭弹框
        $scope.cancel = function() {
            COMMON.hideModal();
        };

        // 图形验证码
        $scope.random = Date.parse(new Date()) + Math.random(8);
        $scope.imgpath = CONFIG.SERVICE_ADDRESS + 'new/ImgVerifyCode?random=' + $scope.random;
        $scope.getimg = function() {
            $scope.random = Date.parse(new Date()) + Math.random(8);
            $scope.imgpath = CONFIG.SERVICE_ADDRESS + 'new/ImgVerifyCode?random=' + $scope.random;
        };
        // 监听图形验证码返回结果
        rootScope.$on('send-result', function(erent, data) {
            var flag = data.result;
            if (!flag) {
                $scope.getimg();
            }
        });

        // 提交
        $scope.submit = function() {
            var phone = this.phone,
                phoneCode = this.phoneCode;

            if (phone && phoneCode) {
                var params = {
                    CusThirtyModel: {
                        thirtyCode: $rootScope.openid
                    },
                    customerName: $scope.policyData.PbHoldName,
                    sex: $scope.policyData.PbHoldSex,
                    bronToString: VALIDATION.dateFormat($scope.policyData.PbHoldBirdy),
                    cretNo: $scope.policyData.PbHoldId,
                    cretType: $scope.policyData.PbHoldIdType,
                    CCBSBCODE: 'CCBSB109',
                    PhoneNo: phone,
                    PhoneIdCode: phoneCode
                };

                CommonRequest.request(params, CONFIG.WECHAT_BIND_SERVCIE, function(result) {
                    if (result.status == 1) {
                        $rootScope.isBinding = true;
                        $scope.cancel();
                    }
                });
            }
        };
    }
})();