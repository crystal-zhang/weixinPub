(function() {
    'use strict';

    angular
        .module('app')
        .controller('PolicyAgreementController', PolicyAgreementController);

    PolicyAgreementController.$inject = ['$state', 'PolicyService', 'COMMON', '$scope', '$rootScope'];

    /** @ngInject */
    function PolicyAgreementController($state, PolicyService, COMMON, $scope, $rootScope) {

        var vm = this;

        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        vm.productData = sessionData.productData;
        if (!vm.productData) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }
        // 投保人信息
        var userdata = vm.userdata = sessionData.userData;
        // 被保人信息
        var insuredata = vm.insuredata = sessionData.insureData;

        // 保单信息
        var policydata = vm.policydata = sessionData.policyData;
        var BkBrchNo; // 机构代码
        if (policydata) {
            BkBrchNo = policydata.BkBrchNo;
        }

        // 户名
        if (policydata.PbHoldName) {
            vm.newGetAccountName = policydata.PbHoldName; // 授权转账银行户名
            vm.authAccountName = policydata.PbHoldName; // 给付账户信息银行户名
            vm.bonusBankAccountName = policydata.PbHoldName; // 年金领取方式银行户名
            vm.liBonusBankAccountName = policydata.PbHoldName; // 红利领取方式银行户名
            vm.renewalBankAccountName = policydata.PbHoldName; // 续费账户信息银行户名
        }

        // 年金
        vm.renteDrawMode = '1';

        // 红利
        vm.bonusGetMode = '2';

        // 续期
        vm.isBatts = vm.productData.isBatts || '1';

        // 给付


        // 授权转账
        vm.newPayMode = '7';

        // 争议方式
        vm.disputeHanding = 1;

        // 是否续期判断
        vm.showRenewal1 = false;
        vm.showRenewal2 = false;
        if (vm.productData.basicProfile.P010 == 'Y') {
            // 产品支持续期
            if (vm.isBatts == '1') {
                $scope.$watch('policyAgreement.isBatts', function(newValue) {
                    if (newValue == '1') {
                        vm.showRenewal1 = true;
                    } else {
                        vm.showRenewal1 = false;
                    }
                });
            }
            if (vm.insuredata.isWholeSale) {
                // 趸交
                vm.showRenewal2 = false;
            } else {
                if (vm.productData.templateCode.toLowerCase() == 'ipah'||vm.productData.templateCode.toLowerCase() == 'tld'||vm.productData.templateCode.toLowerCase() == 'hmra') {
                    // 龙行无忧
                    vm.showRenewal2 = false;
                } else {
                    vm.showRenewal2 = true;
                }
            }
        }

        // 当机构code有值时获取支付银行列表,2代表公司付款
        vm.getBankList1 = function() {
            if (BkBrchNo) {
                COMMON.getCommonBank(BkBrchNo, '2', function(bankList) {
                    vm.bankList2 = bankList;
                    if (vm.bankList2 && vm.bankList2.length > 0) {
                        vm.authBank = bankList[0]; // 给付账户信息银行
                        vm.bonusBank = bankList[0]; // 红利领取方式银行
                        vm.yearMoneyBank = bankList[0]; // 年金领取方式银行
                    }
                });
            }
        };

        vm.getBankList1();

        // 当机构code有值时获取支付银行列表,1代表公司收款
        vm.getBankList2 = function() {
            if (BkBrchNo) {
                COMMON.getCommonBank(BkBrchNo, '1', function(bankList) {
                    vm.bankList1 = bankList;
                    if (vm.bankList && vm.bankList.length > 0) {
                        vm.newGetBkCode = bankList[0]; // 授权转帐银行
                        vm.renewalBancCode = bankList[0]; // 续费账户信息银行
                    }
                });
            }
        };

        vm.getBankList2();

        // 判断是否特殊业务
        vm.transferCheck = function() {
            var specialCheck = vm.productData.basicProfile['P004'] == 'Y' ? '1' : '0'; // 是否特殊业务
            var payWay = vm.productData.payType.split(','); // 支付方式
            var payFlag = '0'; // 支付标志

            if (payWay && payWay.length > 0) {
                for (var i = 0; i < payWay.length; i++) {
                    if (payWay[i] == '109') {
                        payFlag = '1';
                        break;
                    }
                }
            }

            vm.combineCheck = specialCheck + payFlag;
        };
        vm.transferCheck();

        // 显示仲裁机构名称
        vm.showDisName = function() {
            $document[0].policyInfoForm.disputeGroupName.focus();
        }

        vm.next = function() {
            // 数据处理
            PolicyService.control({
                state: 'product-purchase-policy-agreement',
                control: 'data',
                data: {
                    PbInsuPayMode: (vm.renewalBankAccount && vm.renewalBank) ? '0' : '', // 续期保险缴费方式 2 银行折代扣 3 银行卡代扣(待定，根据BAND.xml来写的)  
                    LiSpec: '', // 特别约定 预留，目前送空值 
                    LiExpireInsuDrawMode: '0', // 满期保险金领取方式 0：趸领 1：月领 12：年领 
                    LiRenteDrawMode: vm.renteDrawMode, // 年金/生存金领取方式 
                    AnutyPcsgMtdCd:vm.renteDrawMode, // 年金/生存金领取方式(新的！！！)
                    PbAutoPayTag: '0', // 自动垫交标记 0：不垫交 1：自动垫交
                    LiBonusDistbTag: '', //红利分配标记 预留，目前送空值 0：红利分配； 1：无红利分配
                    LiBonusGetMode: vm.bonusGetMode, // 红利领取方式
                    BkAcctNo1: vm.authBankAccount, // 给付帐号
                    BkAcctNo2: vm.bonusBankAccount, // 被保险人领取账号
                    PiZyzcfs: vm.disputeHanding, // 争议仲裁方式 1：诉讼；2：仲裁
                    PiZcinst: vm.disputeGroupName, // 仲裁机构名称
                    BkAcctNo3: vm.renewalBankAccount || '', // 期缴代扣账号
                    BankCode: (vm.renewalBankAccount && vm.renewalBank) ? vm.renewalBank.bankCode : '', // 续期缴费银行
                    BankName: (vm.renewalBankAccount && vm.renewalBank) ? vm.renewalBankAccountName : '', // 续期缴费用户
                    renewalBankName: (vm.renewalBankAccount && vm.renewalBank) ? vm.renewalBank.bankName : '', //续期账户--开户银行
                    SpecFlag: vm.combineCheck, // 业务流程标记 
                    NewPayMode: (vm.newGetBk && vm.newGetAccount) ? vm.newPayMode : '', // 首期收费方式 
                    NewGetAccName: (vm.newGetBk && vm.newGetAccount) ? vm.newGetAccountName : '', //首期缴费账号名称
                    NewGetBkCode: (vm.newGetBk && vm.newGetAccount) ? vm.newGetBk.bankCode : '', //首期缴费银行编码
                    NewGetAccCode: vm.newGetAccount || '', //首期缴费账号
                    newGetBkName: (vm.newGetBk && vm.newGetAccount) ? vm.newGetBk.bankName : '', //授权转账—--开户银行

                    // 新增字段
                    benfSetType: '1', // 受益人设定方式[1-被保险人的法定继承人;9-指定受益人]
                    isBatts: vm.isBatts, // 是否续保 0否，1是

                    bonusBankCode: (vm.bonusBank && vm.bonusBankAccount) ? vm.bonusBank.bankCode : '', // 开户行编号[年金领取]
                    bonusBankName: (vm.bonusBank && vm.bonusBankAccount) ? vm.bonusBank.bankName : '', //年金领取方式--开户银行(确认页面要)
                    bonusBankAccountName: (vm.bonusBank && vm.bonusBankAccount) ? vm.bonusBankAccountName : '', //  户名[年金领取]
                    bonusBankAccount: vm.bonusBankAccount || '', // 银行账号[年金领取]

                    liBonusBankCode: (vm.liBonusBank && vm.liBonusBankAccount) ? vm.liBonusBank.bankCode : '', //开户行编号[红利领取]
                    LiBonusBankName: (vm.liBonusBank && vm.liBonusBankAccount) ? vm.liBonusBank.bankName : '', //红利领取方式--开户银行(确认页面要)
                    liBonusBankAccountName: (vm.liBonusBank && vm.liBonusBankAccount) ? vm.liBonusBankAccountName : '', // 户名[红利领取]
                    liBonusBankAccount: vm.liBonusBankAccount || '', // 银行账号[红利领取]

                    payBankCode: (vm.authBank && vm.authBankAccount) ? vm.authBank.bankCode : '', // 给付账户银行编码
                    authBankName: (vm.authBank && vm.authBankAccount) ? vm.authBank.bankName : '', //给付账户—--开户银行
                    payBankNo: vm.authBankAccount || '', // 给付账户银行账号
                    payBankName: (vm.authBank && vm.authBankAccount) ? vm.authAccountName : '' // 给付账户户名
                }
            });
            // 流程跳转
            PolicyService.control({
                state: 'product-purchase-policy-agreement',
                control: 'process'
            });
        };
    }
})();