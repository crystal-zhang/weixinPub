(function() {
    'use strict';

    angular
        .module('app')
        .controller('BaneController', BaneController);

    BaneController.$inject = ['$state', 'CONFIG', 'CommonRequest', 'VALIDATION', '$scope', '$rootScope', 'TipService', 'PolicyService', '$filter', '$timeout'];
    /** @ngInject */
    function BaneController($state, CONFIG, CommonRequest, VALIDATION, $scope, $rootScope, TipService, PolicyService, $filter, $timeout) {
        var vm = this;

        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        vm.productData = sessionData.productData;
        // 非法操作：1. 未获取产品数据 2. 要求做而未做手机验证
        if (!vm.productData || (sessionData.loginStatus != 2 && vm.productData.basicProfile['P005'] == 'Y' && !vm.productData.phoneValid)) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        // 初始化开始

        // 用户选择的数据
        vm.user = {};
        vm.user.sex = '1';
        vm.user.birthday = null;
        
        // 日期选择回调
        vm.birthdayCallback = function(val) {
            if (val) {
                vm.user.birthday = val;
            }
        };

        // 投被保人年龄
        var payTypeConfigs = vm.productData.payTypeConfigs;
        if (payTypeConfigs && payTypeConfigs.length > 0) {
            var payTypeConfig = payTypeConfigs[0];

            vm.minAge = payTypeConfig.min_app_age;
            vm.maxAge = payTypeConfig.max_app_age;
            vm.minHolderAge = payTypeConfig.minHolderAge;
            vm.maxHolderAge = payTypeConfig.maxHolderAge;
            
            vm.minStartDate = VALIDATION.getDateByAge(vm.maxAge); // 年龄最小开始日期
            vm.maxEndDate = VALIDATION.getDateByAge(vm.minAge); // 年龄最大结束日期
            vm.holderStartDate = VALIDATION.getDateByAge(vm.maxHolderAge); // 投保人年龄最小开始日期
            vm.holderEndDate = VALIDATION.getDateByAge(vm.minHolderAge); // 投保人年龄最大结束日期
        }

        // 主险数据
        vm.mainPlan = {
            rate: 0,
            amount: '',
            exp: ''
        };
        angular.extend(vm.mainPlan, vm.productData.plans[0]);

        vm.user.insuredAmount = vm.mainPlan.insuredAmount;

        // 缴费方式，年缴
        vm.paymentType = vm.productData.payment_type;

        // 缴费期间
        vm.payAge = vm.productData.pay_age;

        // 监听
        $scope.$watch('bane.user', function() {
            $timeout(function() {
                if ($scope.baneForm.$valid) {
                    vm.calc(vm);
                } else {
                    vm.mainPlan.exp = '';
                }
            }, 100);
        }, true);

        $scope.$watch('bane.mainPlan.amount', function() {
            $timeout(function() {
                if ($scope.baneForm.$valid) {
                    vm.calc(vm);
                } else {
                    vm.mainPlan.exp = '';
                }
            }, 100);
        }, true);

        // 获取费率，计算保费
        vm.calc = function(vm, callback) {
            var user = vm.user,
                age = VALIDATION.getAgeByBirth(user.birthday);

            var params = {
                prdId: vm.productData.prd_id,
                age: age,
                sex: user.sex
            };
            CommonRequest.request(params, CONFIG.PRODUCT_PURCHASE_CALCULATE_SERVICE, function(result) {
                if (result.status == 1) {
                    if (result.data.length == 1) {
                        var rate = result.data[0].rate;
                        // var exp = (rate * 10 + 0.5) / 10 * (user.amount / vm.mainPlan.insuredAmount);
                        var exp = (rate * 10) / 10 * (vm.mainPlan.amount / vm.mainPlan.insuredAmount); // 同老系统一致，去掉0.5
                        vm.mainPlan.exp = exp;

                        callback && callback({
                            exp: exp,
                            mainPlan: vm.mainPlan
                        });
                    }
                }
            });
        };

        // 跳转投保页面
        vm.goPolicy = function() {
            var params = {
                prdId: vm.productData.prd_id,
                sex: vm.user.sex,
                insurerBirthDay: $filter('date')(vm.user.birthday, 'yyyyMMdd'),
                planId: vm.mainPlan.planId,
                // extraPlanId: '',
                premiumResult: vm.mainPlan.exp,
                orderCode: vm.productData.orderCode || ''
            };

            PolicyService.doCalc(params, function() {
                // 数据处理
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'data',
                    data: {
                        birthday: vm.user.birthday, // 被保人生日
                        sex: vm.user.sex, // 被保人性别
                        // selectedPlan: vm.user.selectedPlan, //是否选择附加险
                        mainPlan: vm.mainPlan, // 主险
                        // addPlan: vm.addPlan, // 附加险
                        payendyear: vm.payAge, // 缴费期间
                        paymentType: vm.paymentType, // 缴费方式
                        PbInsuAmt: vm.mainPlan.amount, // 主保险保额 
                        PbInsuExp: vm.mainPlan.exp, // 主保险保费
                        pbApplNoNum: 1,
                        isWholeSale: vm.paymentType == '0' ? true : false,
                        minAge: vm.minAge,
                        maxAge: vm.maxAge,
                        minHolderAge: vm.minHolderAge,
                        maxHolderAge: vm.maxHolderAge,
                        calc: vm.calc.toString(),
                        calcCtrl: vm
                    }
                });
                // 流程跳转
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'process'
                });
            });
        };
    }
})();