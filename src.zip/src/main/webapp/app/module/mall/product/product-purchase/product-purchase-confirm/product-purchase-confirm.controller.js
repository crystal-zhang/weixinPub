(function() {
    'use strict';

    angular
        .module('app')
        .controller('ProPurchaseConfirmController', ProPurchaseConfirmController);

    ProPurchaseConfirmController.$inject = ['$state', '$rootScope', 'PolicyService', 'CommonRequest', 'CONFIG', 'TipService', 'COMMON', '$ionicPopup'];

    /** @ngInject */
    function ProPurchaseConfirmController($state, $rootScope, PolicyService, CommonRequest, CONFIG, TipService, COMMON, $ionicPopup) {
        var vm = this;
        
        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        vm.productData = sessionData.productData;
        vm.insureData = sessionData.insureData;
        vm.policyData = sessionData.policyData;

        if (!vm.productData) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        // 针对天天保的保险期间
        if(vm.productData.templateCode.toLowerCase()=='ipaha'){
            vm.insureData.mainPlan.insuYear = vm.insureData.tempDays;

        }

        // 保险责任显示，如果有责任就显示责任，否则显示计划
        vm.mainPlan = vm.insureData.mainPlan, // 主险计划
        vm.addPlan = vm.policyData.AppdList; // 附加险计划

        if (vm.mainPlan) {
            vm.duty = vm.mainPlan.dutys;
            if (vm.duty && vm.duty.length > 0) {
                vm.showDuty = true;
                vm.showPlan = false;
            } else {
                vm.showDuty = false;
                vm.showPlan = true;
            }
        }

        if (vm.addPlan && vm.addPlan.length > 0) {
            vm.showDuty = false;
            vm.showPlan = true;
        }

        vm.changeFormat = function(insuYear, insuYearFlag) {
            if (insuYearFlag == 'Y') {
                if (insuYear) {
                    if (insuYear == '1000') {
                        return '终身';
                    } else {
                        return insuYear + '年';
                    }
                }
            } else if (insuYearFlag == 'D') {
                return insuYear + '天';
            } else if (insuYearFlag == 'M') {
                return insuYear + '月';
            }
        }

        // 返回修改
        vm.back = function() {
            $state.go('product-purchase-base-info');
        };

        // 确认提交
        vm.submit = function() {
            var params = {
                orderCode: vm.policyData.orderCode
            };
            CommonRequest.request(params, CONFIG.POLICY_INFO_CONFIRM, function(result) {
                if (result.status == 1) {
                    if ($rootScope.isLogin != 1 && !$rootScope.HLIFE) {
                        var alertPopup = $ionicPopup.confirm({
                            title: '温馨提示',
                            template: '是否需要将您的投保信息绑定至此微信账号？',
                            okText: '需要',
                            cancelText: '取消'
                        });
                        alertPopup.then(function(res) {
                            if (res) {
                                COMMON.showModal('app/module/mall/product/auto-bind/auto-bind.html');
                            }
                        }).then(function(res) {
                            // 流程跳转
                            PolicyService.control({
                                state: 'product-purchase-confirm',
                                control: 'process'
                            });
                        });
                    } else {
                        // 流程跳转
                        PolicyService.control({
                            state: 'product-purchase-confirm',
                            control: 'process'
                        });
                    }
                } else {
                    var error = result.error;
                    TipService.showMsg(error.message);
                    $state.go('tab.mall');
                }
            });
        };
    }
})();