(function() {
    'use strict';

    angular
        .module('app')
        .controller('GroupPolicyContactController', GroupPolicyContactController);

    GroupPolicyContactController.$inject = ['$state', 'CommonRequest', 'CONFIG', 'GroupPolicyService', '$scope', '$rootScope', '$ionicLoading','$timeout'];

    /** @ngInject */
    function GroupPolicyContactController($state, CommonRequest, CONFIG, GroupPolicyService, $scope, $rootScope,$ionicLoading,$timeout) {
        var vm = this,
            sessionData = GroupPolicyService.getSessionData();
        vm.productData = sessionData.productData, vm.insureData = sessionData.insureData, vm.policyData = sessionData.policyData, $rootScope.prdId = vm.productData.prd_id, $scope.$on("select-area-group-close", function(event, result) {
            if (vm.province = result[0], vm.city = result[1], vm.district = result[2], vm.branch = "", vm.province.areaCode) {
                var code;
                code = "1" == vm.city.singletonFlag ? vm.city.areaCode : vm.city.parentAreaCode, vm.usCode = code, CommonRequest.request({}, CONFIG.GET_NETPOINTLIST_SERVCIE, function(result) {
                    if (1 == result.status) {
                        var provinceNetList = result.data;
                        if (provinceNetList && provinceNetList.length > 0)
                            for (var i = 0; i < provinceNetList.length; i++) provinceNetList[i].netCode == code && (vm.branch = provinceNetList[i].netName, vm.provinceNet = provinceNetList[i])
                    }
                }), "1" == vm.district.crossAreaFlag ? vm.isCrossArea = !0 : vm.isCrossArea = !1;
                var params = {
                    areaCode: vm.district.areaCode
                };
                CommonRequest.request(params, CONFIG.SYSAREA_GROUP_PROXY_INFO, function(result) {
                    if (1 == result.status) {
                        var data = result.data;
                        vm.staffName = data.staffName, vm.staffId = data.staffId, vm.averageIncome = data.averageIncome, vm.averageIncomeCounty = data.averageIncomeCounty, vm.staffOrgCode = data.staffOrgCode, vm.yearIncome = vm.averageIncome, 0 == vm.livePlace ? vm.yearIncome = vm.averageIncome : 1 == vm.livePlace && (vm.yearIncome = vm.averageIncomeCounty)
                    }
                })
            }
        }), vm.provinceNet = {}, vm.cityNet = {}, vm.districtNet = {}, $scope.$on("select-branch-group-close", function(event, result) {
            vm.provinceNet = result[0], vm.cityNet = result[1], vm.districtNet = result[2]
        }), vm.next = function() {
            $ionicLoading.show({
                template: '<ion-spinner icon="bubbles"></ion-spinner>'
            });
            vm.checkNetcode = function(){
                $timeout(function() {
                    if (vm.provinceNet.netCode) {
                        $ionicLoading.hide();
                        GroupPolicyService.control({
                            state: "product-purchase-group-policy-contact",
                            control: "data",
                            data: {
                                agentCode: vm.staffId,
                                angentName: vm.staffName,
                                BkBrchNo: vm.staffOrgCode,
                                PbHoldAddr: vm.province.areaCode + "," + vm.city.areaCode,
                                PbWebsiteCode: vm.districtNet.netCode || "",
                                PbWebsiteName: vm.districtNet.netName || "",
                                PbOtherProvinceCode: vm.isCrossArea ? vm.province.areaCode : "",
                                bankCodeLV1: vm.provinceNet.netCode || "",
                                bankCodeLV2: vm.cityNet.netCode || "",
                                bankCodeLV3: vm.districtNet.netCode || "",
                                districtCode: vm.province ? vm.province.areaCode : "",
                                liveProvince: vm.province ? vm.province.areaName : "",
                                liveDistrict: vm.city ? vm.city.areaName : "",
                                allWebsite: vm.allWebsite,
                                referrerCode: vm.referrerCode,
                                referrerName: vm.referrerName,
                                PlchdProvCd: vm.province.areaCode,
                                PlchdCityCd: vm.city.areaCode,
                                PlchdDstcCd: vm.district.areaCode,
                                liveDstc: vm.district.areaName || "",
                                crossAreaFlag: vm.isCrossArea ? "1" : "0"
                            }
                        }), GroupPolicyService.control({
                            state: "product-purchase-group-policy-contact",
                            control: "process"
                        })
                     } else {
                    vm.checkNetcode();
                    }
                }, 100);
            }
            vm.checkNetcode();
            if (vm.provinceNet && vm.cityNet && vm.districtNet) {
                var provinceName = vm.provinceNet.netName ? vm.provinceNet.netName : "",
                    cityName = vm.cityNet.netName ? "-" + vm.cityNet.netName : "",
                    districtName = vm.districtNet.netName ? "-" + vm.districtNet.netName : "";
                vm.allWebsite = provinceName + cityName + districtName
            }
            
        }
    }
})();