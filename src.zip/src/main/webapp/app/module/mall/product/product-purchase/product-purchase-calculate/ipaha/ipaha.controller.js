(function() {
    'use strict';

    angular
        .module('app')
        .controller('IpahaController', IpahaController);

    IpahaController.$inject = ['$state', 'CONFIG', 'CommonRequest', 'TipService', 'PolicyService', '$filter', 'VALIDATION', '$rootScope', '$scope'];
    /** @ngInject */
    function IpahaController($state, CONFIG, CommonRequest, TipService, PolicyService, $filter, VALIDATION, $rootScope, $scope) {
        var vm = this;

        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        vm.productData = sessionData.productData;
        // 非法操作：1. 未获取产品数据 2. 要求做而未做手机验证
        if (!vm.productData || (sessionData.loginStatus != 2 && vm.productData.basicProfile['P005'] == 'Y' && !vm.productData.phoneValid)) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        // 初始化开始

        // 用户选择的数据
        vm.user = {};
        vm.user.sex = '';
        vm.user.birthday = null;

        // 投被保人年龄
        var payTypeConfigs = vm.productData.payTypeConfigs;
        if (payTypeConfigs && payTypeConfigs.length > 0) {
            var payTypeConfig = payTypeConfigs[0];

            vm.minAge = payTypeConfig.min_app_age;
            vm.maxAge = payTypeConfig.max_app_age;
            vm.minHolderAge = payTypeConfig.minHolderAge;
            vm.maxHolderAge = payTypeConfig.maxHolderAge;

            vm.minStartDate = VALIDATION.getDateByAge(vm.maxAge); // 年龄最小开始日期
            vm.maxEndDate = VALIDATION.getDateByAge(vm.minAge); // 年龄最大结束日期
            vm.holderStartDate = VALIDATION.getDateByAge(vm.maxHolderAge); // 投保人年龄最小开始日期
            vm.holderEndDate = VALIDATION.getDateByAge(vm.minHolderAge); // 投保人年龄最大结束日期
        }

        // 主险数据
        vm.mainPlan = {
            rate: 0,
            amount: 0,
            exp: 0
        };

        // 责任code
        vm.codeArr = [];

        angular.extend(vm.mainPlan, vm.productData.plans[0]);

        // 缴费方式，年缴
        vm.paymentType = vm.productData.payment_type.split(',')[0];

        // 缴费期间
        vm.payAge = vm.productData.pay_age;

        // 获取费率
        vm.getRate = function(callback) {
            var params = {
                prdId: vm.productData.prd_id
            };
            CommonRequest.request(params, CONFIG.PRODUCT_PURCHASE_CALCULATE_SERVICE, function(result) {
                if (result.status == 1) {
                    vm.rateTable = result.data;
                    angular.isFunction(callback) && callback();
                }

            });
        };

        // 渲染新的责任列表
        // 责任数据包含ilName、insuredAmount、dutyId
        vm.newDuties = [];
        vm.getDutyList = function(cardDuties) {
            if (vm.productData) {
                vm.plans = vm.productData.plans; // 产品计划
                if (vm.plans && vm.plans.length == 1) {
                    // 此处为赠险代码
                    if (cardDuties) {
                        var allDuties = vm.plans[0].dutys,
                            temp = [];
                        for (var m = 0; m < allDuties.length; m++) {
                            var duty = allDuties[m];
                            for (var l = 0; l < cardDuties.length; l++) {
                                if (duty.dutyId == cardDuties[l].ilId) {
                                    temp.push(duty);
                                }
                            }
                        }
                        vm.duties = temp;
                    } else {
                        vm.duties = vm.plans[0].dutys; //责任数组
                    }
                    // 对赠险的责任进行处理（新加需求）
                    vm.dealDuties(vm.duties);

                    if (vm.duties && vm.duties.length > 0) {
                        var duties = vm.duties;
                        for (var i = 0; i < duties.length - 1; i++) {
                            var duty1 = duties[i];

                            for (var j = i + 1; j < duties.length; j++) {
                                var duty2 = duties[j];
                                var code1 = duty1['ilCode'].substr(0, 6).toLowerCase();
                                var code2 = duty2['ilCode'].substr(0, 6).toLowerCase();
                                var amount1 = parseInt(duty1.insuredAmount);
                                var amount2 = parseInt(duty2.insuredAmount);
                                var minSaleQuantity = parseInt(duty1.minSaleQuantity); //责任最小购买份数
                                var maxSaleQuantity = parseInt(duty1.maxSaleQuantity); //责任最大购买份数
                                var amountArr = [{
                                    key: 0,
                                    value: '请选择保险金额'
                                }];

                                if (code1 == code2) {
                                    if (amount1 != amount2) {
                                        for (var k = minSaleQuantity; k <= maxSaleQuantity; k++) {
                                            amountArr.push({
                                                key: k,
                                                value: amount1 * k + '/' + amount2 * k + '万'
                                            });
                                        }

                                        vm.newDuties.push({
                                            ilName: duty1.ilName + '/' + duty2.ilName.substr(duty2.ilName.length - 2, 2),
                                            insuredAmount: amountArr,
                                            dutyId: duty1.ilCode.indexOf('01') > 0 ? duty1.dutyId : duty2.dutyId,
                                            num: vm.productData.token ? minSaleQuantity : 0,
                                            amount: (amount1 + amount2),
                                            minSaleQuantity: minSaleQuantity,
                                            rates: [],
                                            ilCode: code1.substr(code1.length - 1, 1),
                                            checked: duty1.checked
                                        });
                                    } else {
                                        for (var l = minSaleQuantity; l <= maxSaleQuantity; l++) {
                                            amountArr.push({
                                                key: l,
                                                value: amount2 * l + '万'
                                            });
                                        }

                                        vm.newDuties.push({
                                            ilName: vm.duties[i].ilName + '/' + vm.duties[j].ilName.substr(vm.duties[j].ilName.length - 2, 2),
                                            insuredAmount: amountArr,
                                            dutyId: duty1.ilCode.indexOf('01') > 0 ? duty1.dutyId : duty2.dutyId,
                                            num: vm.productData.token ? minSaleQuantity : 0,
                                            amount: amount1,
                                            minSaleQuantity: minSaleQuantity,
                                            rates: [],
                                            ilCode: code1.substr(code1.length - 1, 1),
                                            checked: duty1.checked
                                        });
                                    }
                                }
                            }
                        }
                    }
                }
            }
        };

        // 对赠险的责任进行特殊处理
        vm.dealDuties = function(duties) {
            if (vm.productData.token) {
                for (var i = 0; i < duties.length; i++) {
                    // 后台配置赠险份数，则该责任的最大最小份数为赠险份数
                    duties[i].minSaleQuantity = duties[i].maxSaleQuantity = vm.cardDuties[i].giveNumber;
                    // 赠险的责任默认是选中且不能改
                    duties[i].checked = true;
                }

            } else {
                for (var i = 0; i < duties.length; i++) {
                    duties[i].checked = false;
                }
            }
            return duties;
        }

        // 获取卡券
        if (vm.productData.token) {
            vm.isGift = true; // 该产品配置赠险
            PolicyService.getCardInfo(vm.productData.token, function(data) {
                if (data) {
                    vm.sendingProData = data;
                    if (vm.sendingProData) {
                        // 赠险责任
                        vm.cardDuties = vm.sendingProData.prmLotDutySetModels;
                        vm.getDutyList(vm.cardDuties);
                    }
                }
            });
        } else {
            vm.getDutyList();
        }

        // 初始化责任选择状态
        vm.initDuties = function() {
            for (var i = 0; i < vm.newDuties.length; i++) {
                vm.newDuties[i].checked = false;
                vm.newDuties[i].exp = 0;
            }
        };
        vm.initDuties();

        // 计算保费，每个计划的保费总和
        // 单个计划的保费根据费率、购买份数计算，公式为amount=rate*num
        vm.totalExp = 0;
        vm.calc = function() {
            var duties = vm.newDuties; // 责任列表
            vm.totalExp = 0; // 总保费初始化
            vm.totalAmount = 0; // 总保额初始化

            for (var i = duties.length - 1; i >= 0; i--) {
                var duty = duties[i], // 责任数据
                    checked = duty.checked, // 是否选中
                    rates = duty.rates, // 费率
                    num = duty.num, // 购买份数
                    exp = 0, // 保费
                    amount = duty.amount * num; // 保额
                if (checked) {
                    for (var j = rates.length - 1; j >= 0; j--) {
                        var rate = rates[j];

                        exp += (rate * 100) * num;
                    }
                    vm.newDuties[i].exp = exp / 100;
                }

                vm.totalExp += exp;
                vm.totalAmount += amount;
            }
            vm.codeArr = [];
            vm.duties = [];
            for (var m = 0; m < duties.length; m++) {
                if (duties[m].checked == true) {
                    vm.codeArr.push(duties[m].ilCode.toUpperCase() + ';' + duties[m].num);
                    vm.duties.push({
                        'dutyId': duties[m].dutyId,
                        'ilCode': duties[m].ilCode,
                        'ilName': duties[m].ilName,
                        'insuredAmount': duties[m].amount * duties[m].num,
                        'num': duties[m].num,
                        'exp': duties[m].exp
                    });
                }
            }

            vm.totalExp = vm.totalExp / 100;
        };

        // 初始化时间段数据
        vm.dates = []; // 所有时间段数据存储

        // 添加一天
        vm.plusOneDay = function(date) {
            if (date) {
                return new Date(date.getTime() + 1 * 24 * 60 * 60 * 1000);
            }
        };
        // 减少一天
        vm.minusOneDay = function(date) {
            if (date) {
                return new Date(date.getTime() - 1 * 24 * 60 * 60 * 1000);
            }
        };

        vm.nowDate = new Date(); // 最小开始时间
        if (vm.productData.prdSaleCode == 2 && vm.productData.planSaleTime) {
            var planSaleTime = vm.productData.planSaleTime;
            planSaleTime = planSaleTime.substr(0, 4) + '-' + planSaleTime.substr(4, 2) + '-' + planSaleTime.substr(6, 2);
            planSaleTime = new Date(planSaleTime);
            if (planSaleTime.getTime() > vm.nowDate.getTime()) {
                vm.nowDate = planSaleTime;
            }
        }
        vm.maxDate = new Date(vm.nowDate.getTime() + 365 * 24 * 60 * 60 * 1000); // 最大结束时间

        // 增加时间段或者删减时间段需要重新获取费率表，依据责任ID、缴费期间、缴费期间单位
        vm.getRateByTime = function() {
            var dates = vm.dates, // 时间段
                rates = vm.rateTable,
                duties = vm.newDuties; // 费率表

            for (var i = duties.length - 1; i >= 0; i--) {
                var duty = duties[i];
                vm.newDuties[i].rates = [];

                for (var j = dates.length - 1; j >= 0; j--) {
                    var date = dates[j];

                    for (var k = rates.length - 1; k >= 0; k--) {
                        var rate = rates[k];
                        if (duty.dutyId == rate.ilId && date.temp == rate.insuyear && date.tempFlag == rate.insuyearflag) {
                            // 将筛选的费率存入责任表内
                            vm.newDuties[i].rates.push(rate.rate);
                        }
                    }
                }
            }

            // 计算保费
            vm.calc();
        };

        // 根据开始、结束时间计算时间段内的天数
        vm.getTempDays = function(date) {
            var temp, // 差值时间，28天以内显示天数，以上显示月数
                tempDay, // 差值时间，天数
                tempFlag,
                start = date.start,
                end = date.end; // 差值

            start = $filter('date')(start, 'yyyy-MM-dd');
            start = new Date(start);

            end = $filter('date')(end, 'yyyy-MM-dd');
            end = new Date(end);

            tempDay = parseInt((end.getTime() - start.getTime()) / (24 * 60 * 60 * 1000));

            // 28天以天数记录，28天至31天以1个月份记录，以上以实际月数记录
            if (tempDay > 28) {
                if (tempDay < 31) {
                    temp = 1;
                } else {
                    temp = parseInt(tempDay / 31) + 1;
                }
                tempFlag = 'M';
            } else {
                temp = tempDay;
                tempFlag = 'D';
            }

            date.temp = temp;
            date.tempDay = tempDay;
            date.tempFlag = tempFlag;
        };

        // 添加时间段
        vm.addTime = function() {
            var startDate,
                len = vm.dates.length;

            if (len == 5) {
                TipService.showMsg($rootScope.TIPS.PRODUCT.IPAHA_SELECTED_LIMIT);
                return;
            }

            if (len == 0) {
                startDate = vm.nowDate;
            } else {
                startDate = new Date(vm.dates[len - 1].end.getTime() + 1 * 24 * 60 * 60 * 1000);
            }

            if (startDate && startDate.getTime() < vm.maxDate.getTime()) {
                // 添加的时间段必须小于最大结束时间
                var start, // 开始时间
                    end, // 结束时间
                    minStart, // 最小开始时间
                    maxStart, // 最大开始时间
                    minEnd, // 最小结束时间
                    maxEnd; // 最大结束时间
                if (vm.sendingProData) {
                    vm.giveDay = vm.sendingProData.giveDay; // 赠险配置了天数
                    vm.giveStartTime = vm.sendingProData.giveStartTime; // 赠险配置了开始日期
                    vm.giveEndTime = vm.sendingProData.giveEndTime; // 赠险配置了结束日期
                    if (vm.giveStartTime && vm.giveEndTime) {
                        start = new Date(vm.giveStartTime);
                        end = new Date(vm.giveEndTime);
                        vm.startDisabled = true;
                        vm.endDisabled = true;
                    } else if (vm.giveDay) {
                        start = startDate;
                        minStart = start; // 最小开始时间
                        maxStart = vm.minusOneDay(vm.maxDate); // 最大开始时间
                        end = new Date(start.getTime() + vm.giveDay * 24 * 60 * 60 * 1000);
                        vm.startDisabled = false; // 页面开始日期禁用
                        vm.endDisabled = true; // 页面结束日期禁用
                    }

                } else {
                    start = startDate; // 开始时间
                    end = vm.plusOneDay(start); // 结束时间
                    minStart = start; // 最小开始时间
                    maxStart = vm.minusOneDay(vm.maxDate); // 最大开始时间
                    minEnd = end; // 最小结束时间
                    maxEnd = vm.maxDate; // 最大结束时间 
                    vm.startDisabled = false;
                    vm.endDisabled = false;
                }

                var date = {
                    start: start,
                    end: end,
                    minStart: minStart,
                    maxStart: maxStart,
                    minEnd: minEnd,
                    maxEnd: maxEnd
                };

                vm.getTempDays(date);

                vm.dates.push(date);

                vm.getRateByTime();

                // 日期选择回调
                date.startCallback = function(val) {
                    if (val) {
                        date.start = val;
                        vm.refreshDate(date);
                    }
                };
                date.endCallback = function(val) {
                    if (val) {
                        date.end = val;
                        vm.refreshDate(date);
                    }
                };
            }
        };
        // 默认从今天开始
        vm.getRate(function() {
            vm.addTime();
        });

        // 删除时间段
        vm.deleteTime = function(n) {
            if (vm.dates.length > 1) {
                vm.dates.pop();
                vm.getRateByTime();
            }
        };

        // 时间段监测
        vm.checkTime = function(date) {
            // 若为赠险且配置了天数，则结束日期为开始日期+天数
            if (vm.giveDay) {
                date.end = new Date(date.start.getTime() + vm.giveDay * 24 * 60 * 60 * 1000);
            }
            for (var i = 0; i < vm.dates.length; i++) {
                var num = (vm.dates[i].start.getTime() - date.start.getTime()) / (24 * 60 * 60 * 1000);
                if (num == 0) {
                    if ((i + 1) < vm.dates.length) {
                        var time = (vm.dates[i + 1].start.getTime() - date.end.getTime()) / (24 * 60 * 60 * 1000);
                        if (time < 0) {
                            TipService.showMsg($rootScope.TIPS.PRODUCT.IPAHA_SELECTED_REPEAT);
                            vm.dates[i].end = vm.dates[i + 1].start;
                        }
                    }
                    if (i != 0) {
                        var t = (vm.dates[i].start.getTime() - vm.dates[i - 1].end.getTime()) / (24 * 60 * 60 * 1000);
                        if (t < 0) {
                            vm.dates[i].start = vm.dates[i - 1].end;
                        }
                    }
                    if (vm.dates.length == i + 1) {
                        var m = (vm.dates[i].end.getTime() - vm.dates[i].start.getTime()) / (24 * 60 * 60 * 1000);
                        if (m <= 0) {
                            vm.dates[i].end = vm.plusOneDay(vm.dates[i].start);
                        }
                    } else {
                        var n = (vm.dates[i].end.getTime() - vm.dates[i].start.getTime()) / (24 * 60 * 60 * 1000);
                        if (n <= 0) {
                            vm.dates[i].start = vm.minusOneDay(vm.dates[i].end);
                        }
                    }
                }
            }
        };

        // 改变开始时间，更新时间段
        vm.refreshDate = function(date) {
            vm.checkTime(date);
            vm.getTempDays(date);
            vm.getRateByTime();
        };

        // 单选
        vm.dutyCheck = function(duty) {
            if (duty.checked) {
                duty.num = duty.minSaleQuantity;
            } else {
                duty.num = duty.insuredAmount[0].key;
                duty.amount = 0;
                duty.exp = 0;
            }
            vm.calc();
        };

        // 全选操作
        vm.selectAll = function() {
            vm.allChecked = !vm.allChecked;

            if (vm.allChecked) {
                for (var i = 0; i < vm.newDuties.length; i++) {
                    vm.newDuties[i].checked = true;

                    vm.dutyCheck(vm.newDuties[i]);
                }
            } else {
                for (var j = 0; j < vm.newDuties.length; j++) {
                    vm.newDuties[j].checked = false;

                    vm.dutyCheck(vm.newDuties[j]);
                }
            }
            vm.calc();
        };

        // 跳转投保页面
        vm.goPolicy = function() {
            // 获取保险期间
            var tempDays = 0;
            for (var i = 0; i < vm.dates.length; i++) {
                tempDays += vm.dates[i].tempDay;

            }
            var params = {
                prdId: vm.productData.prd_id,
                sex: vm.user.sex,
                insurerBirthDay: $filter('date')(vm.user.birthday, 'yyyyMMdd'),
                planId: vm.mainPlan.planId,
                premiumResult: vm.totalExp,
                orderCode: vm.productData.orderCode || ''
            };

            PolicyService.doCalc(params, function() {
                vm.mainPlan.exp = vm.totalExp;
                vm.mainPlan.amount = vm.totalAmount;
                vm.mainPlan.dutys = vm.duties;
                // 数据处理
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'data',
                    data: {
                        // birthday: vm.user.birthday, // 被保人生日
                        // sex: vm.user.sex, // 被保人性别
                        // selectedPlan: vm.user.selectedPlan, //是否选择附加险
                        mainPlan: vm.mainPlan, // 主险
                        // addPlan: vm.addPlan, // 附加险
                        payendyear: vm.payAge, // 缴费期间
                        paymentType: vm.paymentType, // 缴费方式
                        PbInsuAmt: vm.mainPlan.amount, // 保险总保额 
                        PbInsuExp: vm.isGift ? 0 : vm.mainPlan.exp, // 保险总保费
                        PbBeginDate: vm.dates, // 保险生效时间
                        pbApplNoNum: vm.dates.length, // 投保单号个数
                        codeArr: vm.codeArr, // 责任code
                        isWholeSale: vm.paymentType == '0' ? true : false,
                        minAge: vm.minAge,
                        maxAge: vm.maxAge,
                        minHolderAge: vm.minHolderAge,
                        maxHolderAge: vm.maxHolderAge,
                        oldPrice: vm.totalExp, // 赠险前原价
                        tempDays: tempDays
                    }
                });
                // 流程跳转
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'process'
                });
            });
        };
    }

})();