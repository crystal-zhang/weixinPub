(function() {
	'use strict';

	angular
		.module('app')
		.controller('EnllController', EnllController);

	EnllController.$inject = ['$state', 'CONFIG', 'CommonRequest', '$scope', 'VALIDATION', '$rootScope', 'PolicyService', 'TipService', '$filter', '$timeout'];
	/** @ngInject */
	function EnllController($state, CONFIG, CommonRequest, $scope, VALIDATION, $rootScope, PolicyService, TipService, $filter, $timeout) {
		var vm = this;

		var sessionData = PolicyService.getSessionData();

		// 所选产品信息
		vm.productData = sessionData.productData;
		if (!vm.productData || (sessionData.loginStatus != 2 && vm.productData.basicProfile['P005'] == 'Y' && !vm.productData.phoneValid)) {
			// TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
			$state.go('tab.mall');
			return;
		}
		// console.log(vm.productData);
		// // 用户选择的数据
		// vm.user = {
		// 	sex: '1',
		// 	birthday: null
		// };
		
		// // 日期选择回调
		// vm.birthdayCallback = function(val) {
		// 	if (val) {
		// 		vm.user.birthday = val;
		// 	}
		// };

		// // 投被保人年龄
		// var payTypeConfigs = vm.productData.payTypeConfigs;

		// //封装缴费期间-保险期间 与 最高投保年龄 映射对象
		// var payAgeAndMaxAge = {
		// 	"10":[{
		// 		"20" : "45",
		// 		"20MIN" : "18",
		// 		"securityAge" : "20"
		// 	}, {
		// 		"30" : "50",
		// 		"30MIN" : "18",
		// 		"securityAge" : "30"
		// 	}, {
		// 		"70" : "45",
		// 		"70MIN" : "0",
		// 		"securityAge" : "70"
		// 	}, {
		// 		"80" : "50",
		// 		"80MIN" : "0",
		// 		"securityAge" : "80"
		// 	}],
		// 	"15":[{
		// 		"20" : "45",
		// 		"20MIN" : "18",
		// 		"securityAge" : "20"
		// 	}, {
		// 		"30" : "45",
		// 		"30MIN" : "18",
		// 		"securityAge" : "30"
		// 	}, {
		// 		"70" : "45",
		// 		"70MIN" : "0",
		// 		"securityAge" : "70"
		// 	}, {
		// 		"80" : "50",
		// 		"80MIN" : "0",
		// 		"securityAge" : "80"
		// 	}],
		// 	"20":[{
		// 		"30" : "45",
		// 		"30MIN" : "18",
		// 		"securityAge" : "30"
		// 	}, {
		// 		"70" : "40",
		// 		"70MIN" : "0",
		// 		"securityAge" : "70"
		// 	}, {
		// 		"80" : "45",
		// 		"80MIN" : "0",
		// 		"securityAge" : "80"
		// 	}]
		// };

		// // 总保费
		// vm.totalExp = "";
		// // 总保额
		// vm.totalAmount = "";

		// // 主险数据
		// vm.mainPlan = {
		// 	rate: 0,
		// 	amount: "",
		// 	exp: ""
		// };
		// // 附加险数据
		// vm.addPlan = {
		// 	rate: 0,
		// 	amount: "",
		// 	exp: ""
		// };


		// // 获取产品计划 和 保险期间
		// vm.getPlan = function() {
		// 	var plan = vm.productData.plans;
		// 	vm.mainPlanObjs = {};
		// 	vm.securityAgeObjs = [];

		// 	//保险期间单位
		// 	// var insuYearLable = {
		// 	//     "Y":"年",
		// 	//     "M":"月",
		// 	//     "D":"天",
		// 	//     "A":"周岁"
		// 	// };
		// 	var getInsuYearLable = function(insuYear, insuYearFlag){
		// 		if(insuYearFlag == "Y"){
		// 			return insuYear+"年";
		// 		} else if(insuYearFlag == "M"){
		// 			return insuYear+"月";
		// 		} else if(insuYearFlag == "D"){
		// 			return insuYear+"天";
		// 		} else if(insuYearFlag == "A"){
		// 			return "至"+insuYear+"周岁";
		// 		} 
		// 	}

		// 	for (var i = 0; i < plan.length; i++) {
		// 		var item = plan[i];
		// 		if (item.planType == '1') {
		// 			// 以保险期间封装主险对象
		// 			vm.mainPlanObjs[item.insuYear] = {
		// 				insuYear: item.insuYear,
		// 				planObj: item
		// 			};
		// 			vm.mainPlanObjs[item.insuYear].planObj.insuredAmountNow = vm.mainPlanObjs[item.insuYear].planObj.insuredAmount*10;
		// 			vm.mainPlanObjs[item.insuYear].planObj.minBuyQautityNow = vm.mainPlanObjs[item.insuYear].planObj.minBuyQautity/10;
		// 			vm.mainPlanObjs[item.insuYear].planObj.maxBuyQautityNow = vm.mainPlanObjs[item.insuYear].planObj.maxBuyQautity/10;

		// 			// 封装保险期间对象
		// 			vm.securityAgeObjs.push({
		// 				insuYear: item.insuYear,
		// 				// label: item.insuYear+insuYearLable[item.insuYearFlag]
		// 				label: getInsuYearLable(item.insuYear, item.insuYearFlag)
		// 			});
		// 		} else if (item.planType == '2') {
		// 			//获取附加险
		// 			angular.extend(vm.addPlan, item);
		// 		}
		// 	}
		// 	// console.log("+++mainPlanObjs+++++++addPlan+++++++++++securityAgeObjs++++++++");
		// 	// console.log(vm.mainPlanObjs);
		// 	// console.log(vm.addPlan);
		// 	// console.log(vm.securityAgeObjs);
		// 	// console.log("-----------------------------");
		// };
		// vm.getPlan();


		// // 获取 缴费方式 和 缴费期间
		// // 同时设置默认 缴费方式 和 缴费期间
		// vm.getPayWay = function() {
		// 	var payment_value = [],
		// 		payage_value = [];

		// 	// 缴费方式
		// 	vm.payWays = [];
		// 	// 缴费期间
		// 	vm.payAges = [];

		// 	if (vm.productData.payment_type) {
		// 		payment_value = vm.productData.payment_type.split(',');
		// 	}
		// 	if (vm.productData.pay_age) {
		// 		payage_value = vm.productData.pay_age.split(',');
		// 	}

		// 	var temp = [];
		// 	for (var i = 0; i < payment_value.length; i++) {
		// 		if (temp.indexOf(payment_value[i]) == -1) {
		// 			temp.push(payment_value[i]);
		// 		}
		// 	}
		// 	payment_value = temp;

		// 	temp = [];
		// 	for (var i = 0; i < payage_value.length; i++) {
		// 		if (temp.indexOf(payage_value[i]) == -1) {
		// 			temp.push(payage_value[i]);
		// 		}
		// 	}
		// 	payage_value = temp;

		// 	//缴费期间列表
		// 	if (payage_value && payage_value.length > 0) {
		// 		for (var i = 0; i < payage_value.length; i++) {
		// 			vm.payAges.push({
		// 				value: payage_value[i],
		// 				label: payage_value[i] + "年"
		// 			})
		// 		}
		// 	}

		// 	//缴费方式列表
		// 	if (payment_value && payment_value.length > 0) {
		// 		for (var i = 0; i < payment_value.length; i++) {
		// 			var label;
		// 			if (payment_value[i] == 12) {
		// 				label = '年交';
		// 			} else if (payment_value[i] == 0) {
		// 				label = '趸交';
		// 			} else if (payment_value[i] == 1) {
		// 				label = '月交';
		// 			} else if (payment_value[i] == 3) {
		// 				label = '季交';
		// 			} else if (payment_value[i] == 6) {
		// 				label = '半年交';
		// 			}
		// 			vm.payWays.push({
		// 				value: payment_value[i],
		// 				label: label
		// 			});
		// 		}
		// 	}

		// 	//缴费期间映射缴费方式及被保人年龄限制
		// 	var pay_age = [];
		// 	var security_age = [];
		// 	vm.payAgeObjs = {};
		// 	if (payTypeConfigs && payTypeConfigs.length > 0) {
		// 		for (var i = 0; i < payTypeConfigs.length; i++) {
		// 			vm.payAgeObjs[payTypeConfigs[i].pay_age] = {
		// 				pay_age: payTypeConfigs[i].pay_age
		// 			};
		// 			var secArr = payAgeAndMaxAge[payTypeConfigs[i].pay_age];
		// 			for (var j = 0; j < secArr.length; j++) {
		// 				for (var k = 0; k < vm.securityAgeObjs.length; k++) {
		// 					if (secArr[j][vm.securityAgeObjs[k].insuYear]) {
		// 						vm.payAgeObjs[payTypeConfigs[i].pay_age][vm.securityAgeObjs[k].insuYear] = {
		// 							security_age: vm.securityAgeObjs[k].insuYear,
		// 							map: {
		// 								maxHolderAge: payTypeConfigs[i].maxHolderAge,
		// 								max_app_age: secArr[j][vm.securityAgeObjs[k].insuYear],
		// 								minHolderAge: payTypeConfigs[i].minHolderAge,
		// 								// min_app_age: payTypeConfigs[i].min_app_age,
		// 								min_app_age: secArr[j][vm.securityAgeObjs[k].insuYear+"MIN"],
		// 								payment_type: payTypeConfigs[i].payment_type,
		// 							}
		// 						};
		// 					}
		// 				}
		// 			}
		// 		}
		// 	}

		// 	// console.log("+++payAges++++++payWays+++++++++payAgeObjs+++++++++++");
		// 	// console.log(vm.payAges);
		// 	// console.log(vm.payWays);
		// 	// console.log(vm.payAgeObjs);
		// 	// console.log("-----------------------------");

		// 	//设置默认缴费期间
		// 	vm.payAge = vm.payAges[0].value;
		// 	//设置默认缴费方式
		// 	vm.payWay = vm.payWays[0].value;
		// };
		// vm.getPayWay();


		// // 根据缴费年期和用户年龄获取保险期间
		// // 同时设置默认 保险期间 和 主险数据
		// var getSecurityAgesByPayAges = function(){
		// 	var age = null;
		// 	if (vm.user.birthday) {
		// 		age = VALIDATION.getAgeByBirth(vm.user.birthday);
		// 	} else {
		// 		age = null;
		// 	}

		// 	var secArr = payAgeAndMaxAge[vm.payAge];
		// 	var securityArr = [];
		// 	var securityNum = [];
		// 	for (var i = 0; i < secArr.length; i++) {
		// 		for (var j = 0; j < vm.securityAgeObjs.length; j++) {
		// 			if (secArr[i].securityAge == vm.securityAgeObjs[j].insuYear) {
		// 				//如果没填年龄或年龄不符合当前保险期间要求则不设置进去
		// 				if(age || age == "0"){
		// 					if (age >= secArr[i][secArr[i].securityAge+"MIN"] && age <= secArr[i][secArr[i].securityAge]) {
		// 						securityArr.push(vm.securityAgeObjs[j]);
		// 						securityNum.push(vm.securityAgeObjs[j].insuYear);
		// 					}
		// 				}else{
		// 					securityArr.push(vm.securityAgeObjs[j]);
		// 					securityNum.push(vm.securityAgeObjs[j].insuYear);
		// 				}
		// 			}
		// 		}
		// 	}
		// 	//console.log("+++secArr++++++securityArr++++++++++securityNum+++++++++");
		// 	//console.log(secArr);
		// 	//console.log(securityArr);
		// 	//console.log(securityNum);
		// 	//console.log("-----------------------------");

		// 	//设置默认保险期间（如果保险期间为空或当前已选保险期间已失效则重新设置）
		// 	if (securityArr && securityArr.length>0) {
		// 		vm.securityAges = securityArr;
		// 		if (!vm.securityAge || securityNum.indexOf(vm.securityAge) == -1) {
		// 			vm.securityAge = securityArr[0].insuYear;
		// 		}
		// 	}
		// 	//设置默认主险数据
		// 	vm.mainPlan = vm.mainPlanObjs[vm.securityAge].planObj;
		// };
		// getSecurityAgesByPayAges();


		// //根据缴费期间和保险期间，确定映射对象，设置投保人最大最小年龄
		// var setMinAndMaxAges = function(){
		// 	if(vm.payAgeObjs[vm.payAge][vm.securityAge]){
		// 		var obj = vm.payAgeObjs[vm.payAge][vm.securityAge].map;

		// 		vm.maxAge = obj.max_app_age;
		// 		vm.minAge = obj.min_app_age;
		// 		vm.minHolderAge = obj.minHolderAge;
		// 		vm.maxHolderAge = obj.maxHolderAge;
				
		// 		vm.minStartDate = VALIDATION.getDateByAge(vm.maxAge); // 年龄最小开始日期
		// 		vm.maxEndDate = VALIDATION.getDateByAge(vm.minAge); // 年龄最大结束日期
		// 		vm.holderStartDate = VALIDATION.getDateByAge(vm.maxHolderAge); // 投保人年龄最小开始日期
		// 		vm.holderEndDate = VALIDATION.getDateByAge(vm.minHolderAge); // 投保人年龄最大结束日期
		// 		//console.log("---vm.payAgeObjs["+vm.payAge+"]["+vm.securityAge+"].map --> MaxAge："+obj.max_app_age+"岁---");
		// 	}
		// };
		// setMinAndMaxAges();


		// //根据被保人年龄，设置 可选的缴费期间、保险期间 和 保额最大值
		// var setMaxAmountByAge = function(){
		// 	var user = vm.user;
		// 	if(user.sex && user.birthday){
		// 		var age = VALIDATION.getAgeByBirth(user.birthday);

		// 		//1.筛选符合当前选择年龄的缴费期间
		// 		var payage_value_now = [];
		// 		for (var i = 0; i < vm.payAges.length; i++) {
		// 			for (var j = 0; j < vm.securityAges.length; j++) {
		// 				if (vm.payAgeObjs[vm.payAges[i].value][vm.securityAges[j].insuYear]) {
		// 					var obj = vm.payAgeObjs[vm.payAges[i].value][vm.securityAges[j].insuYear].map;
		// 					if (obj && age <= obj.max_app_age && age >= obj.min_app_age) {
		// 						if (payage_value_now.indexOf(vm.payAges[i].value) == -1) {
		// 							payage_value_now.push(vm.payAges[i].value);
		// 						}
		// 					}
		// 				}
		// 			}
		// 		}
		// 		//缴费期间列表
		// 		vm.payAges = [];
		// 		if (payage_value_now && payage_value_now.length > 0) {
		// 			for (var i = 0; i < payage_value_now.length; i++) {
		// 				vm.payAges.push({
		// 					value: payage_value_now[i],
		// 					label: payage_value_now[i] + "年"
		// 				})
		// 			}
		// 		}

		// 		//2.如果当前选择的缴费期间已经不合法，则设置默认值
		// 		if (!vm.payAge || payage_value_now.indexOf(vm.payAge) == -1) {
		// 			vm.payAge == vm.payAges[0].value;
		// 		}

		// 		//3.现在已确定缴费期间有效并选定，则筛选出有效的保险期间，并设置默认主险
		// 		getSecurityAgesByPayAges();

		// 		//以上操作会变更主险，需要设置 保额最大值
		// 		if (age !== null && age !== undefined) {
		// 			if (age >= 0 && age <= 9 ) {
		// 				vm.mainPlan.maxBuyQautity = 200000/vm.mainPlan.insuredAmount;
		// 			} else if (age >= 10 && age <= 40) {
		// 				vm.mainPlan.maxBuyQautity = 300000/vm.mainPlan.insuredAmount;
		// 			} else if (age >= 41 && age <= 45) {
		// 				vm.mainPlan.maxBuyQautity = 200000/vm.mainPlan.insuredAmount;
		// 			} else if (age >= 46 && age <= 50) {
		// 				vm.mainPlan.maxBuyQautity = 100000/vm.mainPlan.insuredAmount;
		// 			// } else if (age>=51 && age<=55) {
		// 			// vm.mainPlan.maxBuyQautity = 50000/vm.mainPlan.insuredAmount;
		// 			}
		// 		}

		// 		// vm.mainPlanObjs[item.ins  uYear].planObj.insuredAmountNow = vm.mainPlanObjs[item.insuYear].planObj.insuredAmount*10;
		// 		// vm.mainPlanObjs[item.insuYear].planObj.minBuyQautityNow = vm.mainPlanObjs[item.insuYear].planObj.minBuyQautity/10;
		// 		vm.mainPlan.maxBuyQautityNow = vm.mainPlan.maxBuyQautity/10;

		// 	}

		// 	// console.log("+++vm.payAges+++++++vm.securityAges++++++++++++");
		// 	// console.log(vm.payAges);
		// 	// console.log(vm.securityAges);
		// 	// console.log("vm.payAge:"+ vm.payAge + "---" + "vm.securityAge:" + vm.securityAge);
		// 	// console.log("age:"+age + "---" + "maxBuyQautity:" + vm.mainPlan.maxBuyQautity);
		// 	// console.log("-----------------------------");
		// };
		// setMaxAmountByAge();


		// //console.log("+++进入页面时所有数据准备完毕++Start+");
		// //console.log("+++payAge+++++payWay+++++++securityAge+++++++mainPlan++++++");
		// //console.log("payAge:" + vm.payAge);
		// //console.log("payWay:" + vm.payWay);
		// //console.log("securityAge:" + vm.securityAge);
		// //console.log("maxAmount:" + vm.mainPlan.maxBuyQautity*vm.mainPlan.insuredAmount);
		// //console.log(vm.mainPlan);
		// //console.log("---进入页面时所有数据准备完毕--End-");


		// //根据已选缴费期间和保险期间，验证年龄是否有效合法
		// var validateBirthday = function(){
		// 	if (vm.user.birthday && vm.minAge && vm.maxAge) {
		// 		var age = VALIDATION.getAgeByBirth(vm.user.birthday);
		// 		if (age <= vm.maxAge && age >= vm.minAge) {
		// 			return true;
		// 		} else {
		// 			return false;
		// 		}
		// 	} else {
		// 		return false;
		// 	}
		// };

		// //根据当前年龄，验证保额是否有效合法
		// var validateMoney = function(){
		// 	if(vm.user.sex && vm.user.birthday && vm.mainPlan.amount){
		// 		if (vm.mainPlan.amount <= vm.mainPlan.maxBuyQautity*vm.mainPlan.insuredAmount && vm.mainPlan.amount >= vm.mainPlan.minBuyQautity*vm.mainPlan.insuredAmount) {
		// 			return true;
		// 		} else {
		// 			return false;
		// 		}
		// 	}else{
		// 		return false;
		// 	}
		// };


		// // 下一步按钮是否可用-默认不可用
		// vm.nextStepValide = true;
		// // 验证下一步按钮是否可用
		// var isNextStepValide = function(){
		// 	//主险信息完整则可用
		// 	if (validateBirthday() && validateMoney()) {
		// 		vm.nextStepValide = false;
		// 	}else{
		// 		vm.nextStepValide = true;
		// 	}
		// 	//console.log("vm.nextStepValide:"+vm.nextStepValide + "---" + "validateBirthday():" + validateBirthday() + "---" + "validateMoney():" + validateMoney());
		// };


		// //--------------监听页面数据动态变化-----------------------
		// // 监听缴费期间
		// $scope.$watch('enll.payAge', function(newValue) {
		// 	//console.log("***watch --- payAge: " + newValue);
		// 	if (newValue) {
		// 		//更新保险期间可选项，同时设置 当前主险 和 最高保额
		// 		var amountTemp = vm.mainPlan ? vm.mainPlan.amount : "";
		// 		getSecurityAgesByPayAges();
		// 		vm.mainPlan.amount = amountTemp;

		// 		//根据缴费期间和保险期间，确定映射对象，设置投保人最大最小年龄
		// 		setMinAndMaxAges();
		// 		//根据被保人年龄，设置 可选的缴费期间、保险期间 和 保额最大值
		// 		setMaxAmountByAge();

		// 		//页面数据有效合法则计算保费
		// 		if (validateBirthday() && validateMoney()) {
		// 			vm.calc(vm);
		// 		}else{
		// 			vm.totalExp = "";
		// 		}

		// 		// 验证下一步按钮是否可用
		// 		isNextStepValide();
		// 	}
		// }, true);

		// // 监听缴费方式
		// $scope.$watch('enll.payWay', function(newValue) {
		// 	//console.log("***watch --- payWay: " + newValue);
		// 	if (newValue) {
		// 		//页面数据有效合法则计算保费
		// 		if (validateBirthday() && validateMoney()) {
		// 			vm.calc(vm);
		// 		}else{
		// 			vm.totalExp = "";
		// 		}

		// 		// 验证下一步按钮是否可用
		// 		isNextStepValide();
		// 	}
		// }, true);

		// // 监听保险期间
		// $scope.$watch('enll.securityAge', function(newValue) {
		// 	//console.log("***watch --- securityAge: " + newValue);
		// 	if (newValue) {
		// 		//设置当前主险
		// 		var amountTemp = vm.mainPlan ? vm.mainPlan.amount : "";
		// 		vm.mainPlan = vm.mainPlanObjs[vm.securityAge].planObj;
		// 		vm.mainPlan.amount = amountTemp;

		// 		//根据缴费期间和保险期间，确定映射对象，设置投保人最大最小年龄
		// 		setMinAndMaxAges();
		// 		//根据被保人年龄，设置 可选的缴费期间、保险期间 和 保额最大值
		// 		setMaxAmountByAge();

		// 		//页面数据有效合法则计算保费
		// 		if (validateBirthday() && validateMoney()) {
		// 			vm.calc(vm);
		// 		}else{
		// 			vm.totalExp = "";
		// 		}

		// 		// 验证下一步按钮是否可用
		// 		isNextStepValide();
		// 	}
		// }, true);

		// // 监听获取用户信息
		// $scope.$watch('enll.user', function(newValue) {
		// 	//console.log("***watch --- birthday: " + newValue.birthday + "sex: " + newValue.sex);
		// 	var user = newValue;
		// 	if(user.sex && user.birthday){
		// 		var age = VALIDATION.getAgeByBirth(user.birthday);
				
		// 		//根据被保人年龄，设置 可选的缴费期间、保险期间 和 保额最大值
		// 		setMaxAmountByAge();

		// 		//页面数据有效合法则计算保费
		// 		if (validateBirthday() && validateMoney()) {
		// 			vm.calc(vm);
		// 		}else{
		// 			vm.totalExp = "";
		// 		}

		// 		// 验证下一步按钮是否可用
		// 		isNextStepValide();
		// 	}
		// }, true);

		// // 监听用户输入的保额
		// $scope.$watch('enll.mainPlan.amount', function(newValue) {
		// 	//console.log("***watch --- amount: " + vm.mainPlan.amount);
		// 	if (newValue) {
		// 		//页面数据有效合法则计算保费
		// 		if (validateBirthday() && validateMoney()) {
		// 			vm.calc(vm);
		// 		}else{
		// 			vm.totalExp = "";
		// 		}

		// 		// 验证下一步按钮是否可用
		// 		isNextStepValide();
		// 	}
		// }, true);

		// //--------------监听页面数据动态变化---------END--------------


		// // 计算保费方法
		// vm.calc = function(vm, callback) {
		// 	// console.log("-----------calc Start---------------");

		// 	//页面值校验位-true则正常回调，false则回调空值
		// 	var validateFlag = false;
		// 	//重算方法回调时，通过缴费期间和保险期间判断有效年龄和有效保额
		// 	var validateBirthdayAndMoney = function(){
		// 		//校验年龄
		// 		if (vm.user.birthday && vm.minAge && vm.maxAge) {
		// 			var age = VALIDATION.getAgeByBirth(vm.user.birthday);
		// 			if (age <= vm.maxAge && age >= vm.minAge) {
		// 				validateFlag = true;
		// 			} else {
		// 				TipService.showMsg("当前缴费期间和保险期间，被保人最大年龄为"+vm.maxAge+"岁。");
		// 				validateFlag = false;
		// 			}
		// 		}

		// 		//根据当前年龄设置最大保额
		// 		if (vm.user.birthday && vm.mainPlan.amount) {
		// 			var age = VALIDATION.getAgeByBirth(vm.user.birthday);
		// 			var maxAmount = 300000;
		// 			if (age >=0 && age <=9) {
		// 				maxAmount = 200000;
		// 			} else if (age>=10 && age<=40) {
		// 				maxAmount = 300000;
		// 			} else if (age>=41 && age<=45) {
		// 				maxAmount = 200000;
		// 			} else if (age>=46 && age<=50) {
		// 				maxAmount = 100000;
		// 			// } else if (age>=51 && age<=55) {
		// 			// maxAmount = 50000;
		// 			}

		// 			//校验金额
		// 			if (vm.mainPlan.amount <= maxAmount) {
		// 				validateFlag = true;
		// 			} else {
		// 				TipService.showMsg("当前缴费期间和保险期间，" + age + "岁被保人最大投保金额为"+maxAmount+"元。");
		// 				validateFlag = false;
		// 			}
		// 		}
		// 	}
		// 	if(callback){
		// 		validateBirthdayAndMoney();
		// 	}


		// 	//根据缴费方式获取K值
		// 	var getKRateByPaytype = function(value) {
		// 		var KRate = 0;
		// 		if (value == 12) {
		// 			KRate = 1.000;
		// 		} else if (value == 1) {
		// 			KRate = 1/12;
		// 		}
		// 		return KRate;
		// 	}

		// 	//同步主险数据到附加险
		// 	vm.addPlan.amount = vm.mainPlan.amount;
		// 	vm.addPlan.payendyear = vm.mainPlan.payAge;
		// 	vm.addPlan.paymentType = vm.mainPlan.payWay;
		// 	vm.addPlan.insuYear = vm.mainPlan.securityAge;

		// 	// 开始计算
		// 	var user = vm.user,
		// 		age = VALIDATION.getAgeByBirth(user.birthday);

		// 	// 获取费率
		// 	var params = {
		// 		prdId: vm.productData.prd_id,
		// 		age: age,
		// 		sex: user.sex,
		// 		payEndYear: vm.payAge
		// 	};
		// 	// console.log(params);

		// 	CommonRequest.request(params, CONFIG.PRODUCT_PURCHASE_CALCULATE_SERVICE, function(result) {
		// 		//console.log(result);
		// 		if (result.status == 1) {
		// 			var rateTable = result.data,
		// 				mainRate = [], // 主险费率表
		// 				addRate = []; // 附加险费率表

		// 			//重置总保额和总保费
		// 			vm.totalAmount = "";
		// 			vm.totalExp = "";

		// 			if (rateTable && rateTable.length > 0) {
		// 				for (var i = 0; i < rateTable.length; i++) {
		// 					if (rateTable[i].planType == '1' && 
		// 						rateTable[i].planCode == vm.mainPlan.planCode && 
		// 						rateTable[i].insuyear == vm.securityAge) {
		// 						mainRate.push(rateTable[i]);
		// 					} else if (rateTable[i].planType == '2' && 
		// 						rateTable[i].planCode == vm.addPlan.planCode && 
		// 						rateTable[i].insuyear == vm.securityAge) {
		// 						addRate.push(rateTable[i]);
		// 					}
		// 				}

		// 				//主险费率和保费计算
		// 				if (mainRate && mainRate.length > 0) {
		// 					//弱体等级为A时是否有费率，没有则取费率列表第一个
		// 					var isRisk = false;
		// 					for (var i = 0; i < mainRate.length; i++) {
		// 						if (mainRate[i].suppriskscore == "A") {
		// 							vm.mainPlan.rate = mainRate[i].rate;
		// 							isRisk = true;
		// 						}
		// 					}
		// 					if (!isRisk) {
		// 						vm.mainPlan.rate = mainRate[0].rate;
		// 					}
		// 				}

		// 				//附加险费率和保费计算
		// 				if (addRate && addRate.length > 0) {
		// 					var isRisk = false;
		// 					for (var i = 0; i < addRate.length; i++) {
		// 						if (addRate[i].suppriskscore == "A") {
		// 							vm.addPlan.rate = addRate[i].rate;
		// 							isRisk = true;
		// 						}
		// 					}
		// 					if (!isRisk) {
		// 						vm.addPlan.rate = addRate[0].rate;
		// 					}
		// 				}

		// 				// if (vm.payWay == "1") {
		// 				// 	// 月缴则调用接口进行计算
		// 				// 	var calcParams = {
		// 				// 		mainRate: vm.mainPlan.rate,
		// 				// 		addRate: vm.addPlan.rate,
		// 				// 		Kvalue: 12, //接口中做除法，直接传值12
		// 				// 		insuredAmount: (vm.mainPlan.amount/vm.mainPlan.insuredAmount)
		// 				// 	};
		// 				// 	CommonRequest.request(calcParams, CONFIG.PRODUCT_GETEXP_CALCULATE_SERVICE, function(result) {
		// 				// 		// console.log(result);
		// 				// 		if (result.status == 1) {
		// 				// 			// 每月总保费
		// 				// 			vm.mainPlan.exp = result.data.mainExp;
		// 				// 			vm.addPlan.exp = result.data.addExp;
									
		// 				// 			vm.totalAmount = Number(vm.mainPlan.amount) + Number(vm.addPlan.amount);
		// 				// 			vm.totalExp = Number(vm.mainPlan.exp) + Number(vm.addPlan.exp);
		// 				// 			//首月保费和年化保费
		// 				// 			vm.totalExp = vm.totalExp * 2;
		// 				// 			vm.expByYear = vm.totalExp * 6;

		// 				// 			// 重算回调方法
		// 				// 			if (callback) {
		// 				// 				// 最低年化保费不得低于1000元 
		// 				// 				if (vm.expByYear < 1000) {
		// 				// 					TipService.showMsg("您的投保保额不在本产品投保保额范围之内!");
		// 				// 					return;
		// 				// 				} else if (validateFlag) {
		// 				// 					callback({
		// 				// 						exp: vm.totalExp,
		// 				// 						amount: vm.totalAmount,
		// 				// 						mainPlan: vm.mainPlan,
		// 				// 						addPlan: vm.addPlan
		// 				// 					});
		// 				// 				}
		// 				// 			}
		// 				// 		} else {
		// 				// 			TipService.showMsg("保费计算失败，请稍后重试！");
		// 				// 			return;
		// 				// 		}
		// 				// 	});
		// 				// } else if (vm.payWay == "12") {
		// 					//年缴则直接前端计算
		// 					//计算主险保费
		// 					if(vm.mainPlan.rate){
		// 						// console.log("--main--"+vm.mainPlan.rate*10 * getKRateByPaytype(vm.payWay) * (vm.mainPlan.amount/vm.mainPlan.insuredAmount) / 10);
		// 						vm.mainPlan.exp = Math.round(vm.mainPlan.rate*10 * getKRateByPaytype(vm.payWay) * (vm.mainPlan.amount/vm.mainPlan.insuredAmount) / 10, 0).toFixed(2);
		// 					}else{
		// 						TipService.showMsg("龙佑安康尊享版两全保险费率为空！");
		// 					}
		// 					//计算附加险保费
		// 					if(vm.addPlan.rate){
		// 						// console.log("--add---"+vm.addPlan.rate*10 * getKRateByPaytype(vm.payWay) * (vm.addPlan.amount/vm.addPlan.insuredAmount) / 10);
		// 						vm.addPlan.exp = Math.round(vm.addPlan.rate*10 * getKRateByPaytype(vm.payWay) * (vm.addPlan.amount/vm.addPlan.insuredAmount) / 10, 0).toFixed(2);
		// 					}else{
		// 						TipService.showMsg("附加龙佑安康尊享版重大疾病保险费率为空！");
		// 					}
		// 					//计算总保额，总保费
		// 					vm.totalAmount = Number(vm.mainPlan.amount) + Number(vm.addPlan.amount);
		// 					vm.totalExp = Number(vm.mainPlan.exp) + Number(vm.addPlan.exp);
		// 					//年化保费
		// 					if (vm.payWay == "1") {
		// 						vm.mainPlan.exp = parseInt(vm.mainPlan.exp) * 2;
		// 						vm.addPlan.exp = parseInt(vm.addPlan.exp) * 2;
		// 	                    vm.expByYear = vm.totalExp*6;
		// 	                    vm.totalExp = vm.totalExp * 2;
		// 	                } else if(vm.payWay == "12"){
		// 	                    vm.expByYear = vm.totalExp;
		// 	                }

		// 					// 重算回调方法
		// 					if(callback){
		// 						//最低年化保费不得低于1000元
		// 						if (vm.expByYear < 1000) {
		// 							TipService.showMsg("您的投保保额不在本产品投保保额范围之内!");
		// 							return;
		// 						} else if (validateFlag) {
		// 							callback({
		// 								exp: vm.totalExp,
		// 								amount: vm.totalAmount,
		// 								mainPlan: vm.mainPlan,
		// 								addPlan: vm.addPlan
		// 							});
		// 						}
		// 					}
		// 				// }
		// 			}else{
		// 				TipService.showMsg("产品费率查询失败！");
		// 				return;
		// 			}

		// 			// console.log("+++++++++++calc Result+++++++++++++++");
		// 			// console.log("vm.mainPlan.rate:"+vm.mainPlan.rate);
		// 			// console.log("vm.addPlan.rate:"+vm.addPlan.rate);
		// 			// console.log("vm.mainPlan.exp:"+vm.mainPlan.exp);
		// 			// console.log("vm.addPlan.exp:"+vm.addPlan.exp);
		// 			// console.log("totalAmount:"+vm.totalAmount);
		// 			// console.log("totalExp:"+vm.totalExp);
		// 			// console.log("expByYear:"+vm.expByYear);
		// 			// console.log("-----------calc End---------------");
		// 		}
		// 	});
		// };

		// // 跳转投保页面
		// vm.goPolicy = function() {
		// 	//最低年化保费不得低于1000元
		// 	if (vm.expByYear < 1000) {
		// 		TipService.showMsg("您的投保保额不在本产品投保保额范围之内!");
		// 		return;
		// 	}

		// 	vm.mainPlan.exp = vm.mainPlan.exp.toString();
		// 	vm.mainPlan.amount = vm.mainPlan.amount.toString();
		// 	var params = {
		// 		prdId: vm.productData.prd_id,
		// 		sex: vm.user.sex,
		// 		insurerBirthDay: $filter('date')(vm.user.birthday, 'yyyyMMdd'),
		// 		planId: vm.mainPlan.planId,
		// 		extraPlanId: vm.addPlan.planId,
		// 		premiumResult: vm.totalExp,
		// 		orderCode: vm.productData.orderCode || ''
		// 	};

		// 	PolicyService.doCalc(params, function() {
		// 		// 数据处理
		// 		PolicyService.control({
		// 			state: 'product-purchase-calculate',
		// 			control: 'data',
		// 			data: {
		// 				birthday: $filter('date')(vm.user.birthday, 'yyyy-MM-dd'), // 被保人生日
		// 				sex: vm.user.sex, // 被保人性别
		// 				// selectedPlan: isSelectAddPlan, //vm.user.selectedPlan, //是否选择附加险
		// 				mainPlan: vm.mainPlan, // 主险
		// 				addPlan: vm.addPlan, // 附加险
		// 				payendyear: vm.payAge, // 缴费期间
		// 				paymentType: vm.payWay, // 缴费方式
		// 				PbInsuAmt: vm.totalAmount, // 保险总保额
		// 				PbInsuExp: vm.totalExp, // 保险总保费
		// 				pbApplNoNum: 1,
		// 				isWholeSale: vm.paymentType == '0' ? true : false,
		// 				minAge: vm.minAge,
		// 				maxAge: vm.maxAge,
		// 				minHolderAge: vm.minHolderAge,
		// 				maxHolderAge: vm.maxHolderAge,
		// 				calc: vm.calc.toString(),
		// 				calcCtrl: vm
		// 			}
		// 		});
		// 		// 流程跳转
		// 		PolicyService.control({
		// 			state: 'product-purchase-calculate',
		// 			control: 'process'
		// 		});
		// 	});
		// };
		// 初始化开始

        // 用户选择的数据
        vm.user = {};
        vm.user.sex = '1';
        vm.user.birthday = null;
        vm.params = null;

        // 投被保人年龄
        var payTypeConfigs = vm.productData.payTypeConfigs;
        if (payTypeConfigs && payTypeConfigs.length > 0) {
            var minAge = "", maxAge = "";
            //获取被保人最大，和最小年龄限制
            for (var i = 0; i < payTypeConfigs.length; i++) {
                var payTypeConfig = payTypeConfigs[i];
                if (i == 0) {
                    minAge = payTypeConfig.min_app_age;
                    maxAge = payTypeConfig.max_app_age;
                } else {
                    if (minAge > payTypeConfig.min_app_age) {
                        minAge = payTypeConfig.min_app_age;
                    }
                    if (maxAge < payTypeConfig.max_app_age) {
                        maxAge = payTypeConfig.max_app_age;
                    }
                }
            }

            vm.defMinAge = vm.minAge = minAge;
            vm.defMaxAge = vm.maxAge = maxAge;
            vm.minHolderAge = payTypeConfigs[0].minHolderAge;
            vm.maxHolderAge = payTypeConfigs[0].maxHolderAge;

            vm.minStartDate = VALIDATION.getDateByAge(vm.maxAge); // 年龄最小开始日期
            vm.maxEndDate = VALIDATION.getDateByAge(vm.minAge); // 年龄最大结束日期
            //vm.holderStartDate = VALIDATION.getDateByAge(vm.maxHolderAge); // 投保人年龄最小开始日期
            //vm.holderEndDate = VALIDATION.getDateByAge(vm.minHolderAge); // 投保人年龄最大结束日期
        }

        // 主险数据
        vm.mainPlan = {
            rate: 0,
            amount: '',
            exp: ''
        };
        vm.addPlan = {
            rate: 0,
            amount: '',
            exp: ''
        };
        vm.totalExp = 0;
        vm.totalAmount = 0;

        //--------------------------------
        //获取缴费年限、缴费方式、保险期间

        //缴法比率/缴费方式名称
        //（年缴K=1.000，月缴K=1/12）
        vm.KObj = {
            "-1": {
                value: 1.000, //'不定期交'
                label: '不定期交'
            },
            "0": {
                value: 1.000, //'趸交'
                label: '趸交'
            },
            "1": {
                // value: (1/12), //'月交'
                value: 0.08333333, //'月交'
                label: '月交'
            },
            "3": {
                value: 1.000, //'季交'
                label: '季交'
            },
            "6": {
                value: 1.000, //'半年交'
                label: '半年交'
            },
            "12": {
                value: 1.000, //'年交'
                label: '年交'
            },
            "98": {
                value: 1.000, //'交至某确定年龄'
                label: '交至某确定年龄'
            },
            "99": {
                value: 1.000, //'终生交费'
                label: '终生交费'
            }
        };

        // 获取产品计划
        vm.getPlan = function() {
            var insuYearUnitObj ={
                "Y":"年",
                "M":"月",
                "D":"天",
                "A":"周岁"
            };

            var plan = vm.productData.plans,
                len = plan.length;

            //保险期间 20年 30年 至70周岁 至80周岁 security
            /**
             * {
             *   "20年":{} 
             *   "30年":{} 
             *   "至70周岁":{} 
             *   "至80周岁":{} 
             * }
             */
            vm.securityObj = {};

            var flgStr = [];
            for (var i = len - 1; i >= 0; i--) {
                var item = plan[i];
                if (item.planType == '1') {
                    // 获取主险CNM
                    //保险期间
                    var label = item.insuYear+insuYearUnitObj[item.insuYearFlag];
                    if(item.insuYearFlag == "A"){
                        label = "至"+label;
                    }
                    if(flgStr.join(",").indexOf(label) === -1){
                        flgStr.push(label);
                        angular.extend(item, {label:label}); //添加label
                        vm.securityObj[label] = item;
                    }
                } else if (item.planType == '2') {
                    // 获取附加险MLGB
                    angular.extend(vm.addPlan, item);
                }
            }
        };

        vm.getPlan();

        //根据年龄，重设最大保额限制
        var reSetAmountMax = function(plan){
            var age = VALIDATION.getAgeByBirth(vm.user.birthday);
            var newPlan = plan,
                maxBuyQautity = "", 
                insuredAmount = newPlan.insuredAmount;

            if (age <= 9) {
                maxBuyQautity = 200000/insuredAmount;
            } else if(age >= 10 && age <= 17){
                maxBuyQautity = 300000/insuredAmount;
            } else if(age >= 18 && age <= 40){
                maxBuyQautity = 300000/insuredAmount;
            } else if(age >= 41 && age <= 45){
                maxBuyQautity = 200000/insuredAmount;
            } else if(age >= 46 && age <= 50){
                maxBuyQautity = 100000/insuredAmount;
            }
            maxBuyQautity = maxBuyQautity.toString();
            angular.extend(newPlan, {maxBuyQautity:maxBuyQautity});
            //主险、附加险信息同步
            angular.extend(vm.addPlan, {
                insuYear: newPlan.insuYear,
                insuYearFlag: newPlan.insuYearFlag,
                maxBuyQautity: maxBuyQautity
            });
            return newPlan;
        };

        //获取缴费方式
        var getPaymentType = function(paymentTypeStr) {
            paymentTypeStr = paymentTypeStr || vm.paymentTypeStr;
            var obj = vm.payWaySObjs[paymentTypeStr][vm.payAgeStr][vm.securityStr];
            // console.log("obj.payment_type:"+obj.payment_type);
            vm.paymentType = obj.payment_type;
        };

        //获取缴费年限
        var getPayAge = function(payAgeStr) {
            payAgeStr = payAgeStr || vm.payAgeStr;
            var obj = vm.payWaySObjs[vm.paymentTypeStr][payAgeStr][vm.securityStr];
            // console.log("obj.pay_age:"+obj.pay_age);
            vm.user.payendyear = obj.pay_age;
        };

        //获取保险期间
        var getPlan = function(securityStr) {
            securityStr = securityStr || vm.securityStr;
            var obj = vm.payWaySObjs[vm.paymentTypeStr][vm.payAgeStr][securityStr];
            var plan = obj.plan;
            if(vm.user.birthday){
                //根据年龄，重设最大保额限制
                plan = reSetAmountMax(plan);
            }
            angular.extend(vm.mainPlan, plan);
            //insuredAmount 提升为10000
            angular.extend(vm.mainPlan, {
                insuredAmount_e: (plan.insuredAmount*10).toString(),
                minBuyQautity_e: (plan.minBuyQautity/10).toString(),
                maxBuyQautity_e: (plan.maxBuyQautity/10).toString()
            });
            // console.log("obj.plan.insuYear:"+obj.plan.insuYear);
            vm.security = obj.plan.insuYear;
        };
        
        //生成缴费年限、缴费方式、保险期间映射
        vm.getPayWayAndSecurity = function() {
            //缴费年限、缴费方式不为空
            var payAgeUnitObj = {
                "Y": "年",
                "M": "月",
                "D": "天",
                "A": "年龄"
            };

            //缴费年限、保险期间对应年龄
            var payAgeSecurity_MaxAge = {
                "10年":{
                    "20年":{
                        "min": 18,
                        "max": 45
                    },
                    "30年":{
                        "min": 18,
                        "max": 50
                    },
                    "至70周岁":{
                        "min": 0,
                        "max": 45
                    },
                    "至80周岁":{
                        "min": 0,
                        "max": 50
                    }
                },
                "15年":{
                    "20年":{
                        "min": 18,
                        "max": 45
                    },
                    "30年":{
                        "min": 18,
                        "max": 45
                    },
                    "至70周岁":{
                        "min": 0,
                        "max": 45
                    },
                    "至80周岁":{
                        "min": 0,
                        "max": 50
                    }
                },
                "20年":{
                    "30年":{
                        "min": 18,
                        "max": 45
                    },
                    "至70周岁":{
                        "min": 0,
                        "max": 40
                    },
                    "至80周岁":{
                        "min": 0,
                        "max": 45
                    }
                }
            }

            //获取缴费年限、保险期间映射，设置最高投保年龄
            var setPayAgeSecuritys = function(config, paymentStr, payAgeStr, flag){
                var securityS = {};
                var obj = null, payObj = {};
                for (obj in vm.securityObj) {
                    var label = vm.securityObj[obj].label;
                    var age_Obj = payAgeSecurity_MaxAge[payAgeStr][label];
                    if(age_Obj){
                        var minApp_age = age_Obj["min"];
                        var maxApp_age = age_Obj["max"];
                        payObj[label] = {
                            maxHolderAge: config.maxHolderAge,
                            max_app_age: maxApp_age.toString(), //最大投保年龄
                            minHolderAge: config.minHolderAge,
                            min_app_age: minApp_age.toString(), //最小投保年龄
                            payment_type: config.payment_type,
                            pay_age: config.pay_age,
                            payAgeUnit: config.payAgeUnit,
                            plan: vm.securityObj[obj]
                        };
                    }
                }
                //添加映射关系
                if(!flag){
                    securityS[payAgeStr] = payObj;
                    vm.payWaySObjs[paymentStr] = securityS;
                } else{
                    vm.payWaySObjs[paymentStr][payAgeStr] = payObj;
                }
            };

            //缴费方式 月交 年交
            vm.payWays = [];  
            //记录缴费年限信息
            vm.payAgeObj = {};
            //缴费年限 10年 15年 20年
            vm.payAges = {};
            //保险期间 20年 30年 至70周岁 至70周岁 security
            vm.securityObjs = {};

            //缴费方式映射缴费年限、保险期间及被保人年龄限制
            /**
             *{
             *   '月交':{ //缴费方式
             *       '10年':{ //缴费年限
             *            '20年':{}, //保险期间
             *            '30年':{},
             *            '至70周岁':{},
             *            '至80周岁':{},
             *        }
             *    }
             *}
             */
            vm.payWaySObjs = {}; 

            var payment_type = [];//用来处理重复数据
            if (payTypeConfigs && payTypeConfigs.length > 0) {
                for (i = 0; i < payTypeConfigs.length; i++) {
                    var payTypeConfig = payTypeConfigs[i];
                    var payAgeUnitFlag = payTypeConfig.payAgeUnit || "Y";
                    var payAgeUnit = payAgeUnitObj[payAgeUnitFlag] || "年";
                    var payAge_Str = payTypeConfig.pay_age + payAgeUnit;
                    vm.payAgeObj[payAge_Str] = {
                        pay_age:payTypeConfig.pay_age,
                        label: payAge_Str
                    };
                    var payment_Str = vm.KObj[payTypeConfig.payment_type+''].label;
                    //没有相同的缴费年限->添加缴费年限、缴费方式
                    if (payment_type.join(",").indexOf(payment_Str) === -1) {
                        payment_type.push(payment_Str); 

                        //获取缴费年限、保险期间映射，设置最高投保年龄
                        setPayAgeSecuritys(payTypeConfig, payment_Str, payAge_Str, false);
                    } else { //有相同的缴费年限->插入缴费方式
                        //过滤相同缴费方式
                        var flag = false;
                        var payAge_obj = null;
                        for (payAge_obj in vm.payWaySObjs[payment_Str]) {
                            if (payAge_obj.pay_age === payTypeConfig.pay_age) {
                                flag = true;
                            }
                        }
                        if (!flag) {
                            //获取缴费年限、保险期间映射，设置最高投保年龄
                            setPayAgeSecuritys(payTypeConfig, payment_Str, payAge_Str, true);
                        }
                    }
                }
            }

            //初始取出缴费方式、缴费年限和保险期间
            var obj = null, payAges = [], securityObjs = [];
            for (obj in vm.payWaySObjs) {
                vm.payWays.push(obj);
            }
            console.log(vm.payWays);
            vm.paymentTypeStr = vm.payWays[0];

            var payAgeObj = vm.payWaySObjs[vm.paymentTypeStr];
            for (obj in payAgeObj) {
                payAges.push(obj);
                vm.payAges[obj] = vm.payAgeObj[obj];
            }
            // console.log(vm.payAges);

            vm.payAgeObjForShow = [];
            for (var i = 0; i < payAges.length; i++) {
                vm.payAgeObjForShow.push({
                    label: payAges[i]
                }) ;
            }
            // console.log(vm.payAgeObjForShow);
            vm.payAgeStr = payAges[0];

            var securityObj = vm.payWaySObjs[vm.paymentTypeStr][vm.payAgeStr];
            for (obj in securityObj) {
                securityObjs.push(obj);
                vm.securityObjs[obj] = vm.securityObj[obj];
            }
            // console.log(vm.securityObjs);
            
            vm.securityObjForShow = [];
            for (var i = 0; i < securityObjs.length; i++) {
                vm.securityObjForShow.push({
                    label: securityObjs[i]
                }) ;
            }
            // console.log(vm.payAgeObjForShow);
 
            vm.securityStr = securityObjs[0];

            //初始取出缴费方式、缴费年限和保险期间默认为第一个
            getPaymentType(vm.paymentTypeStr);//获取缴费方式
            getPayAge(vm.payAgeStr);//获取缴费年限
            getPlan(vm.securityStr);//获取保险期间
        };

        // 执行
        vm.getPayWayAndSecurity();

        //--------------------------------
        //--------------------------------
        //排序 方法
        function createComparisonFunction(propertyName){
            return function(obj1, obj2){
                var value1 = obj1[propertyName];
                var value2 = obj2[propertyName];
                if(value1 < value2){
                    return -1;
                } else if(value1 > value2){
                    return 1;
                } else{
                    return 0;
                }
            };
        }

        //重排序对象
        function reSort(sortObj, sortName){
            var array = [], obj = null;
            for(obj in sortObj){
                array.push(sortObj[obj]);
            }
            array.sort(createComparisonFunction(sortName));
            var i, newObj = {};
            for(i = 0; i < array.length; i++){
                var label = array[i].label;
                newObj[label] = array[i];
            }
            return {
                array: array,
                newObj: newObj
            };
        }
        
        //设置投保人和被保人最大最小年龄
        var setMinAndMaxAges = function(paymentTypeStr, payAgeStr, securityStr) {
            var obj = vm.payWaySObjs[paymentTypeStr][payAgeStr][securityStr];
            vm.maxAge = obj.max_app_age;
            vm.minAge = obj.min_app_age;
            vm.minHolderAge = obj.minHolderAge;
            vm.maxHolderAge = obj.maxHolderAge;
        };

        //判断相等
        var isEqualed = function(oldValue, objForShow){
            var flag = false;
            for (var i = 0; i < objForShow.length; i++) {
                if(oldValue == objForShow[i].label){
                    flag = true;
                }
            }
            return flag;
        };

        //重置缴费年限
        var setPayAges = function(age, paymentTypeStr){
            var Objs = vm.payWaySObjs[paymentTypeStr];
            var obj = null;
            vm.payAgeObjForShow = [];

            //清空原先数据
            vm.payAges = {};
            for (obj in Objs) {
                if(age > 45 && age <= 50){
                    if("10年" == obj || "15年" == obj){
                        vm.payAges[obj] = vm.payAgeObj[obj];
                        vm.payAgeObjForShow.push({
                            label: vm.payAgeObj[obj].label
                        }) ;
                    }
                } else{
                    vm.payAges[obj] = vm.payAgeObj[obj];
                    vm.payAgeObjForShow.push({
                        label: vm.payAgeObj[obj].label
                    }) ;
                }
            }
            //重排序对象
            var newSortObj = reSort(vm.payAges, 'pay_age');
            vm.payAges = newSortObj.newObj;
            // console.log(vm.payAgeObjForShow);
            
            // if(!isEqualed(vm.payAgeStr, newSortObj)){
            //    vm.payAgeStr = newSortObj.array[0].label; 
            // }
            if(!isEqualed(vm.securityStr, vm.payAgeObjForShow)){
                vm.payAgeStr = vm.payAgeObjForShow[0].label;
            }
        };

        //重置保险期间
        var setSecuritys = function(age, paymentTypeStr, payAgeStr){
            var Objs = vm.payWaySObjs[paymentTypeStr][payAgeStr];
            var obj = null;
            vm.securityObjForShow = [];

            //清空原先数据
            vm.securityObjs = {};
            for (obj in Objs) {
                //被保险人46-50周岁，只能选择保险期间为30年和至被保险人80周岁，投保限额为10万；
                if(age >= 46 && age <= 50){
                    if("30年" == obj || "至80周岁" == obj){
                       if(age <= Objs[obj].max_app_age){
                            vm.securityObjs[obj] = vm.securityObj[obj]; 
                            vm.securityObjForShow.push({
                                label: vm.securityObj[obj].label
                            }) ;
                        } 
                    }
                } else {
                    //20年       18-45周岁
                    //30年       18-50周岁
                    //至70周岁   0-45周岁
                    //至80周岁   0-50周岁
                    if("20年" == obj || "30年" == obj){
                        if(age >= 18 && age <= Objs[obj].max_app_age){
                            vm.securityObjs[obj] = vm.securityObj[obj]; 
                            vm.securityObjForShow.push({
                                label: vm.securityObj[obj].label
                            }) ;
                        } 
                    } else {
                        if(age <= Objs[obj].max_app_age){ 
                            vm.securityObjs[obj] = vm.securityObj[obj]; 
                            vm.securityObjForShow.push({
                                label: vm.securityObj[obj].label
                            }) ;
                        }
                    }
                }
            }
            //重排序对象
            var newSortObj = reSort(vm.securityObjs, 'insuYear');
            vm.securityObjs = newSortObj.newObj;
            // console.log(vm.securityObjForShow);

            // if(!isEqualed(vm.securityStr, newSortObj)){
            //     vm.securityStr = newSortObj.array[0].label;
            // }
            if(!isEqualed(vm.securityStr, vm.securityObjForShow)){
                vm.securityStr = vm.securityObjForShow[0].label;
            }
        };

        //年龄改变导致缴费年限和保险期间变化
        var ageChange = function(birthday){
            var age = VALIDATION.getAgeByBirth(birthday);
            if(age >= 51){
                TipService.showMsg('最高投保年龄50周岁！');
                return;
            }
            //重置缴费年限
            setPayAges(age, vm.paymentTypeStr);
            //重置保险期间
            setSecuritys(age, vm.paymentTypeStr, vm.payAgeStr);

            getPaymentType(vm.paymentTypeStr);//获取缴费方式
            getPayAge(vm.payAgeStr);//获取缴费年限
            getPlan(vm.securityStr);//获取保险期间

            //设置投保人和被保人最大最小年龄
            setMinAndMaxAges(vm.paymentTypeStr, vm.payAgeStr, vm.securityStr);
        };

        // 监听生日改变
        $scope.$watch('enll.user.birthday', function(newValue) {
            var birthday = newValue;
            if(birthday){
                //年龄改变导致缴费年限和保险期间变化
                ageChange(birthday);
            }
        }, true);

        // 监听获取缴费方式
        $scope.$watch('enll.paymentTypeStr', function(newValue) {
            var paymentTypeStr = newValue;
            if(paymentTypeStr){
                if(vm.user.birthday){
                    var age = VALIDATION.getAgeByBirth(vm.user.birthday);
                    //重置缴费年限
                    setPayAges(age, paymentTypeStr);
                    //重置保险期间
                    setSecuritys(age, paymentTypeStr, vm.payAgeStr);
                }
                
                getPaymentType(paymentTypeStr);//获取缴费方式
                getPayAge(vm.payAgeStr);//获取缴费年限
                getPlan(vm.securityStr);//获取保险期间

                //设置投保人和被保人最大最小年龄
                setMinAndMaxAges(paymentTypeStr, vm.payAgeStr, vm.securityStr);
            
                //获取费率，计算保额保费
                if(vm.user.birthday && vm.mainPlan.amount){
                    vm.calc(vm);  
                }
            }
        }, true);

        // 监听获取缴费年限
        $scope.$watch('enll.payAgeStr', function(newValue) {
            var payAgeStr = newValue;
            if(payAgeStr){
                if(vm.user.birthday){
                    var age = VALIDATION.getAgeByBirth(vm.user.birthday);
                    //重置保险期间
                    setSecuritys(age, vm.paymentTypeStr, payAgeStr);
                }
                
                getPayAge(payAgeStr);//获取缴费年限
                getPlan(vm.securityStr);//获取保险期间

                //设置投保人和被保人最大最小年龄
                setMinAndMaxAges(vm.paymentTypeStr, payAgeStr, vm.securityStr);
                
                //获取费率，计算保额保费
                if(vm.user.birthday && vm.mainPlan.amount){
                    vm.calc(vm);  
                }
            }
        }, true);

        // 监听获取保险期间
        $scope.$watch('enll.securityStr', function(newValue) {
            var securityStr = newValue;
            if(securityStr){
                getPlan(securityStr);//获取保险期间

                //设置投保人和被保人最大最小年龄
                setMinAndMaxAges(vm.paymentTypeStr, vm.payAgeStr, securityStr);
                
                //获取费率，计算保额保费
                if(vm.user.birthday && vm.mainPlan.amount){
                    vm.calc(vm);  
                }
            }
        }, true);

        // 监听获取费率
        $scope.$watch('enll.user', function(newValue) {
            var user = newValue;
            if (user.sex && user.birthday) {
                //获取费率，计算保额保费
                $timeout(function() {
                    if (vm.mainPlan.amount) {
                        vm.calc(vm);
                    }
                }, 300);
            }
        }, true);

        $scope.$watch('enll.mainPlan.amount', function(newValue) {
            if (newValue) {
                //获取费率，计算保额保费
                $timeout(function() {
                    if ($scope.enllForm.$valid) {
                        vm.calc(vm);
                    } else {
                        vm.totalExp = 0;
                        vm.totalAmount = 0;
                    }
                }, 100);
            } else{
                vm.totalExp = 0;
                vm.totalAmount = 0;
            }
        }, true);

        // 获取费率，计算保费
        vm.calc = function(vm, callback) {
            var user = vm.user,
                tipMaxAge = '',
                tipMinAge = '',
                mainPlan = vm.mainPlan,
                age = VALIDATION.getAgeByBirth(user.birthday);

            //限制最高投保年龄
            if(age > mainPlan.max_app_age){
                TipService.showMsg('最高投保年龄'+mainPlan.max_app_age+'周岁！');
                return ;
            }
            // var tipMaxAge = 0； 
            //限制主险最高保额
            if(age <= 9){
                tipMaxAge = 9;
                tipMinAge = 0;
                if(vm.mainPlan.amount > 200000){
                    TipService.showMsg('被保人年龄'+tipMinAge+'到'+ tipMaxAge +'周岁，龙佑安康智尊版限额20万元，您的投保保额不在限额内！');
                    return ;
                }
            }else if(age >= 10 && age <= 40){
                tipMinAge = 10;
                tipMaxAge = 40;
                if(vm.mainPlan.amount > 300000){
                    TipService.showMsg('被保人年龄'+tipMinAge+'到'+ tipMaxAge +'周岁，龙佑安康智尊版限额20万元，您的投保保额不在限额内！');
                    return ;
                }
            } else if(age >= 41 && age <= 45){
                tipMinAge = 41; 
                tipMaxAge = 45;
                if(vm.mainPlan.amount > 200000){
                    TipService.showMsg('被保人年龄'+tipMinAge+'到'+ tipMaxAge +'周岁，龙佑安康智尊版限额20万元，您的投保保额不在限额内！');
                    return ;
                }
            } else if(age >= 46 && age <= 50){
                tipMinAge = 46;
                tipMaxAge = 50;
                if(vm.mainPlan.amount > 100000){
                    TipService.showMsg('被保人年龄'+tipMinAge+'到'+ tipMaxAge +'周岁，龙佑安康智尊版限额20万元，您的投保保额不在限额内！');
                    return ;
                }
            }

            var getRate = function(rateObj){
                // if(rateObj.Ary.length > 0){
                //     return rateObj["A"]? rateObj["A"].rate:(rateObj["B"]? rateObj["B"].rate:(rateObj["C"]? rateObj["C"].rate:(rateObj["D"]? rateObj["D"].rate:rateObj.Ary[0].rate)));  
                // } else {
                //     return null;
                // } 
                return rateObj["A"].rate || rateObj["B"].rate || rateObj["C"].rate || rateObj["D"].rate || rateObj.Ary[0].rate || null;  
            };

            //判断参数是否有改变
            var isPramsEqual = function(vm, params){
                if(vm.params){
                    var paramsOld = vm.params.prdId+vm.params.age+vm.params.sex+vm.params.payEndYear+"";
                    var paramsNew = params.prdId+params.age+params.sex+params.payEndYear+"";
                    vm.params = params;
                    return (paramsOld === paramsNew);
                } else{
                    vm.params = params;
                    return false;
                }
            };

            //计算保额保费
            var toDoCalc = function(vm){
                var mainRateObj = {Ary:[]}, addRateObj = {Ary:[]};
                    
                //重置保费
                vm.mainPlan.exp = 0; 
                vm.addPlan.exp = 0;
                vm.totalExp = 0;
                vm.totalAmount = 0;
                for (var i = 0; i < vm.rateTable.length; i++) {
                    var rateItem = vm.rateTable[i];
                    // 主险费率
                    if(rateItem.planType == '1'&& 
                        rateItem.planCode == vm.mainPlan.planCode &&
                        rateItem.insuyear == vm.security){
                        mainRateObj.Ary.push(rateItem);
                        mainRateObj[rateItem.suppriskscore] = rateItem;
                    }
                    //附加险费率
                    if(rateItem.planType == '2' && rateItem.insuyear == vm.security){
                        addRateObj.Ary.push(rateItem);
                        addRateObj[rateItem.suppriskscore] = rateItem;
                    }
                }

                // ENLL保险费= round（P/S（主险）*K * SA，0）
                // DDOL保险费= round（P/S（附加险）*K * SA，0）
                // P/S：寿险/健康险的标准体或次标准体的年缴费率
                // K：缴法比率（年缴K=1.000，月缴K=1/12）
                // SA：保额（SA数值之计算，依险种而定）
                // round：用于四舍五入的函数，第一个参数是要四舍五入的数字，第二个参数就是位数，如果为0，则四舍五入后为整数。
                var K = vm.KObj[vm.paymentType+""].value;

                // 计算主险保费 
                if (mainRateObj && mainRateObj.Ary.length > 0) {
                    vm.mainPlan.rate = getRate(mainRateObj);
                    vm.mainPlan.exp = Math.round(vm.mainPlan.rate*10 * K*100000000 * (vm.mainPlan.amount / vm.mainPlan.insuredAmount) / 1000000000, 0);
                    
                    //月交，首期交2个月
                    if(vm.paymentType == '1'){
                        vm.mainPlan.exp = parseInt(vm.mainPlan.exp) * 2;
                    }
                } else{
                    //TipService.showMsg('“'+vm.mainPlan.planName+'”费率为空！');
                    return;
                }

                // 计算附加险保费 
                if (addRateObj && addRateObj.Ary.length > 0) {
                    vm.addPlan.amount = vm.mainPlan.amount;
                    vm.addPlan.rate = getRate(addRateObj);
                    vm.addPlan.exp = Math.round(vm.addPlan.rate*10 * K*100000000 * (vm.addPlan.amount / vm.addPlan.insuredAmount) / 1000000000, 0);
                    
                    //月交，首期交2个月
                    if(vm.paymentType == '1'){
                        vm.addPlan.exp = parseInt(vm.addPlan.exp) * 2;
                    }
                } else{
                    //TipService.showMsg('“'+vm.addPlan.planName+'”费率为空！');
                    return;
                }

                vm.totalExp = parseInt(vm.mainPlan.exp) + parseInt(vm.addPlan.exp);
                //vm.totalExp = vm.totalExp? vm.totalExp.toFixed(2):0;

                vm.totalAmount = parseInt(vm.mainPlan.amount) * 2;
                //vm.totalAmount = vm.totalAmount? vm.totalExp.toFixed(2):0;

                if (vm.paymentType == "1") {
                    vm.expByYear = vm.totalExp*6;
                } else if(vm.paymentType == "12"){
                    vm.expByYear = vm.totalExp;
                }
                // console.log("expByYear:"+vm.expByYear);

                if(callback) {//保费重算回调使用
                    if(vm.expByYear < 1000){
                        TipService.showMsg('由于您的被保人信息进行了变更，保费变化为：<span class="fs20 orange">' + vm.totalExp + '</span>元，但ENLL最低年化保费不得低于1000元！');
                        return ;
                    }else{
                        callback && callback({
                            exp: vm.totalExp,
                            amount: vm.totalAmount,
                            mainPlan: vm.mainPlan,
                            addPlan: vm.addPlan
                        });
                    }
                }
            };

            // 获取费率
            var params = {
                prdId: vm.productData.prd_id,
                age: age,
                sex: user.sex,
                payEndYear: user.payendyear
            };

            //判断参数是否有改变,若无改变则不去重新获取费率
            var paramsFalg = isPramsEqual(vm, params);
            if(paramsFalg){
                toDoCalc(vm); //计算保额保费
            } else{
                CommonRequest.request(params, CONFIG.PRODUCT_PURCHASE_CALCULATE_SERVICE, function(result) {
                    if (result.status == 1) {
                        vm.rateTable = result.data; // 主险费率表
                        
                        if (vm.rateTable && vm.rateTable.length > 0) {
                            toDoCalc(vm); //计算保额保费
                        }
                    }
                });
              }
        };

        // 跳转投保页面
        vm.goPolicy = function() {
            vm.totalExp = vm.totalExp.toString();
            vm.totalAmount = vm.totalAmount.toString();
            vm.user.selectedPlan = '1';

            if(vm.expByYear < 1000){
                TipService.showMsg('最低年化保费不得低于1000元！');
                return ;
            }
            
            var params = {
                prdId: vm.productData.prd_id,
                sex: vm.user.sex,
                insurerBirthDay: $filter('date')(vm.user.birthday, 'yyyyMMdd'),
                planId: vm.mainPlan.planId,
                extraPlanId: (vm.user.selectedPlan == '1') ? vm.addPlan.planId : 0,
                premiumResult: vm.totalExp,
                orderCode: vm.productData.orderCode || ''
            };

            PolicyService.doCalc(params, function() {

                // 数据处理
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'data',
                    data: {
                        birthday: $filter('date')(vm.user.birthday, 'yyyy-MM-dd'), // 被保人生日
                        sex: vm.user.sex, // 被保人性别
                        selectedPlan: vm.user.selectedPlan, //是否选择附加险
                        mainPlan: vm.mainPlan, // 主险
                        addPlan: vm.addPlan, // 附加险
                        payendyear: vm.user.payendyear, // 缴费期间
                        paymentType: vm.paymentType, // 缴费方式
                        PbInsuAmt: vm.totalAmount, // 保险总保额 
                        PbInsuExp: vm.totalExp, // 保险总保费
                        pbApplNoNum: 1,
                        isWholeSale: vm.paymentType == '0' ? true : false,
                        minAge: vm.minAge,
                        maxAge: vm.maxAge,
                        minHolderAge: vm.minHolderAge,
                        maxHolderAge: vm.maxHolderAge,
                        calc: vm.calc.toString(),
                        calcCtrl: vm
                    }
                });
                // 流程跳转
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'process'
                });
            });
        };
	}
})();
