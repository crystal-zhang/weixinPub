(function() {
    'use strict';

    angular
        .module('app')
        .controller('OnlineQuestionnaireController', OnlineQuestionnaireController);

    OnlineQuestionnaireController.$inject = ['$state', '$ionicModal', '$scope'];

    /** @ngInject */
    function OnlineQuestionnaireController($state, $ionicModal, $scope) {
        
        
        //继续查看保单
        $scope.continueViewPolicy = function() {
            $ionicModal.close(true);
        };

        //提交
        $scope.submitQuestionnaire = function() {

        };



    }
})();
