(function() {
    'use strict';

    angular
        .module('app')
        .controller('TacaController', TacaController);

    TacaController.$inject = ['$state', 'CONFIG', 'CommonRequest', 'VALIDATION', '$scope', 'PolicyService', 'TipService', '$filter', '$rootScope', '$ionicPopup', '$ionicLoading', '$timeout'];
    /** @ngInject */
    function TacaController($state, CONFIG, CommonRequest, VALIDATION, $scope, PolicyService, TipService, $filter, $rootScope, $ionicPopup, $ionicLoading, $timeout) {
        var vm = this;

        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        vm.productData = sessionData.productData;
        // 非法操作：1. 未获取产品数据 2. 要求做而未做手机验证
        if (!vm.productData || (sessionData.loginStatus != 2 && vm.productData.basicProfile['P005'] == 'Y' && !vm.productData.phoneValid)) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        // 用户选择的数据
        vm.user = {};
        vm.user.sex = '';
        vm.user.birthday = null;
        vm.startDateDisabled = false;
        vm.endDateDisabled = false;
        vm.insuredDaysDisabled = false;
        vm.giveCanNotChoseTime = false;
        vm.securityDays = 1;
        vm.ifGiveToken = false;
        vm.choseEndTime = true;
        vm.giveTokenHaveGivedays = false;
        vm.giveTokenHaveGivedaysAndStartTime = false;
        vm.giveTokenHaveStartTime = false;
        vm.giveTokenHaveStartTimeAndEndTime = false;
        vm.giveTokenHavePlan = false;

        // 投被保人年龄
        var payTypeConfigs = vm.productData.payTypeConfigs;
        if (payTypeConfigs && payTypeConfigs.length > 0) {
            var payTypeConfig = payTypeConfigs[0];
            vm.minAge = payTypeConfig.min_app_age;
            vm.maxAge = payTypeConfig.max_app_age;
            vm.minHolderAge = payTypeConfig.minHolderAge;
            vm.maxHolderAge = payTypeConfig.maxHolderAge;
            vm.minStartDate = VALIDATION.getDateByAge(vm.maxAge); // 年龄最小开始日期
            vm.maxEndDate = VALIDATION.getDateByAge(vm.minAge); // 年龄最大结束日期
            vm.holderStartDate = VALIDATION.getDateByAge(vm.maxHolderAge); // 投保人年龄最小开始日期
            vm.holderEndDate = VALIDATION.getDateByAge(vm.minHolderAge); // 投保人年龄最大结束日期
        }

        // 日期选择回调
        // 指定生效日期；计算部分，生效日期
        vm.startCallback = function(val) {
            if (val) {
                vm.startDate = val;
            }
        };
        // 计算部分，结束日期
        vm.endCallback = function(val) {
            if (val) {
                vm.endDate = val;
            }
        };

        // 如果产品是预售，起始时间为计划转销售时间
        if (vm.productData.prdSaleCode == 2 && vm.productData.planSaleTime) {
            var planSaleTime = vm.productData.planSaleTime;
            planSaleTime = planSaleTime.substr(0, 4) + '-' + planSaleTime.substr(4, 2) + '-' + planSaleTime.substr(6, 2);
            planSaleTime = new Date(planSaleTime);
            if (planSaleTime.getTime() > new Date().getTime()) {
                vm.minDate = planSaleTime;
                vm.startDate = planSaleTime;
            }
        }

        //*******************时间-日期 选择控制部分 Start *********************************
        // 保险生效日期
        // 默认最小为当天，当此时时间大于等于21点时，则最小值为次日
        // 最大范围，不大于最小日期+3个月
        // var nowDate = new Date("2017-6-20 20:21:21");
        var nowDate = new Date();
        var nextDayFlag = 21;
        var nextDay = nowDate.getTime() + 1 * 24 * 60 * 60 * 1000;
        if (nowDate.getHours() >= nextDayFlag) {
            vm.minDate = new Date(nextDay);
            vm.maxDate = new Date(VALIDATION.addMounth(3, new Date(nextDay)));
        } else {
            vm.minDate = new Date(nowDate);
            vm.maxDate = new Date(VALIDATION.addMounth(3, new Date(nowDate)));
        }
        // 默认生效日期为最小日期
        vm.startDate = vm.minDate;
        // vm.startDate = new Date("1993-06-24 22:21:21");
        // console.log("vm.minDate --- " + $filter('date')(vm.minDate, 'yyyy-MM-dd'));
        // console.log("vm.maxDate --- " + $filter('date')(vm.maxDate, 'yyyy-MM-dd'));


        // 保险生效时间列表处理
        vm.getStartTimeList = function() {
            // 时间list
            var createList = function(startHour){
                var tempList = [];
                for (var i = startHour; i <= 24; i++) {
                    tempList.push(i+"");
                }
                return tempList;
            }

            // 获取当前时间和指定生效日的日期yyyy-MM-dd
            var nowDateStr = $filter('date')(nowDate, 'yyyy-MM-dd');
            var nowHour = nowDate.getHours();
            var nextDateStr = $filter('date')(new Date(nextDay), 'yyyy-MM-dd');
            var startDateStr = $filter('date')(vm.startDate, 'yyyy-MM-dd');
            // console.log("nowDateStr: " + nowDateStr);
            // console.log("nowHour: " + nowHour);
            // console.log("nextDateStr: " + nextDateStr);
            // console.log("startDateStr: " + startDateStr);

            // 定义页面显示列表数组
            vm.startHourList = [];
            // part1: 如果指定生效日是当天，且当前时间小于21点，则生成当前时间后一个整点后3个小时至24点的整点list
            if (nowDateStr == startDateStr && nowHour < nextDayFlag) {
                vm.startHourList = createList(nowHour + 4);
            }
            // part2: 如果指定生效日是当天，且当前时间大于21点，此时已经对最小日期做了控制，不会出现此种情况
            // part3: 如果指定生效日是次日，且当前时间小于21点，此时同part5的情况
            // part4: 如果指定生效日是次日，且当前时间大于21点，此时需要处理当前时间+4到24点的整点list
            else if (nextDateStr == startDateStr && nowHour >= nextDayFlag) {
                vm.startHourList = createList(nowHour + 4 - 24);
            }
            // part5: 如果指定生效日大于T+2，此时处理1到24点的整点list
            else {
                vm.startHourList = createList(1);
            }
            // console.log("---vm.startHourList---" + vm.startHourList);

            // 先重置所有时间点为可选
            for (var i = 1; i <= 24; i++) {
                $("#isShow"+i).show();
            }
            // 再循环隐藏不可选的时间点
            for (var i = 1; i <= 24; i++) {
                if(i < vm.startHourList[0]){
                    $("#isShow"+i).hide();
                }else{
                    break;
                }
            }

            //默认设置生效时间为24时
            vm.startTime = "24:00";
        }
        // watch 监控会调用该方法
        // vm.getStartTimeList();

        // 时间选择控件出现
        vm.showTimeSelect = function(){
            vm.timeSelectShow = true;
        }
        // 设置用户选择的时间点，时间选择控件隐藏
        vm.setStartTime = function(value){
            vm.timeSelectShow = false;
            vm.startTime = value+":00";
            // console.log("vm.startTime: " + vm.startTime);
        }

        //*******************时间-日期 选择控制部分 End ***********************************

        //*******************保险基本数据部分 Start ***************************************
        // 初始化主险数据
        vm.mainPlan = {
            rate: 0,
            amount: 0,
            exp: 0
        };

        // 缴费方式
        vm.paymentType = vm.productData.payment_type;
        // 缴费期间
        vm.payAge = vm.productData.pay_age;

        //保险期间拼装方法
        var getInsuYearLable = function(insuYear, insuYearFlag) {
            if (insuYearFlag == "Y") {
                return insuYear + "年";
            } else if (insuYearFlag == "M") {
                return insuYear + "个月";
            } else if (insuYearFlag == "D") {
                return insuYear + "天";
            } else if (insuYearFlag == "A") {
                return "至" + insuYear + "周岁";
            }
        }

        // 补贴类责任，金额单位为 元/日
        var getMoneyUnit = function(ilName) {
            if (ilName.indexOf("住院") != -1) {
                return "元/天";
            } else {
                return "元";
            }
        }

        // 排序，按责任code升序排列
        var compare = function(obj1, obj2) {
            var val1 = obj1.ilCode;
            var val2 = obj2.ilCode;

            if (val1 < val2) {
                return -1;
            } else if (val1 > val2) {
                return 1;
            } else {
                return 0;
            }
        }

        // 处理保险责任显示表格
        var watchSelectedPlans = function() {
            // 初始化用于页面组装和显示的数组，不会污染原始保险责任数据
            var margeDutys = [];
            vm.selectedPlansForMarge = vm.selectedPlans;
            for(var i =0;i< vm.selectedPlansForMarge.dutys.length;i++){
                var duty = vm.selectedPlansForMarge.dutys[i];
                margeDutys.push({
                        ilCode: vm.selectedPlansForMarge.dutys[i].ilCode,
                        ilName: vm.selectedPlansForMarge.dutys[i].ilName,
                        insuredAmount: vm.selectedPlansForMarge.dutys[i].insuredAmount == 10000 ? vm.selectedPlansForMarge.dutys[i].insuredAmount / 10000 * vm.selectedPlansForMarge.dutys[i].maxSaleQuantity + "万" + getMoneyUnit(vm.selectedPlansForMarge.dutys[i].ilName) : vm.selectedPlansForMarge.dutys[i].insuredAmount * vm.selectedPlansForMarge.dutys[i].maxSaleQuantity + getMoneyUnit(vm.selectedPlansForMarge.dutys[i].ilName)
                    });
            }

            // console.log(vm.selectedPlansForMarge);
            vm.selectedPlansForShow = [];
            // 排序计划内责任
            vm.selectedPlansForMarge.dutys.sort(compare);

            // 第三步，合并责任列表
            vm.selectedPlansForShow.dutys = margeDutys;

            // 存入主险，供确认信息页面显示
            vm.mainPlan.dutysForShow = vm.selectedPlansForShow.dutys;
            // console.log(vm.selectedPlansForShow);
            // console.log(vm.selectedPlansForMarge);
        };
        // console.log(vm.productData);

        // 赠险相关
        if (vm.productData.token) {
            vm.ifGiveToken = true;
            var giveMargeDutys = [];
            vm.giveCanNotChoseTime = true;
            PolicyService.getCardInfo(vm.productData.token, function(data) {
                // console.log(data);
                if (data) {

                    vm.giveTokenInfo = data;
                    // console.log(vm.giveTokenInfo);
                    // vm.giveTokenInfo = data;
                    // var planId, // 该产品的计划id 
                    //     duties = data.prmLotDutySetModels; // 计划的责任数组
                    // if (duties && duties.length > 0) {
                    //     planId = duties[0].planId;
                    // }
                    // console.log(vm.giveTokenInfo.prmLotDutySetModels);
                    for(var i = 0;i < vm.giveTokenInfo.prmLotDutySetModels.length;i++){
                        var newDuty = vm.giveTokenInfo.prmLotDutySetModels[i];
                        // console.log(newDuty);
                        for(var j = 0;j < vm.productData.plans[0].dutys.length;j++){
                            var oldDuty = vm.productData.plans[0].dutys[j];
                            if(newDuty.ilCode == oldDuty.ilCode){
                                // console.log(newDuty.ilName);
                                giveMargeDutys.push({
                                    ilCode: oldDuty.ilCode,
                                    ilName: oldDuty.ilName,
                                    insuredAmount: oldDuty.insuredAmount == 10000 ? oldDuty.insuredAmount / 10000 * oldDuty.maxSaleQuantity + "万" + getMoneyUnit(oldDuty.ilName) : oldDuty.insuredAmount * oldDuty.maxSaleQuantity + getMoneyUnit(oldDuty.ilName)
                                });
                            }
                        }
                            // console.log(oldDuty);
                    }

                    if (vm.giveTokenInfo.donationMethodName == "固定保障期间") {
                        vm.securityDays = vm.giveTokenInfo.giveDay;
                        vm.endDate = new Date(vm.startDate.getTime() + vm.giveTokenInfo.giveDay*24*60*60*1000);
                        vm.choseSecurityDays = false;
                        vm.choseEndTime = false;
                        if (vm.giveTokenInfo.giveStartTime) {
                            vm.giveTokenHaveGivedaysAndStartTime = true;
                            vm.choseStartTime = false;
                            vm.startDate = new Date(vm.giveTokenInfo.giveStartTime);
                        }else{
                            vm.giveTokenHaveGivedays = true;
                            vm.choseStartTime = true;
                        }

                    }
                    if (vm.giveTokenInfo.donationMethodName == "指定保障生效和终止日期") {
                        vm.giveTokenHaveStartTimeAndEndTime = true;
                        vm.choseEndTime = false;
                        vm.choseSecurityDays = false;
                        vm.choseStartTime = false;
                        vm.startDate = new Date(vm.giveTokenInfo.giveStartTime);
                        vm.endDate = new Date(vm.giveTokenInfo.giveEndTime);
                        // vm.securityDays = parseInt((vm.endDate.getTime() - vm.startDate.getTime() - 100) / (24 * 60 * 60 * 1000)) + 1;
                        // console.log(vm.securityDays);
                        // vm.mainPlan.insuYear = vm.securityDays;
                        // vm.securityDaysForShow = vm.securityDays + " 天";
                        // console.log(vm.startDate);
                        // console.log(vm.endDate);
                        // console.log(vm.securityDays);
                        // console.log(vm.securityDaysForShow);
                    }
                    if (vm.giveTokenInfo.donationMethodName == "按保障计划赠送") {
                        vm.choseEndTime = true;
                        vm.choseEndTime = true;
                        if (vm.giveTokenInfo.giveStartTime) {
                            vm.giveTokenHaveStartTime = true;
                            vm.choseStartTime = false;
                            vm.startDate = new Date(vm.giveTokenInfo.giveStartTime);
                        }else{
                            vm.giveTokenHavePlan = true;
                            vm.choseStartTime = true;
                        }
                    }
                    // console.log(vm.securityDays);
                    // console.log(giveMargeDutys);
                    // if (vm.productData.plans && vm.productData.plans.length > 0) {
                        // for (var i = 0; i < vm.productData.plans.length; i++) {
                        //     var productPlan = vm.productData.plans[i];
                        //     var tempDuties = [];
                        //     if (planId == productPlan.planId) {
                        //         var dutiesLength = duties.length,
                        //             productDutiesLength = productPlan.dutys.length;
                        //         for (var m = 0; m < dutiesLength; m++) {
                        //             var ilId = duties[m].ilId;
                        //             for (var n = 0; n < productDutiesLength; n++) {
                        //                 if (ilId == productPlan.dutys[n].dutyId) {
                        //                     tempDuties.push(productPlan.dutys[m]);
                        //                     continue;
                        //                 }
                        //             }
                        //         }
                        //         vm.productData.plans[i].dutys = tempDuties;
                        //         break;
                        //     }
                        // }

                        // // 若赠险指定生效日期，则不可更改
                        // if (data.giveStartTime) {
                        //     vm.startDate = new Date(data.giveStartTime);
                        //     vm.startDateDisabled = true;
                        // }
                        // // 若赠险指定结束日期，则不可更改
                        // if (data.giveEndTime) {
                        //     vm.endDate = new Date(data.giveEndTime);
                        //     vm.endDateDisabled = true;
                        // }
                        // // 若赠险指定保障期间，则固定险种保障期间
                        // if (data.giveDay) {
                        //     vm.securityDays = data.giveDay;
                        //     vm.insuredDaysDisabled = true;
                        //     // 计算当前生效日+指定保障期间后的日期
                            
                        // }


                        // 初始化保险计划
                        vm.selectedPlans = vm.productData.plans[0];
                        
                        // watchSelectedPlans();
                        vm.selectedPlansForShow = [];
                        vm.selectedPlansForShow.dutys = giveMargeDutys;
                        vm.mainPlan.dutysForShow = vm.selectedPlansForShow.dutys;
                        angular.extend(vm.mainPlan, vm.selectedPlans);
                        // 保障期间
                        vm.selectedPlans.securityAge = getInsuYearLable(vm.selectedPlans.insuYear, vm.selectedPlans.insuYearFlag);
                        // 记录用户选择的保险计划ID
                        vm.user.selectedPlanId = vm.selectedPlans.planId;
                        // console.log(vm.selectedPlans);
                    }
                // }
            });
        } else {
            vm.ifGiveToken = false;
            // 初始化保险计划
            vm.selectedPlans = vm.productData.plans[0];
            watchSelectedPlans();
            angular.extend(vm.mainPlan, vm.selectedPlans);
            // 保障期间
            vm.selectedPlans.securityAge = getInsuYearLable(vm.selectedPlans.insuYear, vm.selectedPlans.insuYearFlag);
            // 记录用户选择的保险计划ID
            vm.user.selectedPlanId = vm.selectedPlans.planId;
            vm.giveCanNotChoseTime = false;
        }
        // 初始化保险计划
        // vm.selectedPlans = vm.productData.plans[0];
        // watchSelectedPlans();
        // angular.extend(vm.mainPlan, vm.selectedPlans);
        // 记录用户选择的保险计划ID
        // vm.user.selectedPlanId = vm.selectedPlans.planId;
        //*******************保险基本数据部分 End *****************************************


        //*******************监控部分 Start ***********************************************
        // 监听获取用户选择的保险生效日期
        $scope.$watch('taca.startDate', function(newValue) {
            // console.log("***watch --- startDate: " + $filter('date')(newValue, 'yyyy-MM-dd'));
            if (newValue) {
                // 保险生效时间列表处理
                vm.getStartTimeList();

                // 设置结束日期最小值最大值
                // 如果赠险没有设置保险结束日期，则进行计算
                if (vm.choseEndTime) {
                    vm.minEndDate = new Date(vm.startDate.getTime() + 1 * 24 * 60 * 60 * 1000);
                    vm.maxEndDate = new Date(vm.startDate.getTime() + 365 * 24 * 60 * 60 * 1000);
                    vm.endDate = vm.minEndDate;
                }
                // 如果赠险设置了保障期间，则计算对应的结束日期
                if (!vm.choseEndTime) {
                    if (vm.giveTokenInfo.giveDay) {
                        vm.endDate = new Date(vm.startDate.getTime() + vm.giveTokenInfo.giveDay*24*60*60*1000);
                    }
                }

                // 如果当前选择的结束日期 小于 当前选择的生效日期，则结束日期置空，计算结果置空
                if (vm.endDate && vm.startDate.getTime() > vm.endDate.getTime()) {
                    vm.endDate = null;
                    vm.securityDays = null;
                    vm.securityDaysForShow = null;
                }
                // 计算保费
                vm.calc(vm);
            }
        }, true);

        // 监听获取用户选择的结束日期
        $scope.$watch('taca.endDate', function(newValue) {
            // console.log("***watch --- endDate: " + $filter('date')(newValue, 'yyyy-MM-dd'));
            if (newValue) {
                // 计算间隔天数，-100毫秒以控制相差整整一天的情况
                vm.securityDays = parseInt((vm.endDate.getTime() - vm.startDate.getTime() - 100) / (24 * 60 * 60 * 1000)) + 1;
                // console.log(vm.securityDays);
                vm.mainPlan.insuYear = vm.securityDays;
                vm.securityDaysForShow = vm.securityDays + " 天";
                // console.log("vm.endDate --- " + $filter('date')(vm.endDate, 'yyyy-MM-dd'));
                // console.log("vm.startDate --- " + $filter('date')(vm.startDate, 'yyyy-MM-dd'));
                // console.log("vm.securityDays: " + vm.securityDays);

                // 计算保费
                vm.calc(vm);
            }
        }, true);
        //*******************监控部分 End *************************************************

        // 保费计算方法
        vm.calc = function(vm) {
            // 发起计算保费请求
            var calcParams = {
                prdCode: vm.productData.prd_code,
                prdName: vm.productData.prd_title,
                PbBeginDate:$filter('date')(vm.startDate,  'yyyyMMdd'),  // 保险生效日期
                insuredDays: vm.securityDays, //单位默认为 D
                insuYearFlag: vm.mainPlan.insuYearFlag,
                planCode: vm.productData.plans[0].planCode,
                channel: CONFIG.SALE_CHANNEL
            };
            // console.log(calcParams);
            CommonRequest.request(calcParams, CONFIG.PRODUCT_GETEXPFROMCORE_CALCULATE_SERVICE, function(result) {
                // console.log(result);
                if (result.status == 1) {
                    if (result.data.premiumResult) {
                        var data = result.data;
                        // 直接获取到保费结果
                        var amountExpStr = data.premiumResult;
                        // vm.mainPlan.exp = data.premiumResult;
                        var amountExp = amountExpStr.split(':');
                        vm.mainPlan.exp = amountExp[0];
                        vm.mainPlan.amount = amountExp[1];
                        // vm.mainPlan.exp = result.data.premiumResult;
                        // vm.mainPlan.amount = result.data.mainAmount;
                    }
                    if (result.data.redisKey) {
                        // 核心未给出结果，需要再次查询
                        vm.redisKey = result.data.redisKey;
                        // 解耦间隔时间timeout后,再次执行查询
                        $timeout(function() {
                            checkPremium();
                        }, CONFIG.CALCEXP_DECOUPLING_DURATION);
                    }
                } 
            });

            // ajax轮循 查询保费计算结果
            var checkPremiumNum = 0;
            var checkPremium = function() {
                // 累计轮循次数
                checkPremiumNum++;

                // 查询次数是否已经超过核心解耦间隔次数
                if (checkPremiumNum > CONFIG.CALCEXP_DECOUPLING_TIMES) {
                    $ionicLoading.hide();
                    // 提示消息
                    TipService.showMsg($rootScope.TIPS.PRODUCT.GETEXPFROMCORE_CALCULATE_FAILED);
                    // 查询次数重置为0
                    checkPremiumNum = 0;
                    return;
                }

                // 发起保费结果查询请求
                var checkPremiumParams = {
                    redisKey: vm.redisKey
                };
                CommonRequest.request(checkPremiumParams, CONFIG.PRODUCT_GETEXPFROMREDIS_CALCULATE_SERVICE, function(result) {
                    // console.log(result);
                    if (result.status == 1) {
                        if (result.data.premiumResult) {
                            // 得到结果，隐藏loading
                            $ionicLoading.hide();
                            var data = result.data;
                            // 得到结果
                            var amountExpStr = data.premiumResult;
                            // vm.mainPlan.exp = data.premiumResult;
                            var amountExp = amountExpStr.split(':');
                            vm.mainPlan.exp = amountExp[0];
                            vm.mainPlan.amount = amountExp[1];

                            // vm.mainPlan.exp = result.data.premiumResult;
                            // vm.mainPlan.amount = result.data.mainAmount;

                            // 查询次数重置为0
                            checkPremiumNum = 0;
                        }
                        if (result.data.redisKey) {
                            // 核心未给出结果，需要再次查询
                            vm.redisKey = result.data.redisKey;

                            // 解耦间隔时间timeout后,再次执行查询
                            $timeout(function() {
                                checkPremium();
                            }, CONFIG.CALCEXP_DECOUPLING_DURATION);
                        }
                    } else {
                        // 出现异常，隐藏loading
                        $ionicLoading.hide();
                        // 查询次数重置为0
                        checkPremiumNum = 0;
                        TipService.showMsg($rootScope.TIPS.PRODUCT.GETEXPFROMCORE_CALCULATE_FAILED);
                        return;
                    }
                });
            }
        };

        // 保险保障期间止期 计算方法
        var calcDate = function() {
            if (vm.startDate && vm.selectedPlans.insuYear && vm.selectedPlans.insuYearFlag) {
                // console.log("vm.startDate ----- " + vm.startDate + ";vm.selectedPlans.insuYear ----- " + vm.selectedPlans.insuYear + ";vm.selectedPlans.insuYearFlag ----- " + vm.selectedPlans.insuYearFlag);
                var endDate = new Date(vm.startDate);
                if ("M" == vm.selectedPlans.insuYearFlag) {
                    // endDate.setMonth(vm.startDate.getMonth() + Number(vm.selectedPlans.insuYear));
                    endDate = new Date(VALIDATION.addMounth(Number(vm.selectedPlans.insuYear), new Date(vm.startDate)));
                } else if ("D" == vm.selectedPlans.insuYearFlag) {
                    endDate.setDate(vm.startDate.getDate() + Number(vm.selectedPlans.insuYear));
                } else if ("Y" == vm.selectedPlans.insuYearFlag) {
                    endDate.setFullYear(vm.startDate.getFullYear() + Number(vm.selectedPlans.insuYear));
                }
                // console.log("vm.startDate ----- " + vm.startDate);
                // console.log("endDate ----- " + new Date(endDate));
                return $filter('date')(endDate, 'yyyyMMdd');
            }
        }

        // 跳转投保页面
        vm.goPolicy = function() {
            // 计算保险保障期间止期,并处理为'yyyyMMdd'
            vm.cvrInsDt = calcDate();
            // console.log(vm.endDate);
            var params = {
                prdId: vm.productData.prd_id,
                sex: vm.user.sex,
                insurerBirthDay: $filter('date')(vm.user.birthday, 'yyyyMMdd'),
                planId: vm.selectedPlans.planId,
                premiumResult: vm.mainPlan.exp,
                orderCode: vm.productData.orderCode || ''
            };
            PolicyService.doCalc(params, function() {
                // 数据处理
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'data',
                    data: {
                        // birthday: vm.user.birthday, // 被保人生日
                        // sex: vm.user.sex, // 被保人性别
                        // selectedPlan: vm.user.selectedPlanId, //是否选择附加险
                        mainPlan: vm.mainPlan, // 主险
                        // addPlan: vm.addPlan, // 附加险
                        payendyear: vm.payAge, // 缴费期间
                        paymentType: vm.paymentType, // 缴费方式
                        PbBeginDate: vm.startDate, // 保险生效日期
                        beginTime: vm.startTime+":00", // 保险生效时间 "24:00:00"
                        PbInsuAmt: vm.mainPlan.amount, // 保险总保额
                        PbInsuExp: vm.mainPlan.exp, // 保险总保费
                        pbApplNoNum: 1,
                        isWholeSale: vm.paymentType == '0' ? true : false,
                        minAge: vm.minAge,
                        maxAge: vm.maxAge,
                        minHolderAge: vm.minHolderAge,
                        maxHolderAge: vm.maxHolderAge,
                        oldPrice: vm.mainPlan.exp, // 赠险前原价
                        cvrInsDt: vm.cvrInsDt
                    }
                });
                // 流程跳转
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'process'
                });
            });
        };
    }
})();