(function() {
    'use strict';

    angular
        .module('app')
        .controller('CheckIdentityController', CheckIdentityController);

    CheckIdentityController.$inject = ['$state', 'CONFIG', 'CommonRequest', 'PolicyService', 'TipService', '$rootScope'];
    /** @ngInject */
    function CheckIdentityController($state, CONFIG, CommonRequest, PolicyService, TipService, $rootScope) {
        var vm = this;

        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        var prodata = vm.prodata = sessionData.productData;
        if (!prodata) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        // 证件类型，默认身份证
        vm.cerType = 'A';

        //如果是TAC学生惠产品，则只能为身份证，不可更改
        // by lixianzhang 2017年5月8日
        if(prodata.templateCode == "TAC"){
            vm.cerTypeDisabled = true;
        }

        // 身份核查提交
        vm.checkIdentitySubmit = function() {
            var params = {
                customer_name: vm.name,
                insurer_cer_type: vm.cerType,
                insurer_cer_id: vm.cerNo
            };
            PolicyService.checkRisk(params, function(testStatus) {
                // 数据处理
                PolicyService.control({
                    state: $state.current.name,
                    control: 'data',
                    data: {
                        customerName: vm.name,
                        cretType: vm.cerType,
                        cretNo: vm.cerNo,
                        testStatus: testStatus
                    }
                });
                // 流程跳转
                PolicyService.control({
                    state: $state.current.name,
                    control: 'process'
                });
            });
        };
    }

})();