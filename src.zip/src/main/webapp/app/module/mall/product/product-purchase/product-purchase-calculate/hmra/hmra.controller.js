(function() {
    'use strict';

    angular
        .module('app')
        .controller('HmraController', HmraController);

    HmraController.$inject = ['$state', 'CONFIG', 'CommonRequest', 'VALIDATION', '$scope', '$rootScope', 'PolicyService', 'TipService', '$filter', '$timeout'];
    /** @ngInject */
    function HmraController($state, CONFIG, CommonRequest, VALIDATION, $scope, $rootScope, PolicyService, TipService, $filter, $timeout) {
        var vm = this;

        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        vm.productData = sessionData.productData;
        // 非法操作：1. 未获取产品数据 2. 要求做而未做手机验证
        if (!vm.productData || (sessionData.loginStatus != 2 && vm.productData.basicProfile['P005'] == 'Y' && !vm.productData.phoneValid)) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        // 初始化开始


        // 主险数据
        vm.mainPlan = {
            rate: 0,
            amount: 0,
            exp: 0
        };


        // 用户选择的数据
        vm.user = {};
        // vm.user.sex = '1';
        vm.user.birthday = null;
        vm.nextStep = true;
        vm.mainPlan.amount = 1000000;
        vm.mainPlan.socialSecurity = 'Y';
        vm.nextStep = true;
        vm.ifShowInfo0 = false;
        vm.ifShowInfo1 = false;

        // 日期选择回调
        vm.birthdayCallback = function(val) {
            if (val) {
                vm.user.birthday = val;
            }
        };


        vm.navActiveCss = function(index, amount, socialSecurity) {
            var normalNav = document.getElementsByName('nav');
            for (var i = 0; i < normalNav.length; i++) {
                normalNav[i].className = "normal-nav";
                normalNav[0].style.marginLeft = 0 + 'px';
                if (i == index) {
                    normalNav[i].className = "active-nav";
                }
            }
            vm.mainPlan.amount = amount;
            vm.mainPlan.socialSecurity = socialSecurity;

            vm.showInfoStr(amount, socialSecurity);

            vm.setPlan();
        };


        vm.showInfoContent = function(index) {
            if (index == 0) {
                if (!vm.ifShowInfo0) {
                    vm.ifShowInfo0 = true;
                } else {
                    vm.ifShowInfo0 = false;
                }
            } else if (index == 1) {
                if (!vm.ifShowInfo1) {
                    vm.ifShowInfo1 = true;
                } else {
                    vm.ifShowInfo1 = false;
                }
            }
        };

        // 投被保人年龄
        var payTypeConfigs = vm.productData.payTypeConfigs;
        if (payTypeConfigs && payTypeConfigs.length > 0) {
            var payTypeConfig = payTypeConfigs[0];

            vm.minAge = payTypeConfig.min_app_age;
            vm.maxAge = payTypeConfig.max_app_age;
            vm.minHolderAge = payTypeConfig.minHolderAge;
            vm.maxHolderAge = payTypeConfig.maxHolderAge;

            vm.minStartDate = VALIDATION.getDateByAge(vm.maxAge); // 年龄最小开始日期
            vm.maxEndDate = VALIDATION.getDateByAge(vm.minAge); // 年龄最大结束日期
            vm.holderStartDate = VALIDATION.getDateByAge(vm.maxHolderAge); // 投保人年龄最小开始日期
            vm.holderEndDate = VALIDATION.getDateByAge(vm.minHolderAge); // 投保人年龄最大结束日期
        }

        vm.getPlan = function() {
            var plan = vm.productData.plans,
                len = plan.length;

            for (var i = len - 1; i >= 0; i--) {
                var item = plan[i];
                if (item.planType == '1') {
                    // 获取主险CNM
                    angular.extend(vm.mainPlan, item);
                } else if (item.planType == '2') {
                    // 获取附加险MLGB
                    angular.extend(vm.addPlan, item);
                }
            }

        };
        vm.getPlan();

        // 缴费方式，年缴
        vm.paymentType = vm.productData.payment_type;

        // 缴费期间
        vm.payAge = vm.productData.pay_age;

        vm.setPlan = function() {
            vm.chosePlanFlag = vm.mainPlan.amount / 1000000 - 1;
            if (vm.productData.plans && vm.productData.plans.length > 0) {
                for (var i = 0; i < vm.productData.plans.length; i++) {
                    if (vm.chosePlanFlag == i) {
                        vm.selectedPlans = vm.productData.plans[i];
                        angular.extend(vm.mainPlan, vm.selectedPlans);
                    }
                }
            }

            if (vm.user.birthdayfm && vm.user.sex) {
                vm.calc(vm);
            } else {
                return;
            }

        }

        vm.setPlan();

        vm.showInfoStr = function(amount, socialSecurity) {
            vm.amountStr = amount / 10000 + "万";
            vm.doubleAmountStr = amount / 10000 * 2 + "万";
        }
        vm.showInfoStr(vm.mainPlan.amount, vm.mainPlan.socialSecurity);


        $scope.$watch('hmra.user.birthday', function(newValue) {
            if (newValue) {
                vm.user.birthdayfm = $filter('date')(vm.user.birthday, 'yyyyMMdd');
                //console.log(vm.user.birthdayfm);
                if (vm.user.sex && vm.mainPlan.amount) {
                    vm.calc(vm);
                }
            }
        });

        $scope.$watch('hmra.user.sex', function(newValue) {
            if (newValue) {
                if (vm.user.birthdayfm && vm.mainPlan.amount) {
                    vm.calc(vm);
                }
            }
        });

        //计算保费方法
        vm.calc = function(vm, callback) {
            vm.askPractise = 0;
            var askPractise = function() {
                    vm.askPractise++;
                    if (vm.askPractise > CONFIG.CALCEXP_DECOUPLING_TIMES) {
                        vm.askPractise = 0;
                        TipService.showMsg($rootScope.TIPS.PRODUCT.GETEXPFROMCORE_CALCULATE_FAILED);
                        vm.nextStep = true;
                        return;
                    }

                    var checkPremiumParams = {
                        redisKey: vm.redisKey
                    };

                    CommonRequest.request(checkPremiumParams, CONFIG.PRODUCT_GETEXPFROMREDIS_CALCULATE_SERVICE, function(result) {

                        if (result.status == 1) {

                            var data = result.data;
                            if (data.redisKey) {
                                vm.mainPlan.exp = "";
                                $timeout(function() {
                                    askPractise();
                                }, CONFIG.CALCEXP_DECOUPLING_DURATION);
                                return;
                            }

                            if (data.premiumResult) {
                                var amountExpStr = data.premiumResult;
                                var amountExp = amountExpStr.split(':');
                                vm.askPractise = 0;
                                vm.mainPlan.exp = amountExp[0];
                                // vm.mainPlan.amount = amountExp[1];
                                vm.nextStep = false;
                                callback && callback({
                                    exp: vm.mainPlan.exp,
                                    mainPlan: vm.mainPlan
                                });
                                return;
                            }
                        }
                    });
                }
                // console.log(vm.mainPlan.insuYear);
                // 获取费率
            var calcParams = {
                prdCode: vm.productData.prd_code, //产品code
                prdName: vm.productData.prd_title, //产品名称
                insurerBirthDay: vm.user.birthdayfm, //生日
                sex: vm.user.sex, //性别
                PbInsuAmt: vm.mainPlan.amount, //保额
                insuredDays: vm.mainPlan.insuYear, // 用户选择保障期间的数值
                insuYearFlag: vm.mainPlan.insuYearFlag, //用户选择保障期间单位
                planCode: vm.mainPlan.planCode,
                payendyear: vm.payAge, //缴费期间
                paymentType: vm.paymentType, //缴费方式
                socialSecurity:vm.mainPlan.socialSecurity,
                // copies: copies,
                channel: CONFIG.SALE_CHANNEL
            };

            CommonRequest.request(calcParams, CONFIG.PRODUCT_GETEXPFROMCORE_CALCULATE_SERVICE, function(result) {
                if (result.status == 1) {
                    var data = result.data;
                    if (data.redisKey) {
                        vm.redisKey = data.redisKey;
                        askPractise();
                        return;
                    }

                    if (data.premiumResult) {
                        var amountExpStr = data.premiumResult;
                        var amountExp = amountExpStr.split(':');
                        vm.mainPlan.exp = amountExp[0];
                        // vm.mainPlan.amount = amountExp[1];
                        vm.nextStep = false;
                    }

                    callback && callback({
                        exp: vm.mainPlan.exp,
                        mainPlan: vm.mainPlan
                    });

                } else {
                    vm.nextStep = true;
                    return;
                }
            })
        };

        if (vm.productData.token) {

        }

        // 跳转投保页面
        vm.goPolicy = function() {
            var params = {
                prdId: vm.productData.prd_id,
                sex: vm.user.sex,
                insurerBirthDay: $filter('date')(vm.user.birthday, 'yyyyMMdd'),
                planId: vm.mainPlan.planId,
                premiumResult: vm.mainPlan.exp,
                orderCode: vm.productData.orderCode || ''
            };

            PolicyService.doCalc(params, function() {
                // 数据处理
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'data',
                    data: {
                        birthday: vm.user.birthday, // 被保人生日
                        sex: vm.user.sex, // 被保人性别
                        //selectedPlan: vm.user.selectedPlan, //是否选择附加险
                        mainPlan: vm.mainPlan, // 主险
                        // addPlan: vm.addPlan, // 附加险
                        payendyear: vm.payAge, // 缴费期间
                        paymentType: vm.paymentType, // 缴费方式
                        //  PbBeginDate: vm.startTime, // 保险生效时间
                        PbInsuAmt: vm.mainPlan.amount, // 保险总保额 
                        PbInsuExp: vm.mainPlan.exp, // 保险总保费
                        pbApplNoNum: 1,
                        isWholeSale: vm.paymentType == '0' ? true : false,
                        minAge: vm.minAge,
                        maxAge: vm.maxAge,
                        minHolderAge: vm.minHolderAge,
                        maxHolderAge: vm.maxHolderAge,
                        oldPrice: vm.mainPlan.exp,
                        socialSecurity:vm.mainPlan.socialSecurity,
                        calc: vm.calc.toString(),
                        calcCtrl: vm
                    }
                });
                // 流程跳转
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'process'
                });
            });
        };
    }
})();