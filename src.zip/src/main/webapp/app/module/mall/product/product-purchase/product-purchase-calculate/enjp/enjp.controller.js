(function() {
    'use strict';

    angular
        .module('app')
        .controller('EnjpController', EnjpController);

    EnjpController.$inject = ['$state', 'CONFIG', 'CommonRequest', 'VALIDATION', '$scope', '$rootScope', 'PolicyService', 'TipService', '$filter', '$timeout'];
    /** @ngInject */
    function EnjpController($state, CONFIG, CommonRequest, VALIDATION, $scope, $rootScope, PolicyService, TipService, $filter, $timeout) {
        var vm = this;

        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        vm.productData = sessionData.productData;
        // 非法操作：1. 未获取产品数据 2. 要求做而未做手机验证
        if (!vm.productData || (sessionData.loginStatus != 2 && vm.productData.basicProfile['P005'] == 'Y' && !vm.productData.phoneValid)) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        // 初始化开始

        // 用户选择的数据
        vm.user = {};
        vm.user.sex = '1';
        vm.user.birthday = null;
        
        // 日期选择回调
        vm.birthdayCallback = function(val) {
            if (val) {
                vm.user.birthday = val;
            }
        };

        // 投被保人年龄
        var payTypeConfigs = vm.productData.payTypeConfigs;
        if (payTypeConfigs && payTypeConfigs.length > 0) {
            var payTypeConfig = payTypeConfigs[0];

            vm.minAge = payTypeConfig.min_app_age;
            vm.maxAge = payTypeConfig.max_app_age;
            vm.minHolderAge = payTypeConfig.minHolderAge;
            vm.maxHolderAge = payTypeConfig.maxHolderAge;

            vm.minStartDate = VALIDATION.getDateByAge(vm.maxAge); // 年龄最小开始日期
            vm.maxEndDate = VALIDATION.getDateByAge(vm.minAge); // 年龄最大结束日期
            vm.holderStartDate = VALIDATION.getDateByAge(vm.maxHolderAge); // 投保人年龄最小开始日期
            vm.holderEndDate = VALIDATION.getDateByAge(vm.minHolderAge); // 投保人年龄最大结束日期
        }

        // 主险数据
        vm.mainPlan = {
            rate: 0,
            amount: '',
            exp: ''
        };

        // 总保额
        vm.totalAmount = vm.mainPlan.amount;
        // 总保费
        vm.totalExp = vm.mainPlan.exp;

        // 获取产品计划
        vm.getPlan = function() {
            var plan = vm.productData.plans,
                len = plan.length;

            for (var i = len - 1; i >= 0; i--) {
                var item = plan[i];
                if (item.planType == '1') {
                    // 获取主险CNM
                    angular.extend(vm.mainPlan, item);
                } else if (item.planType == '2') {
                    // 获取附加险MLGB
                    angular.extend(vm.addPlan, item);
                }
            }
        };
        vm.getPlan();

        // 缴费方式，年缴
        vm.paymentType = vm.productData.payment_type;

        // 缴费期间
        vm.payAge = vm.productData.pay_age;

        // 监听获取费率
        $scope.$watch('enjp.user', function() {
            if ($scope.enjpForm.$valid) {
                vm.calc(vm);
            } else {
                vm.mainPlan.amount = 0;
            }
        }, true);

        $scope.$watch('enjp.mainPlan.exp', function() {
            $timeout(function() {
                if ($scope.enjpForm.$valid) {
                    vm.calc(vm);
                } else {
                    vm.mainPlan.amount = 0;
                }
            }, 100);
        }, true);

        // 计算保费方法
        vm.calc = function(vm, callback) {
            var user = vm.user,
                age = VALIDATION.getAgeByBirth(user.birthday);

            // 获取费率
            var params = {
                prdId: vm.productData.prd_id,
                age: age,
                sex: user.sex,
                payEndYear: user.payendyear
            };

            CommonRequest.request(params, CONFIG.PRODUCT_PURCHASE_CALCULATE_SERVICE, function(result) {
                if (result.status == 1) {
                    var rateTable = result.data,
                        mainRate1 = [], // 主险费率表(等级A)
                        mainRate2 = []; // 主险费率表(等级A)
                    // 重置保额
                    vm.mainPlan.amount = 0;

                    if (rateTable && rateTable.length > 0) {
                        for (var i = 0; i < rateTable.length; i++) {
                            if (rateTable[i].planType == '1') {
                                if (rateTable[i].suppriskscore == 'A') {
                                    mainRate1.push(rateTable[i]);
                                } else {
                                    mainRate2.push(rateTable[i]);
                                }
                            }
                        }

                        if (mainRate1 && mainRate1.length > 0) {
                            // 主险费率
                            vm.mainPlan.rate = mainRate1[0].rate;
                        } else if (mainRate2 && mainRate2.length > 0) {
                            // 主险费率
                            vm.mainPlan.rate = mainRate2[0].rate;
                        }
                        // 计算主险保费
                        vm.mainPlan.amount = vm.mainPlan.exp / vm.mainPlan.normalPrice * vm.mainPlan.rate;

                        callback && callback({
                            exp: vm.mainPlan.exp,
                            amount: vm.mainPlan.amount,
                            mainPlan: vm.mainPlan,
                            addPlan: vm.addPlan
                        });
                    }
                }
            });
        };

        // 跳转投保页面
        vm.goPolicy = function() {
            var params = {
                prdId: vm.productData.prd_id,
                sex: vm.user.sex,
                insurerBirthDay: $filter('date')(vm.user.birthday, 'yyyyMMdd'),
                planId: vm.mainPlan.planId,
                premiumResult: vm.mainPlan.exp,
                orderCode: vm.productData.orderCode || ''
            };

            PolicyService.doCalc(params, function() {
                // 数据处理
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'data',
                    data: {
                        birthday: vm.user.birthday, // 被保人生日
                        sex: vm.user.sex, // 被保人性别
                        //selectedPlan: vm.user.selectedPlan, //是否选择附加险
                        mainPlan: vm.mainPlan, // 主险
                        // addPlan: vm.addPlan, // 附加险
                        payendyear: vm.payAge, // 缴费期间
                        paymentType: vm.paymentType, // 缴费方式
                        //  PbBeginDate: vm.startTime, // 保险生效时间
                        PbInsuAmt: vm.mainPlan.amount, // 保险总保额 
                        PbInsuExp: vm.mainPlan.exp, // 保险总保费
                        pbApplNoNum: 1,
                        isWholeSale: vm.paymentType == '0' ? true : false,
                        minAge: vm.minAge,
                        maxAge: vm.maxAge,
                        minHolderAge: vm.minHolderAge,
                        maxHolderAge: vm.maxHolderAge,
                        calc: vm.calc.toString(),
                        calcCtrl: vm
                    }
                });
                // 流程跳转
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'process'
                });
            });
        };
    }
})();