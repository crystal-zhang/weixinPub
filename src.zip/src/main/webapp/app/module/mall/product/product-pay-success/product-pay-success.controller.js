(function() {
    'use strict';

    angular
        .module('app')
        .controller('ProductPaySuccessController', ProductPaySuccessController);

    ProductPaySuccessController.$inject = ['PolicyService', '$state', '$rootScope', '$scope', '$ionicModal', '$log', 'CONFIG', 'CommonRequest', 'TipService', '$window'];
    /** @ngInject */
    function ProductPaySuccessController(PolicyService, $state, $rootScope, $scope, $ionicModal, $log, CONFIG, CommonRequest, TipService, $window) {
        var vm = this;

        var params = $state.params;

        var sessionData = PolicyService.getSessionData();

        vm.productData = sessionData.productData || {};

        if (vm.productData.newSaleChnl && vm.productData.salesId) {
            vm.luckyButtonFowShow = true;
        } else {
            vm.luckyButtonFowShow = false;
        }


        // if (!sessionData.policyData) {
        //     // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
        //     $state.go('home');
        //     return;
        // }

        // 订单号
        vm.orderCode = params.orderCode;
        // 支付回调状态
        vm.status = params.payResult;

        vm.productData = sessionData.productData;
        vm.insureData = sessionData.insureData;
        vm.policyData = sessionData.policyData;
        if (vm.insureData) {
            if (vm.insureData.groupProName) {
                vm.groupProName = vm.insureData.groupProName;
                //console.log(vm.groupProName)
            }
        } else if (vm.policyData) {
            if (vm.policyData.groupProName) {
                vm.groupProName = vm.policyData.groupProName;
                //console.log(vm.groupProName)
            }
        }
        // 承保
        // vm.holdPolicy = function() {
        //     var params = {
        //         bkOthOldSeq: sessionData.policyData.bkOthSeq, // 流水号
        //         orderCode: vm.orderCode, // 订单号
        //         BkBrchNo: sessionData.policyData.BkBrchNo
        //     };
        //     PolicyService.holdPolicy(params, function(pbInsuSlipNo) {
        //         vm.pbInsuSlipNo = pbInsuSlipNo;
        //     });
        // }

        // 获取保单号
        vm.getPolicy = function() {
            var params = {
                orderCode: vm.orderCode
            };
            CommonRequest.request(params, CONFIG.FIND_POILCYNO_SERVICE, function(result) {
                if (result.status == 1) {
                    vm.order = result.data;
                    if (vm.order && vm.order.length > 0) {
                        vm.policyList = vm.order;
                    } else {
                        TipService.showMsg($rootScope.TIPS.PRODUCT.NO_POLICY);
                    }
                } else {
                    TipService.showMsg($rootScope.TIPS.PRODUCT.NO_POLICY);
                }
            });
        };

        // 支付成功
        if (vm.status == 2) {
            // vm.holdPolicy();
            vm.getPolicy();
            // vm.productName = vm.productData.prd_title || '';
        }

        vm.onlineQuestionnaire = function() {
            $ionicModal.fromTemplateUrl('app/module/mall/product/product-pay-success/online-return-questionnaire/online-return-questionnaire.html', {
                scope: $scope,
            }).then(function(modal) {
                $scope.modal = modal;
            });
        };

        vm.getLuckyHref = function() {
            if (vm.orderCode && vm.orderCode.length > 0) {
                var params = {
                    orderCode:vm.orderCode
                };
                CommonRequest.request(params,CONFIG.GET_LUCKY_HREF,function(result) {
                    if (result.status == 1) {
                        vm.resultMsg = result.data;
                        vm.mobilephone = vm.resultMsg.phone;
                        vm.luckyPath = vm.resultMsg.requestPath;
                        vm.passwordText = vm.resultMsg.value;
                        $window.location.href = vm.luckyPath + '?mobilephone=' + vm.mobilephone + '&pNo=' + vm.productData.salesId + '&value=' + vm.passwordText; 
                    }
                });
            }
        };
        // 电子保单下载
        // vm.benefitInfoDetail = function() {
        //     // 参数： 保单号  证件号
        //     vm.id = $rootScope.userData.cretNo;
        //     vm.token = $rootScope.userData.token;
        //     vm.cusId = $rootScope.userData.cusId;
        //     $window.location.href=CONFIG.SERVICE_ADDRESS + 'EleInsPolicyDownload?policyNo=' + vm.policyNo + '&idNo=' + vm.id + '&downType=E&custId=' + vm.cusId + '&token=' + vm.token + '&channelCode=' + CONFIG.SALE_CHANNEL;
        // };
    }
})();