(function() {
    'use strict';

    angular
        .module('app')
        .controller('TacController', TacController);

    TacController.$inject = ['$state', 'CONFIG', 'CommonRequest', 'VALIDATION', '$scope', 'PolicyService', 'TipService', '$filter', '$rootScope'];
    /** @ngInject */
    function TacController($state, CONFIG, CommonRequest, VALIDATION, $scope, PolicyService, TipService, $filter, $rootScope) {
        var vm = this;

        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        vm.productData = sessionData.productData;
        // 非法操作：1. 未获取产品数据 2. 要求做而未做手机验证
        if (!vm.productData || (sessionData.loginStatus != 2 && vm.productData.basicProfile['P005'] == 'Y' && !vm.productData.phoneValid)) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        // 用户选择的数据
        vm.user = {};
        vm.user.sex = '';
        vm.user.birthday = null;
        vm.choseStartTime = true;

        // 投被保人年龄
        var payTypeConfigs = vm.productData.payTypeConfigs;
        if (payTypeConfigs && payTypeConfigs.length > 0) {
            var payTypeConfig = payTypeConfigs[0];
            vm.minAge = payTypeConfig.min_app_age;
            vm.maxAge = payTypeConfig.max_app_age;
            vm.minHolderAge = payTypeConfig.minHolderAge;
            vm.maxHolderAge = payTypeConfig.maxHolderAge;
            vm.minStartDate = VALIDATION.getDateByAge(vm.maxAge); // 年龄最小开始日期
            vm.maxEndDate = VALIDATION.getDateByAge(vm.minAge); // 年龄最大结束日期
            vm.holderStartDate = VALIDATION.getDateByAge(vm.maxHolderAge); // 投保人年龄最小开始日期
            vm.holderEndDate = VALIDATION.getDateByAge(vm.minHolderAge); // 投保人年龄最大结束日期
        }

        // 日期选择回调
        vm.startCallback = function(val) {
            if (val) {
                vm.startTime = val;
            }
        };

        // 保险生效日期
        var nowDate = new Date();
        // 如果产品是预售，起始时间为计划转销售时间
        if (vm.productData.prdSaleCode == 2 && vm.productData.planSaleTime) {
            var planSaleTime = vm.productData.planSaleTime;
            planSaleTime = planSaleTime.substr(0, 4) + '-' + planSaleTime.substr(4, 2) + '-' + planSaleTime.substr(6, 2);
            planSaleTime = new Date(planSaleTime);
            if (planSaleTime.getTime() > nowDate.getTime()) {
                vm.minDate = planSaleTime;
                vm.startTime = planSaleTime;
            }
        }
        // 保险生效日期最小最大范围，不大于当前日期+3个月
        vm.minDate = nowDate;
        vm.startTime = vm.minDate;
        vm.maxDate = new Date(new Date().setMonth(new Date().getMonth() + 3));
        // console.log("vm.maxDate --- " + vm.maxDate);


        // 缴费方式
        vm.paymentType = vm.productData.payment_type;
        // 缴费期间
        vm.payAge = vm.productData.pay_age;


        //保险期间拼装方法
        var getInsuYearLable = function(insuYear, insuYearFlag){
            if(insuYearFlag == "Y"){
                return insuYear+"年";
            } else if(insuYearFlag == "M"){
                return insuYear+"个月";
            } else if(insuYearFlag == "D"){
                return insuYear+"天";
            } else if(insuYearFlag == "A"){
                return "至"+insuYear+"周岁";
            } 
        }

        // 初始化主险数据
        vm.mainPlan = {
            rate: 0,
            amount: 0,
            exp: 0
        };


        // 补贴类责任，金额单位为 元/日
        var getMoneyUnit = function(ilName){
            if (ilName.indexOf("补贴") != -1) {
                return "元/日";
            }else{
                return "元";
            }
        }

        // 排序，按责任code升序排列
        var compare = function(obj1, obj2){
            var val1 = obj1.ilCode;
            var val2 = obj2.ilCode;

            if (val1 < val2) {
                return -1;
            }else if (val1 > val2) {
                return 1;
            }else{
                return 0;
            }
        }

        // 保险计划改变，处理保险责任显示表格
        var watchSelectedPlans = function(){
            // 初始化用于页面组装和显示的数组，不会污染原始保险责任数据
            vm.selectedPlansForMarge = vm.selectedPlans;
            vm.selectedPlansForShow = [];
            // 排序计划内责任
            vm.selectedPlansForMarge.dutys.sort(compare);
            // console.log(vm.productData.plans[0]);
            // console.log(vm.selectedPlans);
            // console.log(vm.selectedPlansForMarge);
            
            // 第一步，取出所有责任的ilCode的公共部分并去除重复项
            var dutysCodeArr = [];
            for (var i = 0; i < vm.selectedPlansForMarge.dutys.length; i++) {
                dutysCodeArr.push(vm.selectedPlansForMarge.dutys[i].ilCode.substr(0,6).toLowerCase());
            }
            // console.log(dutysCodeArr);

            // 第二步，根据dutysCodeArr确定合并显示项
            var margeDutys = [];
            var unmargeDutys = [];
            for (var i = 0; i < dutysCodeArr.length; i++) {
                var nowDutyCode1 = dutysCodeArr[i];
                var margeFlag = false;
                for (var j = i+1; j < dutysCodeArr.length; j++) {
                    var nowDutyCode2 = dutysCodeArr[j];
                    if (nowDutyCode1 == nowDutyCode2) {
                        var duty1 = vm.selectedPlansForMarge.dutys[i];
                        var duty2 = vm.selectedPlansForMarge.dutys[j];
                        
                        margeDutys.push({
                            ilCode: duty1.ilCode + '/' + duty2.ilCode,
                            ilName: duty1.ilName + '/' + duty2.ilName.substr(duty2.ilName.length-2,2),
                            insuredAmount:duty1.insuredAmount == 10000 ? duty1.insuredAmount / 10000 * duty1.maxSaleQuantity+"万"+ getMoneyUnit(duty1.ilName): duty1.insuredAmount * duty1.maxSaleQuantity+ getMoneyUnit(duty1.ilName)
                            // insuredAmount: duty1.insuredAmount * duty1.maxSaleQuantity + getMoneyUnit(duty1.insuredAmount, duty1.ilName)
                        });

                        //去除已标记合并的责任
                        dutysCodeArr.splice(j,1);
                        vm.selectedPlansForMarge.dutys.splice(j,1);
                        // console.log(PolicyService.getSessionData().productData.plans);

                        margeFlag = true;
                        break;
                    }
                }
                if (!margeFlag) {
                    unmargeDutys.push({
                        ilCode: vm.selectedPlansForMarge.dutys[i].ilCode,
                        ilName: vm.selectedPlansForMarge.dutys[i].ilName,
                        insuredAmount: vm.selectedPlansForMarge.dutys[i].insuredAmount == 10000 ? vm.selectedPlansForMarge.dutys[i].insuredAmount / 10000 * vm.selectedPlansForMarge.dutys[i].maxSaleQuantity+"万"+ getMoneyUnit(vm.selectedPlansForMarge.dutys[i].ilName) : vm.selectedPlansForMarge.dutys[i].insuredAmount * vm.selectedPlansForMarge.dutys[i].maxSaleQuantity+getMoneyUnit(vm.selectedPlansForMarge.dutys[i].ilName) 
                        // insuredAmount: vm.selectedPlansForMarge.dutys[i].insuredAmount * vm.selectedPlansForMarge.dutys[i].maxSaleQuantity + getMoneyUnit(vm.selectedPlansForMarge.dutys[i].insuredAmount, vm.selectedPlansForMarge.dutys[i].ilName)
                    });
                }
            }
            // console.log(margeDutys);
            // console.log(unmargeDutys);

            // 第三步，合并责任列表
            vm.selectedPlansForShow.dutys = margeDutys.concat(unmargeDutys);

            // 排序组装后的责任列表
            vm.selectedPlansForShow.dutys.sort(compare);

            // 存入主险，供确认信息页面显示
            vm.mainPlan.dutysForShow = vm.selectedPlansForShow.dutys;
            // console.log(vm.selectedPlansForShow);
            // console.log(vm.selectedPlansForMarge);
        };


        // 切换计划
        vm.selectPlan = function(planId) {
            // console.log(PolicyService.getSessionData().productData.plans);
            //由于splice方法会改变原数组的值，所以需要从session里面重新取值
            vm.productData.plans = PolicyService.getSessionData().productData.plans;
            
            // 根据主险planCode，排序主险顺序
            vm.productData.plans.sort(function(obj1, obj2){
                var val1 = obj1.planCode;
                var val2 = obj2.planCode;

                if (val1 < val2) {
                    return -1;
                }else if (val1 > val2) {
                    return 1;
                }else{
                    return 0;
                }
            });
            // console.log(vm.productData.plans);
           
            // 获取选中的计划
            if (vm.productData.plans && vm.productData.plans.length > 0) {
                for (var i = 0; i < vm.productData.plans.length; i++) {
                    if (vm.productData.plans[i].planId == planId) {
                        vm.selectedPlans = vm.productData.plans[i];
                        watchSelectedPlans();
                        angular.extend(vm.mainPlan, PolicyService.getSessionData().productData.plans[i]);
                    }
                }
            }

            // 保费
            vm.mainPlan.exp = vm.selectedPlans.normalPrice;
            // 保额
            vm.mainPlan.amount = vm.selectedPlans.insuredAmount;
            // 保障期间
            vm.selectedPlans.securityAge = getInsuYearLable(vm.selectedPlans.insuYear, vm.selectedPlans.insuYearFlag);
            // 记录用户选择的保险计划ID
            vm.user.selectedPlanId = vm.selectedPlans.planId;

         };
        // 初始化选择第一个计划
        vm.user.selectedPlanId = vm.productData.plans[0].planId;
        vm.selectPlan(vm.user.selectedPlanId);


        // 赠险相关
        if (vm.productData.token) {
            vm.ifGiveToken = true;
            var giveMargeDutys = [];
            vm.giveCanNotChoseTime = true;
            PolicyService.getCardInfo(vm.productData.token, function(data) {
                console.log(data);
                if (data) {

                    vm.giveTokenInfo = data;
                    var newPlanId;
                    var newGivenDutys = vm.giveTokenInfo.prmLotDutySetModels;
                    vm.newDutysArr = [];
                    if (newGivenDutys && newGivenDutys.length > 0) {
                        newPlanId = newGivenDutys[0].planId;
                    }

                    // console.log(newPlanId);

                    vm.user.selectedPlanId = newPlanId;
                    vm.selectPlan(vm.user.selectedPlanId);

                    if (vm.giveTokenInfo.donationMethodName == "固定保障期间") {
                        vm.selectedPlans.securityAge = vm.giveTokenInfo.giveDay;
                        if (vm.giveTokenInfo.giveStartTime) {
                            vm.giveTokenHaveGivedaysAndStartTime = true;
                            vm.choseStartTime = false;
                            vm.startTime = new Date(vm.giveTokenInfo.giveStartTime);
                        }else{
                            vm.giveTokenHaveGivedays = true;
                            vm.choseStartTime = true;
                        }
                    }
                    if (vm.giveTokenInfo.donationMethodName == "指定保障生效和终止日期") {
                        vm.giveTokenHaveStartTimeAndEndTime = true;
                        vm.choseEndTime = false;
                        vm.choseSecurityDays = false;
                        vm.choseStartTime = false;
                        vm.startTime = new Date(vm.giveTokenInfo.giveStartTime);
                        vm.endDate = new Date(vm.giveTokenInfo.giveEndTime);
                    }
                    if (vm.giveTokenInfo.donationMethodName == "按保障计划赠送") {
                        if (vm.giveTokenInfo.giveStartTime) {
                            vm.giveTokenHaveStartTime = true;
                            vm.choseStartTime = false;
                            vm.startTime = new Date(vm.giveTokenInfo.giveStartTime);
                        }else{
                            vm.giveTokenHavePlan = true;
                            vm.choseStartTime = true;
                        }
                    }
                }
            });
        } else {
            vm.ifGiveToken = false;
        }

        // 保险保障期间止期 计算方法
        var calcDate = function(){
            if (vm.startTime && vm.selectedPlans.insuYear && vm.selectedPlans.insuYearFlag) {
                // console.log("vm.startTime ----- " + vm.startTime + ";vm.selectedPlans.insuYear ----- " + vm.selectedPlans.insuYear + ";vm.selectedPlans.insuYearFlag ----- " + vm.selectedPlans.insuYearFlag);
                var endTime = new Date(vm.startTime);
                if ("M" == vm.selectedPlans.insuYearFlag) {
                    endTime.setMonth(vm.startTime.getMonth() + Number(vm.selectedPlans.insuYear));
                } else if ("D" == vm.selectedPlans.insuYearFlag) {
                    endTime.setDate(vm.startTime.getDate() + Number(vm.selectedPlans.insuYear));
                }
                // console.log("vm.startTime ----- " + vm.startTime);
                // console.log("endTime ----- " + new Date(endTime));
                return $filter('date')(endTime, 'yyyyMMdd');
            }
        }

        // 跳转投保页面
        vm.goPolicy = function() {
            // 计算保险保障期间止期,并处理为'yyyyMMdd'
            vm.cvrInsDt = calcDate();
            // console.log(vm.cvrInsDt);

            var params = {
                prdId: vm.productData.prd_id,
                sex: vm.user.sex,
                insurerBirthDay: $filter('date')(vm.user.birthday, 'yyyyMMdd'),
                planId: vm.selectedPlans.planId,
                premiumResult: vm.mainPlan.exp,
                orderCode: vm.productData.orderCode || ''
            };
            PolicyService.doCalc(params, function() {
                // 数据处理
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'data',
                    data: {
                        // birthday: vm.user.birthday, // 被保人生日
                        // sex: vm.user.sex, // 被保人性别
                        // selectedPlan: vm.user.selectedPlanId, //是否选择附加险
                        mainPlan: vm.mainPlan, // 主险
                        // addPlan: vm.addPlan, // 附加险
                        payendyear: vm.payAge, // 缴费期间
                        paymentType: vm.paymentType, // 缴费方式
                        PbBeginDate: vm.startTime, // 保险生效时间
                        PbInsuAmt: vm.mainPlan.amount, // 保险总保额 
                        PbInsuExp: vm.mainPlan.exp, // 保险总保费
                        pbApplNoNum: 1,
                        isWholeSale: vm.paymentType == '0' ? true : false,
                        minAge: vm.minAge,
                        maxAge: vm.maxAge,
                        minHolderAge: vm.minHolderAge,
                        maxHolderAge: vm.maxHolderAge,
                        // oldPrice: vm.mainPlan.exp // 赠险前原价
                        cvrInsDt : vm.cvrInsDt
                    }
                });
                // 流程跳转
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'process'
                });
            });
        };
    }
})();