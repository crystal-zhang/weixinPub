(function() {
    'use strict';

    angular
        .module('app')
        .controller('IlclController', IlclController);

    IlclController.$inject = ['$state', 'VALIDATION', '$scope', '$document', 'CommonRequest', 'CONFIG', 'TipService', 'PolicyService', '$filter', '$rootScope'];
    /** @ngInject */
    function IlclController($state, VALIDATION, $scope, $document, CommonRequest, CONFIG, TipService, PolicyService, $filter, $rootScope) {
        var vm = this;

        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        vm.productData = sessionData.productData;
        // 非法操作：1. 未获取产品数据 2. 要求做而未做手机验证
        if (!vm.productData || (sessionData.loginStatus != 2 && vm.productData.basicProfile['P005'] == 'Y' && !vm.productData.phoneValid)) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        // 用户选择的数据
        vm.user = {};
        vm.user.sex = '';
        vm.user.birthday = null;

        // 投被保人年龄
        var payTypeConfigs = vm.productData.payTypeConfigs;
        if (payTypeConfigs && payTypeConfigs.length > 0) {
            var payTypeConfig = payTypeConfigs[0];

            vm.minAge = payTypeConfig.min_app_age;
            vm.maxAge = payTypeConfig.max_app_age;
            vm.minHolderAge = payTypeConfig.minHolderAge;
            vm.maxHolderAge = payTypeConfig.maxHolderAge;

            vm.minStartDate = VALIDATION.getDateByAge(vm.maxAge); // 年龄最小开始日期
            vm.maxEndDate = VALIDATION.getDateByAge(vm.minAge); // 年龄最大结束日期
            vm.holderStartDate = VALIDATION.getDateByAge(vm.maxHolderAge); // 投保人年龄最小开始日期
            vm.holderEndDate = VALIDATION.getDateByAge(vm.minHolderAge); // 投保人年龄最大结束日期
        }

        // 主险数据
        vm.mainPlan = {
            rate: 0,
            amount: '',
            exp: 0
        };

        // 获取产品计划
        vm.getPlan = function() {
            var plan = vm.productData.plans;
            if (plan && plan.length >= 1) {
                vm.mainPlan = plan[0];

            }
        };
        vm.getPlan();

        // 账户类型
        vm.account = vm.productData.prdAccount;

        // 筛选产品状态
        var type1 = [];
        var type2 = [];
        angular.forEach(vm.account, function(data) {
            // 显示当期账号（1为当期账户，0为非当期）
            if (data.currentAcountFlg == 1) {
                type1.push(data)
            } else {
                type2.push(data)
            }
        });
        // 当期账户
        vm.accountStar = type1;
        // 非当期账户
        vm.account = type2;

        // 缴费方式，年缴
        vm.paymentType = vm.productData.payment_type.split(',')[0];

        // 缴费期间
        vm.payAge = vm.productData.pay_age;

        // 启用产品状态单一绑定购宝全额
        vm.onlyOne = function() {
            var ilclForm = $document[0].ilclForm;
            if (type1.length == 1) {
                if (vm.mainPlan.amount >= 1000) {
                    ilclForm.type0.value = vm.mainPlan.amount;
                }
            } else {
                ilclForm.type0.value = vm.mainPlan.amount;
            }
        };

        vm.button = false;

        // 展开其他投资账户
        vm.add = function() {
            vm.button = !vm.button;
        };

        // 提交
        vm.submitAccount = function() {
            vm.totalScore = 0;

            var ilclForm = $document[0].ilclForm;
            var score = [], // 每项金额
                accountScore = [];

            for (var i = 0; i < type1.length; i++) {
                score.push(ilclForm['type' + i].value)
            }

            accountScore = score;

            for (var k = 0; k < vm.productData.prdAccount.length; k++) {
                if (vm.productData.prdAccount[k].currentAcountFlg == 1) {
                    for (var l = 0; l < accountScore.length; l++) {
                        vm.productData.prdAccount[k].PbInsuExp = accountScore[l];
                        accountScore = accountScore.slice(1);
                        break;
                    }

                } else {
                    vm.productData.prdAccount[k].PbInsuExp = '0.0';
                }
            }

            // 购买金额总和
            for (var j = 0; j < score.length; j++) {
                vm.totalScore += parseInt(score[j]);
                vm.mainPlan.exp = vm.totalScore;
            }

            // 投资总金额必须等于购买金额
            if (parseInt(vm.mainPlan.amount) != vm.totalScore) {
                TipService.showMsg($rootScope.TIPS.PRODUCT.ILCL_TOTAL_ERROR);
            } else {
                // 跳转投保页面
                vm.goPolicy();
            }
        };

        // 跳转投保页面
        vm.goPolicy = function() {
            var params = {
                prdId: vm.productData.prd_id,
                sex: vm.user.sex,
                insurerBirthDay: $filter('date')(vm.user.birthday, 'yyyyMMdd'),
                planId: vm.productData.plans[0].planId,
                premiumResult: vm.totalScore,
                orderCode: vm.productData.orderCode || ''
            };

            PolicyService.doCalc(params, function() {
                // 数据处理
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'data',
                    data: {
                        //birthday: vm.user.birthday, // 被保人生日
                        //sex: vm.user.sex, // 被保人性别
                        //selectedPlan: vm.user.selectedPlan, //是否选择附加险
                        mainPlan: vm.mainPlan, // 主险
                        //addPlan: vm.addPlan, // 附加险
                        payendyear: vm.payAge, // 缴费期间
                        paymentType: vm.paymentType, // 缴费方式
                        PbInsuAmt: parseInt(vm.mainPlan.amount), // 保险总保额 
                        PbInsuExp: vm.mainPlan.exp, // 保险总保费
                        pbApplNoNum: 1,
                        isWholeSale: vm.paymentType == '0' ? true : false,
                        minAge: vm.minAge,
                        maxAge: vm.maxAge,
                        minHolderAge: vm.minHolderAge,
                        maxHolderAge: vm.maxHolderAge,
                        prdAccount: vm.productData.prdAccount
                    }
                });
                // 流程跳转
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'process'
                });
            });
        };
    }

})();