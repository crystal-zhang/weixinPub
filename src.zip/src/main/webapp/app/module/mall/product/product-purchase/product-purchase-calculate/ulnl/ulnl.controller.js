(function() {
    'use strict';

    angular
        .module('app')
        .controller('UlnlController', UlnlController);

    UlnlController.$inject = ['$state', 'CONFIG', 'CommonRequest', 'VALIDATION', '$scope', '$rootScope', 'PolicyService', 'TipService', '$filter', '$timeout'];
    /** @ngInject */
    function UlnlController($state, CONFIG, CommonRequest, VALIDATION, $scope, $rootScope, PolicyService, TipService, $filter, $timeout) {
        var vm = this;

        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        vm.productData = sessionData.productData;
        // 非法操作：1. 未获取产品数据 2. 要求做而未做手机验证
        if (!vm.productData || (sessionData.loginStatus != 2 && vm.productData.basicProfile['P005'] == 'Y' && !vm.productData.phoneValid)) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        // 初始化开始

        // 用户选择的数据
        vm.user = {};
        vm.user.sex = '1';
        vm.user.birthday = null;
        
        // 日期选择回调
        vm.birthdayCallback = function(val) {
            if (val) {
                vm.user.birthday = val;
            }
        };

        // 投被保人年龄选择
        var min_age,
            max_age,
            min_hoider_age,
            max_hoider_age,
            payTypeConfigs = vm.productData.payTypeConfigs;

        if (payTypeConfigs && payTypeConfigs.length > 0) {
            min_age = payTypeConfigs[0].min_app_age;
            max_age = payTypeConfigs[0].max_app_age;
            min_hoider_age = payTypeConfigs[0].minHolderAge;
            max_hoider_age = payTypeConfigs[0].maxHolderAge;
            vm.minAge = min_age;
            vm.maxAge = max_age;
            vm.minHolderAge = min_hoider_age;
            vm.maxHolderAge = max_hoider_age;
            vm.minStartDate = VALIDATION.getDateByAge(max_age); // 被保人最大年龄
            vm.maxEndDate = VALIDATION.getDateByAge(min_age); // 被保人最小年龄
            vm.hoiderStartDate = VALIDATION.getDateByAge(max_hoider_age); // 投保人最大年龄
            vm.hoiderEndDate = VALIDATION.getDateByAge(min_hoider_age); // 投保人最小年龄
        }

        // 主险数据
        vm.mainPlan = {
            rate: 0,
            amount: '',
            exp: ''
        };
        vm.addPlan = {};
        // 获取产品计划
        vm.getPlan = function() {
            var plan = vm.productData.plans,
                len = plan.length;

            for (var i = len - 1; i >= 0; i--) {
                var item = plan[i];
                if (item.planType == '1') {
                    // 获取主险
                    angular.extend(vm.mainPlan, item);
                } else if (item.planType == '2') {
                    // 获取附加险
                    angular.extend(vm.addPlan, item);
                }
            }
        };
        vm.getPlan();

        // 缴费方式，年缴
        vm.paymentType = vm.productData.payment_type;
        // 缴费期间
        vm.payAge = vm.productData.pay_age;

        // 监听获取费率
        $scope.$watch('ulnl.user', function() {
            if ($scope.ulnlForm.$valid) {
                vm.calc(vm);
            } else {
                vm.mainPlan.amount = '';
            }
        }, true);

        // 监听保费改变
        $scope.$watch('ulnl.mainPlan.exp', function() {
            $timeout(function() {
                if ($scope.ulnlForm.$valid) {
                    vm.calc(vm);
                } else {
                    vm.mainPlan.amount = '';
                }
            }, 100);
        });

        // 获取费率，计算保费
        vm.calc = function(vm, callback) {
            var user = vm.user;
            if (vm.productData.feeSetType !== "3") {
                vm.mainPlan.amount = vm.mainPlan.exp;
                callback && callback({
                    exp: vm.mainPlan.exp, 
                    amount: vm.mainPlan.amount,
                    mainPlan: vm.mainPlan
                });
            } else {
                var age = VALIDATION.getAgeByBirth(user.birthday);
                // 获取费率
                var params = {
                    prdId: vm.productData.prd_id,
                    age: age,
                    sex: user.sex,
                    payEndYear: vm.payAge
                };

                CommonRequest.request(params, CONFIG.PRODUCT_PURCHASE_CALCULATE_SERVICE, function(result) {
                    if (result.status == 1) {
                        var rateTable = result.data,
                            mainRate = []; // 主险费率表
                        // 重置保额
                        vm.mainPlan.amount = 0;

                        if (rateTable && rateTable.length > 0) {
                            for (var i = 0; i < rateTable.length; i++) {
                                if (rateTable[i].planType == '1') {
                                    mainRate.push(rateTable[i]);
                                }
                            }

                            if (mainRate && mainRate.length > 0) {
                                // 主险费率
                                vm.mainPlan.rate = mainRate[0].rate;
                                // 计算主险保费
                                vm.mainPlan.amount = (vm.mainPlan.exp / vm.mainPlan.normalPrice) * vm.mainPlan.rate;
                                // callback(vm.mainPlan.exp, vm.mainPlan.rate, vm.mainPlan.amount);
                                callback && callback({
                                    exp: vm.mainPlan.exp, 
                                    amount: vm.mainPlan.amount,
                                    mainPlan: vm.mainPlan
                                });
                            }
                        } else {
                            //var amount = vm.mainPlan.exp;
                            //callback(amount);
                            TipService.showMsg('费率为空！');
                        }
                    }
                });
            }
        };

        // 跳转投保页面
        vm.goPolicy = function() {
            vm.mainPlan.exp = vm.mainPlan.exp.toString();
            vm.mainPlan.amount = vm.mainPlan.amount.toString();
            var params = {
                prdId: vm.productData.prd_id,
                sex: vm.user.sex,
                insurerBirthDay: $filter('date')(vm.user.birthday, 'yyyyMMdd'),
                planId: vm.mainPlan.planId,
                premiumResult: vm.mainPlan.exp,
                orderCode: vm.productData.orderCode || ''
            };

            PolicyService.doCalc(params, function() {
                // 数据处理
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'data',
                    data: {
                        birthday: $filter('date')(vm.user.birthday, 'yyyy-MM-dd'), // 被保人生日
                        sex: vm.user.sex, // 被保人性别
                        //selectedPlan: vm.user.selectedPlan, //是否选择附加险
                        mainPlan: vm.mainPlan, // 主险
                        // addPlan: vm.addPlan, // 附加险
                        payendyear: vm.payAge, // 缴费期间
                        paymentType: vm.paymentType, // 缴费方式
                        //  PbBeginDate: vm.startTime, // 保险生效时间
                        PbInsuAmt: vm.mainPlan.amount, // 保险总保额 
                        PbInsuExp: vm.mainPlan.exp, // 保险总保费
                        pbApplNoNum: 1,
                        isWholeSale: vm.paymentType == '0' ? true : false,
                        minAge: vm.minAge,
                        maxAge: vm.maxAge,
                        minHolderAge: vm.minHolderAge,
                        maxHolderAge: vm.maxHolderAge,
                        calc: vm.calc.toString(),
                        calcCtrl: vm
                    }
                });
                // 流程跳转
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'process'
                });
            });
        };
    }
})();