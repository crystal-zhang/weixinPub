(function() {
    'use strict';

    angular
        .module('app')
        .controller('PolicyNoticeController', PolicyNoticeController);

    PolicyNoticeController.$inject = ['$state', 'CommonRequest', 'CONFIG', 'VALIDATION', 'PolicyService', '$filter', 'TipService', '$rootScope', '$timeout'];

    /** @ngInject */
    function PolicyNoticeController($state, CommonRequest, CONFIG, VALIDATION, PolicyService, $filter, TipService, $rootScope, $timeout) {
        var vm = this;

        var sessionData = PolicyService.getSessionData();
        vm.checkImgCodeForShow = false;
        // 所选产品信息
        vm.productData = sessionData.productData;
        if (!vm.productData) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        // 被保人信息
        vm.insureData = sessionData.insureData;

        // 投保信息
        vm.policyData = sessionData.policyData;

        // 投保费用
        vm.PbInsuExp = vm.insureData.PbInsuExp;

        // 健康告知
        vm.healthTag = '';

        // 条款列表
        vm.materials = vm.productData.materials;

        // 获取条款明细
        vm.materialDetail = function(ma) {
            if (ma) {
                var materialTypeDesc = ma.materialTypeDesc,
                    materialType = ma.materialType;
                var params = {
                    prdId: vm.productData.prd_id,
                    materialType: materialType,
                    materialTypeDesc: materialTypeDesc

                };
                PolicyService.getMaterialDetail(params);
            }
        };

        // 保险期间类型转换
        vm.insuYearFlag = vm.insureData.mainPlan.insuYearFlag; // 保险年期类型 0：无关 1：终身 2：按年 3：按季 4：按月 5:按天 6：至某确定年龄
        switch (vm.insuYearFlag) {
            case 'D':
                vm.PbInsuYearFlag = '5';
                break;
            case 'M':
                vm.PbInsuYearFlag = '4';
                break;
            case 'Y':
                vm.PbInsuYearFlag = '2';
                break;
            case 'A':
                vm.PbInsuYearFlag = '6';
                break;
        }

        // 投连型
        vm.prdAccount = vm.insureData.prdAccount;
        vm.PbInsuExp1 = '';
        vm.PbInsuExp2 = '';
        vm.LiImpawnTag = '';
        if (vm.prdAccount && vm.prdAccount.length > 0) {
            for (var j = 0; j < vm.prdAccount.length; j++) {
                vm.PbInsuExp2 = vm.PbInsuExp2 + vm.prdAccount[j].PbInsuExp + ';';
                vm.PbInsuExp1 = vm.PbInsuExp1 + vm.prdAccount[j].accountCode + ';';
            }
            // 核心那最后";"不要
            vm.PbInsuExp2 = vm.PbInsuExp2.substr(0, vm.PbInsuExp2.length - 1);
            vm.PbInsuExp1 = vm.PbInsuExp1.substr(0, vm.PbInsuExp1.length - 1);
            vm.LiImpawnTag = '2';
        }

        // 信息校验
        vm.dataCheck = function() {
            // 健康告知校验
            if (vm.healthTag != '0') {
                TipService.showMsg($rootScope.TIPS.PRODUCT.HEALTHY_INVALID);
                return false;
            }

            return true;
        };

        // 获取投保录入信息
        vm.getPolicyData = function() {
            // 附加险
            vm.addPlan = vm.insureData.addPlan;
            if (vm.addPlan) {
                if (!angular.isArray(vm.addPlan)) {
                    vm.addPlan = [vm.addPlan];
                }

                vm.BkNum1 = 0; // 附加险个数
                vm.AppdList = [];

                for (var i = 0; i < vm.addPlan.length; i++) {
                    vm.BkNum1++;
                    vm.AppdList.push({
                        cvrID: vm.addPlan[i].planCode,
                        cvrNm: vm.addPlan[i].planName,
                        insCps: 1, // 份数
                        insPremAmt: vm.addPlan[i].exp,
                        insCvr: vm.addPlan[i].amount,
                        insDdln: vm.insureData.mainPlan.insuYear,
                        insPremPyFPrdNum: vm.insureData.payendyear,
                        LiBackTag: vm.policyData.isBatts,
                        mainAndAdlInsInd: '0',
                        prdId: vm.productData.prd_id, // 产品ID
                        planId: vm.addPlan[i].planId// 计划ID
                    });
                }
            }

            // 提交核保请求
            var params = {
                orderCode: vm.productData.orderCode,
                PbBenfNum: '0', // 受益人个数 0默认法定
                PbInsuType: vm.productData.prd_code, // 主险险种代码
                PbInsuName: vm.productData.prd_title, // 主险险种名称 预留，目前送空值
                mainAndAdlInsInd: '1', // 主附险标志--fxzg
                PbSlipNumb: 1, // 主险份数
                PbInsuExp: vm.insureData.mainPlan.exp, // 主险保费
                PbInsuAmt: vm.insureData.mainPlan.amount, // 主险保额
                PbMainInsuExp: 0, // 可选部分身故保险金额 投连险专用
                PbInsuExpAppd: 0, // 首次额外追加保费 投连险专用
                PbSendMode: '2', // 保单递送方式 1：邮寄 2：电子发送 3：指定柜台领取
                PbBeginDate: vm.insureData.PbBeginDate, // 起保日期 指定生效日
                // PbInsuPayMode: '1', // 续期保险缴费方式 2 银行折代扣 3 银行卡代扣(待定，根据BAND.xml来写的) 
                LiSpec: '', // 特别约定 预留，目前送空值 
                LiExpireInsuDrawMode: '', // 满期保险金领取方式 0：趸领 1：月领 12：年领 
                LiPayOffTag: '', // 减额交清标记 0：正常；1：减额交清；
                LiHealthTag: vm.healthTag, // 健康告知标志 0：无健康告知1：有健康告知
                PbPayPeriod: vm.insureData.paymentType, // 缴费间隔/频次
                PbPayAgeTag: vm.insureData.payendyear || '1', // 缴费年期 默认1
                PbInsuYearFlag: vm.PbInsuYearFlag, // 保险年期类型 0：无关 1：终身 2：按年 3：按季 4：按月 5：按天
                LiInsuPeriod: vm.insureData.mainPlan.insuYear, //保险期限 一年
                PbInsuYear: 0, // 保险年龄 预留，目前送0或空
                PbPayAge: 0, // 缴费年龄 预留，目前送0或空
                PbDrawAgeTag: '', // 领取年期,暂时为空
                PbDrawAge: 0, // 领取年龄 预留，目前送0或空
                LiImpawnTag: vm.LiImpawnTag || '', // 投资方式 投连险使用
                BkNum1: vm.BkNum1 || 0, // 附加险个数
                AppdList: vm.AppdList || [], // 附加险
                BkNum2: 0, // 投资账户个数
                PbApplNo: vm.PbApplNo || '', // 投保单号
                BkVchNo: '', // 保单印刷号
                LiInsuSlipPWD: '', // 保单密码 用于传输加密的密码字段
                PiTrfVchNo: '', // 发票印刷区域性保险公司使用。建总行合作的保险公司不用。
                BkRckrNo: '', // 银行客户经理代码
                PiZxbe20: 0, // 未成年人累计保额
                BkAreaNo: '', // 保险公司省级机构编号 非柜台渠道使用
                PiManBankNo: '', // 地市代码 非柜台渠道使用

                PbRemark1: (vm.productData.token || vm.policyData.hasDiscount == '1') ? '0' : '1', // 保留域1
                PbRemark2: vm.productData.token ? 2 : (vm.policyData.hasDiscount == '1' ? '1' : '0'), // 保留域2,0为无，1为浮动费率，2为赠险
                PbRemark3: vm.productData.token ? '0.00000000' : (vm.policyData.discount || ''), // 保留域3
                PbRemark4: vm.productData.lotCode ? vm.productData.lotCode : (vm.policyData.disActivityId || ''), // 保留域4 传赠险或折扣的活动id
                PbRemark5: '', // 保留域5
                PbRemark6: '', // 保留域6

                insScmInf: vm.insureData.mainPlan.planCode, // 6个计划别，两位代码：A-D+1-4
                disActId: (vm.productData.token || vm.policyData.configType == '1' || vm.policyData.configType == '4') ? '0000' : vm.policyData.BkBrchNo.substr(0, 4), // 折扣地区
                saleChnl: (!vm.productData.token || vm.policyData.configType == '2' || vm.policyData.configType == '4') ? '000' : CONFIG.SALE_CHANNEL, // 折扣地区

                SellTypeDetail: CONFIG.SALE_CHANNEL, // 来源为空，悦生活渠道
                PbInsuExp1: vm.PbInsuExp1, // 投连型账户code
                PbInsuExp2: vm.PbInsuExp2, // 投连型账户金额
                allInsuExp: vm.insureData.PbInsuExp, // 投连型账户金额
                materials: vm.materials, // 传到确认页面的链接名称
                cardToken: vm.productData.token, // 卡券的token 
                dutys: vm.insureData.mainPlan.dutys,
                prdId: vm.productData.prd_id, // 产品ID
                planId: vm.insureData.mainPlan.planId, // 计划ID
            };

            //如果核保超过三次以上，则传递验证码code和random字段
            if (vm.checkImgCodeForShow) {
                params.cpRandom = vm.cpRandom;
                params.cpImageCode = vm.cpImageCode;
            }else{
                params.cpRandom = '';
                params.cpImageCode = '';
            }

            if (vm.productData.newSaleChnl) {
                params.sellTypeDetail = vm.productData.newSaleChnl;
                params.saleChnl = vm.productData.newSaleChnl;
                params.salesId = vm.productData.salesId;
                params.parentSalesId = vm.productData.parentSalesId;
                params.salesLevel = vm.productData.salesLevel;
            }   
            
            //  若是天天保产品选择多个时间段则会发送多个请求，生成多个保单
            var dates = params.PbBeginDate;
            if (angular.isArray(dates) && dates.length >= 1) {
                var codeArr = vm.insureData.codeArr;
                var code = '';
                if (codeArr && codeArr.length > 0) {
                    for (var m = 0; m < codeArr.length; m++) {
                        code = code + codeArr[m] + ';';
                    }
                    code = code.substr(0, code.length - 1);
                }

                var newParams = [];
                for (var j = 0; j < dates.length; j++) {
                    var startTime = dates[j].start,
                        endTime = dates[j].end,
                        tempDay = dates[j].tempDay;

                    var temp = {};
                    angular.extend(temp, params);

                    temp.PbBeginDate = $filter('date')(startTime, 'yyyyMMdd');
                    temp.LiInsuPeriod = tempDay;
                    temp.cvrInsDt = $filter('date')(endTime, 'yyyyMMdd');//暂时保留
                    temp.PbRemark6 = $filter('date')(endTime, 'yyyyMMdd');//天天保的结束日期--cvrInsDt（新的核保字段）InsPolcyExpDt
                    temp.PbApplNo = vm.PbApplNo[j];
                    temp.insScmInf = code;
                    temp.allInsuExp = vm.insureData.PbInsuExp / dates.length;
                    temp.PbInsuExp = '0.0'; // 主险保费
                    temp.PbInsuAmt = '0.0'; // 主险保额
                    newParams.push(temp);
                }
                return newParams;
            } else {
                params.PbBeginDate = $filter('date')(params.PbBeginDate, 'yyyyMMdd');
                params.PbApplNo = vm.PbApplNo[0];
                params.insScmInf = vm.insureData.mainPlan.planCode;
                params.PbInsuExp = vm.insureData.mainPlan.exp;
            }

            // 添加CvrInsDt参数，后台存储
            // TAC学生惠产品 二阶段建信旅游意外伤害保障计划A IPAM建信超值自驾意外伤害保障险产品
            // by lixianzhang 2017年6月14日
            if (vm.productData.templateCode == "TAC" || vm.productData.templateCode == "TACA" || vm.productData.templateCode == "IPAM") {
                params.cvrInsDt = vm.insureData.cvrInsDt;
                params.PbRemark6 = vm.insureData.cvrInsDt;
            }

            // 添加beginTime参数，起保时间 指定生效时刻
            // TAC二阶段建信旅游意外伤害保障计划A
            // by lixianzhang 2017年6月27日
            if (vm.productData.templateCode == "TACA") {
                params.beginTime = vm.insureData.beginTime;
            }

            if (vm.productData.templateCode == "HMRA") {
                params.socialSecurity = vm.insureData.socialSecurity;
            }

                     
            return params;
        };

        // 投保
        vm.checkPolicy = function() {
            var policyData = vm.getPolicyData();

            if (!policyData) {
                return;
            }

            if (angular.isArray(policyData) && policyData.length > 0) {
                for (var i = 0; i < policyData.length; i++) {
                    doCheck(policyData[i], i);
                }
            } else {
                doCheck(policyData, 0);
            }

            function doCheck(params, index) {
                $timeout(function() {
                    // 数据处理
                    PolicyService.control({
                        state: $state.current.name,
                        control: 'data',
                        data: params
                    });
                    // 流程跳转
                    PolicyService.control({
                        state: $state.current.name,
                        control: 'process'
                    });
                }, 500 * index);
            }
        };

        // 新增核保超过三次图形验证码
        // 获取图形验证码
        vm.cpRandom = Date.parse(new Date()) + Math.random(8);
        vm.cpImgpath = CONFIG.SERVICE_ADDRESS + 'new/ImgVerifyCode?random=' + vm.cpRandom;
        // //如果核保不通过，则更新图形验证码
        $rootScope.$on('get-newimgCode', function(erent, data) {
            // console.log(data);
            if (data.result == 'true') {
                // params.cpImageCode = '';
                vm.cpRandom = Date.parse(new Date()) + Math.random(8);
                vm.cpImgpath = CONFIG.SERVICE_ADDRESS + 'new/ImgVerifyCode?random=' + vm.cpRandom;
            }
        });
        // //监听核保是否超过三次，判断是否需要输入图形验证码
        vm.checkImgCode = function() {
            // console.log(vm.checkImgCodeForShow);
            var rootScope = $rootScope;
            rootScope.$on('send-imgCode', function(erent, data) {
                // console.log(data);
                if (data.isCheckImgFlag == 'Y') {
                    // params.cpImageCode = '';
                    vm.checkImgCodeForShow = true;
                } else {
                    vm.checkImgCodeForShow = false;
                }
            });
        };
        // //点击验证码图片更新图形验证码
        vm.getCpimg = function() {
            vm.cpImageCode = '';
            vm.cpRandom = Date.parse(new Date()) + Math.random(8);
            vm.cpImgpath = CONFIG.SERVICE_ADDRESS + 'new/ImgVerifyCode?random=' + vm.cpRandom;
        };

        // 提交信息
        vm.submit = function() {
            if (!vm.dataCheck()) {
                return;
            }
            //判断是否需要输入图形验证码
            vm.checkImgCode(vm);
            // 生成投保单号并核保
            PolicyService.createPbApplNo(vm.policyData.BkBrchNo, function(pbApplNoList) {
                vm.PbApplNo = pbApplNoList;

                vm.checkPolicy();
            });
        };
    }
})();