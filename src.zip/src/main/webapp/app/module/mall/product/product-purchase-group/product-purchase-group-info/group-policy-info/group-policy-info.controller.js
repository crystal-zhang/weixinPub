(function() {
	'use strict';

	angular
		.module('app')
		.controller('GroupPolicyInfoController', GroupPolicyInfoController);

	GroupPolicyInfoController.$inject = ['$state', 'CONFIG', '$rootScope', 'VALIDATION', '$scope', 'COMMON', '$filter', 'TipService', 'GroupPolicyService', 'CommonRequest', '$ionicPopup', '$timeout', '$ionicLoading'];

	/** @ngInject */
	function GroupPolicyInfoController($state, CONFIG, $rootScope, VALIDATION, $scope, COMMON, $filter, TipService, GroupPolicyService, CommonRequest, $ionicPopup, $timeout, $ionicLoading) {
		//获取缓存
		var vm = this,
			sessionData = GroupPolicyService.getSessionData();
		vm.productData = sessionData.productData, vm.insureData = sessionData.insureData, vm.userData = sessionData.userData || {}, vm.policyData = sessionData.policyData || {};
		//重新获取ordercode
		vm.insureData.params.orderCode = vm.productData.orderCode;
		//投保人年龄限制
		var payTypeConfigs = vm.productData.payTypeConfigs;
		if (payTypeConfigs && payTypeConfigs.length > 0) {
			var payTypeConfig = payTypeConfigs[0];
			vm.minAge = payTypeConfig.minHolderAge,
				vm.maxAge = payTypeConfig.maxHolderAge
		}
		//被保人年龄限制
		vm.childMinAge = "0", vm.childMaxAge = "23", vm.secList = [];
		for (var i = 1; i < vm.insureData.params.premiumAppEntity.insuredList.length; i++) vm.secList.push({
			id: vm.insureData.params.premiumAppEntity.insuredList[i].rcgnNm,
			secIsShow: !1,
			birth: vm.insureData.params.premiumAppEntity.insuredList[i].rcgnBrthDt,
			isMate: vm.insureData.params.premiumAppEntity.insuredList[i].insuredAppntRela,
			isMedic: vm.insureData.params.premiumAppEntity.insuredList[i].insuredSSflag
		});
		//列表点击展开折叠
		vm.secShow = function(id) {
			for (var i = 0; i < vm.secList.length; i++)
				if (vm.secList[i].id == id) {
					vm.secList[i].secIsShow = !vm.secList[i].secIsShow;
					break
				}
		};
		//字段展示隐藏
		vm.priChecked = !1, vm.priCheck = function() {
			vm.priChecked = !vm.priChecked
		};
		//配偶性别检验
		vm.checkMateSex = function() {
			"03" == vm.secList[i].isMate && ("男" == vm.gender && "男" == vm.secList[i].gender || "女" == vm.gender && "女" == vm.secList[i].gender) && TipService.showMsg($rootScope.TIPS.PRODUCT.MATE_SEX_ERROR)
		};
		//初始化开始
		vm.init = function() {
			vm.userData.customerName ? (vm.insureName = vm.userData.customerName, vm.nameDisabled = !0) : vm.insureName = vm.policyData.PbHoldName || "", vm.medic = vm.insureData.appntSsflag, vm.nationalities = [{
				label: "中国",
				value: "0156"
			}], vm.nationality = vm.policyData.PbNationality || "0156", vm.certTypes = [$rootScope.COMMON_DATA.ID_TYPES[0]], vm.certType = "A", vm.userData.cretNo && "A" == vm.userData.certType ? (vm.certNo = vm.userData.cretNo, vm.certNoDisabled = !0) : vm.certNo = vm.policyData.PbHoldId || "", vm.certStartDate = vm.policyData.PbIdStartDate || "", vm.certExpireType = vm.policyData.certExpireType || "2", vm.gender = "", vm.certType && "A" == vm.certType && vm.certNo ? (vm.gender = VALIDATION.getSex(vm.certNo) + "" == "1" ? "男" : "女", vm.genderDisabled = !0) : vm.userData.sex ? (vm.gender = vm.userData.sex + "" == "1" ? "男" : "女", vm.genderDisabled = !0) : vm.policyData.PbHoldSex && (vm.gender = "1" == vm.policyData.PbHoldSex ? "男" : "女"), vm.birthday = vm.insureData.plchdBrthDt.substring(0, 4) + "-" + vm.insureData.plchdBrthDt.substring(4, 6) + "-" + vm.insureData.plchdBrthDt.substring(6, 8), vm.userData.phoneNo ? (vm.phone = vm.userData.phoneNo, vm.phoneDisabled = !0) : vm.phone = vm.policyData.PbHoldMobl || "", vm.email = vm.policyData.PbHoldEmail || "", vm.address = vm.policyData.PbHoldHomeAddr || "", vm.zipCode = vm.policyData.PbHoldHomePost || "", vm.district = "0", vm.minStartDate = new Date((new Date).getTime() + 864e5);
			for (var i = 0; i < vm.secList.length; i++) vm.secList[i].nationalities = [{
				label: "中国",
				value: "0156"
			}], vm.secList[i].nationality = "0156", vm.secList[i].certTypes = [$rootScope.COMMON_DATA.ID_TYPES[0]], vm.secList[i].certType = "A", vm.secList[i].birthday = vm.secList[i].birth.substring(0, 4) + "-" + vm.secList[i].birth.substring(4, 6) + "-" + vm.secList[i].birth.substring(6, 8), vm.secList[i].certNo = "", vm.secList[i].isAdult = !0, "03" != vm.secList[i].isMate ? vm.secList[i].occupations = [{
				label: "办事人员和有关人员",
				value: "C0000"
			}] : vm.secList[i].occupations = $rootScope.COMMON_DATA.OCCUPATION_CODE, vm.secList[i].certExpireType = "2", vm.secList[i].minStartDate = new Date((new Date).getTime() + 864e5), VALIDATION.getAgeByBirth(vm.secList[i].birthday) < 18 && "03" != vm.secList[i].isMate ? vm.secList[i].isAdult = !1 : vm.secList[i].isAdult = !0
		};
		//初始化结束

		//事件监听开始 
		vm.watch = function() {
			$scope.$watch("groupPolicyInfo.certNo", function(newValue) {
					if (newValue) {
						if (vm.certType && "A" == vm.certType) {
							if (!VALIDATION.idCheck(newValue)) return;
							vm.gender = VALIDATION.getSex(newValue) + "" == "1" ? "男" : "女", vm.genderDisabled = !0, vm.birthday = VALIDATION.getBirthday(newValue)
						}
					} else vm.genderDisabled = !1
				}), vm.idChange = function(id) {
					for (var i = 0; i < vm.secList.length; i++)
						if (vm.secList[i].id == id && vm.secList[i].certType && "A" == vm.secList[i].certType) {
							if (!VALIDATION.idCheck(vm.secList[i].certNo)) return;
							vm.secList[i].gender = VALIDATION.getSex(vm.secList[i].certNo) + "" == "1" ? "男" : "女", "03" != vm.secList[i].isMate && (vm.secList[i].isMate = VALIDATION.getSex(vm.secList[i].certNo) + "" == "1" ? "06" : "07"), vm.secList[i].birthday = VALIDATION.getBirthday(vm.secList[i].certNo), VALIDATION.getAgeByBirth(vm.secList[i].birthday) < 18 && "03" != vm.secList[i].isMate ? vm.secList[i].isAdult = !1 : vm.secList[i].isAdult = !0
						}
				}, $scope.$watch("groupPolicyInfo.birthday", function(newValue, oldValue) {
					newValue != oldValue && (vm.pbHoldChanged = !0)
				}), $scope.$watch("groupPolicyInfo.medic", function(newValue, oldValue) {
					newValue != oldValue && (vm.pbHoldChanged = !0)
				})
				/*监听结束*/
		};
		//被保人信息变化缓存
		vm.insuredChangedData = function() {
			vm.insuredChangedCache = [];
			for (var i = 0; i < vm.secList.length; i++) {
				var birth, isMedic, isMate;
				birth = vm.secList[i].birthday.substring(0, 4) + vm.secList[i].birthday.substring(5, 7) + vm.secList[i].birthday.substring(8, 10), isMedic = vm.secList[i].isMedic, isMate = vm.secList[i].isMate, vm.insuredChangedCache.push({
					birth: birth,
					isMedic: isMedic,
					isMate: isMate
				}), birth == vm.insureData.params.premiumAppEntity.insuredList[i + 1].rcgnBrthDt && isMate == vm.insureData.params.premiumAppEntity.insuredList[i + 1].insuredAppntRela && isMedic == vm.insureData.params.premiumAppEntity.insuredList[i + 1].insuredSSflag || (vm.insuredChanged = !0)
			}
		};
		//保费重测算查询
		vm.getPremiumRateGroupCoreResultTimes = 0;
		vm.getPremiumRateGroupCoreResult = function(cacheData, flowNo) {
			$ionicLoading.show({
				template: '<ion-spinner icon="bubbles"></ion-spinner>'
			});
			// 累计请求次数限制
			vm.getPremiumRateGroupCoreResultTimes++;
			if (vm.getPremiumRateGroupCoreResultTimes > CONFIG.GROUP_CORE_DECOUPLING_TIMES) {
				$ionicLoading.hide();
				// TipService.showMsg($rootScope.TIPS.PRODUCT.POLICY_QUERY_FAILED);
				// 提示消息
				TipService.showMsg('系统繁忙,请稍后重试');
				// 重置请求次数
				vm.getPremiumRateGroupCoreResultTimes = 0;
				return;
			}
			var params = {
				flowNo4Trial: flowNo
			};

			CommonRequest.request(params, CONFIG.GHMB_GET_PREMIUM_RATE_GROUP_CORE_RESULT, function(result) {
				if (result.status == 1) {
					var data = result.data || '';
					// 获取核保结果
					if (data == '') {
						$timeout(function() {
							vm.getPremiumRateGroupCoreResult(cacheData,flowNo);
						}, CONFIG.GROUP_CORE_DECOUPLING_DURATION);
						return;
					}
					$ionicLoading.hide();

					// 重置请求次数
					vm.getPremiumRateGroupCoreResultTimes = 0;
					if (data.respCode == '00000') {
						var orderCode = data.orderCode;
						if (orderCode) {
							GroupPolicyService.setSessionData({
								productData: {
									orderCode: orderCode
								}
							});
						}
						//1 == result.status && "00000" == result.data.respCode ? (vm.insureData.totalInsCvr = result.data.totalInsCvr, TipService.showMsg($rootScope.TIPS.PRODUCT.RECACULATED + '<span class="fs20 orange">' + vm.insureData.totalInsCvr + "</span>元"), vm.pbHoldChanged = vm.insuredChanged = !1, vm.insureData.params = params) : TipService.showMsg(result.data.respDesc)
						vm.insureData.totalInsCvr = data.totalInsCvr;
						TipService.showMsg($rootScope.TIPS.PRODUCT.RECACULATED + '<span class="fs20 orange">' + vm.insureData.totalInsCvr + "</span>元");
						vm.pbHoldChanged = vm.insuredChanged = !1;
						vm.insureData.params = cacheData;
					} else {
						TipService.showMsg(data.respDesc);
						return;
					}
				} else {
					$ionicLoading.hide();
					// 重置请求次数
					vm.getPremiumRateGroupCoreResultTimes = 0;
				}
			}, true);
		};
		//拒保校验
		vm.validatePremiumRateParam = function() {
			for (var insuredList = [{
					rcgnGndCd: "男" == vm.gender ? "1" : "2",
					rcgnOcpCd: vm.occupation,
					insuredAppntRela: "01",
					rcgnNm: vm.insureName,
					rcgnMoveTelNo: vm.phone,
					rcgnCrdtNo: vm.certNo.toUpperCase()
				}], i = 0; i < vm.secList.length; i++) insuredList.push({
				rcgnGndCd: "男" == vm.secList[i].gender ? "1" : "2",
				rcgnOcpCd: vm.secList[i].occupation,
				insuredAppntRela: vm.secList[i].isMate,
				rcgnNm: vm.secList[i].name,
				rcgnMoveTelNo: vm.secList[i].phone || null,
				rcgnCrdtNo: vm.secList[i].certNo.toUpperCase()
			});
			var params = {
				checkPolicyGroupApp: {
					plchdOcpCd: vm.occupation,
					plchdGndCd: "男" == vm.gender ? "1" : "2",
					plchdNm: vm.insureName,
					plchdMoveTelNo: vm.phone,
					insuredList: insuredList
				}
			};
			CommonRequest.request(params, CONFIG.GHMB_VALIDATE_PREMIUMRATE_PARAM, function(result) {
				if (result) {
					if (1 != result.status) return !1;
					if (vm.insuredChangedData(), vm.pbHoldChanged || vm.insuredChanged) {
						var params = vm.insureData.params;
						params.premiumAppEntity.insuredList[0].rcgnBrthDt = params.premiumAppEntity.plchdBrthDt = vm.birthday.substring(0, 4) + vm.birthday.substring(5, 7) + vm.birthday.substring(8, 10), params.premiumAppEntity.insuredList[0].insuredSSflag = params.premiumAppEntity.appntSsflag = vm.medic;
						for (var i = 0; i < vm.insuredChangedCache.length; i++) params.premiumAppEntity.insuredList[i + 1].rcgnBrthDt = vm.insuredChangedCache[i].birth, params.premiumAppEntity.insuredList[i + 1].insuredSSflag = vm.insuredChangedCache[i].isMedic, params.premiumAppEntity.insuredList[i + 1].insuredAppntRela = vm.insuredChangedCache[i].isMate;
						return CommonRequest.request(params, CONFIG.PREMIUM_RATE_FROM_GROUP_CORE, function(result) {
							if (result.status == 1) {
								vm.getPremiumRateGroupCoreResult(params, result.data);
							}
						}), !1
					}
					for (var i = 0; i < vm.secList.length; i++) {
						for (var LiRcgnList = [], i = 0; i < vm.secList.length; i++) LiRcgnList.push({
							confirmRela: vm.secList[i].isMate,
							LiRcgnName: vm.secList[i].name,
							LiRcgnMedic: vm.secList[i].isMedic,
							LiNationality: vm.secList[i].nationality,
							LiRcgnIdType: vm.secList[i].certType,
							LiRcgnId: vm.secList[i].certNo.toUpperCase(),
							LiRcgnExpireType: vm.secList[i].certExpireType,
							LiIdEndDate: $filter("date")(vm.secList[i].certExpireDate, "yyyyMMdd"),
							LiRcgnSex: "男" == vm.secList[i].gender ? "1" : "2",
							LiRcgnBirdy: vm.insureData.params.premiumAppEntity.insuredList[i + 1].rcgnBrthDt,
							LiRcgnMobl: vm.secList[i].phone,
							LiRcgnOccupCode: vm.secList[i].occupation,
							LiRcgnAddress: vm.secList[i].address,
							LiRcgnZipCode: vm.secList[i].zipCode
						});
						GroupPolicyService.control({
							state: "product-purchase-group-policy-info",
							control: "data",
							data: {
								PbHoldName: vm.insureName,
								PbHoldMedic: vm.medic,
								PbNationality: vm.nationality,
								PbHoldIdType: vm.certType,
								PbHoldId: vm.certNo.toUpperCase(),
								PbHoldExpireType: vm.certExpireType,
								PbIdEndDate: $filter("date")(vm.certExpireDate, "yyyyMMdd"),
								PbHoldSex: "男" == vm.gender ? "1" : "2",
								PbHoldBirdy: vm.insureData.params.premiumAppEntity.insuredList[0].rcgnBrthDt,
								PbHoldMobl: vm.phone,
								PbHoldEmail: vm.email,
								PbHoldOccupCode: vm.occupation,
								PbHoldAmount: vm.amount,
								PbHoldDistrict: vm.district,
								PbHoldAddress: vm.address,
								PbHoldZipCode: vm.zipCode,
								totalInsCvr: vm.insureData.totalInsCvr,
								LiRcgnList: LiRcgnList
							}
						}), GroupPolicyService.control({
							state: "product-purchase-group-policy-info",
							control: "process"
						})
					}
				}
			})
		};
		$timeout(function() {
			vm.init(), vm.watch()
		}, 500);
		//下一步
		vm.next = function() {
			var age = VALIDATION.getAgeByBirth(vm.birthday);
			if (age > vm.maxAge || age < vm.minAge) return TipService.showMsg("投保人年龄应该在" + vm.minAge + "-" + vm.maxAge + "周岁"), !1;
			for (var i = 0; i < vm.secList.length; i++) {
				var insuredAge = VALIDATION.getAgeByBirth(vm.secList[i].birthday),
					birthDate = vm.secList[i].certNo.substring(6, 14),
					nowDate = $filter("date")(new Date, "yyyyMMdd"),
					d1 = new Date(birthDate.substring(0, 4), birthDate.substring(4, 6)-1, birthDate.substring(6, 8)).getTime(),
					d2 = new Date(nowDate.substring(0, 4), nowDate.substring(4, 6)-1, nowDate.substring(6, 8)).getTime(),
					insuredDate = (d2 - d1) / 864e5;
				if ("03" == vm.secList[i].isMate) {
					if (insuredAge > vm.maxAge || insuredAge < vm.minAge) return TipService.showMsg("配偶年龄应该在" + vm.minAge + "-" + vm.maxAge + "周岁"), !1
				} else if (insuredAge > vm.childMaxAge || "30" > insuredDate) return TipService.showMsg("子女年龄应该在" + vm.childMinAge + "-" + vm.childMaxAge + "周岁"), !1
			}
			vm.validatePremiumRateParam()
		}
	}
})();