(function() {
    'use strict';

    angular
        .module('app')
        .controller('PolicyInfoController', PolicyInfoController);

    PolicyInfoController.$inject = ['$state', 'CONFIG', '$rootScope', 'VALIDATION', '$scope', 'COMMON', '$filter', 'TipService', 'PolicyService', 'CommonRequest', '$ionicPopup', '$timeout'];

    /** @ngInject */
    function PolicyInfoController($state, CONFIG, $rootScope, VALIDATION, $scope, COMMON, $filter, TipService, PolicyService, CommonRequest, $ionicPopup, $timeout) {
        var vm = this;

        // 获取session数据
        var sessionData = PolicyService.getSessionData();

        // 所选产品信息、投保信息
        vm.productData = sessionData.productData;
        vm.insureData = sessionData.insureData;

        // 非法操作
        if (!vm.productData || !vm.insureData) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        vm.checkCusId = true;
        vm.checkInCusld = false;

        // 测算方法
        vm.calc = vm.insureData.calc ? eval('(' + vm.insureData.calc + ')') : null;
        vm.calcCtrl = vm.insureData.calcCtrl || null;

        // 投保人信息
        vm.userData = sessionData.userData || {};

        // 已存在policyData重载
        vm.policyData = sessionData.policyData || {};

        /****** 各模块初始化 ******/
        vm.init = function() {
            // 投保费用
            vm.PbInsuExp = vm.insureData.PbInsuExp;

            /*
             ** 投保人信息
             ** 1. 证件类型 PbHoldIdType
             ** 2. 证件号 PbHoldId
             ** 3. 国籍 PbNationality
             ** 4. 姓名 PbHoldName
             ** 5. 证件生效日期 PbIdStartDate
             ** 6. 证件失效日期 PbIdEndDate
             ** 7. 性别 PbHoldSex
             ** 8. 生日 PbHoldBirdy
             ** 9. 手机 PbHoldMobl
             ** 10. 邮箱 PbHoldEmail
             ** 11. 职业 PbHoldOccupCode
             ** 12. 联系地址 PbHoldHomeAddr
             ** 13. 邮编 PbHoldHomePost
             ** 14. 家庭电话 PbHoldHomeTele
             ** 15. 单位地址 PbHoldAddr
             ** 16. 单位邮编 PbHoldPost
             ** 17. 单位电话 PbHoldOfficTele
             */

            // 如果是TAC学生惠产品，特殊处理 用户session信息、国籍、证件类型
            // by lixianzhang 2017年5月8日
            if (vm.productData.templateCode == "TAC") {
                // 只保留手机号，不处理历史用户信息
                // 如果是用户原信息非身份证，则不保留原身份信息
                if (vm.userData.cretType != "A") {
                    // vm.userData = {phoneNo:vm.userData.phoneNo};
                    vm.userData.cretType = "A";
                    vm.userData.cretNo = "";
                }
                // 国籍默认中国，身份类型只有身份证，且不可更改
                vm.nationality = '0156';
                vm.nationalityDisabled = true;
                vm.certTypeDisabled = true;
            }

            // 1. 证件类型
            if (vm.userData.cretType) {
                // 用户信息存在证件类型，证件类型选项将会固定
                vm.certType = vm.userData.cretType;
                vm.certTypeDisabled = true;
                vm.certTypes = COMMON.getCertTypesByCode(vm.userData.cretType);
            } else {
                vm.certType = vm.policyData.PbHoldIdType || '';
                vm.certTypes = [];
            }
            // 2. 证件号
            if (vm.userData.cretNo) {
                vm.certNo = vm.userData.cretNo;
                vm.certNoDisabled = true;
            } else {
                vm.certNo = vm.policyData.PbHoldId || '';
            }
            // 3. 国籍
            vm.nationalities = $rootScope.COMMON_DATA.NATIONALITIES;
            if (vm.userData.cretType) {
                vm.nationalities = COMMON.getNationalitiesByCertType(vm.userData.cretType);
                vm.nationality = vm.nationalities[0].value;
                // vm.nationalityDisabled = true;
            } else {
                vm.nationality = vm.policyData.PbNationality || '0156'; // 默认中国
            }
            // 4. 姓名
            if (vm.userData.customerName) {
                vm.name = vm.userData.customerName;
                vm.nameDisabled = true;
            } else {
                vm.name = vm.policyData.PbHoldName || '';
            }
            // 5. 证件生效日期
            vm.certStartDate = vm.policyData.PbIdStartDate || '';
            // 6. 证件失效日期
            vm.certExpireType = vm.policyData.certExpireType || '2'; // 默认长期有效

            // 7. 性别
            vm.gender = '1'; // 默认男
            if (vm.certType && vm.certType == 'A' && vm.certNo) {
                // 已存在证件类型、证件号，计算得出
                vm.gender = VALIDATION.getSex(vm.certNo) + '';
                vm.genderDisabled = true;
            } else if (vm.userData.sex) {
                // 用户信息中存在生日
                vm.gender = vm.userData.sex + '';
                vm.genderDisabled = true;
            } else if (vm.policyData.PbHoldSex) {
                // policyData反显
                vm.gender = vm.policyData.PbHoldSex;
            }
            // 8. 生日
            vm.birthday = '';
            if (vm.certType && vm.certType == 'A' && vm.certNo) {
                // 已存在证件类型、证件号，计算得出
                vm.birthday = new Date(VALIDATION.getBirthday(vm.certNo));
                vm.birthdayDisabled = true;
            } else if (vm.userData.birthday && vm.userData.birthday.length == 10) {
                // 用户信息中存在生日,长度区分官网的8
                vm.birthday = new Date(vm.userData.birthday);
                vm.birthdayDisabled = true;
            } else if (vm.policyData.PbHoldBirdy && vm.policyData.PbHoldBirdy.length == 8) {
                // policyData反显
                vm.birthday = new Date(VALIDATION.dateFormat(vm.policyData.PbHoldBirdy));
            }
            // 9. 手机
            if (vm.userData.phoneNo) {
                vm.phone = vm.userData.phoneNo;
                vm.phoneDisabled = true;
            } else {
                vm.phone = vm.policyData.PbHoldMobl || '';
            }
            // 10. 邮箱
            vm.email = vm.policyData.PbHoldEmail || '';
            // 11. 职业
            vm.occupation = vm.policyData.PbHoldOccupCode || ''; // 被投保人默认职业类型
            vm.occupations = $rootScope.COMMON_DATA.OCCUPATION_CODE;
            vm.occupationDisable = false;

            // 如果是TAC学生惠产品，特殊处理 职业类型、投被保人关系
            // by lixianzhang 2017年5月8日
            if (vm.productData.templateCode == "TAC") {
                // 职业只能选择 学生 ,不可更改
                vm.occupation = "13020";
                // vm.occupationDisabled = true;
                // 投被保人关系 只能选择 本人 ,不可更改
                vm.relationDisabled = true;
            }
            if (vm.productData.templateCode == "TLD") {
                // 投被保人关系 只能选择 本人 ,不可更改
                vm.relationDisabled = true;
            }

            // 12. 联系地址
            vm.address = vm.policyData.PbHoldHomeAddr || '';
            // 13. 邮编
            vm.zipCode = vm.policyData.PbHoldHomePost || '';
            // 14. 家庭电话
            vm.homeTel = vm.policyData.PbHoldHomeTele || '';
            // 15. 单位地址
            vm.officeAddress = vm.policyData.PbHoldAddr || '';
            // 16. 单位邮编
            vm.officeZipCode = vm.policyData.PbHoldPost || '';
            // 17. 单位电话
            vm.officeTel = vm.policyData.PbHoldOfficTele || '';
            // 投保人出生日期控制
            vm.minHolderAge = vm.insureData.minHolderAge;
            vm.maxHolderAge = vm.insureData.maxHolderAge;
            vm.holderStartDate = VALIDATION.getDateByAge(vm.maxHolderAge);
            vm.holderEndDate = VALIDATION.getDateByAge(vm.minHolderAge);

            // 投被保人关系
            vm.relation = '01'; // 默认本人

            // 关系映射
            vm.checkRelation = function(relation, gender) {
                if (relation == '01') {
                    return '01';
                } else if (relation == '02') {
                    return '03';
                } else if (relation == '03') {
                    return '02';
                } else if (relation == '04' || relation == '05') {
                    if (gender == '1') {
                        return '06';
                    } else {
                        return '07';
                    }
                } else if (relation == '06' || relation == '07') {
                    if (gender == '1') {
                        return '04';
                    } else {
                        return '05';
                    }
                } else {
                    return '01';
                }
            };

            /*
             ** 被保人信息
             ** 1. 证件类型 LiRcgnIdType
             ** 2. 证件号 LiRcgnId
             ** 3. 国籍 LiNationality
             ** 4. 姓名 LiRcgnName
             ** 5. 证件生效日期 LiIdStartDate
             ** 6. 证件失效日期 LiIdEndDate
             ** 7. 性别 LiRcgnSex
             ** 8. 生日 LiRcgnBirdy
             ** 9. 手机 LiRcgnMobl
             ** 10. 邮箱 LiRcgnEmail
             ** 11. 职业 LiRcgnOccupCode
             ** 12. 联系地址 LiRcgnAddr
             ** 13. 邮编 LiRcgnPost
             ** 14. 家庭电话 LiRcgnTele
             */

            // 1. 证件类型
            vm.insureCertTypes = [];
            // 3. 国籍
            vm.insureNationalities = $rootScope.COMMON_DATA.NATIONALITIES;
            // 7. 性别
            vm.insureGender = vm.insureData.sex || '1';
            // 8. 生日
            vm.insureBirthday = vm.insureData.birthday || new Date();
            // 9. 职业
            vm.insureOccupations = $rootScope.COMMON_DATA.OCCUPATION_CODE;
            vm.insureOccupation = 'C0000';

            // 被保人出生日期控制
            vm.minAge = vm.insureData.minAge;
            vm.maxAge = vm.insureData.maxAge;
            vm.insureStartDate = VALIDATION.getDateByAge(vm.maxAge);
            vm.insureEndDate = VALIDATION.getDateByAge(vm.minAge);

            // 证件有效期不能低于当日日期
            vm.minStart = vm.minStartDate = new Date(new Date().getTime() + 1 * 24 * 60 * 60 * 1000);

            // 日期选择回调
            vm.certExpireDateCallback = function(val) {
                if (val) {
                    vm.certExpireDate = val;
                }
            };
            vm.insureCertExpireDateCallback = function(val) {
                if (val) {
                    vm.insureCertExpireDate = val;
                }
            };
            vm.birthdayCallback = function(val) {
                if (val) {
                    vm.birthday = val;
                }
            };
            vm.insureBirthdayCallback = function(val) {
                if (val) {
                    vm.insureBirthday = val;
                }
            };
        };
        /****** 各模块初始化结束 ******/

        /****** 事件监听 ******/
        vm.watch = function() {
            // 监听投保人国籍变化，改变证件类型
            $scope.$watch('policyInfo.nationality', function(newValue) {
                if (newValue) {
                    if (!vm.userData.cretType) {
                        vm.certTypes = COMMON.getCertTypesByNationality(newValue);
                        vm.certType = vm.certTypes[0].value;
                    }
                }
                // console.log(vm.nationality);
                if (vm.nationality == '0156') {
                    vm.checkCusId = true;
                } else {
                    vm.checkCusId = false;
                    if (vm.relation == '01') {
                        vm.checkInCusld = false;
                    } else {
                        vm.checkInCusld = true;
                    }
                }
            });

            // 监听被保人国籍变化，改变证件类型
            $scope.$watch('policyInfo.insureNationality', function(newValue) {
                if (newValue) {
                    vm.insureCertTypes = COMMON.getCertTypesByNationality(newValue);
                    vm.insureCertType = vm.insureCertTypes[0].value;
                }
                // console.log(vm.insureNationality);
                // console.log(vm.checkCusId);
                if (vm.insureNationality == '0156') {
                    vm.checkInCusld = true;
                } else {
                    if (vm.relation != '01') {
                        vm.checkInCusld = false;
                    }
                }
            });

            // 监听客户姓名，赋值给所有银行名称（现有系统只）
            $scope.$watch('policyInfo.name', function(newValue) {
                if (newValue) {

                    // vm.checkCusId = true;

                    vm.newGetAccountName = newValue; // 授权转账银行户名
                    vm.authAccountName = newValue; // 给付账户信息银行户名
                    vm.bonusBankAccountName = newValue; // 年金领取方式银行户名
                    vm.liBonusBankAccountName = newValue; // 红利领取方式银行户名
                    vm.renewalBankAccountName = newValue; // 续费账户信息银行户名

                    if (vm.nationality == '0156') {
                        vm.checkCusId = true;
                    }
                }
            });

            // 监听投保人证件类型变化
            $scope.$watch('policyInfo.certType', function(newValue) {
                if (newValue) {

                    // vm.checkCusId = true;

                    if (!vm.userData.cretNo && !vm.policyData.PbHoldId) {
                        vm.certNo = '';
                    }
                }
            });

            // 监听被保人证件类型变化
            $scope.$watch('policyInfo.insureCertType', function(newValue) {
                if (newValue) {
                    vm.insureCertNo = '';
                }
            });

            // 监听投保人证件号变化，如果为身份证，自动带出性别生日
            $scope.$watch('policyInfo.certNo', function(newValue) {
                if (newValue) {
                    if (vm.certType && vm.certType == 'A') {

                        // vm.checkCusId = true;

                        if (!VALIDATION.idCheck(newValue)) {
                            return;
                        }

                        vm.gender = VALIDATION.getSex(newValue) + '';
                        vm.genderDisabled = true;
                        vm.birthday = new Date(VALIDATION.getBirthday(newValue));
                        vm.birthdayDisabled = true;
                    }
                } else {
                    vm.genderDisabled = false;
                    vm.birthdayDisabled = false;
                }
            });

            // 监听被保人证件号变化，如果为身份证，自动带出性别生日
            $scope.$watch('policyInfo.insureCertNo', function(newValue) {
                if (newValue) {
                    if (vm.relation != '01' && vm.insureCertType && vm.insureCertType == 'A') {
                        if (!VALIDATION.idCheck(newValue)) {
                            return;
                        }

                        var newGender = VALIDATION.getSex(newValue) + '',
                            newBirthday = new Date(VALIDATION.getBirthday(newValue));

                        vm.insureGender = newGender;
                        vm.insureGenderDisabled = true;
                        vm.insureBirthday = newBirthday;
                        vm.insureBirthdayDisabled = true;
                    }
                } else {
                    vm.insureGenderDisabled = false;
                    vm.insureBirthdayDisabled = false;
                }
            });

            // 监听投保人证件有效期
            $scope.$watch('policyInfo.certExpireType', function(newValue) {
                if (newValue == 1) {
                    vm.certExpireDate = '2099-12-31';
                } else if (newValue == 2) {
                    vm.certExpireDate = vm.policyData.PbIdEndDate ? new Date(VALIDATION.dateFormat(vm.policyData.PbIdEndDate)) : '';
                }
            });

            // 监听被保人证件有效期
            $scope.$watch('policyInfo.insureCertExpireType', function(newValue) {
                if (newValue == 1) {
                    vm.insureCertExpireDate = '2099-12-31';
                } else if (newValue == 2) {
                    vm.insureCertExpireDate = vm.policyData.LiIdEndDate ? new Date(VALIDATION.dateFormat(vm.policyData.LiIdEndDate)) : '';
                }
            });

            // 监听投保人性别变化
            $scope.$watch('policyInfo.gender', function(newValue, oldValue) {
                if (newValue && newValue != oldValue) {
                    if (vm.relation == '01') {
                        vm.insureGender = newValue;
                    }
                }
            });

            // 监听被保人性别变化
            $scope.$watch('policyInfo.insureGender', function(newValue, oldValue) {
                if (newValue != oldValue) {
                    vm.insureGenderChanged = true;
                }
            });

            // 监听投保人生日变化
            $scope.$watch('policyInfo.birthday', function(newValue, oldValue) {
                if (newValue && newValue != oldValue) {
                    if (vm.relation == '01') {
                        vm.insureBirthday = newValue;
                    }
                }
            });

            // 监听被保人生日变化
            $scope.$watch('policyInfo.insureBirthday', function(newValue, oldValue) {
                if (newValue != oldValue) {
                    vm.insureBirthdayChanged = true;
                }
            });

            // 监听投被保人关系
            $scope.$watch('policyInfo.relation', function(newValue, oldValue) {
                if (newValue) {
                    if (newValue == '01') {
                        // 本人
                        vm.insureCertType = vm.certType;
                        vm.insureCertTypes = vm.certTypes;
                        vm.insureCertNo = vm.certNo;
                        vm.insureNationality = vm.nationality;
                        vm.insureNationalities = vm.nationalities;
                        vm.insureName = vm.name;
                        vm.insureCertExpireType = vm.certExpireType;
                        vm.insureCertExpireDate = vm.certExpireDate;
                        vm.insureGender = vm.gender;
                        vm.insureGenderDisabled = false;
                        vm.insureBirthday = vm.birthday;
                        vm.insureBirthdayDisabled = false;
                        vm.insureOccupation = vm.occupation;
                    } else {
                        // 非本人
                        if (oldValue == '01' || (vm.insureData && vm.insureData.birthday)) {
                            // 测算页面存在被保险人信息，优先于policyData回显
                            vm.insureBirthday = vm.insureData.birthday ? new Date(vm.insureData.birthday) : '';
                            vm.insureBirthdayDisabled = false;
                            vm.insureGender = vm.insureData.sex || '1';
                            vm.insureGenderDisabled = false;
                            vm.insureCertType = 'A';
                            vm.insureCertTypes = COMMON.getCertTypesByCode(vm.insureCertType);
                            vm.insureCertNo = '';
                            vm.insureNationality = '0156';
                            vm.insureNationalities = $rootScope.COMMON_DATA.NATIONALITIES;
                            vm.insureName = '';
                            vm.insureCertExpireType = '2';
                            vm.insureCertExpireDate = '';
                            vm.insureOccupation = 'C0000';
                        } else if (newValue == vm.policyData.PbHoldRcgnRela) {
                            // policyData回显
                            vm.insureCertType = vm.policyData.LiRcgnIdType;
                            vm.insureCertTypes = COMMON.getCertTypesByCode(vm.insureCertType);
                            vm.insureCertNo = vm.policyData.LiRcgnId;
                            vm.insureNationality = vm.policyData.LiNationality;
                            vm.insureNationalities = $rootScope.COMMON_DATA.NATIONALITIES;
                            vm.insureName = vm.policyData.LiRcgnName;
                            vm.insureCertExpireType = vm.policyData.insureCertExpireType;
                            vm.insureCertExpireDate = new Date(VALIDATION.dateFormat(vm.policyData.LiIdEndDate));
                            vm.insureGender = vm.policyData.LiRcgnSex;
                            vm.insureGenderDisabled = false;
                            vm.insureBirthday = new Date(VALIDATION.dateFormat(vm.policyData.LiRcgnBirdy));
                            vm.insureBirthdayDisabled = false;
                            vm.insureOccupation = vm.policyData.LiRcgnOccupCode;
                        }
                    }
                }

                if (vm.relation == '01') {
                    vm.checkInCusld = false;
                } else {
                    // console.log(vm.insureNationality);
                    if (vm.insureNationality && vm.insureNationality == '0156') {
                        vm.checkInCusld = true;
                    } else {
                        vm.checkInCusld = false;
                    }
                }
            });

        };
        /****** 事件监听结束 ******/

        // 信息校验
        vm.dataCheck = function() {
            // 投保人年龄校验
            var age = VALIDATION.getAgeByBirth(vm.birthday);
            if (age > vm.maxHolderAge || age < vm.minHolderAge) {
                TipService.showMsg('投保人年龄应该在' + vm.minHolderAge + '-' + vm.maxHolderAge + '周岁');
                return false;
            }

            var insureAge = vm.relation == '01' ? age : VALIDATION.getAgeByBirth(vm.insureBirthday);
            if (insureAge > vm.maxAge || insureAge < vm.minAge) {
                TipService.showMsg('被投保人年龄应该在' + vm.minAge + '-' + vm.maxAge + '周岁');
                return false;
            }

            // 当被保人生日性别与测算不一致时，需要重新计算保费
            if (vm.insureGenderChanged || vm.insureBirthdayChanged) {
                // if (confirm($rootScope.TIPS.PRODUCT.RECACULATE)) {
                if (vm.calc && vm.calcCtrl) {

                    if (vm.productData.templateCode == 'HMRA' || vm.productData.templateCode == 'TLD' || vm.productData.templateCode == 'BANO') {
                        angular.extend(vm.calcCtrl.user, {
                            sex: vm.insureGender,
                            birthday: vm.insureBirthday,
                            birthdayfm: $filter('date')(vm.insureBirthday, 'yyyyMMdd'),
                            payendyear: vm.insureData.payendyear
                        });
                    } else {
                        angular.extend(vm.calcCtrl.user, {
                            sex: vm.insureGender,
                            birthday: vm.insureBirthday,
                            payendyear: vm.insureData.payendyear
                        });
                    }

                    // angular.extend(vm.calcCtrl.user, {
                    //     sex: vm.insureGender,
                    //     birthday: vm.insureBirthday,
                    //     payendyear: vm.insureData.payendyear
                    // });



                    angular.extend(vm.calcCtrl.mainPlan, {
                        amount: vm.insureData.mainPlan.amount
                    });

                    // 重新计算保费
                    vm.calc(vm.calcCtrl, function(recalcData) {
                        if (recalcData) {
                            // 重置被保人生日性别变化的状态（当回调有效时再更改）
                            vm.insureGenderChanged = false;
                            vm.insureBirthdayChanged = false;

                            // 重置总保费
                            // if (recalcData.exp) {
                            //     // 如果保费发生变化，给予提示
                            //     if (vm.insureData.PbInsuExp != recalcData.exp) {
                            //         vm.insureData.PbInsuExp = recalcData.exp;
                            //         TipService.showMsg($rootScope.TIPS.PRODUCT.RECACULATED + '<span class="fs20 orange">' + recalcData.exp + '</span>元');
                            //     } else {
                            //         vm.next();
                            //     }
                            // }
                            if (recalcData.exp) {
                                // 如果保费发生变化，给予提示
                                if (vm.insureData.PbInsuExp != recalcData.exp) {
                                    vm.insureData.PbInsuExp = recalcData.exp;
                                    TipService.showMsg($rootScope.TIPS.PRODUCT.RECACULATED + '<span class="fs20 orange">' + recalcData.exp + '</span>元');
                                } else if (vm.insureData.PbInsuAmt != recalcData.mainPlan.amount) {
                                    vm.insureData.PbInsuAmt = recalcData.mainPlan.amount;
                                    TipService.showMsg($rootScope.TIPS.PRODUCT.RECACULATED_AMOUNT + '<span class="fs20 orange">' + recalcData.mainPlan.amount + '</span>元');
                                } else {
                                    vm.next();
                                }
                            }
                            // 重置总保额
                            if (recalcData.amount) {
                                vm.insureData.PbInsuAmt = recalcData.amount;
                            }


                            // if (recalcData.mainPlan.amount) {
                            //     // vm.insureData.PbInsuAmt = recalcData.amount;
                            //     if (vm.productData.templateCode == "BANO") {
                            //         if (vm.insureData.PbInsuAmt != recalcData.mainPlan.amount) {
                            //             vm.insureData.PbInsuAmt = recalcData.mainPlan.amount;
                            //             TipService.showMsg($rootScope.TIPS.PRODUCT.RECACULATED_AMOUNT + '<span class="fs20 orange">' + recalcData.mainPlan.amount + '</span>元');
                            //         } else {
                            //             vm.next();
                            //         }
                            //     }else{
                            //         vm.insureData.PbInsuAmt = recalcData.amount;
                            //     }
                            // }

                            // 重置主险信息
                            if (recalcData.mainPlan) {
                                vm.insureData.mainPlan = recalcData.mainPlan;
                            }
                            // 重置附加险信息
                            if (recalcData.addPlan) {
                                vm.insureData.addPlan = recalcData.addPlan;
                            }
                        }
                    });
                } else {
                    // 重置被保人生日性别变化的状态
                    vm.insureGenderChanged = false;
                    vm.insureBirthdayChanged = false;

                    vm.next();
                }
                // }
                return false;
            }

            return true;
        };

        // 下一步
        vm.next = function() {
            
            if (!vm.dataCheck()) {
                return;
            }

            // 数据处理
            PolicyService.control({
                state: 'product-purchase-policy-info',
                control: 'data',
                data: {
                    PbHoldName: vm.name,
                    PbHoldSex: vm.gender,
                    PbHoldBirdy: $filter('date')(vm.birthday, 'yyyyMMdd'),
                    PbHoldIdType: vm.certType,
                    PbHoldId: vm.certType == 'A' ? vm.certNo.toUpperCase() : vm.certNo,
                    PbIdStartDate: vm.certStartDate, // 投保人证件生效日期
                    PbIdEndDate: $filter('date')(vm.certExpireDate, 'yyyyMMdd'), // 投保人证件失效日期
                    PbNationality: vm.nationality,
                    PbHoldOfficTele: '', // 投保人单位联系电话
                    PbHoldHomeTele: vm.phone, // 投保人家庭联系电话，暂用手机号
                    PbHoldMobl: vm.phone, // 投保人联系电话
                    PbHoldEmail: vm.email, // 投保人邮箱
                    PbHoldOccupCode: vm.occupation || '', // 投保人职业代码/工种 预留，目前送空值见代码表 默认A
                    confirmRela: vm.relation, // 确认页面投被保人关系
                    PbHoldRcgnRela: vm.checkRelation(vm.relation, vm.gender), // 投被保人关系
                    LiRcgnName: vm.relation == '01' ? vm.name : vm.insureName,
                    LiRcgnSex: vm.relation == '01' ? vm.gender : vm.insureGender,
                    LiRcgnBirdy: $filter('date')(vm.relation == '01' ? vm.birthday : vm.insureBirthday, 'yyyyMMdd'),
                    LiRcgnIdType: vm.relation == '01' ? vm.certType : vm.insureCertType,
                    LiRcgnId: vm.relation == '01' ? (vm.certType == 'A' ? vm.certNo.toUpperCase() : vm.certNo) : (vm.insureCertType == 'A' ? vm.insureCertNo.toUpperCase() : vm.insureCertNo),
                    LiIdStartDate: '', // 被保人证件生效日期
                    LiIdEndDate: $filter('date')(vm.relation == '01' ? vm.certExpireDate : vm.insureCertExpireDate, 'yyyyMMdd'), // 被保人证件失效日期 20991231表示长期有效
                    LiNationality: vm.relation == '01' ? vm.nationality : vm.insureNationality,
                    LiRcgnTele: '', //被保人家庭电话
                    LiRcgnMobl: vm.phone, // 被保人手机号码
                    LiRcgnEmail: vm.email, // 被保人邮箱
                    LiRcgnOccupCode: vm.relation == '01' ? vm.occupation : vm.insureOccupation, // 被保人职业工种
                    BankName: vm.name, // 续期缴费用户
                    minAge: vm.minAge,
                    maxAge: vm.maxAge,
                    minHolderAge: vm.minHolderAge,
                    maxHolderAge: vm.maxHolderAge,
                    certExpireType: vm.certExpireType, // 投保人证件有效期
                    insureCertExpireType: vm.insureCertExpireType // 被保人证件有效期
                }
            });
            PolicyService.setSessionData({
                insureData: {
                    PbInsuExp: vm.insureData.PbInsuExp,
                    PbInsuAmt: vm.insureData.PbInsuAmt,
                    mainPlan: vm.insureData.mainPlan,
                    addPlan: vm.insureData.addPlan,
                    birthday: vm.insureBirthday,
                    sex: vm.insureGender
                }
            });
            // 流程跳转
            PolicyService.control({
                state: 'product-purchase-policy-info',
                control: 'process'
            });
        };


        // 图形验证码
        vm.random = Date.parse(new Date()) + Math.random(8);
        vm.imgpath = CONFIG.SERVICE_ADDRESS + 'new/ImgVerifyCode?random=' + vm.random;
        vm.getimg = function() {
            vm.random = Date.parse(new Date()) + Math.random(8);
            vm.imgpath = CONFIG.SERVICE_ADDRESS + 'new/ImgVerifyCode?random=' + vm.random;
        };

        // 监听图形验证码返回结果
        var rootScope = $rootScope;
        rootScope.$on('send-result', function(erent, data) {
            var flag = data.result;
            if (!flag) {
                vm.getimg();
            }
        });

        vm.checkCretNo = function(invalid) {
            if (invalid) {
                TipService.showMsg($rootScope.TIPS.COMMON.REQUIRED);
                return;
            }
            var params = '';
            if (vm.relation == '01' && vm.nationality == '0156') {
                params = {
                    cusInfoList: [{
                        insureType: vm.certType,
                        cretNo: vm.certNo,
                        name: vm.name
                    }],
                    imageCode: vm.code,
                    random: vm.random,
                    mobileNo: vm.phone
                }
            } else if (vm.relation != '01' && vm.insureNationality != '0156' && vm.nationality == '0156') {
                params = {
                    cusInfoList: [{
                        insureType: vm.certType,
                        cretNo: vm.certNo,
                        name: vm.name
                    }],
                    imageCode: vm.code,
                    random: vm.random,
                    mobileNo: vm.phone
                }
            } else if (vm.relation != '01' && vm.insureNationality == '0156' && vm.nationality != '0156') {
                params = {
                    cusInfoList: [{
                        insureType: vm.insureCertType,
                        cretNo: vm.insureCertNo,
                        name: vm.insureName
                    }],
                    imageCode: vm.code,
                    random: vm.random,
                    mobileNo: vm.phone
                };
            } else if (vm.relation != '01' && vm.insureNationality == '0156' && vm.nationality == '0156') {
                params = {
                    cusInfoList: [{
                        insureType: vm.certType,
                        cretNo: vm.certNo,
                        name: vm.name
                    }, {
                        insureType: vm.insureCertType,
                        cretNo: vm.insureCertNo,
                        name: vm.insureName
                    }],
                    imageCode: vm.code,
                    random: vm.random,
                    mobileNo: vm.phone
                };
            }

            // var params = {
            //     cusInfoList: [{
            //         insureType: vm.certType,
            //         cretNo: vm.certNo,
            //         name: vm.name
            //     }],
            //     imageCode: vm.code,
            //     random: vm.random
            // }
            // CommonRequest.request(params, CONFIG.CHECK_CUSIDENTITY_SERVICE, function(result) {
            //     if (result.status == '1') {
            //         if (result.data.checkStatus == '1') {
            //             // vm.checkCusId = false;
            //             vm.checkCusId = false;
            //             vm.checkInCusId = false;
            //             vm.next();
            //         }
            //     } else {
            //         vm.getimg();
            //         vm.code = '';
            //     }
            // });
            if ((vm.checkCusId || vm.checkInCusld) && vm.productData.basicProfile.P002 == 'Y') {
                CommonRequest.request(params, CONFIG.CHECK_CUSIDENTITY_SERVICE, function(result) {
                    if (result.status == '1') {
                        if (result.data.checkStatus == '1') {
                            // vm.checkCusId = false;
                            vm.checkCusId = false;
                            vm.checkInCusId = false;
                            vm.next();
                        }
                    } else {
                        vm.getimg();
                        vm.code = '';
                    }
                });
            } else {
                vm.next();
            }
        };

        /****** 初始化 ******/
        vm.watch();
        vm.init();
        /****** 初始化结束 ******/
    }
})();