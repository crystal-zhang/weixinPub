(function() {
    'use strict';

    angular
        .module('app')
        .controller('TransferController', TransferController);

    TransferController.$inject = ['$rootScope', '$location', 'CONFIG', '$scope', 'TipService', 'PolicyService', 'COMMON'];
    /** @ngInject */
    function TransferController($rootScope, $location, CONFIG, $scope, TipService, PolicyService, COMMON) {
        var vm = this;

        var sessionData = PolicyService.getSessionData();

        var policydata = sessionData.policyData;

        PolicyService.control({
            state: 'transfer',
            control: 'data',
            data: {
                transferShown: true
            }
        });

        // 关闭弹框
        $scope.cancel = function() {
            COMMON.hideModal();
        };

        // 支付银行列表, 1代表公司收款
        var BkBrchNo = policydata.BkBrchNo;
        COMMON.getCommonBank(BkBrchNo, '1', function(bankList) {
            $scope.bankList = bankList;
            if ($scope.bankList && $scope.bankList.length > 0) {
                $scope.newGet.newGetBk = $scope.bankList[0]; // 授权转帐银行
            }
        });

        $scope.newGet = {};
        $scope.newGet.newPayMode = '7';
        $scope.newGet.newGetAccName = policydata.PbHoldName;
        $scope.newGet.newGetAccCode = '';

        // 提交授权转账信息
        $scope.submit = function() {
            var params = {
                NewPayMode: $scope.newGet.newPayMode || '7', // 首期收费方式 
                NewGetAccName: $scope.newGet.newGetAccName, //首期缴费账号名称
                NewGetBkCode: $scope.newGet.newGetBk.bankCode, //首期缴费银行编码
                NewGetAccCode: $scope.newGet.newGetAccCode, //首期缴费账号
                NewGetBkName: $scope.newGet.newGetBk.bankName, // 首期缴费银行名称
            };

            params = angular.extend(policydata, params);

            PolicyService.control({
                state: 'transfer',
                control: 'data',
                data: angular.extend(params, {
                    isTransferred: true
                })
            });

            PolicyService.checkPolicy(params);
        };
    }

})();