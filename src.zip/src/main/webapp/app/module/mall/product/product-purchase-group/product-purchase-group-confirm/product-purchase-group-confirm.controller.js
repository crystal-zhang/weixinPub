(function() {
    'use strict';

    angular
        .module('app')
        .controller('ProPurchaseGroupConfirmController', ProPurchaseGroupConfirmController);

    ProPurchaseGroupConfirmController.$inject = ['$state', '$rootScope', 'GroupPolicyService', 'CommonRequest', 'CONFIG', 'TipService', 'COMMON', '$ionicPopup','$filter'];

    /** @ngInject */
    function ProPurchaseGroupConfirmController($state, $rootScope, GroupPolicyService, CommonRequest, CONFIG, TipService, COMMON, $ionicPopup,$filter) {
        var vm = this;
        
        var sessionData = GroupPolicyService.getSessionData();
        
       	 // 所选产品信息
        vm.productData = sessionData.productData;
        vm.insureData = sessionData.insureData;
        vm.policyData = sessionData.policyData;
        vm.materials = vm.productData.materials;
        vm.plans = vm.insureData.plans;
        if (!vm.productData) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }
        
        //提交
        vm.submit = function() {
            var params = {
                orderCode: vm.policyData.orderCode
            };
            CommonRequest.request(params, CONFIG.POLICY_INFO_CONFIRM, function(result) {
                if (result.status == 1) {
                    if ($rootScope.isLogin != 1 && !$rootScope.HLIFE && CONFIG.wxSwitch) {
                        var alertPopup = $ionicPopup.confirm({
                            title: '温馨提示',
                            template: '是否需要将您的投保信息绑定至此微信账号？',
                            okText: '需要',
                            cancelText: '取消'
                        });
                        alertPopup.then(function(res) {
                            if (res) {
                                COMMON.showModal('app/module/mall/product/auto-bind/auto-bind.html');
                            }
                        }).then(function(res) {
                            // 流程跳转
                            GroupPolicyService.control({
                                state: 'product-purchase-group-confirm',
                                control: 'process'
                            });
                        });
                    } else {
                        // 流程跳转
                        GroupPolicyService.control({
                            state: 'product-purchase-group-confirm',
                            control: 'process'
                        });
                    }
                } else {
                    var error = result.error;
                    TipService.showMsg(error.message);
                    $state.go('tab.mall');
                }
            });
        };

        // if (!vm.productData) {
        //     // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
        //     $state.go('tab.mall');
        //     return;
        // }

        
    }
})();