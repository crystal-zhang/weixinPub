(function() {
    'use strict';

    angular
        .module('app')
        .controller('IpamController', IpamController);

    IpamController.$inject = ['$state', 'CONFIG', 'CommonRequest', 'VALIDATION', '$scope', 'PolicyService', 'TipService', '$filter', '$rootScope', '$ionicLoading', '$timeout'];
    /** @ngInject */
    function IpamController($state, CONFIG, CommonRequest, VALIDATION, $scope, PolicyService, TipService, $filter, $rootScope, $ionicLoading, $timeout) {
        var vm = this;

        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        vm.productData = sessionData.productData;
        // 非法操作：1. 未获取产品数据 2. 要求做而未做手机验证
        if (!vm.productData || (sessionData.loginStatus != 2 && vm.productData.basicProfile['P005'] == 'Y' && !vm.productData.phoneValid)) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        // 用户选择的数据
        vm.user = {};
        vm.user.sex = '';
        vm.user.birthday = null;
        // vm.startDateDisabled = false;
        vm.securityDays = 1;
        vm.startDate = new Date();
        vm.giveTokenHaveGivedays = false;
        vm.giveTokenHaveStartTime = false;
        vm.giveTokenHavePlan = false;
        vm.ifGiveToken = false;

        vm.plans = vm.productData.plans[0];

        // 用户选择的数据
        // vm.user = {};
        // vm.user.sex = '';
        // vm.user.birthday = null;
        // vm.startDateDisabled = false;
        // vm.endDateDisabled = false;
        // vm.insuredDaysDisabled = false;
        // vm.giveCanNotChoseTime = false;
        // vm.securityDays = 1;
        // vm.choseEndTime = true;
        // vm.giveTokenHaveGivedaysAndStartTime = false;
        // vm.giveTokenHaveStartTimeAndEndTime = false;



        // 投被保人年龄
        var payTypeConfigs = vm.productData.payTypeConfigs;
        if (payTypeConfigs && payTypeConfigs.length > 0) {
            var payTypeConfig = payTypeConfigs[0];
            vm.minAge = payTypeConfig.min_app_age;
            vm.maxAge = payTypeConfig.max_app_age;
            vm.minHolderAge = payTypeConfig.minHolderAge;
            vm.maxHolderAge = payTypeConfig.maxHolderAge;
            vm.minStartDate = VALIDATION.getDateByAge(vm.maxAge); // 年龄最小开始日期
            vm.maxEndDate = VALIDATION.getDateByAge(vm.minAge); // 年龄最大结束日期
            vm.holderStartDate = VALIDATION.getDateByAge(vm.maxHolderAge); // 投保人年龄最小开始日期
            vm.holderEndDate = VALIDATION.getDateByAge(vm.minHolderAge); // 投保人年龄最大结束日期
        }

        // 日期选择回调
        vm.startCallback = function(val) {
            if (val) {
                vm.startDate = val;
            }
        };

        // 保险生效日期
        var nowDate = new Date();
        // 如果产品是预售，起始时间为计划转销售时间
        // if (vm.productData.prdSaleCode == 2 && vm.productData.planSaleTime) {
        //     var planSaleTime = vm.productData.planSaleTime;
        //     planSaleTime = planSaleTime.substr(0, 4) + '-' + planSaleTime.substr(4, 2) + '-' + planSaleTime.substr(6, 2);
        //     planSaleTime = new Date(planSaleTime);
        //     if (planSaleTime.getTime() > nowDate.getTime()) {
        //         vm.minDate = planSaleTime;
        //         vm.startDate = planSaleTime;
        //     }
        // }
        // // 保险生效日期最小最大范围，不大于当前日期+1年
        // vm.minDate = nowDate;
        // vm.startDate = vm.minDate;
        // vm.maxDate = new Date(new Date().setFullYear(new Date().getFullYear() + 1));
        // console.log("vm.maxDate --- " + vm.maxDate.toLocaleDateString());

        var nextDayFlag = 21;
        var nextDay = nowDate.getTime() + 1 * 24 * 60 * 60 * 1000;
        if (nowDate.getHours() >= nextDayFlag) {
            vm.minDate = new Date(nextDay);
            vm.maxDate = new Date(VALIDATION.addMounth(3, new Date(nextDay)));
        } else {
            vm.minDate = new Date(nowDate);
            vm.maxDate = new Date(VALIDATION.addMounth(3, new Date(nowDate)));
        }
        // 默认生效日期为最小日期
        vm.startDate = vm.minDate;


        // 缴费方式
        vm.paymentType = vm.productData.payment_type;
        // 缴费期间
        vm.payAge = vm.productData.pay_age;


        //保险期间拼装方法
        var getInsuYearLable = function(insuYear, insuYearFlag){
            if(insuYearFlag == "Y"){
                return insuYear+"年";
            } else if(insuYearFlag == "M"){
                return insuYear+"个月";
            } else if(insuYearFlag == "D"){
                return insuYear+"天";
            } else if(insuYearFlag == "A"){
                return "至"+insuYear+"周岁";
            } 
        }

        // 初始化主险数据
        vm.mainPlan = {
            rate: 0,
            amount: 0,
            exp: 0
        };


        // 补贴类责任，金额单位为 元/日
        var getMoneyUnit = function(ilName){
            if (ilName.indexOf("住院") != -1) {
                return "元/天";
            }else{
                return "元";
            }
        }

        // 排序，按责任code升序排列
        var compare = function(obj1, obj2){
            var val1 = obj1.ilCode;
            var val2 = obj2.ilCode;

            if (val1 < val2) {
                return -1;
            }else if (val1 > val2) {
                return 1;
            }else{
                return 0;
            }
        }

        // 处理保险责任显示表格
        var watchSelectedPlans = function(){

            // 初始化用于页面组装和显示的数组，不会污染原始保险责任数据
            var margeDutys = [];
            vm.selectedPlansForMarge = vm.selectedPlans;
            for(var i =0;i< vm.selectedPlansForMarge.dutys.length;i++){
                var duty = vm.selectedPlansForMarge.dutys[i];
                margeDutys.push({
                        ilCode: vm.selectedPlansForMarge.dutys[i].ilCode,
                        ilName: vm.selectedPlansForMarge.dutys[i].ilName,
                        insuredAmount: vm.selectedPlansForMarge.dutys[i].insuredAmount == 10000 ? vm.selectedPlansForMarge.dutys[i].insuredAmount / 10000 * vm.selectedPlansForMarge.dutys[i].maxSaleQuantity + "万" + getMoneyUnit(vm.selectedPlansForMarge.dutys[i].ilName) : vm.selectedPlansForMarge.dutys[i].insuredAmount * vm.selectedPlansForMarge.dutys[i].maxSaleQuantity + getMoneyUnit(vm.selectedPlansForMarge.dutys[i].ilName)
                    });
            }

            // console.log(vm.selectedPlansForMarge);
            vm.selectedPlansForShow = [];
            // 排序计划内责任
            vm.selectedPlansForMarge.dutys.sort(compare);

            // 第三步，合并责任列表
            vm.selectedPlansForShow.dutys = margeDutys;

            // 存入主险，供确认信息页面显示
            vm.mainPlan.dutysForShow = vm.selectedPlansForShow.dutys;
           
        };


        // 赠险相关
        if (vm.productData.token) {
            vm.ifGiveToken = true;
            var giveMargeDutys = [];
            vm.giveCanNotChoseTime = true;
            PolicyService.getCardInfo(vm.productData.token, function(data) {
                // console.log(data);
                if (data) {

                    vm.giveTokenInfo = data;
                    // console.log(vm.giveTokenInfo);
                    // vm.giveTokenInfo = data;
                    // var planId, // 该产品的计划id 
                    //     duties = data.prmLotDutySetModels; // 计划的责任数组
                    // if (duties && duties.length > 0) {
                    //     planId = duties[0].planId;
                    // }
                    // console.log(vm.giveTokenInfo.prmLotDutySetModels);
                    for(var i = 0;i < vm.giveTokenInfo.prmLotDutySetModels.length;i++){
                        var newDuty = vm.giveTokenInfo.prmLotDutySetModels[i];
                        // console.log(newDuty);
                        for(var j = 0;j < vm.productData.plans[0].dutys.length;j++){
                            var oldDuty = vm.productData.plans[0].dutys[j];
                            if(newDuty.ilCode == oldDuty.ilCode){
                                // console.log(newDuty.ilName);
                                giveMargeDutys.push({
                                    ilCode: oldDuty.ilCode,
                                    ilName: oldDuty.ilName,
                                    insuredAmount: oldDuty.insuredAmount == 10000 ? oldDuty.insuredAmount / 10000 * oldDuty.maxSaleQuantity + "万" + getMoneyUnit(oldDuty.ilName) : oldDuty.insuredAmount * oldDuty.maxSaleQuantity + getMoneyUnit(oldDuty.ilName)
                                });
                            }
                        }
                            // console.log(oldDuty);
                    }

                    if (vm.giveTokenInfo.donationMethodName == "固定保障期间") {
                        vm.securityDays = vm.giveTokenInfo.giveDay;
                        // vm.endDate = new Date(vm.startDate.getTime() + vm.giveTokenInfo.giveDay*24*60*60*1000);
                        vm.choseSecurityDays = false;
                        // vm.choseEndTime = false;
                        if (vm.giveTokenInfo.giveStartTime) {
                            vm.giveTokenHaveGivedaysAndStartTime = true;
                            vm.choseStartTime = false;
                            vm.startDate = new Date(vm.giveTokenInfo.giveStartTime);
                        }else{
                            vm.giveTokenHaveGivedays = true;
                            vm.choseStartTime = true;
                        }

                    }
                    if (vm.giveTokenInfo.donationMethodName == "指定保障生效和终止日期") {
                        vm.giveTokenHaveStartTimeAndEndTime = true;
                        // vm.choseEndTime = false;
                        vm.choseSecurityDays = false;
                        vm.choseStartTime = false;
                        vm.startDate = new Date(vm.giveTokenInfo.giveStartTime);
                        // vm.endDate = new Date(vm.giveTokenInfo.giveEndTime);
                        // vm.securityDays = parseInt((vm.endDate.getTime() - vm.startDate.getTime() - 100) / (24 * 60 * 60 * 1000)) + 1;
                        // console.log(vm.securityDays);
                        // vm.mainPlan.insuYear = vm.securityDays;
                        // vm.securityDaysForShow = vm.securityDays + " 天";
                        // console.log(vm.startDate);
                        // console.log(vm.endDate);
                        // console.log(vm.securityDays);
                        // console.log(vm.securityDaysForShow);
                    }
                    if (vm.giveTokenInfo.donationMethodName == "按保障计划赠送") {
                        vm.choseEndTime = true;
                        vm.choseEndTime = true;
                        if (vm.giveTokenInfo.giveStartTime) {
                            vm.giveTokenHaveStartTime = true;
                            vm.choseStartTime = false;
                            vm.startDate = new Date(vm.giveTokenInfo.giveStartTime);
                        }else{
                            vm.giveTokenHavePlan = true;
                            vm.choseStartTime = true;
                        }
                    }
                    // console.log(vm.securityDays);
                    // console.log(giveMargeDutys);
                    // if (vm.productData.plans && vm.productData.plans.length > 0) {
                        // for (var i = 0; i < vm.productData.plans.length; i++) {
                        //     var productPlan = vm.productData.plans[i];
                        //     var tempDuties = [];
                        //     if (planId == productPlan.planId) {
                        //         var dutiesLength = duties.length,
                        //             productDutiesLength = productPlan.dutys.length;
                        //         for (var m = 0; m < dutiesLength; m++) {
                        //             var ilId = duties[m].ilId;
                        //             for (var n = 0; n < productDutiesLength; n++) {
                        //                 if (ilId == productPlan.dutys[n].dutyId) {
                        //                     tempDuties.push(productPlan.dutys[m]);
                        //                     continue;
                        //                 }
                        //             }
                        //         }
                        //         vm.productData.plans[i].dutys = tempDuties;
                        //         break;
                        //     }
                        // }

                        // // 若赠险指定生效日期，则不可更改
                        // if (data.giveStartTime) {
                        //     vm.startDate = new Date(data.giveStartTime);
                        //     vm.startDateDisabled = true;
                        // }
                        // // 若赠险指定结束日期，则不可更改
                        // if (data.giveEndTime) {
                        //     vm.endDate = new Date(data.giveEndTime);
                        //     vm.endDateDisabled = true;
                        // }
                        // // 若赠险指定保障期间，则固定险种保障期间
                        // if (data.giveDay) {
                        //     vm.securityDays = data.giveDay;
                        //     vm.insuredDaysDisabled = true;
                        //     // 计算当前生效日+指定保障期间后的日期
                            
                        // }


                        // 初始化保险计划
                        vm.selectedPlans = vm.productData.plans[0];
                        
                        // watchSelectedPlans();
                        vm.selectedPlansForShow = [];
                        vm.selectedPlansForShow.dutys = giveMargeDutys;
                        vm.mainPlan.dutysForShow = vm.selectedPlansForShow.dutys;
                        angular.extend(vm.mainPlan, vm.selectedPlans);
                        // 保障期间
                        vm.selectedPlans.securityAge = getInsuYearLable(vm.selectedPlans.insuYear, vm.selectedPlans.insuYearFlag);
                        // 记录用户选择的保险计划ID
                        vm.user.selectedPlanId = vm.selectedPlans.planId;
                        // console.log(vm.selectedPlans);
                    }
                // }
            });
        } else {
            vm.ifGiveToken = false;
            // 初始化保险计划
            vm.selectedPlans = vm.productData.plans[0];
            watchSelectedPlans();
            angular.extend(vm.mainPlan, vm.selectedPlans);
            // 保障期间
            vm.selectedPlans.securityAge = getInsuYearLable(vm.selectedPlans.insuYear, vm.selectedPlans.insuYearFlag);
            // 记录用户选择的保险计划ID
            vm.user.selectedPlanId = vm.selectedPlans.planId;
            vm.giveCanNotChoseTime = false;
        }

        // // 赠险相关
        // if (vm.productData.token) {
        //     PolicyService.getCardInfo(vm.productData.token, function(data) {
        //         // console.log(data);
        //         if (data) {
        //             vm.giveInsurement = data;
        //             var planId, // 该产品的计划id 
        //                 duties = data.prmLotDutySetModels; // 计划的责任数组
        //             if (duties && duties.length > 0) {
        //                 planId = duties[0].planId;
        //             }
        //             if (vm.productData.plans && vm.productData.plans.length > 0) {
        //                 for (var i = 0; i < vm.productData.plans.length; i++) {
        //                     var productPlan = vm.productData.plans[i];
        //                     var tempDuties = [];
        //                     if (planId == productPlan.planId) {
        //                         var dutiesLength = duties.length,
        //                             productDutiesLength = productPlan.dutys.length;
        //                         for (var m = 0; m < dutiesLength; m++) {
        //                             var ilId = duties[m].ilId;
        //                             for (var n = 0; n < productDutiesLength; n++) {
        //                                 if (ilId == productPlan.dutys[n].dutyId) {
        //                                     tempDuties.push(productPlan.dutys[m]);
        //                                     continue;
        //                                 }
        //                             }
        //                         }
        //                         vm.productData.plans[i].dutys = tempDuties; //vm.productData.plans = 
        //                         break;
        //                     }
        //                 }

        //                 // 若赠险指定生效日期，则不可更改
        //                 if (data.giveStartTime) {
        //                     vm.startDate = new Date(data.giveStartTime);
        //                     vm.startDateDisabled = true;
        //                 }
        //                 // 初始化保险计划
        //                 vm.selectedPlans = vm.productData.plans[0];
        //                 watchSelectedPlans();
        //                 angular.extend(vm.mainPlan, vm.selectedPlans);
        //                 // 保障期间
        //                 vm.selectedPlans.securityAge = getInsuYearLable(vm.selectedPlans.insuYear, vm.selectedPlans.insuYearFlag);
        //                 // 记录用户选择的保险计划ID
        //                 vm.user.selectedPlanId = vm.selectedPlans.planId;
        //                 // console.log(vm.selectedPlans);
        //             }
        //         }
        //     });
        // } else {
        //     // 初始化保险计划
        //     vm.selectedPlans = vm.productData.plans[0];
        //     watchSelectedPlans();
        //     angular.extend(vm.mainPlan, vm.selectedPlans);
        //     // 保障期间
        //     vm.selectedPlans.securityAge = getInsuYearLable(vm.selectedPlans.insuYear, vm.selectedPlans.insuYearFlag);
        //     // 记录用户选择的保险计划ID
        //     vm.user.selectedPlanId = vm.selectedPlans.planId;
        // }
        // 初始化保险计划
        // vm.selectedPlans = vm.productData.plans[0];
        // watchSelectedPlans();
        // angular.extend(vm.mainPlan, vm.selectedPlans);
        // 保障期间
        // vm.selectedPlans.securityAge = getInsuYearLable(vm.selectedPlans.insuYear, vm.selectedPlans.insuYearFlag);
        // 记录用户选择的保险计划ID
        // vm.user.selectedPlanId = vm.selectedPlans.planId;


        // 监听获取用户选择的保险生效日期
        $scope.$watch('ipam.startDate', function(newValue) {
            // console.log("***watch --- startTime: " + newValue);
            if(newValue){
                vm.calc(vm);
            }
        }, true);


        // console.log(vm.productData.plans[0].insuYearFlag);
        // console.log(vm.productData.plans[0].insuYear);
        // console.log(vm.productData.plans[0].planCode);
        // 保费计算方法
        vm.calc = function(vm) {
            // 发起计算保费请求
            var calcParams = {
                prdCode: vm.productData.prd_code,
                prdName: vm.productData.prd_title,
                insuredDays: vm.plans.insuYear, //单位默认为 D
                insuYearFlag: vm.plans.insuYearFlag,
                planCode: vm.plans.planCode,
                channel: CONFIG.SALE_CHANNEL
            };
            // console.log(calcParams);
            CommonRequest.request(calcParams, CONFIG.PRODUCT_GETEXPFROMCORE_CALCULATE_SERVICE, function(result) {
                // console.log(result);
                if (result.status == 1) {
                    if (result.data.premiumResult) {
                        var data = result.data;
                        // 直接获取到保费结果
                        var amountExpStr = data.premiumResult;
                        // vm.mainPlan.exp = data.premiumResult;
                        var amountExp = amountExpStr.split(':');
                        vm.mainPlan.exp = amountExp[0];
                        vm.mainPlan.amount = amountExp[1];
                        // vm.mainPlan.exp = result.data.premiumResult;
                        // vm.mainPlan.amount = result.data.mainAmount;
                    }
                    if (result.data.redisKey) {
                        // 核心未给出结果，需要再次查询
                        vm.redisKey = result.data.redisKey;
                        // 解耦间隔时间timeout后,再次执行查询
                        $timeout(function() {
                            checkPremium();
                        }, CONFIG.CALCEXP_DECOUPLING_DURATION);
                    }
                } 
            });

            // ajax轮循 查询保费计算结果
            var checkPremiumNum = 0;
            var checkPremium = function() {
                // 累计轮循次数
                checkPremiumNum++;

                // 查询次数是否已经超过核心解耦间隔次数
                if (checkPremiumNum > CONFIG.CALCEXP_DECOUPLING_TIMES) {
                    $ionicLoading.hide();
                    // 提示消息
                    TipService.showMsg($rootScope.TIPS.PRODUCT.GETEXPFROMCORE_CALCULATE_FAILED);
                    // 查询次数重置为0
                    checkPremiumNum = 0;
                    return;
                }

                // 发起保费结果查询请求
                var checkPremiumParams = {
                    redisKey: vm.redisKey
                };
                CommonRequest.request(checkPremiumParams, CONFIG.PRODUCT_GETEXPFROMREDIS_CALCULATE_SERVICE, function(result) {
                    // console.log(result);
                    if (result.status == 1) {
                        if (result.data.premiumResult) {
                            // 得到结果，隐藏loading
                            $ionicLoading.hide();
                            var data = result.data;
                            // 得到结果
                            var amountExpStr = data.premiumResult;
                            // vm.mainPlan.exp = data.premiumResult;
                            var amountExp = amountExpStr.split(':');
                            vm.mainPlan.exp = amountExp[0];
                            vm.mainPlan.amount = amountExp[1];

                            // vm.mainPlan.exp = result.data.premiumResult;
                            // vm.mainPlan.amount = result.data.mainAmount;

                            // 查询次数重置为0
                            checkPremiumNum = 0;
                        }
                        if (result.data.redisKey) {
                            // 核心未给出结果，需要再次查询
                            vm.redisKey = result.data.redisKey;

                            // 解耦间隔时间timeout后,再次执行查询
                            $timeout(function() {
                                checkPremium();
                            }, CONFIG.CALCEXP_DECOUPLING_DURATION);
                        }
                    } else {
                        // 出现异常，隐藏loading
                        $ionicLoading.hide();
                        // 查询次数重置为0
                        checkPremiumNum = 0;
                        TipService.showMsg($rootScope.TIPS.PRODUCT.GETEXPFROMCORE_CALCULATE_FAILED);
                        return;
                    }
                });
            }
        };



        // 保险保障期间止期 计算方法
        var calcDate = function(){
            if (vm.startDate && vm.selectedPlans.insuYear && vm.selectedPlans.insuYearFlag) {
                // console.log("vm.startDate ----- " + vm.startDate + ";vm.selectedPlans.insuYear ----- " + vm.selectedPlans.insuYear + ";vm.selectedPlans.insuYearFlag ----- " + vm.selectedPlans.insuYearFlag);
                var endTime = new Date(vm.startDate);
                if ("M" == vm.selectedPlans.insuYearFlag) {
                    endTime.setMonth(vm.startDate.getMonth() + Number(vm.selectedPlans.insuYear));
                } else if ("D" == vm.selectedPlans.insuYearFlag) {
                    endTime.setDate(vm.startDate.getDate() + Number(vm.selectedPlans.insuYear));
                } else if ("Y" == vm.selectedPlans.insuYearFlag) {
                    endTime.setFullYear(vm.startDate.getFullYear() + Number(vm.selectedPlans.insuYear));
                }
                // console.log("vm.startDate ----- " + vm.startDate);
                // console.log("endTime ----- " + new Date(endTime));
                return $filter('date')(endTime, 'yyyyMMdd');
            }
        }

        // 跳转投保页面
        vm.goPolicy = function() {
            // 计算保险保障期间止期,并处理为'yyyyMMdd'
            vm.cvrInsDt = calcDate();
            // console.log(vm.cvrInsDt);

            var params = {
                prdId: vm.productData.prd_id,
                sex: vm.user.sex,
                insurerBirthDay: $filter('date')(vm.user.birthday, 'yyyyMMdd'),
                planId: vm.selectedPlans.planId,
                premiumResult: vm.mainPlan.exp,
                orderCode: vm.productData.orderCode || ''
            };
            PolicyService.doCalc(params, function() {
                // 数据处理
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'data',
                    data: {
                        // birthday: vm.user.birthday, // 被保人生日
                        // sex: vm.user.sex, // 被保人性别
                        // selectedPlan: vm.user.selectedPlanId, //是否选择附加险
                        mainPlan: vm.mainPlan, // 主险
                        // addPlan: vm.addPlan, // 附加险
                        payendyear: vm.payAge, // 缴费期间
                        paymentType: vm.paymentType, // 缴费方式
                        PbBeginDate: vm.startDate, // 保险生效时间
                        PbInsuAmt: vm.mainPlan.amount, // 保险总保额 
                        PbInsuExp: vm.productData.token ? 0 : vm.mainPlan.exp, // 保险总保费
                        pbApplNoNum: 1,
                        isWholeSale: vm.paymentType == '0' ? true : false,
                        minAge: vm.minAge,
                        maxAge: vm.maxAge,
                        minHolderAge: vm.minHolderAge,
                        maxHolderAge: vm.maxHolderAge,
                        oldPrice: vm.mainPlan.exp, // 赠险前原价
                        cvrInsDt : vm.cvrInsDt
                    }
                });
                // 流程跳转
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'process'
                });
            });
        };
    }
})();