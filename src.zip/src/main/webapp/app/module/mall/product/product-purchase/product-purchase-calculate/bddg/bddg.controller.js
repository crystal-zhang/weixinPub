(function() {
    'use strict';

    angular
        .module('app')
        .controller('BddgController', BddgController);

    BddgController.$inject = ['$state', 'CONFIG', 'CommonRequest', '$scope', 'VALIDATION', '$rootScope', 'PolicyService', 'TipService', '$filter', '$timeout'];
    /** @ngInject */
    function BddgController($state, CONFIG, CommonRequest, $scope, VALIDATION, $rootScope, PolicyService, TipService, $filter, $timeout) {
        var vm = this;

        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        vm.productData = sessionData.productData;
        // 非法操作：1. 未获取产品数据 2. 要求做而未做手机验证
        if (!vm.productData || (sessionData.loginStatus != 2 && vm.productData.basicProfile['P005'] == 'Y' && !vm.productData.phoneValid)) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        vm.user = {};
        vm.user.sex = '1';
        vm.user.birthday = null;
        
        // 日期选择回调
        vm.birthdayCallback = function(val) {
            if (val) {
                vm.user.birthday = val;
            }
        };

        // 投被保人年龄
        var payTypeConfigs = vm.productData.payTypeConfigs;
        if (payTypeConfigs && payTypeConfigs.length > 0) {
            var payTypeConfig = payTypeConfigs[0];

            // vm.minAge = payTypeConfig.min_app_age;
            // vm.maxAge = payTypeConfig.max_app_age;
            vm.minAge = "0";
            vm.maxAge = "50";
            vm.minHolderAge = payTypeConfig.minHolderAge;
            vm.maxHolderAge = payTypeConfig.maxHolderAge;

            vm.minStartDate = VALIDATION.getDateByAge(vm.maxAge); // 年龄最小开始日期
            vm.maxEndDate = VALIDATION.getDateByAge(vm.minAge); // 年龄最大结束日期
            vm.holderStartDate = VALIDATION.getDateByAge(vm.maxHolderAge); // 投保人年龄最小开始日期
            vm.holderEndDate = VALIDATION.getDateByAge(vm.minHolderAge); // 投保人年龄最大结束日期
        }

        //设置投保人和被保人最大最小年龄
        var setMinAndMaxAges = function(obj) {
            // console.log(obj);
            // vm.maxAge = obj.max_app_age;
            // vm.minAge = obj.min_app_age;
            // vm.minAge = "0";
            // vm.maxAge = "50";
            vm.minHolderAge = obj.minHolderAge;
            vm.maxHolderAge = obj.maxHolderAge;

            vm.minStartDate = VALIDATION.getDateByAge(vm.maxAge); // 年龄最小开始日期
            vm.maxEndDate = VALIDATION.getDateByAge(vm.minAge); // 年龄最大结束日期
            vm.holderStartDate = VALIDATION.getDateByAge(vm.maxHolderAge); // 投保人年龄最小开始日期
            vm.holderEndDate = VALIDATION.getDateByAge(vm.minHolderAge); // 投保人年龄最大结束日期
        };


        // 获取缴费期间缴费方式
        vm.getPayWay = function() {
            var payment_value = [],
                payage_value = [];

            // 缴费方式
            vm.payWays = [];
            // 缴费期间
            vm.payAges = [];

            if (vm.productData.payment_type) {
                payment_value = vm.productData.payment_type.split(',');
            }
            if (vm.productData.pay_age) {
                payage_value = vm.productData.pay_age.split(',');
            }

            var temp = [];
            for (var i = 0; i < payment_value.length; i++) {
                if (temp.indexOf(payment_value[i]) == -1) {
                    temp.push(payment_value[i]);
                }
            }
            payment_value = temp;
            //console.log("payment_value:"+payment_value);

            temp = [];
            for (var i = 0; i < payage_value.length; i++) {
                if (temp.indexOf(payage_value[i]) == -1) {
                    temp.push(payage_value[i]);
                }
            }
            payage_value = temp;
            //console.log("payage_value:"+payage_value);

            if (payment_value && payment_value.length > 0) {
                for (var i = 0; i < payment_value.length; i++) {
                    var label;
                    if (payment_value[i] == 12) {
                        label = '年交';
                    } else if (payment_value[i] == 0) {
                        label = '趸交';
                    } else if (payment_value[i] == 1) {
                        label = '月交';
                    } else if (payment_value[i] == 3) {
                        label = '季交';
                    } else if (payment_value[i] == 6) {
                        label = '半年交';
                    }
                    vm.payWays.push({
                        label: label,
                        value: payment_value[i]
                    });
                }
            }
            //console.log(vm.payWays);

            if (payage_value && payage_value.length > 0) {
                for (var i = 0; i < payage_value.length; i++) {
                    vm.payAges.push({
                        label: payage_value[i] + "年",
                        value: payage_value[i],
                    })
                }
            }
            //console.log(vm.payAges);            

            //遍历payTypeConfigs数组，组合map对象
            var pay_age = [];
            vm.payWayObjs = {}; //缴费期间映射缴费方式及被保人年龄限制
            if (payTypeConfigs && payTypeConfigs.length > 0) {
                for (var i = 0; i < payTypeConfigs.length; i++) {
                    //没有相同的缴费期间->添加缴费期间、缴费方式
                    if (pay_age.join(",").indexOf(payTypeConfigs[i].pay_age) === -1) {
                        pay_age.push(payTypeConfigs[i].pay_age);

                        //添加映射
                        vm.payWayObjs[payTypeConfigs[i].pay_age] = {
                            pay_age: payTypeConfigs[i].pay_age,
                            map: [{
                                maxHolderAge: payTypeConfigs[i].maxHolderAge,
                                max_app_age: payTypeConfigs[i].max_app_age,
                                minHolderAge: payTypeConfigs[i].minHolderAge,
                                min_app_age: payTypeConfigs[i].min_app_age,
                                payment_type: payTypeConfigs[i].payment_type,
                            }]
                        };
                    } else { //有相同的缴费期间->插入缴费方式
                        //过滤相同缴费方式
                        var flag = false;
                        for (var j = 0; j < vm.payWayObjs[payTypeConfigs[i].pay_age].map.length; j++) {
                            if (payTypeConfigs[i].payment_type === vm.payWayObjs[payTypeConfigs[i].pay_age].map[j].payment_type) {
                                flag = true;
                            }
                        }
                        if (!flag) {
                            //插入不同缴费方式
                            vm.payWayObjs[payTypeConfigs[i].pay_age].map.push({
                                maxHolderAge: payTypeConfigs[i].maxHolderAge,
                                max_app_age: payTypeConfigs[i].max_app_age,
                                minHolderAge: payTypeConfigs[i].minHolderAge,
                                min_app_age: payTypeConfigs[i].min_app_age,
                                payment_type: payTypeConfigs[i].payment_type,
                            });
                        }
                    }
                }
            }
            //console.log(vm.payWayObjs);
        };
        vm.getPayWay();
        if (payTypeConfigs && payTypeConfigs.length > 0) {
            vm.payWay = payTypeConfigs[0].payment_type;
            vm.payAge = payTypeConfigs[0].pay_age;
        } else {
            vm.payWay = vm.payWays[0].value;
            vm.payAge = vm.payAges[0].value;
        }


        //监听缴费方式
        $scope.$watch('bddg.payAge', function(newValue) {
            //console.log(vm.payWay + "---" + vm.payAge);
            var payAgeNow = newValue;
            //console.log(vm.payWayObjs[payAgeNow].map);
            // vm.payAges = vm.payWayObjs[payAgeNow].map;
            vm.user.payendyear = vm.payWayObjs[payAgeNow].pay_age;

            var map = vm.payWayObjs[payAgeNow].map;
            for (var i = 0; i < map.length; i++) {
                if (map[i].payment_type === vm.payWay) {
                    setMinAndMaxAges(map[i]); //设置投保人和被保人最大最小年龄
                    break;
                }
            }
            //console.log(vm.payWays);
            //console.log(vm.user.payendyear);
        }, true);

        //监听缴费期间
        $scope.$watch('bddg.payWay', function(newValue) {
            //console.log(vm.payWay + "---" + vm.payAge);            
            var paymentType = newValue;
            var map = vm.payWayObjs[vm.payAge].map;
            for (var i = 0; i < map.length; i++) {
                if (map[i].payment_type === paymentType) {
                    setMinAndMaxAges(map[i]); //设置投保人和被保人最大最小年龄
                    break;
                }
            }
            //console.log(vm.payWays);
            //console.log(vm.user.payendyear);

            //监控信息计算保费
            if (newValue) {
                var user = vm.user;
                if (user.sex && user.birthday) {
                    vm.calc(vm);
                }
            }
        }, true);


        // 主险数据
        vm.mainPlan = {
            rate: 0,
            amount: '',
            exp: ''
        };

        // 获取产品计划
        vm.getPlan = function() {
            var plan = vm.productData.plans,
                len = plan.length;

            for (var i = len - 1; i >= 0; i--) {
                var item = plan[i];
                if (item.planType == '1') {
                    // 获取主险
                    angular.extend(vm.mainPlan, item);
                } else if (item.planType == '2') {
                    // 获取附加险
                    // angular.extend(vm.addPlan, item);
                }
            }
        };
        vm.getPlan();


        //定义投保金额选项可用性,true-no,false-ok
        // vm.isExpDisabled = {
        //         exp_1: true, //200000
        //         exp_2: true //300000
        //     }
            // 监听
        $scope.$watch('bddg.user', function(newValue) {
            var user = newValue;
            if (user.sex && user.birthday) {

                var birthday = new Date(user.birthday);
                var now = new Date();

                var age = VALIDATION.getAgeByBirth(user.birthday);
                var mouth = now.getMonth() - birthday.getMonth();
                if (age == 0 && mouth < 0) {
                    mouth = now.getMonth() + 12 - birthday.getMonth();
                }

                if ((((age == 0 && mouth >= 1) || age >= 1) && age <= 17) || (age >= 41 && age <= 50)) {
                    vm.mainPlan.amount = "200000";
                    // vm.isExpDisabled.exp_1 = false;
                    // vm.isExpDisabled.exp_2 = true;
                    // if (vm.mainPlan.amount == "300000") {
                    //     vm.mainPlan.amount = "";
                    // }
                } else if (age >= 18 && age <= 40) {
                    vm.mainPlan.amount = "300000";
                    // vm.isExpDisabled.exp_1 = true;
                    // vm.isExpDisabled.exp_2 = false;
                    // if (vm.mainPlan.amount == "200000") {
                    //     vm.mainPlan.amount = "";
                    // }
                } else {
                    vm.mainPlan.amount = "";
                    // vm.isExpDisabled.exp_1 = true;
                    // vm.isExpDisabled.exp_2 = true;
                }

                //监控信息计算保费
                vm.calc(vm);

            }
        }, true);

        $scope.$watch('bddg.mainPlan.amount', function(newValue) {
            if (newValue) {
                var user = vm.user;
                if (user.sex && user.birthday && vm.mainPlan.amount) {
                    vm.calc(vm);
                }
            }
        });

        // 获取费率，计算保费
        vm.calc = function(vm, callback) {
            var user = vm.user,
                age = VALIDATION.getAgeByBirth(user.birthday);

            //回调时需判断被保人年龄与BDDG保额的有效性
            if ((age>=0 && age<=17) || (age>=41 && age<=50)) {
                if (vm.mainPlan.amount && (vm.mainPlan.amount != 200000)) {
                    $ionicPopup.alert({
                        title: '温馨提示',
                        template: "当被保人为0-17周岁或41到50周岁时，龙行康佑2号恶性肿瘤疾病保险保额只能为200 000！",
                        okText: '我知道了'
                    });
                    return false;
                }
            } else if (age>=18 && age<=40) {
                if (vm.mainPlan.amount && (vm.mainPlan.amount != 300000)) {
                    $ionicPopup.alert({
                        title: '温馨提示',
                        template: "当被保人为18到40周岁时，龙行康佑2号恶性肿瘤疾病保险保额只能为300 000！",
                        okText: '我知道了'
                    });
                    return false;
                }
            } else {
                $ionicPopup.alert({
                    title: '温馨提示',
                    template: "当被保人大于等于51周岁时，不能购买龙行康佑2号恶性肿瘤疾病保险！",
                    okText: '我知道了'
                });
                return false;
            }

            var getKRateByPaytype = function(value) {
                var KRate = 0;
                if (value == 0 || value == 12) {
                    KRate = 1.000;
                } else if (value == 6) {
                    KRate = 0.520;
                } else if (value == 3) {
                    KRate = 0.262;
                } else if (value == 1) {
                    KRate = 0.09;
                }
                //console.log(value + "---" + KRate);
                return KRate;
            }

            // 获取费率
            var params = {
                prdId: vm.productData.prd_id,
                age: age,
                sex: user.sex,
                payEndYear: user.payendyear //vm.payAge
            };

            CommonRequest.request(params, CONFIG.PRODUCT_PURCHASE_CALCULATE_SERVICE, function(result) {
                if (result.status == 1) {
                    var rateTable = result.data,
                        mainRate = [], //主险费率表
                        addRate = []; //附加险费率表

                    // 重置保费
                    vm.mainPlan.exp = 0;
                    // vm.addPlan.amount = 0;

                    if (rateTable && rateTable.length > 0) {
                        for (var i = 0; i < rateTable.length; i++) {
                            if (rateTable[i].planType == '1') {
                                mainRate.push(rateTable[i]);
                            } else if (rateTable[i].planType == '2') {
                                addRate.push(rateTable[i]);
                            }
                        }

                        if (mainRate && mainRate.length > 0) {
                            // 主险费率
                            var flag = false;
                            for (var i = 0; i < mainRate.length; i++) {
                                if (mainRate[i].suppriskscore == "A") {
                                    vm.mainPlan.rate = mainRate[i].rate;
                                    flag = true;
                                }
                            }
                            if (!flag) { //取不到"A"时取第0项
                                vm.mainPlan.rate = mainRate[0].rate;
                            }
                            // vm.mainPlan.rate = mainRate[0].rate;
                            //console.log("rate:" + vm.mainPlan.rate);
                            //console.log("amount:" + vm.mainPlan.amount);
                            // 计算主险保费
                            vm.mainPlan.exp = (parseInt(10 * vm.mainPlan.rate * getKRateByPaytype(vm.payWay) + 0.5) / 10 * (vm.mainPlan.amount / vm.mainPlan.insuredAmount)).toFixed(2);
                            //console.log("exp:" + vm.mainPlan.exp);
                            // callback(vm.mainPlan.exp, vm.mainPlan.rate, vm.mainPlan.amount);
                            callback && callback({
                                exp: vm.mainPlan.exp,
                                amount: vm.mainPlan.amount,
                                mainPlan: vm.mainPlan
                            });
                        }

                    } else {
                        vm.mainPlan.exp = vm.mainPlan.amount;
                        // callback(vm.mainPlan.exp, "", vm.mainPlan.amount);
                        callback && callback({
                            exp: vm.mainPlan.exp,
                            amount: vm.mainPlan.amount,
                            mainPlan: vm.mainPlan
                        });
                    }
                }
            });
        };

        // 跳转投保页面
        vm.goPolicy = function() {
            vm.mainPlan.exp = vm.mainPlan.exp.toString();
            vm.mainPlan.amount = vm.mainPlan.amount.toString();
            var params = {
                prdId: vm.productData.prd_id,
                sex: vm.user.sex,
                insurerBirthDay: $filter('date')(vm.user.birthday, 'yyyyMMdd'),
                planId: vm.mainPlan.planId,
                premiumResult: vm.mainPlan.exp,
                orderCode: vm.productData.orderCode || ''
            };

            PolicyService.doCalc(params, function() {
                // 数据处理
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'data',
                    data: {
                        birthday: $filter('date')(vm.user.birthday, 'yyyy-MM-dd'), // 被保人生日
                        sex: vm.user.sex, // 被保人性别
                        // selectedPlan: vm.user.selectedPlan, //是否选择附加险
                        mainPlan: vm.mainPlan, // 主险
                        // addPlan: vm.addPlan, // 附加险
                        payendyear: vm.user.payendyear, // 缴费期间
                        paymentType: vm.payWay, // 缴费方式
                        PbInsuAmt: vm.mainPlan.amount, // 保险总保额 
                        PbInsuExp: vm.mainPlan.exp, // 保险总保费
                        pbApplNoNum: 1,
                        isWholeSale: vm.paymentType == '0' ? true : false,
                        minAge: vm.minAge,
                        maxAge: vm.maxAge,
                        minHolderAge: vm.minHolderAge,
                        maxHolderAge: vm.maxHolderAge,
                        calc: vm.calc.toString(),
                        calcCtrl: vm
                    }
                });
                // 流程跳转
                PolicyService.control({
                    state: 'product-purchase-calculate',
                    control: 'process'
                });
            });
        };
    }

})();