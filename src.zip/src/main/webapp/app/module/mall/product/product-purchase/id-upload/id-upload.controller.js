(function() {
    'use strict';

    angular
        .module('app')
        .controller('IDUploadController', IDUploadController);

    IDUploadController.$inject = ['$rootScope', '$location', 'Upload', 'CONFIG', '$scope', 'TipService', 'PolicyService', 'COMMON', '$ionicLoading', '$timeout'];
    /** @ngInject */
    function IDUploadController($rootScope, $location, Upload, CONFIG, $scope, TipService, PolicyService, COMMON, $ionicLoading, $timeout) {
        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        var policydata = $scope.policydata = sessionData.policyData,
            prodata = $scope.prodata = sessionData.productData;

        if (!prodata.orderCode) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $scope.close();
            return;
        }

        // 初始化
        $scope.files = {};
        $scope.files.file1 = '';
        $scope.files.file2 = '';

        // 存放图片的数组
        $scope.imageList = [];

        // 上传成功的数量
        $scope.uploaded = 0;

        // 获取用户影像件资料
        if (sessionData.login == 1) {
            PolicyService.getCustPhoto('100', function(images) {
                // imageFlag F001/F002/F003/F004
                for (var i = images.length - 1; i >= 0; i--) {
                    var image = images[i],
                        flag = image.imageFlag;
                    if (flag == 'F001') {
                        // 身份证正面
                        $scope.image1 = $scope.files.file1 = image.imagePath;
                    } else if (flag == 'F002') {
                        // 身份证反面
                        $scope.image2 = $scope.files.file2 = image.imagePath;
                    }
                }
            });
        }

        // 关闭弹框
        $scope.cancel = function() {
            COMMON.hideModal();
        };

        // 支付银行列表,1代表公司收款
        var BkBrchNo = policydata ? policydata.BkBrchNo : '';
        if (BkBrchNo) {
            COMMON.getCommonBank(BkBrchNo, '1', function(bankList) {
                $scope.bankList = bankList;
                if ($scope.bankList && $scope.bankList.length > 0) {
                    $scope.newGet.newGetBk = $scope.bankList[0]; // 授权转帐银行
                }
            });
        }

        // 初始化姓名
        $scope.name = policydata ? policydata.PbHoldName : '';

        $scope.newGet = {};
        $scope.newGet.newPayMode = '7';
        $scope.newGet.newGetAccName = policydata ? policydata.PbHoldName : '';
        $scope.newGet.newGetAccCode = '';

        // upload later on form submit or something similar
        $scope.submit = function() {
            if ($scope.uploaded == 2) {
                $scope.process();
                return;
            }
            var self = this,
                file1 = self.files.file1,
                file2 = self.files.file2,
                image1 = self.image1,
                image2 = self.image2;

            $scope.imageList = [];
            if (file1 && file2) {
                $scope.imageList.push({
                    F001: file1,
                    uploadType: '1000'

                }, {
                    F002: file2,
                    uploadType: '0100'
                });
            }

            if (image1 && image2) {
                if ((file1 == image1 && file2 != image2) || (file1 != image1 && file2 == image2)) {
                    TipService.showMsg($rootScope.TIPS.PRODUCT.UPLOAD_ANOTHER_PHOTO);
                    return;
                }
            }

            // 需要判断是否允许上传
            PolicyService.isAllowUpload($scope.imageList.length, function() {
                $scope.checkUpload($scope.uploaded);
            });
        };

        // 准备上传
        $scope.checkUpload = function(uploaded) {
            var data = {
                custId: sessionData.userData ? sessionData.userData.cusId : '',
                token: sessionData.userData ? sessionData.userData.token : '',
                channelCode: CONFIG.SALE_CHANNEL,
                orderCode: prodata.orderCode,
                txCode: 'CCBSB107',
                srCode: 'R0017' // 规则编码
            };
            $scope.upload(angular.extend($scope.imageList[uploaded], data),
                function() {
                    $scope.uploaded++;
                });
        };

        // 上传成功后的处理
        $scope.process = function() {
            // $uibModalInstance.close(true);

            var params = {};

            if ($scope.newGet.newGetAccCode) {
                params = {
                    NewPayMode: $scope.newGet.newPayMode || '7', // 首期收费方式 
                    NewGetAccName: $scope.newGet.newGetAccName, //首期缴费账号名称
                    NewGetBkCode: $scope.newGet.newGetBk.bankCode, //首期缴费银行编码
                    NewGetBkName: $scope.newGet.newGetBk.bankName, // 首期缴费银行名称
                    NewGetAccCode: $scope.newGet.newGetAccCode, //首期缴费账号
                    orderCode: prodata.orderCode
                };

                params = angular.extend(policydata, params);

                PolicyService.control({
                    state: 'id-upload',
                    control: 'data',
                    data: angular.extend(params, {
                        isTransferred: false,
                        idUploaded: true
                    })
                });
            } else {
                params = policydata;
            }

            PolicyService.checkPolicy(params, function() {
                PolicyService.control({
                    state: 'id-upload',
                    control: 'process'
                });
            });
        };

        // upload on file select or drop
        $scope.upload = function(data, callback) {
            $ionicLoading.show({
                template: '<ion-spinner icon="bubbles"></ion-spinner>'
            });

            Upload.upload({
                url: CONFIG.UPLOAD_SERVICE.url,
                data: data
            }).then(function(result) {
                $ionicLoading.hide();
                if (result.data.status == '1') {
                    $scope.uploadMsg = '上传成功！';
                    angular.isFunction(callback) && callback();
                } else {
                    TipService.showMsg(result.data.error.message + result.data.error.code);
                    $scope.uploadMsg = '上传失败';
                }
            }, function(resp) {
                $ionicLoading.hide();
                $scope.uploadMsg = '上传失败，错误代码: ' + resp.status;
            }, function(evt) {
                var progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
                $scope.uploadMsg = '上传进度: ' + progressPercentage + '%';
            });
        };

        // 上传成功的通知
        $scope.notify = function() {
            var params = {
                channelCode: CONFIG.SALE_CHANNEL,
                orderCode: prodata.orderCode,
                txCode: 'CCBSB107',
                uploadType: '100'
            };
            PolicyService.CertUploadDone(params, function(data) {
                if (data) {
                    $scope.process();
                }
            });
        };

        // 监听上传成功
        $scope.$watch('uploaded', function(newValue, oldValue) {
            if (newValue) {
                if (newValue != oldValue && newValue < 2) {
                    $scope.checkUpload(newValue);
                } else if (newValue == 2) {
                    $scope.notify();
                }
            }
        });
    }

})();