(function() {
    'use strict';

    angular
        .module('app')
        .controller('MaterialController', MaterialController);

    MaterialController.$inject = ['$scope', '$ionicModal', 'TipService', 'PolicyService', 'COMMON','$sce'];
    /** @ngInject */
    function MaterialController($scope, $ionicModal, TipService, PolicyService, COMMON,$sce) {
        var sessionData = PolicyService.getSessionData();

        // 所选产品信息
        var prodata = $scope.prodata = sessionData.productData;
        if (!prodata) {
            TipService.showMsg('非法操作！');
            $state.go('tab.mall');
            return;
        }
        //条款详情
        var materialArr = prodata.materialArr;
        $scope.oneDetail = false;
        if (materialArr && materialArr.length > 0) {
            $scope.materialArr = materialArr;
            if ($scope.materialArr.length == 1) {
                $scope.url = $sce.trustAsResourceUrl($scope.materialArr[0].materialPath);

            }
        }

        // 关闭弹框
        $scope.cancel = function() {
            COMMON.hideModal();
        };

    }

})();