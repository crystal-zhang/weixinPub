(function() {
    'use strict';

    angular
        .module('app')
        .controller('GhmbController', GhmbController);

    GhmbController.$inject = ['$state', 'VALIDATION', '$scope', '$document', 'CommonRequest', 'CONFIG', 'TipService', 'GroupPolicyService', '$filter', '$rootScope','$ionicLoading','$timeout'];
    /** @ngInject */
    function GhmbController($state, VALIDATION, $scope, $document, CommonRequest, CONFIG, TipService, GroupPolicyService, $filter, $rootScope,$ionicLoading,$timeout) {
        var vm = this;
        var sessionData = GroupPolicyService.getSessionData();

        // 所选产品信息
        vm.productData = sessionData.productData;
        // 用户信息
        vm.userData = sessionData.userData;
        // 非法操作：1. 未获取产品数据 2. 要求做而未做手机验证
        if (!vm.productData || (sessionData.loginStatus != 2 && vm.productData.basicProfile['P005'] == 'Y' && !vm.productData.phoneValid)) {
            // TipService.showMsg($rootScope.TIPS.SYSTEM.INVALID_OPERATION);
            $state.go('tab.mall');
            return;
        }

        vm.hasSpecial = true;
        // 投被保人年龄
        var payTypeConfigs = vm.productData.payTypeConfigs;
        if (payTypeConfigs && payTypeConfigs.length > 0) {
            var payTypeConfig = payTypeConfigs[0];

            vm.minAge = payTypeConfig.minHolderAge;
            vm.maxAge = payTypeConfig.maxHolderAge;


            vm.minStartDate = VALIDATION.getDateByAge(vm.maxAge); // 年龄最小开始日期
            vm.maxEndDate = VALIDATION.getDateByAge(vm.minAge); // 年龄最大结束日期

        }
        // 被保人为子女时年龄限制
        var minDate = VALIDATION.getDateByAge('23');
        var maxDate = VALIDATION.getDateByAge('0');


        //保障计划选择,保障计划详情,保障金额
        vm.planChecked = '';
        vm.planDet = false;
        vm.planMoney = '50万元';
        vm.nextStep = false;
        //保障计划
        vm.planOneCheck = function() {
            vm.planChecked = '1';
            vm.planDet = true;
            vm.planMoney = '50万元';
        };
        vm.planTwoCheck = function() {
            vm.planChecked = '2';
            vm.planDet = true;
            vm.planMoney = '100万元';
        }
        vm.slideUp = function() {
                vm.planDet = false;
            }
            //投保人
        vm.priChecked = false;
        vm.priInfo = {
            isMedic: '',
            birthday: '',
        };
        vm.priMedic = function(medic) {
                vm.priInfo.isMedic = medic;
            }
            //被保人页面渲染
        vm.secList = [{
            id: 1,
            trashShow: false,
            secIsShow: false,
            birthday: '',
            isMate: '',
            isMedic: '',
            minStartDate: minDate,
            maxEndDate: maxDate,
            disabled: null
        }, {
            id: 2,
            trashShow: false,
            secIsShow: false,
            birthday: '',
            isMate: '',
            isMedic: '',
            minStartDate: minDate,
            maxEndDate: maxDate,
            disabled: null
        }];
        vm.secInfo = [{
            id: 1,
            birthday: '',
            isMate: '',
            isMedic: ''
        }, {
            id: 2,
            birthday: '',
            isMate: '',
            isMedic: ''
        }];
        //展示隐藏
        vm.secShow = function(id) {
            for (var i = 0; i < vm.secList.length; i++) {
                if (vm.secList[i].id == id) {
                    vm.secList[i].secIsShow = !vm.secList[i].secIsShow;
                    break;
                }
            }
        };
        //投保人医疗
        //添加被保人
        vm.add = function() {
                var id = vm.secList[vm.secList.length - 1].id + 1;
                vm.secList.push({
                    id: id,
                    trashShow: true,
                    secIsShow: false,
                    birthday: '',
                    isMate: '',
                    isMedic: '',
                    minStartDate: minDate,
                    maxEndDate: maxDate,
                    disabled: null
                });
                vm.secInfo.push({
                    id: id,
                    birthday: '',
                    isMate: '',
                    isMedic: '',
                });
                vm.checkRelations();
            }
            //删除被保人
        vm.del = function(id) {
                for (var i = 0; i < vm.secList.length; i++) {
                    if (vm.secList[i].id == id) {
                        vm.secList.splice(i, 1);
                        vm.secInfo.splice(i, 1);
                        if (vm.secList.length == 3) {
                            vm.secList[i].secIsShow = !vm.secList[i].secIsShow;
                        }
                        break;
                    }
                }
                vm.checkRelations();
            }
            //选择被保人关系
        vm.secMate = function(id, relation) {
            // vm.checkRelation(id, relation);

            for (var i = 0; i < vm.secList.length; i++) {
                if (vm.secList[i].id == id) {
                    vm.secList[i].isMate = relation;
                    vm.secInfo[i].isMate = relation;
                    vm.secList[i].birthday = '';
                    break;
                }
            }
            vm.checkRelations();
        }
        vm.checkRelations = function() {
            var flag = true;
            for (var m = 0; m < vm.secList.length; m++) {
                if (vm.secList[m].isMate == "03") {
                    flag = false;
                    for (var n = 0; n < vm.secList.length; n++) {
                        vm.secList[n].disabled = true;
                    }
                    vm.secList[m].disabled = false;
                }
            }
            if (flag) {
                for (var m = 0; m < vm.secList.length; m++) {
                    vm.secList[m].disabled = false;
                }
            }
        }
        vm.checkRelation = function(id, relation) {
                // 对配偶关系做特殊校验
                for (var m = 0; m < vm.secList.length; m++) {
                    if (vm.secList[m].isMate == "03") {
                        vm.hasSpecial = true;
                        break;
                    } else {
                        vm.hasSpecial = false;
                    }
                }
                if (vm.hasSpecial) {
                    for (var k = 0; k < vm.secList.length; k++) {
                        if (id) {
                            if (relation != '03' && vm.secList[k].id != id) {
                                vm.secList[k].disabled = false;
                            }
                        } else {
                            if (vm.secList[k].isMate != "03") {
                                vm.secList[k].disabled = true;
                            } else {
                                vm.secList[k].disabled = false;
                            }
                        }
                    }
                } else {
                    for (var j = 0; j < vm.secList.length; j++) {
                        if (relation == '03') {
                            if (vm.secList[j].id == id) {
                                vm.secList[j].disabled = false;
                            } else {
                                vm.secList[j].disabled = true;
                            }
                        } else {
                            vm.secList[j].disabled = false;
                        }
                    }
                }
            }
            // vm.checkRelation();
            //被保人医疗
        vm.secMedic = function(id, medic) {
                for (var i = 0; i < vm.secList.length; i++) {
                    if (vm.secList[i].id == id) {
                        vm.secList[i].isMedic = medic;
                        vm.secInfo[i].isMedic = medic;
                        break;
                    }
                }
            }
            //监听页面,重新测算保费
        $scope.$watch('ghmb.planChecked', function(newValue) {
            vm.nextStep = false;
        }, true)
        $scope.$watch('ghmb.priInfo', function(newValue) {
            vm.nextStep = false;
        }, true)
        $scope.$watch('ghmb.secInfo', function(newValue) {
            vm.nextStep = false;
        }, true)
        vm.dateChange = function() {
                vm.nextStep = false;
            }
            //监听事件,限制被保人上限
        vm.addPic = true;
        $scope.$watch('ghmb.secList.length', function(newValue) {
            if (newValue >= 4) {
                vm.addPic = false;
            } else {
                vm.addPic = true;
            }
        }, true)

        /*
         ** 团险保费测算解耦
         **查询接口
         ** @params 核保参数转换
         **
         **
         */
        vm.getPremiumRateGroupCoreResultTimes = 0;
        vm.getPremiumRateGroupCoreResult = function(flowNo) {
            $ionicLoading.show({
                template: '<ion-spinner icon="bubbles"></ion-spinner>'
            });
            // 累计请求次数限制
            vm.getPremiumRateGroupCoreResultTimes++;
            if (vm.getPremiumRateGroupCoreResultTimes > CONFIG.GROUP_CORE_DECOUPLING_TIMES) {
                $ionicLoading.hide();
                // TipService.showMsg($rootScope.TIPS.PRODUCT.POLICY_QUERY_FAILED);
                // 提示消息
                TipService.showMsg('系统繁忙,请稍后重试');
                // 重置请求次数
                vm.getPremiumRateGroupCoreResultTimes = 0;
                return;
            }
            var params = {
                flowNo4Trial: flowNo
            };

            CommonRequest.request(params, CONFIG.GHMB_GET_PREMIUM_RATE_GROUP_CORE_RESULT, function(result) {
                if (result.status == 1) {
                    var data = result.data || '';
                    // 获取核保结果
                    if (data == '') {
                        $timeout(function() {
                            vm.getPremiumRateGroupCoreResult(flowNo);
                        }, CONFIG.GROUP_CORE_DECOUPLING_DURATION);
                        return;
                    }
                    $ionicLoading.hide();

                    // 重置请求次数
                    vm.getPremiumRateGroupCoreResultTimes = 0;
                    if (data.respCode == '00000') {
                        // 保单金额
                        var orderCode = data.orderCode;
                        if (orderCode) {
                            GroupPolicyService.setSessionData({
                                productData: {
                                    orderCode: orderCode
                                }
                            });
                        }
                        for (var i = 0; i < data.rcgnList.length; i++) {
                            for (var j = 0; j < vm.secList.length; j++) {
                                if (data.rcgnList[i].rcgnNm == '0') {
                                    vm.insCvr = data.rcgnList[i].insPrem;
                                } else if (data.rcgnList[i].rcgnNm == vm.secList[j].id) {
                                    vm.secList[j].insCvr = data.rcgnList[i].insPrem;
                                }
                            }
                        }
                        vm.totalInsCvr = data.totalInsCvr;
                        vm.nextStep = true;
                    } else {
                        TipService.showMsg(data.respDesc);
                        return;
                    }
                } else {
                    $ionicLoading.hide();
                    // 重置请求次数
                    vm.getPremiumRateGroupCoreResultTimes = 0;
                }
            }, true);
        };

        var rcgnList = [],
            insuredList = [],
            plans = [],
            params;
        vm.submitAccount = function() {
            plans = vm.planChecked == 1 ? vm.productData.plans[0] : vm.productData.plans[1];
            insuredList = [{
                rcgnNm: '0', //被保人编号
                rcgnBrthDt: $filter('date')(vm.priInfo.birthday, 'yyyyMMdd'), //被保人生日
                insuredSSflag: vm.priInfo.isMedic, //被保人社保医疗
                insuredAppntRela: '01', //与投保人关系
                cvrNum: "1", //险种个数
                busiList: [{
                    cvrID: plans.planCode, //险种id
                    mainAndAdlInsInd: "1", //主险/附加险
                    insCps: "1", //投保份数
                    insCvr: plans.insuredAmount, //投保保额
                    insScmInf: plans.planCode //计划别编号
                }]
            }]
            for (var i = 0; i < vm.secList.length; i++) {
                insuredList.push({
                    rcgnNm: vm.secList[i].id.toString(),
                    rcgnBrthDt: $filter('date')(vm.secList[i].birthday, 'yyyyMMdd'),
                    insuredSSflag: vm.secList[i].isMedic,
                    insuredAppntRela: vm.secList[i].isMate,
                    cvrNum: "1",
                    busiList: [{
                        cvrID: plans.planCode,
                        mainAndAdlInsInd: "1",
                        insCps: "1",
                        insCvr: plans.insuredAmount,
                        insScmInf: plans.planCode
                    }]
                });
            }
            params = {
                premiumAppEntity: {
                    plchdBrthDt: $filter('date')(vm.priInfo.birthday, 'yyyyMMdd'), //投保人生日
                    appntSsflag: vm.priInfo.isMedic, //社保状态
                    insuredNum: insuredList.length, //被保人个数
                    insuredList: insuredList //被保人信息
                },
                orderCode: vm.productData.orderCode || '', //订单编号
                channelCode: CONFIG.SALE_CHANNEL, //渠道编号
                isMobileCheck: vm.productData.basicProfile.P005 == 'Y' ? '1' : '0', //是否手机验证
                isCalculate: vm.productData.basicProfile.P001 == 'Y' ? '1' : '0', //是否保费测算 
                isRiskTest: vm.productData.basicProfile.P006 == 'Y' ? '1' : '0', //是否风险评估 
                isAuthentication: vm.productData.basicProfile.P002 == 'Y' ? '1' : '0', //是否身份核查 
                isSpecialCheck: vm.productData.basicProfile.P004 == 'Y' ? '1' : '0', //是否特殊业务 
                prdSaleCode: vm.productData.saleAvailFlag, //是否销售 
                planId: plans.planId, //计划别id
                planCode: plans.planCode, //计划别编号
                planName: plans.planName, //计划别名称
                prdId: vm.productData.prd_id, //产品id
                prdCode: vm.productData.prd_code, //产品code
                prdName: vm.productData.prd_title, //产品tittle
                sellTypeDetail: CONFIG.SALE_CHANNEL //销售渠道
            }

            CommonRequest.request(params, CONFIG.PREMIUM_RATE_FROM_GROUP_CORE, function(result) {
                if (result.status == 1) {
                   vm.getPremiumRateGroupCoreResult(result.data);
                }
            });
            //vm.nextStep = true;
        }

        vm.next = function() {
            GroupPolicyService.control({
                state: 'product-purchase-group-calculate',
                control: 'data',
                data: {
                    plchdBrthDt: $filter('date')(vm.priInfo.birthday, 'yyyyMMdd'),
                    appntSsflag: vm.priInfo.isMedic,
                    insuredList: insuredList,
                    totalInsCvr: vm.totalInsCvr, //总保费
                    insCvr: vm.insCvr, //投保人保费
                    plans: plans, //保险计划
                    groupProName: vm.productData.prd_title, //产品名称
                    pbApplNoNum: '1', //投保单号个数,
                    params: params
                }
            });
            GroupPolicyService.control({
                state: 'product-purchase-group-calculate',
                control: 'process'
            });
        }



    }
})();