(function() {
    'use strict';

    angular
        .module('app')
        .controller('ProductDetailController', ProductDetailController);

    ProductDetailController.$inject = ['$state', '$log', '$location', '$rootScope', 'CONFIG', 'CommonRequest', '$scope', 'PolicyService', 'TipService', '$timeout', '$filter'];
    /** @ngInject */
    function ProductDetailController($state, $log, $location, $rootScope, CONFIG, CommonRequest, $scope, PolicyService, TipService, $timeout, $filter) {
        var vm = this;
        var userData = PolicyService.getSessionData().userData;

        // 所选产品id
        vm.id = $state.params.id;

        vm.buttonShow = $state.params.buttonShow;
        vm.salesId = $state.params.salesId;
        vm.parentSalesId = $state.params.parentSalesId;
        vm.salesLevel = $state.params.salesLevel;
        vm.newSaleChnl = $state.params.saleChnl;

        if (vm.newSaleChnl && vm.newSaleChnl.length > 0) {
            CONFIG.NEW_SALE_CHANNEL = vm.newSaleChnl;
        }
        // console.log('1-buttonShow:'+vm.buttonShow);
        // console.log('2-salesId:'+vm.salesId);
        // console.log('3-parentSalesId:'+vm.parentSalesId);
        // console.log('4-salesLevel:'+vm.salesLevel);
        // console.log('5-newSaleChnl:'+vm.newSaleChnl);

        if (vm.buttonShow == 'false') {
            vm.nextButton = false;
            PolicyService.control({
                state: $state.current.name,
                control: 'data',
                data: {
                    buttonShow: vm.buttonShow,
                }
            });
        } else {
            vm.nextButton = true;
        }

        if (vm.salesId && vm.salesLevel && vm.newSaleChnl) {
            PolicyService.control({
                state: $state.current.name,
                control: 'data',
                data: {
                    salesId: vm.salesId,
                    parentSalesId: vm.parentSalesId,
                    salesLevel: vm.salesLevel,
                    newSaleChnl: vm.newSaleChnl,
                }
            });
        }

        vm.channelCode = CONFIG.SALE_CHANNEL;

        // 获取所选产品数据
        vm.getProductDetail = function(id) {
            var params = {
                prdId: id
            };
            CommonRequest.request(params, {
                url: $filter('jsonFilter')(id),
                method: 'GET'
            }, function(result) {
                if (result.status == 1) {
                    vm.productData = result.data;
                    var prdparams = {
                        prdIds: [id]
                    };
                    if (vm.productData) {
                        // CommonRequest.request(prdparams, CONFIG.PRD_STATUS_SERVICE, function(result) {
                        //     var prdStatus = result.data[0];
                        //     if (prdStatus) {
                        //         vm.productData.hasDiscount = prdStatus.hasDiscount;
                        //         vm.productData.prdSaleCode = prdStatus.prdSaleCode;
                        //         vm.productData.saleAvailFlag = prdStatus.saleAvailFlag;
                        //     } else {

                        //     }
                        var prdDetails = vm.productData.prdDetails,
                            prdPayments = vm.productData.prdPayments;
                        // // 涮选产品详情内容
                        // if (prdDetails && prdDetails.length > 0) {
                        //     for (var i = 0; i < prdDetails.length; i++) {
                        //         if (vm.channelCode == prdDetails[i].channelCode) {
                        //             vm.productData.prd_title = prdDetails[i].prdName;
                        //             vm.productData.prdDescription = prdDetails[i].prdDescription;
                        //             vm.productData.prd_tip = prdDetails[i].prdTip;
                        //             vm.productData.prdStartPrice = prdDetails[i].prdStartPrice;
                        //             vm.productData.prd_pic = prdDetails[i].prdPic;
                        //         }
                        //     }
                        // }
                        // // 涮选产品支付方式
                        // if (prdPayments && prdPayments.length > 0) {
                        //     for (var i = 0; i < prdPayments.length; i++) {
                        //         if (vm.channelCode == prdPayments[i].channelCode) {
                        //             var paymentCodes = prdPayments[i].paymentCodes;
                        //             vm.productData.payType = paymentCodes.join();

                        //         }
                        //     }
                        // }
                        // 显示被保人的最小大年龄
                        var payTypeConfigs = vm.productData.payTypeConfigs;
                        vm.minAge = [];
                        vm.maxAge = [];
                        if (payTypeConfigs && payTypeConfigs.length > 0) {
                            for (var l = 0; l < payTypeConfigs.length; l++) {
                                vm.minAge.push(payTypeConfigs[l].min_app_age);
                                vm.maxAge.push(payTypeConfigs[l].max_app_age);
                            }
                            for (var m = 0; m < vm.minAge.length - 1; m++) {
                                for (var n = m + 1; n < vm.minAge.length; n++) {
                                    var temp1, temp2;
                                    if (vm.minAge[m] > vm.minAge[n]) {
                                        temp1 = vm.minAge[m];
                                        vm.minAge[m] = vm.minAge[n];
                                        vm.minAge[n] = temp1;
                                    }
                                    if (vm.maxAge[m] < vm.maxAge[n]) {
                                        temp2 = vm.maxAge[m];
                                        vm.maxAge[m] = vm.maxAge[n];
                                        vm.maxAge[n] = temp2;
                                    }
                                }
                            }
                            vm.productData.minAge = vm.minAge[0];
                            vm.productData.maxAge = vm.maxAge[0];
                            vm.changeInsurYear(vm.productData.plans);
                            vm.changePayAge();
                        }
                        // });

                        PolicyService.control({
                            state: $state.current.name,
                            control: 'data',
                            data: vm.productData
                        });
                    }
                    vm.getProductMaterials();
                    vm.getProductToken();
                    // angular.isFunction(callback) && callback(vm.productData);
                }

                // $broadcast
                if (vm.productData) {
                    var second = vm.productData['tag_name'][0],
                        secondLink = vm.productData['tag_code'][0],
                        third = vm.productData['prd_title'];

                    $rootScope.$broadcast('refresh-location', {
                        second: second,
                        secondLink: 'product-list({tag:' + secondLink.substr(secondLink.length - 1, 1) + '})',
                        third: third
                    });
                }

                $rootScope.$broadcast('scroll.refreshComplete');
            });
        };

        // 处理产品保险期间
        vm.changeInsurYear = function(plans) {
            var hash = [],
                arr = [];
            vm.insurYearArr = [];
            if (plans && plans.length > 0) {
                for (var i = 0; i < plans.length; i++) {
                    if (plans[i].insuYearFlag == 'Y') {
                        if (plans[i].insuYear == '1000') {
                            arr.push('终身');
                        } else {
                            arr.push(plans[i].insuYear + '年');
                        }
                    } else if (plans[i].insuYearFlag == 'D') {
                        arr.push(plans[i].insuYear + '天');
                    } else if (plans[i].insuYearFlag == 'M') {
                        arr.push(plans[i].insuYear + '月');
                    } else if (plans[i].insuYearFlag == 'A') {
                        arr.push("至被保险人年满" + plans[i].insuYear + '周岁后首个保单周年日');
                    }

                }
                // 除掉数组里面的重复字符
                for (var i = 0; i < arr.length; i++) {
                    hash[arr[i]] != null;
                    if (!hash[arr[i]]) {
                        vm.insurYearArr.push(arr[i]);
                        hash[arr[i]] = true;
                    }
                }

                // 单位不同，不适合直接排序
                // vm.insurYearArr.sort();
                // console.log("insurYearArr:"+vm.insurYearArr);
                if (vm.insurYearArr.length > 1) {
                    vm.insurYearArr = "可选" + vm.insurYearArr.toString().replace(/,/g, "、");
                } else {
                    vm.insurYearArr = vm.insurYearArr.toString();
                }
            }
        }

        // 处理产品交费方式和交费年限
        vm.changePayAge = function() {
            var payment_value = [],
                payage_value = [];

            // 缴费方式
            vm.payWays = [];
            // 缴费期间
            vm.payAges = [];

            if (vm.productData.payment_type) {
                payment_value = vm.productData.payment_type.split(',');
            }
            if (vm.productData.pay_age) {
                payage_value = vm.productData.pay_age.split(',');
            }

            var temp = [];
            for (var i = 0; i < payment_value.length; i++) {
                if (temp.indexOf(payment_value[i]) == -1) {
                    temp.push(payment_value[i]);
                }
            }
            payment_value = temp;
            payment_value.sort();
            // console.log("payment_value:"+payment_value);

            temp = [];
            for (var i = 0; i < payage_value.length; i++) {
                if (temp.indexOf(payage_value[i]) == -1) {
                    temp.push(payage_value[i]);
                }
            }
            payage_value = temp;
            payage_value.sort();
            // console.log("payage_value:"+payage_value);

            if (payment_value && payment_value.length > 0) {
                for (var i = 0; i < payment_value.length; i++) {
                    var label;
                    if (payment_value[i] == 12) {
                        label = '年交';
                    } else if (payment_value[i] == 0) {
                        label = '趸交';
                    } else if (payment_value[i] == 1) {
                        label = '月交';
                    } else if (payment_value[i] == 3) {
                        label = '季交';
                    } else if (payment_value[i] == 6) {
                        label = '半年交';
                    }
                    vm.payWays.push(label);
                }
            }
            // console.log(vm.payWays);

            if (payage_value && payage_value.length > 0) {
                for (var i = 0; i < payage_value.length; i++) {
                    vm.payAges.push(payage_value[i] + "年");
                }
            }
            // console.log(vm.payAges);

            if (vm.payWays.length > 1) {
                vm.payMentTypeArr = "可选" + vm.payWays.toString().replace(/,/g, "、");
            } else {
                vm.payMentTypeArr = vm.payWays.toString();
            }
            if (vm.payAges.length > 1) {
                vm.payAgeArr = "可选" + vm.payAges.toString().replace(/,/g, "、");
            } else {
                vm.payAgeArr = vm.payAges.toString();
            }
        }

        // 获取产品数据并存入session
        var times = 0;
        vm.loadingPage = function() {
            if (times >= 10) {
                times = 0;
                return;
            }
            times++;
            vm.getProductDetail(vm.id);
            $timeout(function() {
                if (!vm.productData) {
                    vm.loadingPage();
                } else {
                    return;
                }
            }, 1000);
        };
        vm.loadingPage();
        // $timeout(function() {
        //     vm.getProductDetail(vm.id);
        // }, 100);

        // 获取卡券token
        vm.getcardToken = function(callback) {
            var $search = $location.search(),
                lotCode = $search.lotCode;

            if (lotCode) {
                var params = {
                    lotCode: lotCode,
                    channelCode: CONFIG.SALE_CHANNEL,
                    custWXId: $rootScope.openid,
                    prdId: vm.id
                };
                PolicyService.getCardToken(params, function(token) {
                    if (token) {
                        angular.isFunction(callback) && callback(token);
                    }
                });
            }
        };

        // 获取产品卡券
        vm.getProductToken = function() {
            // 获取卡券
            vm.getcardToken(function(token) {
                if (token) {
                    // 赠险token
                    vm.token = token;
                    // 获取卡券
                    PolicyService.getCardInfo(token, function(data) {
                        if (data.prdId != vm.productData.prd_id) {
                            TipService.showMsg('该活动不适用于产品“' + productData.prd_title + '”，请核实！');
                            $state.go('tab.mall');
                            return;
                        }

                        PolicyService.control({
                            state: $state.current.name,
                            control: 'data',
                            data: {
                                token: token,
                                lotCode: data.lotCode
                            }
                        });
                    });
                }
            });
        };

        // 获取产品条款
        vm.getProductMaterials = function() {
            PolicyService.getMaterials({
                prdId: vm.id,
                saleChannel: CONFIG.SALE_CHANNEL
            }, function(materials) {
                vm.materials = materials;
                for (var i = 0; i < vm.materials.length; i++) {
                    if (vm.materials[i].materialType == 'M01') {
                        vm.ma = vm.materials[i];
                        if (vm.ma) {
                            var materialTypeDesc = vm.ma.materialTypeDesc,
                                materialType = vm.ma.materialType;
                            var params = {
                                prdId: vm.id,
                                materialType: materialType,
                                materialTypeDesc: materialTypeDesc

                            };
                            CommonRequest.request(params, CONFIG.GET_MATRRIAL_DETAIL_SERVICE, function(result) {
                                if (result.status == 1) {
                                    vm.maDetail = result.data;
                                    for (var i = 0; i < vm.maDetail.length; i++) {
                                        vm.maDetail[i].materialPath = CONFIG.IMAGE_SERVICE_ADDRESS + vm.maDetail[i].materialPath;
                                    }
                                }
                            });
                        }
                    }
                }

                PolicyService.control({
                    state: $state.current.name,
                    control: 'data',
                    data: {
                        materials: materials,
                    }
                });
            });
        };
        // 获取产品条款
        vm.getProductMaterialsWithoutCache = function() {
            PolicyService.getMaterialsWithoutCache({
                prdId: vm.id,
                saleChannel: CONFIG.SALE_CHANNEL
            }, function(materials) {
                vm.materials = materials;
                for (var i = 0; i < vm.materials.length; i++) {
                    if (vm.materials[i].materialType == 'M01') {
                        vm.ma = vm.materials[i];
                        if (vm.ma) {
                            var materialTypeDesc = vm.ma.materialTypeDesc,
                                materialType = vm.ma.materialType;
                            var params = {
                                prdId: vm.id,
                                materialType: materialType,
                                materialTypeDesc: materialTypeDesc

                            };
                            CommonRequest.requestWithoutCache(params, CONFIG.GET_MATRRIAL_DETAIL_SERVICE, function(result) {
                                if (result.status == 1) {
                                    vm.maDetail = result.data;
                                    for (var i = 0; i < vm.maDetail.length; i++) {
                                        vm.maDetail[i].materialPath = CONFIG.IMAGE_SERVICE_ADDRESS + vm.maDetail[i].materialPath;
                                    }
                                }
                            });
                        }
                    }
                }

                PolicyService.control({
                    state: $state.current.name,
                    control: 'data',
                    data: {
                        materials: materials,
                    }
                });
            });
        };

        // 流程跳转
        vm.process = function() {
            if (vm.newSaleChnl && vm.productData.orderCode && vm.productData.orderCode > 0) {
                PolicyService.setSessionData({
                    productData: {
                        orderCode: null
                    }
                });
            }

            // 如果当前为TAC学生惠产品，且用户已登录，且用户证件类型不为身份证
            // 则拒绝投保
            // by lixianzhang 2017年5月25日
            // console.log($rootScope.isLogin);
            // console.log(userData.cretType);
            if (vm.productData.templateCode == "TAC" && $rootScope.isLogin && userData.cretType != "A") {
                TipService.showMsg($rootScope.TIPS.PRODUCT.TAC_CERTTYPE_FAILED);
                return;
            }

            PolicyService.control({
                state: $state.current.name,
                control: 'process'
            });
        };
    }

})();