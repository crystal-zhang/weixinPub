(function() {
	'use strict';

	angular
		.module('app')
		.controller('extensionController', extensionController);

	extensionController.$inject = ['$scope', 'CommonRequest', '$rootScope', 'CONFIG', '$timeout'];

	/** @ngInject */
	function extensionController($scope, CommonRequest, $rootScope, CONFIG, $timeout) {
	
		


		
	}

})();