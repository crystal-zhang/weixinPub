(function() {
	
	'use strict';

	angular
		.module('app')
		.controller('problemMoreController', problemMoreController)
		
		//更多问题切换
		.run(function ($rootScope) {
            $rootScope.data = {
                current: "1"
            };
            $rootScope.actionMore = {
                setCurrents: function (param,scope) {
                	scope.data.currents = param;
	            	scope.facePanel = !scope.facePanel;
                }
            }
        });


	problemMoreController.$inject = ['$scope', 'CommonRequest', '$rootScope', 'CONFIG', '$timeout' ,'$state'];

	/** @ngInject */
	function problemMoreController($scope, CommonRequest, $rootScope, CONFIG, $timeout, $state) {
//		var vm = this;
		

		
	}

})();