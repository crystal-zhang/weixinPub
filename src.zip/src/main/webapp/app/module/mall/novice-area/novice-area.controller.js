(function() {
	'use strict';

	angular
		.module('app')
		.controller('noviceController', noviceController)
	
		//常见问题切换
		.run(function ($rootScope) {
	        $rootScope.actionss = {
	            setCurrents: function (param,scope) {
	            	scope.data.currents = param;
	            	scope.facePanel = !scope.facePanel;
	            }
	        }
	    });
		

	noviceController.$inject = ['$scope', 'CommonRequest', '$rootScope', 'CONFIG', '$timeout'];

	/** @ngInject */
	function noviceController($scope, CommonRequest, $rootScope, CONFIG, $timeout) {
		
		//点击问题展开
		$scope.showFace = function () {
			$scope.facePanel = !$scope.facePanel;
	    };
		


		
	}

})();