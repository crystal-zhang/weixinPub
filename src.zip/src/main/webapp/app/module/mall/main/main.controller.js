(function() {
	'use strict';

	angular
		.module('app')
		.controller('MallController', MallController);

	MallController.$inject = ['$scope', '$state', 'CommonRequest', '$rootScope', 'CONFIG', '$timeout', '$ionicSlideBoxDelegate'];

	/** @ngInject */
	function MallController($scope, $state, CommonRequest, $rootScope, CONFIG, $timeout, $ionicSlideBoxDelegate) {
		var vm = this;

		vm.queryTodoTask = function(salerId,salerType) {
			vm.taskList = [];
			
			var parm = new Object();
			parm.salerId = salerId;
			parm.salerType = salerType;
			CommonRequest.request(parm, CONFIG.QUERY_TODO_TASK, function(resdata) {
				vm.taskList = resdata.RSP_BODY.Data.taskList;
			});
		};
		
		vm.checkRedPack = function(openId,salerType,alertFlag){
			var parm = {
				"openId":openId,
				"salerType":salerType
			};
			
			CommonRequest.request(parm, CONFIG.QUERY_ROB_REDPACK, function(resdata) {
				var flag = resdata.RSP_BODY.Data.flag;
				if(flag == '0'){
					/* 抽奖信息 */
					ruleId=resdata.RSP_BODY.Data.ruleId;
					periodId=resdata.RSP_BODY.Data.periodId;
					robKey=resdata.RSP_BODY.Data.robKey;
					var redEnveSusp=$(document).dialog({
			               type : 'confirm',
			               style: 'ios',
			               content: '<div style="width:5.12rem;height:6rem;margin:0 auto;background: url(././images/luckDraw/ex-redEnveTan-gn.png) no-repeat;background-size: 5.12rem;">'+
			                            '<div class="ex-modal-close" style="position:absolute;right:1.1rem;width:0.8rem;height:0.8rem;"></div>'+
			                            '<div class="draw_btn_per" style="position:absolute;left:2rem;bottom:1.2rem;width:3rem;height:1rem;"></div>'+
			                        '</div>',
			               dialogClass:'dialog-redEnve'
			            });
			            $(".dialog-redEnve .dialog-content-ft").hide();
			            $(".dialog-redEnve .dialog-content-hd").hide();
			            $(".dialog-redEnve .dialog-content").css("background","none");
			            $(".ex-modal-close").click(function(){
			                javascript:redEnveSusp.close();
			            });
			            
			            //红包弹窗-打开红包
			            $('.draw_btn_per').on("click",function() {
			            	var parm1 = {
			    					"openId":openId,
			    					"ruleId":ruleId,
			    					"periodId":periodId,
			    					"robKey":robKey,
			    				};
			            	//此处访问接口获取奖品
			            	CommonRequest.request(parm1, CONFIG.ROB_REDPACK, function(resdata) {
		    					var flag = resdata.RSP_BODY.Data.flag;
		    					if(flag == '0'){
		    						currMoney=resdata.RSP_BODY.Data.money;
		    						 var redEnveSuspOpen=$(document).dialog({
		  			                   type : 'confirm',
		  			                   style: 'ios',
		  			                   content: '<div style="width:5.12rem;height:6rem;margin:0 auto;background: url(././images/luckDraw/ex-redEnveTan-g3.png) no-repeat;background-size: 5.12rem;">'+
		  			                                '<div class="open-modal-close" style="position:absolute;right:1.2rem;width:0.6rem;height:1.24rem;top:0;"></div>'+
		  			                                '<div style="position:absolute;bottom:1.1rem;left:0;right:0;width:4.4rem;margin:0 auto;text-align:center;">'+
		  			                                    '<p style="color:#fed000;"><span style="font-size:22px;">'+currMoney*100+'</span>&nbsp;e豆</p>'+
		  			                                    '<p style="color:#fff;padding-top:0.2rem;">恭喜您，获得<span>'+currMoney*100+'</span>e豆，可在个人中心-活动奖励中查看详情</p>'+
		  			                                '</div>'+
		  			                            '</div>',
		  			                    dialogClass:'dialog-redEnve'
		  			                });
		  			                $(".dialog-redEnve .dialog-content-ft").hide();
		  			                $(".dialog-redEnve .dialog-content-hd").hide();
		  			                $(".dialog-redEnve .dialog-content").css("background","none");
		  			                $(".open-modal-close").click(function(){
		  			                    javascript:redEnveSuspOpen.close();
		  			                });
		    					}else{
		    						alert(resdata.RSP_BODY.Data.msg);
		    					}
			    			});
			                javascript:redEnveSusp.close();
			            });
				}else{
					if(alertFlag == '0'){
						if($("#salerTypeVal").val() =='01' && ($("#bankCardNo").val() == '' || $("#bankCardNo").val() == 'null'))
							alertBindCard();
					}
					else
						alert(resdata.RSP_BODY.Data.msg);
				}
			});
		}
		
		
		vm.goRegister = function(){
			if($("#openId").val() == "")
			{
				alert("openid未获取，请关闭页面后重新进入");
				return;
			}
			
			$(document).dialog({
			       type : 'confirm',
			       style: 'ios',
			       titleText: '',
			       content: '<div style="text-align:left;">　　欢迎您关注“美好生活，建信人寿伴你行”微信专属推荐平台！<br/>　　建信人寿提醒您，通过平台身份注册认证，您可享受邀请好友、推荐产品等各种丰富多彩的活动权益。<br/>　　一起身份注册认证吧？</div>',
			       buttons: [          
			           {
			               name: '不用了',
			               callback: function() {
			               },
			           }, 
			           {
			               name: '好',
			               callback: function() {
			            	   $state.go('register');
			            	   return;
			               },
			           }
			       ]
				}
			);
		};
		
		// 广告banner
		vm.queryBannerList = function(callback) {
			vm.headBannerList = [];
			vm.midBannerList = [];
			vm.hotSaleProList = [];
			
			var params = {
			};

			CommonRequest.request(params, CONFIG.QUERY_BANNER_LIST, function(result) {
				vm.headBannerList = result.RSP_BODY.Data.headBannerList;
				vm.midBannerList = result.RSP_BODY.Data.midBannerList;
				
				// 热销产品
				$.ajax({
					cache: false,
					notRewrite:true,
					type: "GET",
//						url: domainInner+"/statics/weixinMarketing/811/productList.json",
						url: "./json/productList.js",
					data:null,
					dataType:"json",
					async: true,
					error: function(request) {
						alert("网络繁忙，请稍候再试");
					},
					success: function(resdata,state,xhr) {
						if(resdata.status=='1'){
							if(resdata.data.length>0){
								var totalProductList=resdata.data;
								$.each(totalProductList,function(index,product){
									if(product.isMarketingStatus == '1' && product.prdStatus == '2'  && product.saleStartDate <= nowstring && product.saleEndDate >= nowstring){
										vm.hotSaleProList.push(product);
									}
			 					});
							}
						}
						angular.isFunction(callback) && callback();
					}
				});
			});
		};
		

		var queryData = false;
		$scope.gofunction = function(page){
			if(!queryData)
			{
				//遮罩
				if($("#manageFlg").val() != "1")
				{
					var params = {
						"code":$("#code").val(),
						"openid":$("#openId").val(),
						"salerType":$("#salerTypeVal").val()
					};
					
					var parm = {"code":$("#code").val(),
						"openid":$("#openId").val(),
						"salerType":$("#salerTypeVal").val()
					};
					
					CommonRequest.request(params, CONFIG.HOME_LOAD, function(resdata) {
						queryData = true;
						var storage=window.localStorage;
						var manageFlg = resdata.RSP_BODY.Data.manageFlg;
						_jsVal("openId",resdata.RSP_BODY.Data.openId);
						_jsVal("manageFlg",manageFlg);
						
						storage.setItem("openId",resdata.RSP_BODY.Data.openId);
						storage.setItem("manageFlg",manageFlg);
						if(manageFlg == '1'){
							_jsVal("salerId",resdata.RSP_BODY.Data.salerId);
							_jsVal("pNo",resdata.RSP_BODY.Data.pNo);
							_jsVal("salerLevel",resdata.RSP_BODY.Data.salerLevel);
							_jsVal("bankCardNo",resdata.RSP_BODY.Data.bankCardNo);
							_jsVal("idCode",resdata.RSP_BODY.Data.idCode);
							
							storage.setItem("salerId",resdata.RSP_BODY.Data.salerId);
							storage.setItem("pNo",resdata.RSP_BODY.Data.pNo);
							storage.setItem("salerLevel",resdata.RSP_BODY.Data.salerLevel);
							storage.setItem("bankCardNo",resdata.RSP_BODY.Data.bankCardNo);
							storage.setItem("idCode",resdata.RSP_BODY.Data.idCode);
						}
						if(page != ""){
							 if($("#manageFlg").val() == "1")
								$state.go(page);
							else
								vm.goRegister();
						}
					});
				}
				else{
					if(page != "")
					{
						 if($("#manageFlg").val() == "1")
							$state.go(page);
						else
							vm.goRegister();
					}
				}
			}
			else
			{
				if(page != "")
				{
					 if($("#manageFlg").val() == "1")
						$state.go(page);
					else
						vm.goRegister();
				}
				
			}
		};
	
	
		$scope.alertBindCard = function(){
			$(document).dialog({
			       type : 'confirm',
			       style: 'ios',
			       titleText: '',
			       content: '您还没有绑定银行卡，请先绑定银行卡。银行卡可用于积分和e豆申请转账哦！',
			       buttons: [          
			           {
			               name: '暂不绑定',
			               callback: function() {
			               },
			           }, 
			           {
			               name: '去绑定',
			               callback: function() {
			            	   $state.go('personalModifyBank');
			               },
			           }
			       ]
			});
		};
		
		vm.loadingPage = function() {
			$timeout(function() {
				if ($rootScope.loadingPage) {
					/* manageFlg 0-未注册，1-已注册 */
					if($("#manageFlg").val() != "1"){
						setTimeout($scope.gofunction(""),500);	
					}

					
					if($("#salerId").val() != '')
					{
						vm.queryTodoTask($("#salerId").val(),$("#salerTypeVal").val());
						vm.checkRedPack($("#openId").val(),$("#salerTypeVal").val(),'0');
					}
					
					vm.queryBannerList();
				} else {
					vm.loadingPage();
				}
			}, 100);
		};
		vm.loadingPage();

		// 刷新
		vm.refresh = function() {
			vm.queryBannerList(function(){
				$rootScope.$broadcast('scroll.refreshComplete');
			});
		};
			
		
		
		
	}
	
})();