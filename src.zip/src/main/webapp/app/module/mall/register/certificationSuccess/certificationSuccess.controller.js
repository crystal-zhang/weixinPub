(function() {
	'use strict';

	angular
		.module('app')
		.controller('certificationSuccessController', certificationSuccessController);

	certificationSuccessController.$inject = ['$scope', 'CommonRequest', '$rootScope', 'CONFIG', '$timeout','$ionicPopup','$state'];

	/** @ngInject */
	function certificationSuccessController($scope, CommonRequest, $rootScope, CONFIG, $timeout,$ionicPopup,$state) {
		var vm=this;
		vm.loadRegisterSuccess=function(){
		 var delay = document.getElementById("countDownZ").innerHTML;
	 		var t = setTimeout("delayURL()", 1000);
	        if (delay > 0) {
	            delay--;
	            document.getElementById("countDownZ").innerHTML = delay;
	        } else {
	     		clearTimeout(t);
	     		goHome();
	        }      
		}
		function goHome(){
			window.localStorage.setItem("registerSuccess","1");
	    	location.href="home.do?openid="+$("#openId").val()+"&code="+$("#code").val()+"&state="+$("#salerTypeVal").val();
		}

		vm.loadRegisterSuccess();//默认进入
	}
})();