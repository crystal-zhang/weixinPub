(function() {
	'use strict';

	angular
		.module('app')
		.controller('personalInforAreaController', personalInforAreaController);

	personalInforAreaController.$inject = ['$scope', 'CommonRequest', '$rootScope', 'CONFIG', '$timeout','$ionicPopup','$state','$ionicHistory'];

	/** @ngInject */
	function personalInforAreaController($scope, CommonRequest, $rootScope, CONFIG, $timeout,$ionicPopup,$state,$ionicHistory) {
		var vm=this;
		var province = [];//省
		var city = [];//市
		var district = [];//区
		/* 已选择省 (数据格式{provinceCode:123,provinceName:安徽省}) */
		var selectProvince = {};
		/* 已选择市 (数据格式{cityCode:123,cityName:蚌埠市}) */
		var selectCity = {};
		/* 已选择区(数据格式{districtCode:123,districtName:固镇县})  */
		var selectDistrict = {};
		var selectArea = {};
		var expressArea, areaCont, areaList = $("#areaList");
		var areajson = "";
		var prdid = "";
		
		vm.loadArea=function(){//加载区域
			var params = {
			};
			CommonRequest.request(params, CONFIG.QUERY_REGISTAREA_LIST, function(Presult) {
//				prdid = Presult.RSP_BODY.Data.prdid;//10044
				prdid="10044";
//				areajson = prdid  + "."+jsonName;
				areajson = prdid  + ".js";
				$scope.getProvinceData();
			})
		 	
		}
		
		/* 查询省信息 */
		$scope.getProvinceData=function(){
				$.ajax({
					cache: false,
					async:false,  
					notRewrite:true,
					type: "GET",
					url: domainInner + "/statics/product/areas/"+prdid+"/"+areajson,
					data:null,
					dataType:"json",
					error: function(request) {
						alert("网络繁忙，请稍候再试");
					},
					success: function(resdata,state,xhr) {
						province=resdata;
						intProvince();//初始化省的信息
					}
				});
		}
		/* 查询市信息 */
		function getCityData(provinceCode){
				$.ajax({
					cache: false,
					notRewrite:true,
					type: "GET",
					url: domainInner + "/statics/product/areas/"+prdid+"/"+provinceCode+"/"+areajson,
					data:null,
					dataType:"json",
					async: false,
					error: function(request) {
						alert("网络繁忙，请稍候再试444");
					},
					success: function(resdata,state,xhr) {
						city = resdata;
					}
				});
		}
		/* 查询区信息 */
		function getDistrictData(provinceCode,cityCode){
				$.ajax({
					cache: false,
					notRewrite:true,
					type: "GET",
					url: domainInner + "/statics/product/areas/"+prdid+"/"+provinceCode+"/"+cityCode+"/"+areajson,
					data:null,
					dataType:"json",
					async: false,
					error: function(request) {
						alert("网络繁忙，请稍候再试666");
					},
					success: function(resdata,state,xhr) {
						district = resdata;
					}
				});
		}
		
		   /*初始化省份*/
		   function intProvince() {
				areaCont = "";
				$("#areaList").empty();
				for (var i=0; i<province.length; i++) {
					$("#areaList").append('<li class=\'province\' areaCode=\''+province[i].areaCode+'\', areaName=\''+province[i].areaName+'\' >' + province[i].areaName + '</li>');
				}
				
				$(".province").click(function(e){
					selectP($(this).attr("areaCode"),$(this).attr("areaName"));
					e.preventDefault();
				});
				
				$("#areaBox").scrollTop(0);
				$("#backUp").show();
//				$("#backUp").removeAttr("onClick").hide();
				
			}
		   
		   /*选择省份*/
		  function selectP(provinceCode,provinceName) {
			  	getCityData(provinceCode);
			  	/* 省信息 值存储 */
			  	selectProvince.provinceCode=provinceCode;
			  	selectProvince.provinceName=provinceName;
			  	selectArea.selectProvince=selectProvince;
			  	
				$("#areaList").empty();
				for (var i=0; i<city.length; i++) {
					$("#areaList").append('<li class=\'city\' areaCode=\''+city[i].areaCode+'\', areaName=\''+city[i].areaName+'\' >' + city[i].areaName + '</li>');
				}
				
				$(".city").click(function(e){
					selectC(provinceCode,provinceName,$(this).attr("areaCode"),$(this).attr("areaName"));
					e.preventDefault();
				});

				$("#areaBox").scrollTop(0);
		    	expressArea = provinceName + " > ";
		    	
//		    	$("#backUp").attr("onClick", "intProvince()").show();
		    }
		 

		  

		   /*选择城市*/
		   function selectC(provinceCode,provinceName,cityCode,cityName) {
		   	getDistrictData(provinceCode,cityCode);
		   	
			/* 市信息 值存储  */
		  	selectCity.cityCode=cityCode;
		  	selectCity.cityName=cityName;
		  	selectArea.selectCity=selectCity;
		   	
			$("#areaList").empty();
			for (var i=0; i<district.length; i++) {
				$("#areaList").append('<li class=\'district\' areaCode=\''+district[i].areaCode+'\', areaName=\''+district[i].areaName+'\' >' + district[i].areaName + '</li>');
			}
			
			$(".district").click(function(e){
				selectD($(this).attr("areaCode"),$(this).attr("areaName"));
				e.preventDefault();
			});
			
		   	$("#areaList").scrollTop(0);
		   	
		   	expressArea += cityName + " > ";
		   	
//		   	$("#backUp").attr('onClick', 'selectP(\''+provinceCode+'\',\''+provinceName+'\')');
		   }

		   /*选择区县*/
		   //最终将所选的省市区返回到注册页面
		   function selectD(districtCode,districtName) {
			   /* 区信息 值存储  */
			  	selectDistrict.districtCode=districtCode;
			  	selectDistrict.districtName=districtName;
			  	selectArea.selectDistrict=selectDistrict;
		   
			  	var from = '{{from}}';
			  	if(from != 'register')
			  	{
				   	expressArea += districtName;
				   	
				   	
				   	$("#expressArea dl dd").html(expressArea);
				   	
					var saler = {};
					saler.name = '{{saler.name}}';
					saler.eduLevel = '{{saler.eduLevel}}';
					saler.cardType = '{{saler.cardType}}';
					saler.idNo = '{{saler.idNo}}';
					$state.go('register');//跳到区域列表页
//					window.pageManager.update('register',{'areaPath':selectArea,'saler':saler,'nameFlag':{{nameFlag}},'idNoFlag':{{idNoFlag}}});
//				   	javascript:window.pageManager.go('register');
			  	}else{
			  		
			  		var data = {};
			  		data.salerId = $("#salerId").val();
			  		data.provinceCode = selectProvince.provinceCode;
			  		data.provinceName = selectProvince.provinceName;
			  		data.cityCode = selectCity.cityCode;
			  		data.cityName = selectCity.cityName;
			  		data.districtCode = selectDistrict.districtCode;
			  		data.districtName = selectDistrict.districtName;
			  		
					$.ajax({
						cache: false,
						type: "POST",
						url: "register/registerSaler.json",
						data: data,
						dataType:"json",
						async: true,
						error: function(request) {
							alert("网络繁忙，请稍候再试666");
						},
						success: function(resdata,state,xhr) {
							alert("来这里了吗");
//						   	javascript:window.pageManager.go('personalInformation');
						}
					});	  		
			  	}
		   }
//
		   /*关闭省市区选项*/
		   function clockArea() {
			   	$("#areaMask").fadeOut();
			   	$("#areaLayer").animate({"bottom": "-100%","top":"0"});
			   	intProvince();
		   }
//		   $(function() {
//		   	
//				/*打开省市区选项*/
////				$("#expressArea").click(function() {
//					$("#areaMask").fadeIn();
//					$("#areaLayer").animate({"bottom": 0,"top":"0"});
////				});
//				/*关闭省市区选项*/
//				$("#areaMask, #closeArea").click(function() {
//					window.pageManager.update('personalInformation',{'areaPath':selectArea});
//					javascript:window.pageManager.go('personalInformation');
//					clockArea();
//				});
//			});
	   // 返回上一级
	   $scope.back = function() {
		   $ionicHistory.goBack();
        };
		
		vm.loadArea();//默认进入
	}
})();