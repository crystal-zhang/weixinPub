(function() {
	'use strict';

	angular
		.module('app')
		.controller('registerController', registerController);

	registerController.$inject = ['$scope', 'CommonRequest', '$rootScope', 'CONFIG', '$timeout','$ionicPopup','$state'];

	/** @ngInject */
	function registerController($scope, CommonRequest, $rootScope, CONFIG, $timeout,$ionicPopup,$state) {
		var vm=this;
		var idTypeMap;
		/*协议容器*/
    	var $protoDomMy;
		var protocolContent = document.createElement("div");
		var $protocolContent = $(protocolContent);
		var pNo=$("#pNo").val();//营销员编号
		var salerType=$("#salerTypeVal").val();//营销员类别主要区分客户经理和非客户经理
		var random=Math.random();//产生一个0~1之间的随机数
		var curCount='60';//短信验证计时
		var InterValObj;
		var imageCodeUrl="";
		//以下变量主要是为了区别客户经理和非客户经理
		var nameFlag=false;var idNoFlag=false;var salerNumFlag=false;var phoneFlag=false;var messageCodeFlag=false;
		
		vm.loadRegister=function(){
//			$scope.forbidSubmit();
			var params = {
			};
			CommonRequest.request(params, CONFIG.REGISTER_INIT, function(result) {
				var data = result.RSP_BODY.Data;
				//初始化图片验证码
				imageCodeUrl=data.verifyCode;
				$(".imageCode").attr("src", imageCodeUrl+"?random="+random);
				var salerTypeList=data.salerTypeList;
				if(salerTypeList.length>0){//加载保代公司的公司名字
					angular.forEach(salerTypeList,function(salerType,index){
						$("#idType").append("<option value="+salerType.idCode+">"+salerType.name+"</option>");
					});
				}
				//根据客户经理和非客户经理来决定页面哪些字段需要
				if(salerType=='01'){
					$(".salerType02").remove();
					//加载协议信息
					var protrocolparams = {
					};
					CommonRequest.request(protrocolparams, CONFIG.REGISTER_LOAD_PROTROCOL, function(Presult) {
						var salerTypeListP = Presult.RSP_BODY.Data.salerTypeList;
						idTypeMap=new Object();
						angular.forEach(salerTypeListP,function(salerType,index){
							idTypeMap[salerType.idCode]=salerType;
						});
					})
				}else{
					$(".salerType01").remove();
				}
			});
		}
		
		
		
		$("#idType").change(function(){
			var idType=$("#idType").val();
			if(idType!=''){
				if(idTypeMap[idType].protocolContent!=''){//协议文本
					$("#protocol").show();
					$("#protocol").find("a").eq(0).text("《"+idTypeMap[idType].protocolName+"》");
					$('#protocolRead').prop('checked',false);//将单选框给取消掉
					$protocolContent.html(idTypeMap[$("#idType").val()].protocolContent);
					$protoDomMy=$protocolContent;//这里的DOMMy是一个超链接形式的，专门给建行代保公司的
				}else if(idTypeMap[idType].protocolPath){//协议pdf
					$("#protocol").show();
					$("#protocol").find("a").eq(0).text("《"+idTypeMap[idType].protocolName+"》");
					$('#protocolRead').prop('checked',false);//将单选框给取消掉
					$protocolContent.empty();
					$scope.aaa(idTypeMap[$("#idType").val()].protocolPath);
				}else{
					$("#protocol").hide();
				}
			}else{
				$("#protocol").hide();
			}
		});
		 $scope.aaa=function(path){
			 var pdfDomMy='<div id="innerPdf" style="width:100%;height:9rem !important;"></div>';
		    	$("#myPdfContainer").append(pdfDomMy);
				PDFJS.getDocument(path).then(function getPdfHelloWorld(pdf) {
				  for (var i = 0; i <= pdf.numPages; i++) {
					pdf.getPage(i).then(function getPageHelloWorld(page) {
					  var scale = 1;
					  var viewport = page.getViewport(scale);
					  var canvas = document.createElement('canvas');
					  var context = canvas.getContext('2d');
					  canvas.height = viewport.height;
					  canvas.width = viewport.width;
					  $("#innerPdf").append(canvas);
					  page.render({canvasContext: context, viewport: viewport});
					});
				  }
				  $protoDomMy=$("#innerPdf");
				}); 
		 }
		
		//切换图形验证码
		$scope.changeimageCode=function(){
			random=Math.random();
			$(".imageCode").attr("src",imageCodeUrl+"?random="+random);
		}
		
		//获取手机短信验证码
		$scope.choosemessageCode=function(){
			var imageCode=$("#imageCode").val().trim();
			var phone=$("input[name='phone']").val().trim();
			if(imageCode==''){
				alert("图片验证码不能为空!");
				return ;
			}
			if(phone==''){
				alert("手机号不能为空!");
				return ;
			}else if(phone.match(/^(1\d{10}$/)==null){
				alert("请输入正确的手机号码。");
				return ;
			}
			$(".au-vCode").css("pointer-events","none");
			var params = {
					phone:phone,
					imageCode:imageCode,
					random:random,
					salerType:$("#salerTypeVal").val()
			};
			CommonRequest.request(params, CONFIG.REGISTER_MESSAGECODE, function(resdata) {
				if(resdata.RSP_HEAD.Type!='1'){
//					$(".au-vCode").removeAttr("disabled");//启用按钮
					 $(".au-vCode").css("pointer-events","auto");
					 $(".au-vCode").css("background","#09b6f2");
					alert(resdata.RSP_BODY.ErrorMessage);
				}else{
					$(".au-vCode").css("background","#ddd");
					InterValObj = window.setInterval(setRemainTime, 1000); //启动计时器，1秒执行一次	
		 			return;
				}
				})
		}
		
		 $("#submit").click(function(){
			 //数据校验
			 if($("input[name=name]").val().trim()==''){
				alert("姓名不能为空。");
				return ;
			 }
			 if (!retxtName.test($("input[name=name]").val())){
				 	alert("您输入的姓名格式不正确");
//					alert("姓名只能为汉字、字母、.");
					return;
				}
			 if($("input[name=name]").val().trim()!=''){
				 if($("input[name=name]").val().trim().length>30){
					alert("姓名不能超过30个汉字。");
					return ;
				}
			 }
			 if($("input[name=idNo]").val().trim()==''){
				 alert($("#cardType option").not(function(){ return !this.selected }).text()+"号码不能为空。");
				 return ;
			 }
			 if($("input[name=idNo]").val().trim()!=''){
					if($("#cardType").val()=='A'){//身份证
						if(!($("input[name=idNo]").val().trim().length==15||$("input[name=idNo]").val().trim().length==18)){
							alert("您输入的证件号码格式不正确。");
//							alert("身份证号应为15或18位。");
							return ;
						}
						if(!checkIdCard($("input[name=idNo]").val().trim())){
							return;
						}
					}else{
						if($("input[name=idNo]").val().trim().length<8||$("input[name=idNo]").val().trim().length>30){
//							alert($("#cardType option").not(function(){ return !this.selected }).text()+"号码应为9至30位。");
							alert("您输入的证件号码格式不正确。");
							return ;
						}
					}
			}
			 if (salerType == '02'&&!retxtSalerNum.test($("#salerNum").val())){
				alert("营销员编号必须由6~12位字母和数字组成");
				return;
			}
			if(salerType == '01'&& $("#idType").val()==''){
				alert("请选择保代公司。");
				return ;
			}
			if($("input[name='phone']").val().trim()==''){
				alert("手机号不能为空。");
				return ;
			}
			
			if(salerType == '02'&& $("#salerNum").val().trim()==''){
				alert("营销员编号不能为空。");
				return ;
			}
			if($("input[name='phone']").val().trim().match(/^((17[0-9])|(14[0-9])|(13[0-9])|(15[^4,\D])|(18[0-9]))\d{8}$/)==null){
				alert("请输入正确的手机号码。");
//				alert("手机号有误。");
				return ;
			}
			if($("#messageCode").val().trim()==''){
				alert("短信验证码不能为空。");
				return ;
			}
			if($("#areaVal").val().trim()==''){
				alert("请选择所在区域。");
				return ;
			}

			if(salerType == '01'&& $("#protocol").css("display")!="none"){
				if(!$('#protocolRead').is(":checked")){
					alert("请先阅读并同意协议。");
					return ;
				}
			}
			var dataObject=new Object();
				dataObject.name=$("input[name='name']").val().trim();
				dataObject.phone=$("input[name='phone']").val().trim();
				dataObject.messageCode=$("#messageCode").val().trim();
				dataObject.pNo=pNo;
				dataObject.salerType=salerType;
				dataObject.openId=$("#openId").val();
				dataObject.cardType=$("#cardType").val();
				dataObject.idNo=$("input[name='idNo']").val().trim();
				dataObject.eduLevel=$("#eduLevel").val();
				
			if(salerType == '01'){
				dataObject.idType=$("#idType").val();
				dataObject.isNormal=$("input[name='type']:checked").val().trim();
			}else if(salerType == '02'){
				dataObject.salerNum=$("#salerNum").val();
			}
			
			dataObject.area=$("#areaVal").val();
			showLoad(10000);
//			//认证
			CommonRequest.request(dataObject, CONFIG.REGISTER_SUBMIT, function(resdata) {
				if(resdata.RSP_HEAD.Type!='1'){
					alert(resdata.RSP_BODY.ErrorMessage);
				}else{
					$state.go('certificationSuccess');//跳到认证成功页面
				}
			})
		 });
		
		
		
		$("input[name=idNo]").blur(function(){
			if($("input[name=idNo]").val().trim()!=''){
				if($("#cardType").val()=='A'){//身份证如果长度不为15或者18则直接报错
					if(!($("input[name=idNo]").val().trim().length==15||$("input[name=idNo]").val().trim().length==18)){
						alert("您输入的证件号码格式不正确。");
						return ;
					}
					//当身份是15或18位时再去验证是否规则
					$scope.checkIdCard($("input[name=idNo]").val().trim());
				}else{
					if($("input[name=idNo]").val().trim().length<8||$("input[name=idNo]").val().trim().length>30){
						alert("您输入的证件号码格式不正确。");
//						alert($("#cardType option").not(function(){ return !this.selected }).text()+"号码应为9至30位。");
						return ;
					}
				}
			}
		});
		$("input[name='phone']").change(function(){
			var phone=$("input[name='phone']").val().trim();
			if(phone==''){
				alert("手机号不能为空!");
				return ;
			}else if(phone.match(/^((17[0-9])|(14[0-9])|(13[0-9])|(15[^4,\D])|(18[0-9]))\d{8}$/)==null){
				alert("请输入正确的手机号码。");
				return ;
			}
			phoneFlag=true;
		});
		
		$("input[name='phone']").bind('input',function(){
			$scope.checkFlag('phone');
			if($scope.checkRegister()){
				$scope.allowSubmit();
			}else{
				$scope.forbidSubmit();
			}
		});
		function setRemainTime(){
		 if (curCount == 0) {
		    	$(".au-vCode").css("background","#09b6f2");
		        window.clearInterval(InterValObj);//停止计时器
//		        $(".au-vCode").removeAttr("disabled");//启用按钮
		        $(".au-vCode").css("pointer-events","auto");
		        $(".au-vCode").html("免费获取");
		        curCount='60';
		    }else {
		        curCount--;
		        $(".au-vCode").html(curCount + "s后获取");
		    }
		}
		//选择省市区的三级联动
		$scope.chooseArea=function(){
//			var saler = {};
//			saler.name = $("input[name=name]").val();
//			saler.eduLevel = $("#eduLevel").val();
//			saler.cardType = $("#cardType").val();
//			saler.idNo = $("input[name='idNo']").val();
//			var a1='0',a2='0';
//			if(nameFlag){
//				a1 = '1';}
//			if(idNoFlag){
//				a2 = '1';}
			$state.go('personalInforArea');//跳到区域列表页
//			window.pageManager.update('personalInforArea',{'from':'register','saler':saler,'nameFlag':a1,'idNoFlag':a2});
//	 		javascript:window.pageManager.go('personalInforArea');
//			e.preventDefault();
		}
		
		
		
		
		$scope.generalUserInstructions=function(){//普通用户说明提示
			 var confirmPopup = $ionicPopup.confirm({
	               title: '普通用户和非普通用户的区别是什么呢？',
	               template: '普通用户指非集团员工，推荐购买成功后，积分按100:1比例兑换等值1元人民币商品或转账额度;非普通用户推荐购买成功后，积分可兑换等值善融商务券',
	               buttons:[{
	            	    text: '确定',
	            	    type: 'button-positive',
	            	    onTap: function(e) {
	            	    }
	            	  }]
	             });
		}
		
		//禁用认证按钮
		$scope.forbidSubmit=function(){
			$("#submit").css({"background":"#ddd!important","pointer-events":"none","border-color":'#ddd',"color":'#FFF!important'});
		}
		//启用认证按钮
		$scope.allowSubmit=function(){
			$("#submit").css({"background":"#09b6f2!important","pointer-events":"auto","border-color":'#09b6f2',"color":'#FFF!important'});
		}
		
		$scope.checkIdCard=function(str){//验证身份证号码
			str = str.toUpperCase();
            //身份证号码为15位或者18位，15位时全为数字，18位前17位为数字，最后一位是校验位，可能为数字或字符X。
            if (!(/(^\d{15}$)|(^\d{17}([0-9]|X)$)/.test(str))) {
                alert('输入的身份证号长度不对，或者号码不符合规定！\n15位号码应全为数字，18位号码末位可以为数字或X。');
                return false;
            }
            //校验位按照ISO 7064:1983.MOD 11-2的规定生成，X可以认为是数字10。
            //下面l分别分析出生日期和校验位
            var len = str.length,
                re,
                arrSplit,
                dtmBirth,
                bGoodDay,
                arrInt,
                arrCh,
                nTemp,
                i;

            if (len == 15) {
                re = new RegExp(/^(\d{6})(\d{2})(\d{2})(\d{2})(\d{3})$/);
                arrSplit = str.match(re);

                //检查生日日期是否正确
                dtmBirth = new Date('19' + arrSplit[2] + '/' + arrSplit[3] + '/' + arrSplit[4]);
                bGoodDay;
                bGoodDay = (dtmBirth.getYear() == Number(arrSplit[2])) && ((dtmBirth.getMonth() + 1) == Number(arrSplit[3])) && (dtmBirth.getDate() == Number(arrSplit[4]));
                if (!bGoodDay) {
                    alert('输入的身份证号里出生日期不对！');
                    return false;
                } else {
                    //将15位身份证转成18位
                    //校验位按照ISO 7064:1983.MOD 11-2的规定生成，X可以认为是数字10。
                    arrInt = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);
                    arrCh = new Array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
                    nTemp = 0;
                    str = str.substr(0, 6) + '19' + str.substr(6, str.length - 6);
                    for (i = 0; i < 17; i++) {
                        nTemp += str.substr(i, 1) * arrInt[i];
                    }
                    str += arrCh[nTemp % 11];
                    return true;
                }
            }
            if (len == 18) {
                re = new RegExp(/^(\d{6})(\d{4})(\d{2})(\d{2})(\d{3})([0-9]|X)$/);
                arrSplit = str.match(re);

                //检查生日日期是否正确
                dtmBirth = new Date(arrSplit[2] + "/" + arrSplit[3] + "/" + arrSplit[4]);
                bGoodDay;
                bGoodDay = (dtmBirth.getFullYear() == Number(arrSplit[2])) && ((dtmBirth.getMonth() + 1) == Number(arrSplit[3])) && (dtmBirth.getDate() == Number(arrSplit[4]));
                if (!bGoodDay) {
                    //alert(dtmBirth.getYear());
                    //alert(arrSplit[2]);
                    alert('输入的身份证号里出生日期不对！');
                    return false;
                } else {
                    //检验18位身份证的校验码是否正确。
                    //校验位按照ISO 7064:1983.MOD 11-2的规定生成，X可以认为是数字10。
                    var valnum;
                    arrInt = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);
                    arrCh = new Array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
                    nTemp = 0;
                    for (i = 0; i < 17; i++) {
                        nTemp += str.substr(i, 1) * arrInt[i];
                    }
                    valnum = arrCh[nTemp % 11];
                    if (valnum != str.substr(17, 1)) {
                        alert('18位身份证的校验码不正确！应该为：' + valnum);
                        return false;
                    }
                    return true;
                }
            }
            return false;
		}
		
		$scope.checkFlag=function(flag){
			if(flag == 'name')
			{
				if($("input[name=name]").val().length!=0){
					nameFlag=true;
				}else{
					nameFlag=false;
				}
			}
			else if(flag == 'idNo')
			{
				if($("input[name=idNo]").val().length!=0){
					idNoFlag=true;
				}else{
					idNoFlag=false;
				}
			}
			else if(flag == 'phone')
			{
				if($("input[name='phone']").val().length!=0){
					phoneFlag=true;
				}else{
					phoneFlag=false;
				}
			}
			else if(flag == 'salerNum')
			{
				if($("#salerNum").val().length!=0){
					salerNumFlag=true;
				}else{
					salerNumFlag=false;
				}
			}
			else if(flag == 'messageCode')
			{
				if($("#messageCode").val().length!=0){
					messageCodeFlag=true;
				}else{
					messageCodeFlag=false;
				}
				
			}
		}
		
		$scope.checkRegister=function(){
			if($("#salerTypeVal").val() == '01'){//普通用户
				if(nameFlag&&idNoFlag&&phoneFlag&&messageCodeFlag){
					return true;
				}else{
					return false;
				}
			}else{//客户经理
				if(nameFlag&&idNoFlag&&salerNumFlag&&phoneFlag&&messageCodeFlag){
					return true;
				}else{
					return false;
				}
			}
		}
		
		vm.loadRegister();//默认进入
	}
})();