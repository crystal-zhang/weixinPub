(function() {
	'use strict';

	angular
		.module('app')
		.controller('secondController', secondController);

	secondController.$inject = ['$scope', '$state', 'CommonRequest', '$rootScope', 'CONFIG'];

	/** @ngInject */
	function secondController($scope, $state, CommonRequest, $rootScope, CONFIG) {
		var vm = this;

		alert("第二个页面")
			
		
		
		
	}
	
})();