(function() {
	'use strict';

	angular
		.module('app', ['ionic', 'templates', 'ngFileUpload', 'ionic-datepicker'])

    angular.module('templates', []);

})();
