(function() {
    'use strict';

    angular
        .module('app')
        .config(routerConfig);

    routerConfig.$inject = ['$stateProvider', '$urlRouterProvider', '$ionicConfigProvider', '$httpProvider'];

    /** @ngInject */
    function routerConfig($stateProvider, $urlRouterProvider, $ionicConfigProvider, $httpProvider) {
        // 默认的 timeout
        $httpProvider.defaults.timeout = 6;

        // ionicConfigProvider
        // 在 android 中依然使用 iOS style
        $ionicConfigProvider.views.transition('ios');
        $ionicConfigProvider.tabs.style('standard').position('bottom');
        $ionicConfigProvider.navBar.alignTitle('center').positionPrimaryButtons('left');

        // 不用缓存
        // $ionicConfigProvider.views.maxCache(0);
        // backbtn 取消文字
        $ionicConfigProvider.backButton.previousTitleText(false);
        $ionicConfigProvider.backButton.text('');

        // 禁止滑动返回，这是因为返回界面需要有一些前置操作
        $ionicConfigProvider.views.swipeBackEnabled(false);

        // Ionic uses AngularUI Router which uses the concept of states
        // Learn more here: https://github.com/angular-ui/ui-router
        // Set up the various states which the app can be in.
        // Each state's controller can be found in controllers.js
        $stateProvider
        	// tab
            .state('tab', {
                url: '/tab',
                abstract: true,
                templateUrl: 'app/module/tabs/tabs.html'
            })
            // mall
            .state('tab.mall', {
                url: '/mall',
                views: {
                    'tab-mall': {
                        templateUrl: 'app/module/mall/main/main.html',
                        controller: 'MallController',
                        controllerAs: 'mall'
                    }
                }
            })
            
            //第二个页面
            .state('mail.html', {
                url: '/second',
                views: {
                    'mail': {
                        templateUrl: 'app/module/second/main.html',
                        controller: 'secondController',
                        controllerAs: 'second'
                    }
                }
            })
  
       

        // if none of the above states are matched, use this as the fallback
        $urlRouterProvider.otherwise('/tab/mall');
    }

})();