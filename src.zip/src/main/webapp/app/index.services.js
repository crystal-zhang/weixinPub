(function() {
    'use strict';

    angular
        .module('app')
        .service('NetworkService', NetworkService)
        .service('CommonRequest', CommonRequest)
        .service('PendingRequestsService', PendingRequestsService)
        .service('TipService', TipService);

    NetworkService.$inject = ['$state', '$rootScope', '$http', '$q', 'PendingRequestsService', '$timeout', 'CONFIG', 'TipService'];
    CommonRequest.$inject = ['NetworkService', 'CONFIG', '$ionicLoading'];
    PendingRequestsService.$inject = ['$rootScope'];
    TipService.$inject = ['CONFIG', '$ionicPopup', '$ionicBackdrop', '$timeout', '$rootScope'];

    /** @ngInject */

    // 网络请求
    // @httpConfig {Object}
    //      .url    {String} 请求地址
    //      .method {String} 请求方式POST/GET
    function NetworkService($state, $rootScope, $http, $q, PendingRequestsService, $timeout, CONFIG, TipService) {
        // 请求处理
        this.httpExecute = function(httpConfig) {
            if (!httpConfig) {
                return $q.reject({
                    success: false,
                    message: 'no http config',
                    code: 'NO_HTTP_CONFIG'
                });
            }

            var deferred = $q.defer(),
                requestDone = false;

            PendingRequestsService.add({
                url: httpConfig.url,
                deferred: deferred
            });

            // http header 插入 token
            httpConfig.headers = httpConfig.headers || {};

            var httpHeader;
            if ($rootScope.userData) {
                var custId = $rootScope.userData.cusId;
                var token = $rootScope.userData.token;
                httpHeader = {
                    // 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'x-token': token,
                    'x-channelCode': CONFIG.NEW_SALE_CHANNEL,
                    'x-custId': custId,
                    'x-timestamp': new Date().getTime()
                };
            } else {
                httpHeader = {
                    'x-channelCode': CONFIG.NEW_SALE_CHANNEL,
                    'x-timestamp': new Date().getTime()
                };
            }

            httpConfig.timeout = CONFIG.REQUEST_TIMEOUT;
            if (!httpConfig.timeout) {
                httpConfig.timeout = deferred.promise;
            }

            angular.extend(httpConfig.headers, httpHeader);

            $timeout(function() {
                if (!requestDone) {
                    TipService.showMsg($rootScope.TIPS.SYSTEM.TIMEOUT);
                    deferred.resolve($rootScope.TIPS.SYSTEM.TIMEOUT);
                }
            }, CONFIG.REQUEST_TIMEOUT);

            $.ajax({
				cache: false,
				notRewrite:true,
				type: httpConfig.method,
				url: httpConfig.url,
				data:httpConfig.data,
				dataType:"json",
				async: true,
				error: function(request) {
					alert("网络繁忙，请稍候再试");
				},
				success: function(resdata,state,xhr) {
                    requestDone = true;
                    deferred.resolve(resdata);
				}
			});
            
//            $http(httpConfig)
//                .then(function(result) {
//                    requestDone = true;
//
//                    errorCatch(result);
//
//                    deferred.resolve(result.data);
//                })
//                .catch(function(error) {
//                    requestDone = true;
//
//                    errorCatch(error);
//
//                    deferred.resolve(error.data);
//
//                    throw error;
//                });

            // error catch
            function errorCatch(error) {
                var httpStatus = error.status,
                    httpData = error.data;

                var msg = $rootScope.TIPS.SYSTEM.REQUEST_ERROR;

                if (httpStatus === 0) {
                    msg = $rootScope.TIPS.SYSTEM.NETWORK_ERROR;
                } else {
                    if (!httpData) {
                        msg = $rootScope.TIPS.SYSTEM.REQUEST_ERROR;
                    } else {
                        if (httpData.error) {
                            // 登录失效处理
                            if (httpData.error.code && httpData.error.code.indexOf('X159019000') != -1) {
                                $rootScope.isLogin = false;
                                $rootScope.userData = null;

                                if (sessionStorage) {
                                    sessionStorage.removeItem('elife-login');
                                    sessionStorage.removeItem('elife-loginStatus');
                                    sessionStorage.removeItem('elife-userData');
                                }
                                $state.go('tab.mall');
                            }

                            // msg = httpData.error.message + '\n错误代码: ' + httpData.error.code;
                            msg = httpData.error.message;

                            if (httpData.error.code && httpData.error.message.indexOf('服务异常，小的正在拼命拯救中，请客官稍后再试试~') != -1) {
                                msg = '系统繁忙，请您稍后重试，谢谢';
                            }

                            // 暂时过滤
                            if (httpData.error.code && httpData.error.code.indexOf('44014') == -1) {
                                msg && TipService.showMsg(msg);
                            }
                        }
                    }
                }
            }

            return deferred.promise;
        };
    }

    // 通用请求
    function CommonRequest(NetworkService, CONFIG, $ionicLoading) {

        var requestService = this;

        /**
         **根据请求不同的字段生成缓存的名字
         **/
        this.getRequestName = function(params, requestCode) {
            var requestCodeList = requestCode.split(",");
            var stringName = '';
            for (var i = 0; i < requestCodeList.length; i++) {
                if (i == 0) {
                    stringName = eval('params.' + requestCodeList[i]);
                } else {
                    stringName = stringName + '-' + eval('params.' + requestCodeList[i]);
                }
            }
            return stringName;
        };

        /**
         ** 存储接口调用后拿到的数据
         ** params 请求的参数
         ** data 缓存的数据
         ** sessionName 缓存的名称
         ** requestCode 区分请求的字段
         **/
        this.setSessionCache = function(params, data, sessionName, requestCode) {
            if (requestCode) {
                var stringName = requestService.getRequestName(params, requestCode);
                data = angular.toJson(data);
                sessionStorage.setItem(sessionName + '-' + stringName, data);
            } else {
                data = angular.toJson(data);
                sessionStorage.setItem(sessionName, data);
            }
        };

        /**
         ** 获取对应的缓存数据
         ** params 请求的参数
         ** sessionName 缓存的名称
         ** requestCode 区分请求的字段
         **/
        this.getSessionCache = function(params, sessionName, requestCode) {
            var result;
            if (requestCode) {
                var stringName = requestService.getRequestName(params, requestCode);
                result = sessionStorage.getItem(sessionName + '-' + stringName);
            } else {
                result = sessionStorage.getItem(sessionName);
            }
            return result;
        };

        /**
         ** 存储调用需要缓存接口的时间
         ** params 请求的参数
         ** sessionName 缓存的名称
         ** requestCode 区分请求的字段
         **/
        this.setSessionTime = function(params, sessionName, requestCode) {
            var requestTime = new Date().getTime();
            if (requestCode) {
                var stringName = requestService.getRequestName(params, requestCode);
                sessionStorage.setItem(sessionName + '-' + stringName + '-cacheTime', requestTime);
            } else {
                sessionStorage.setItem(sessionName + '-cacheTime', requestTime);
            }
        };

        /**
         ** 获取上次调用该接口所用的时间
         ** params 请求的参数
         ** sessionName 缓存的名称
         ** requestCode 区分请求的字段
         **/
        this.getSessionTime = function(params, sessionName, requestCode) {
            var data;
            if (requestCode) {
                var stringName = requestService.getRequestName(params, requestCode);
                data = sessionStorage.getItem(sessionName + '-' + stringName + '-cacheTime');
            } else {
                data = sessionStorage.getItem(sessionName + '-cacheTime');
            }
            return data;
        };

        /*
         ** params 请求的参数
         ** config 请求地址和请求方式的配置
         ** callback 成功回调
         */
        this.request = function(params, config, callback, hideLoading) {
            !hideLoading && $ionicLoading.show({
                template: '<ion-spinner icon="bubbles"></ion-spinner>'
            });

            var httpConfig;
            if (config.method == 'GET') {
                httpConfig = angular.extend({
                    params: params || {}
                }, config);
            } else {
                httpConfig = angular.extend({
                    data: params || {}
                }, config);
            }

            if (params && config) {
                var result;
                var needcache;
                var sessionName;
                var requestCode;
                // 判断调用接口是否需要缓存
                requestService.needCache(config.url, params, function(cache, cacheName, requestName) {
                    needcache = cache;
                    sessionName = cacheName;
                    requestCode = requestName;
                });
                //需要缓存则调用缓存，不需要则直接调用接口
                if (needcache == 1 || needcache == 2) {
                    // 从缓存中读取数据
                    result = requestService.getSessionCache(params, sessionName, requestCode);
                    // 缓存中的数据不存在则调用接口
                    if (!result || needcache == 2) {
                        NetworkService.httpExecute(httpConfig).then(function(result) {
                            !hideLoading && $ionicLoading.hide();
                            // 根据请求参数存入缓存
                            if (result) {
                                requestService.setSessionCache(params, result, sessionName, requestCode);
                                requestService.setSessionTime(params, sessionName, requestCode);
                            }

                            // result = JSON.parse(result);
                            angular.isFunction(callback) && callback(result);
                        });
                    } else {
                        !hideLoading && $ionicLoading.hide();
                        result = JSON.parse(result);
                        angular.isFunction(callback) && callback(result);
                    }
                } else {
                    // 不需要缓存则直接调用接口
                    NetworkService.httpExecute(httpConfig).then(function(result) {
                        !hideLoading && $ionicLoading.hide();
                        angular.isFunction(callback) && callback(result);
                    });
                }
            }
        };
        /*
         ** params 请求的参数
         ** url 请求地址
         ** result 1-需要取缓存 2-需要取缓存但是缓存时间已经失效 0-不需要取缓存
         ** callback 成功回调
         */
        this.needCache = function(url, params, callback) {
            var sessionList = CONFIG.SESSION_LIST;
            // console.log(url + "这是请求链接1");
            var result = 0;
            var sessionName = null;
            var requestCode = null;

            for (var k = 0; k < sessionList.length; k++) {
                if (sessionList[k].url == url) {
                    sessionName = sessionList[k].sessionName;
                    requestCode = sessionList[k].requestCode;

                    var data = requestService.getSessionTime(params, sessionName, requestCode);

                    var nowTime = new Date().getTime();

                    if (!data) {
                        result = 1;
                    } else {
                        var timeLine = (nowTime - data) / 60000;
                        // alert(timeLine);
                        if (timeLine >= CONFIG.SESSION_TIME) {
                            result = 2;
                        } else {
                            result = 1;
                        }
                    }
                }
            }
            angular.isFunction(callback) && callback(result, sessionName, requestCode);
        };

        /*
         ** 缓存接口手动从服务器获取数据
         ** params 请求的参数
         ** config 请求地址和请求方式的配置
         ** callback 成功回调
         */
        this.requestWithoutCache = function(params, config, callback, hideLoading) {
            var sessionList = CONFIG.SESSION_LIST;
            var sessionName = null;
            var requestCode = null;
            var url = config.url;
            if (params && config) {
                !hideLoading && $ionicLoading.show({
                    template: '<ion-spinner icon="bubbles"></ion-spinner>'
                });

                var httpConfig;
                if (config.method == 'GET') {
                    httpConfig = angular.extend({
                        params: params || {}
                    }, config);
                } else {
                    httpConfig = angular.extend({
                        data: params || {}
                    }, config);
                }

                for (var k = 0; k < sessionList.length; k++) {
                    if (sessionList[k].url == url) {
                        sessionName = sessionList[k].sessionName;
                        requestCode = sessionList[k].requestCode;
                    }
                }
                NetworkService.httpExecute(httpConfig).then(function(result) {
                    !hideLoading && $ionicLoading.hide();

                    if (sessionName && result) {
                        requestService.setSessionCache(params, result, sessionName, requestCode);
                        requestService.setSessionTime(params, sessionName, requestCode);
                    }

                    angular.isFunction(callback) && callback(result);
                });
            }
        };
    }

    // 异常请求服务
    function PendingRequestsService($rootScope) {
        this.pending = [];

        this.add = function(p) {
            this.pending.push(p);
        };

        this.cancel = function(url) {
            var self = this,
                pending = self.pending;

            for (var i = 0; i < pending.length; i++) {
                if (pending[i].url === url) {
                    pending[i].deferred.resolve($rootScope.TIPS.SYSTEM.REQUEST_DENIED);
                    pending.splice(i, 1);
                }
            }
        };

        this.cancelAll = function() {
            var self = this,
                pending = self.pending;

            angular.forEach(pending, function(p) {
                p.deferred.resolve($rootScope.TIPS.SYSTEM.REQUEST_DENIED);
            });
            pending.length = 0;
        };
    }

    // 提示信息
    function TipService(CONFIG, $ionicPopup, $ionicBackdrop, $timeout, $rootScope) {
        // 显示提示信息，延时自动消失
        this.showMsg = function(msg, type) {
            if (msg) {
                var dialog;
                if (type && type == 'success') {
                    dialog = $ionicPopup.show({
                        cssClass: 'popup-success',
                        title: '<i class="ion-checkmark"><span class="text">' + msg + '</span>' + '</i>'
                    });
                } else {
                    // dialog = $ionicPopup.show({
                    //     cssClass: 'popup-tip',
                    //     title: msg
                    // });

                    $ionicPopup.alert({
                        title: '温馨提示',
                        template: msg,
                        okText: '我知道了'
                    });
                }

                $ionicBackdrop.release();
                if (dialog) {
                    $timeout(function() {
                        dialog.close();
                        $rootScope.$broadcast('tip-done', {
                            msg: msg
                        });
                    }, CONFIG.TIPS_DURATION);
                }
            }
        };
    }



})();