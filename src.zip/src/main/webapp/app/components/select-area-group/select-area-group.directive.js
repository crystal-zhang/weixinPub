// /**
//  * Created by zhang on 2016/4/25.
//  */
(function() {
    'use strict';

    angular
        .module('app')
        .directive('selectAreaGroup', selectAreaGroup);

    selectAreaGroup.$inject = ['$ionicModal', 'CommonRequest', 'CONFIG', '$rootScope'];
    /** @ngInject */
    function selectAreaGroup($ionicModal, CommonRequest, CONFIG, $rootScope) {
        var directive = {
            restrict: 'A',
            require: '?ngModel',
            scope: {
                selectedAreaGroup: '=selectAreaGroup' // 用于存储被选择的区域
            },
            link: linkFunc
        };

        return directive;

        function linkFunc(scope, element, attr, ngModel) {
            var areaHistory = []; // 用于储层历史选项
            var selectedAreaGroup = []; // 用于存储被选择的区域
            var selectedAreaGroupCode = []; // 用于存储被选择的区域Code
            $ionicModal.fromTemplateUrl('app/components/select-area-group/select-area-group.html', {
                scope: scope
            }).then(function(modal) {
                scope.modal = modal;

            });

            scope.hideModal = function() {
                // 清空存储的数据
                selectedAreaGroup = [];
                selectedAreaGroupCode = [];
                areaHistory = [];
                scope.cities = [];
                scope.counties = [];
                scope.modal.hide();
            };

            // 所在地区
            scope.showModal = function() {
                scope.areas = scope.provinces;
                scope.modal.show();
            };

            // 返回到先前区域，如果已经无法返回，则关闭区域选择
            scope.returnPreArea = function() {
                if (areaHistory.length !== 0 && selectedAreaGroup.length !== 0) {
                    scope.areas = areaHistory.pop();
                    selectedAreaGroup.pop();
                    selectedAreaGroupCode.pop();
                    scope.cities = [];
                    scope.counties = [];
                } else {
                    scope.hideModal();
                }
            };

            // 选择城市
            scope.selectAreaGroup = function(area) {
                var params = {},
                    level = 1;
                if (!area || !area.areaCode) {
                    params = {
                        prdId: $rootScope.prdId
                    };
                } else {
                    level = parseInt(area.areaLevel) + 1;
                    params = {
                        parentAreaCode: area.areaCode,
                        areaLevel: level,
                        prdId: $rootScope.prdId
                    }
                }
                var request;
                if (!area) {
                    request = CONFIG.GET_DISTRICT_LEVEL_FIRST_SERVCIE;
                } else {
                    request = CONFIG.GET_DISTRICT_LEVEL_SECOND_SERVCIE;
                }
                CommonRequest.request(params, request, function(result) {
                    if (result.status == 1) {
                        if (!area) {
                            scope.provinces = result.data; //省
                        } else if (level == 2) {
                            scope.cities = result.data; //市
                        } else if (level == 3) {
                            scope.counties = result.data; //区/县
                        }
                    }

                    if (!area) {
                        return;
                    }

                    selectedAreaGroup.push(area);

                    areaHistory.push(scope.areas);

                    if (level == 2) {
                        scope.areas = scope.cities
                    } else if (level == 3) {
                        scope.areas = scope.counties
                    } else {
                        if (ngModel) {
                            var areaNames = [];
                            var areaCodes = [];
                            angular.forEach(selectedAreaGroup, function(area) {
                                areaNames.push(area.areaName);
                            });
                            angular.forEach(selectedAreaGroup, function(area) {
                                areaCodes.push(area.areaCode);
                            });
                            ngModel.$setViewValue(areaNames.join('-'));
                            ngModel.$render();
                            scope.$emit('select-area-group-close', selectedAreaGroup);
                            scope.hideModal();
                        }
                    }
                });

            };
            scope.selectAreaGroup();

            // 监听点击事件，单元素被点击，则弹出选择框
            element.on('click', scope.showModal);
            // 设置为只读
            element.attr('readonly', 'readonly');
            element.css('background-color', '#fff');

            // 当页面被销毁，则释放资源
            scope.$on('$destroy', function() {
                scope.modal.remove();
                element.off('click', scope.showModal);
            });
        }

    }
})();