// /**
//  * Created by zhang on 2016/4/25.
//  */
(function() {
    'use strict';

    angular
        .module('app')
        .directive('selectPrdArea', selectPrdArea);

    selectPrdArea.$inject = ['$ionicModal', 'CommonRequest', 'CONFIG', '$rootScope'];
    /** @ngInject */
    function selectPrdArea($ionicModal, CommonRequest, CONFIG, $rootScope) {
        var directive = {
            restrict: 'A',
            require: '?ngModel',
            scope: {
                selectedPrdArea: '=selectPrdArea' // 用于存储被选择的区域
            },
            link: linkFunc
        };

        return directive;

        function linkFunc(scope, element, attr, ngModel) {
            var areaHistory = []; // 用于储层历史选项
            var selectedArea = []; // 用于存储被选择的区域
            var selectedAreaCode = []; // 用于存储被选择的区域Code
            $ionicModal.fromTemplateUrl('app/components/select-prdarea/select-prdarea.html', {
                scope: scope
            }).then(function(modal) {
                scope.modal = modal;

            });
            scope.prodata = attr.prodata;

            scope.hideModal = function() {
                // 清空存储的数据
                selectedArea = [];
                selectedAreaCode = [];
                areaHistory = [];
                scope.cities = [];
                scope.counties = [];
                scope.modal.hide();
            };

            // 所在地区
            scope.showModal = function() {
                scope.areas = scope.provinces;
                scope.modal.show();
            };

            // 返回到先前区域，如果已经无法返回，则关闭区域选择
            scope.returnPreArea = function() {
                if (areaHistory.length !== 0 && selectedArea.length !== 0) {
                    scope.areas = areaHistory.pop();
                    selectedArea.pop();
                    selectedAreaCode.pop();
                    scope.cities = [];
                    scope.counties = [];
                } else {
                    scope.hideModal();
                }
            };
            // 所在地区一级
            scope.districtLevel1 = function() {
                var params = {
                    prdId: scope.prodata

                };
                var config = {
                    url: '../statics/product/areas/' + scope.prodata + '/' + scope.prodata + '.json',
                    method: 'GET'
                };
                CommonRequest.request(params, config, function(result) {
                    // if (result.status == 1) {
                    scope.provinces = result;
                    // }
                });
            };
            // 所在地区二级
            scope.districtLevel2 = function(area) {
                var level = parseInt(area.areaLevel)+1;
                var config;
                if (level == 2) {
                    scope.province = area.areaCode;
                    config = {
                        url: '../statics/product/areas/' + scope.prodata + '/' + area.areaCode + '/' + scope.prodata + '.json',
                        method: 'GET'
                    };
                } else if (level == 3) {
                    config = {
                        url: '../statics/product/areas/' + scope.prodata + '/' + scope.province + '/' + area.areaCode + '/' + scope.prodata + '.json',
                        method: 'GET'
                    };
                }
                var params = {
                    prdId: scope.prodata,
                    parentAreaCode: area.areaCode,
                    areaLevel: level
                };
                CommonRequest.request(params, config, function(result) {
                    // if (result.status == 1) {
                        if (level == 2) {
                            scope.cities = result;
                            scope.areas = scope.cities;
                        } else {
                            scope.counties = result;
                            scope.areas = scope.counties;
                        }

                    // }

                });
            };
            // 选择城市
            scope.selectArea = function(area) {
                if (!area) {
                    scope.districtLevel1();
                } else if(parseInt(area.areaLevel)<3){
                    scope.districtLevel2(area)
                }
                if (!area) {
                    return;
                }
                selectedArea.push(area);

                areaHistory.push(scope.areas);

                if (scope.counties && scope.counties.length > 0) {
                    if (ngModel) {
                        var areaNames = [];
                        var areaCodes = [];
                        angular.forEach(selectedArea, function(area) {
                            areaNames.push(area.areaName);
                        });
                        angular.forEach(selectedArea, function(area) {
                            areaCodes.push(area.areaCode);
                        });
                        $rootScope.areaCodes = areaCodes.join('-');
                        ngModel.$setViewValue(areaNames.join('-'));
                        ngModel.$render();
                        scope.$emit('select-prdarea-close', selectedArea);
                        scope.hideModal();
                    }
                }
            };
            scope.selectArea();

            // 监听点击事件，单元素被点击，则弹出选择框
            element.on('click', scope.showModal);
            // 设置为只读
            element.attr('readonly', 'readonly');
            element.css('background-color', '#fff');

            // 当页面被销毁，则释放资源
            scope.$on('$destroy', function() {
                scope.modal.remove();
                element.off('click', scope.showModal);
            });
        }

    }

})();