/*
** disable paste 禁用复制粘贴
**
*/

(function() {
	'use strict';

	angular
		.module('app')
		.directive('disablePaste', disablePaste);

	disablePaste.$inject = [];
	/** @ngInject */
	function disablePaste() {
		var directive = {
			restrict: 'A',
			link: linkFunc
		};

		return directive;

		function linkFunc(scope, elem) {
			elem.on('paste', function(e) {
				e.preventDefault();
			});

			elem.on('copy', function(e) {
				e.preventDefault();
			});
		}
	}

})();
