/*
 ** common flow 通用流程展示效果
 **
 */
(function() {
    'use strict';

    angular
        .module('app')
        .directive('commonFlow', commonFlow);

    function commonFlow() {
        return {
            restrict: 'E',
            transclude: true,
            scope: {
                text: '@',
                current: '@'
            },
            templateUrl: 'app/components/common-flow/common-flow.html',
            controller: commonFlowController
        };

        function commonFlowController($scope) {
            var text = $scope.text,
                arr = text.split(','),
                steps = [];

            for (var i = 0; i < arr.length; i++) {
                steps.push({
                    text: arr[i]
                });
            }

            $scope.steps = steps;
        }
    }
})();
