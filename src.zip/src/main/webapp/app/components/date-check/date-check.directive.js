/*
 ** date check 时间校验
 **
 ** 	
 **
 */

(function() {
	'use strict';

	angular
		.module('app')
		.directive('dateCheck', dateCheck);

	dateCheck.$inject = ['VALIDATION', '$filter'];
	/** @ngInject */
	function dateCheck(VALIDATION, $filter) {
		var directive = {
			restrict: 'A',
			require: 'ngModel',
			link: linkFunc
		};

		return directive;

		function linkFunc(scope, elem, attr, ngModel) {
			scope.$watch(attr.ngModel, function(value) {
				if (!value) {
					ngModel.$setValidity('min', true);
					ngModel.$setValidity('max', true);
					return;
				}
				
				value = $filter('date')(value, 'yyyy-MM-dd');

				var min = new Date(attr.mintime);
				var max = new Date(attr.maxtime);
				
				value = new Date(value);
				
				if (value.getTime() > max.getTime()) {
					ngModel.$setValidity('max', false);
				} else {
					ngModel.$setValidity('max', true);
				}
				
				if (value.getTime() < min.getTime()) {
					ngModel.$setValidity('min', false);
				} else {
					ngModel.$setValidity('min', true);
				}

			});
		}
	}

})();