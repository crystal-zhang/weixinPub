/*
 ** phone code check 手机验证码校验
 **
 ** 校验规则：
 ** 1、数字类型；
 ** 2、长度为6位；
 **
 */

(function() {
  'use strict';

  angular
    .module('app')
    .directive('phoneCodeCheck', phoneCodeCheck);

  phoneCodeCheck.$inject = ['VALIDATION'];
  /** @ngInject */
  function phoneCodeCheck(VALIDATION) {
    var directive = {
      restrict: 'A',
      require: 'ngModel',
      link: linkFunc
    };

    return directive;

    function linkFunc(scope, elem, attr, ngModel) {
      scope.$watch(attr.ngModel, function(value) {
        if (!value) {
          ngModel.$setValidity('invalid', true);
          ngModel.$setValidity('length', true);
          return;
        }

        if (VALIDATION.numberCheck(value)) {
          // 数字校验
          ngModel.$setValidity('invalid', false);
          ngModel.$setValidity('length', true);
        } else {
          ngModel.$setValidity('invalid', true);
          if (!VALIDATION.stringLengthCheck(value, 6, '=')) {
            // 长度校验
            ngModel.$setValidity('length', false);
          } else {
            ngModel.$setValidity('length', true);
          }
        }
      });
    }
  }

})();