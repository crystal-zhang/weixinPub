/*
 ** invalid string check 非法字符校验
 ** 
 ** 校验项：
 ** 1、特殊字符
 ** 2、特殊名称，如admin、管理员
 ** 3、防SQL注入
 ** 
 */

(function() {
	'use strict';

	angular
		.module('app')
		.directive('invalidStringCheck', invalidStringCheck);

	invalidStringCheck.$inject = ['VALIDATION'];
	/** @ngInject */
	function invalidStringCheck(VALIDATION) {
		var directive = {
			restrict: 'A',
			require: 'ngModel',
			link: linkFunc
		};

		return directive;

		function linkFunc(scope, elem, attr, ngModel) {
			scope.$watch(attr.ngModel, function(value) {
				if (!value) {
					ngModel.$setValidity('invalid', true);
					return;
				}

				if (!VALIDATION.invalidStringCheck(value)) {
					ngModel.$setValidity('invalid', false);
				} else {
					ngModel.$setValidity('invalid', true);
				}
			});
		}
	}

})();