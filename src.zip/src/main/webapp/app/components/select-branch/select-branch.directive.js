// /**
//  * Created by zhang on 2016/4/25.
//  */
(function() {
    'use strict';

    angular
        .module('app')
        .directive('selectBranch', selectBranch);

    selectBranch.$inject = ['$ionicModal', 'CommonRequest', 'CONFIG'];
    /** @ngInject */
    function selectBranch($ionicModal, CommonRequest, CONFIG) {
        var directive = {
            restrict: 'A',
            require: '?ngModel',
            scope: {
                selectBranch: '=selectBranch' // 用于存储被选择的区域
            },
            link: linkFunc
        };

        return directive;

        function linkFunc(scope, element, attr, ngModel) {
            var areaHistory = []; // 用于储层历史选项
            var selectedArea = []; // 用于存储被选择的区域
            var selectedAreaCode = []; // 用于存储被选择的区域Code
            $ionicModal.fromTemplateUrl('app/components/select-branch/select-branch.html', {
                scope: scope
            }).then(function(modal) {
                scope.modal = modal;

            });
            scope.hideModal = function() {
                // 清空存储的数据
                selectedArea = [];
                selectedAreaCode = [];
                areaHistory = [];

                scope.modal.hide();
            };


            //所在地区
            scope.showModal = function() {
                scope.provincecode = attr.provincecode;
                scope.selectBranch();
                scope.modal.show();
            };

            // 返回到先前区域，如果已经无法返回，则关闭区域选择
            scope.returnPreArea = function() {
                if (areaHistory.length !== 0 && selectedArea.length !== 0) {
                    scope.areas = areaHistory.pop();
                    selectedArea.pop();
                    selectedAreaCode.pop();
                } else {
                    scope.hideModal();
                }
            };

            // 选择城市
            scope.selectBranch = function(netName, code, netLevel, areaCode) {
                if (netLevel) {
                    var level = parseInt(netLevel) + 1;
                } else {
                    var level = 1;
                }
                if (level == 4) {
                    if (ngModel) {
                        selectedArea.push({
                            netName: netName,
                            netCode: code
                        });
                        var areaNames = [];
                        var areaCodes = [];
                        angular.forEach(selectedArea, function(area) {
                            areaNames.push(area.netName);
                        });
                        ngModel.$setViewValue(areaNames[2]);
                        ngModel.$render();
                        scope.$emit('select-branch-close', selectedArea);
                        scope.hideModal();
                    }
                } else {
                    var params = {};
                    var config;
                    if (!code || !level) {
                        params = {};
                    } else {
                        params = {
                            parentNetCode: code,
                            netLevel: level
                        };
                    }
                    if (level == 1) {
                        config = {
                            url: '../statics/product/netpoints/0/netpoint.json',
                            method: 'GET'
                        };
                    } else if (level == 2) {
                        scope.province = code;
                        config = config = {
                            url: '../statics/product/netpoints/0/' + code + '/' + 'netpoint.json',
                            method: 'GET'
                        };
                    } else if (level == 3) {
                        config = config = {
                            url: '../statics/product/netpoints/0/' + scope.province + '/' + code + '/' + 'netpoint.json',
                            method: 'GET'
                        };
                    }
                    CommonRequest.request(params, config, function(result) {
                        // if (result.status == 1) {
                        if (level == 1) {
                            scope.provinceMarkList = result;
                            scope.provinceMarks = [];
                            if (scope.provinceMarkList && scope.provinceMarkList.length > 0) {
                                for (var i = 0; i < scope.provinceMarkList.length; i++) {
                                    if (scope.provinceMarkList[i].netCode == scope.provincecode) {
                                        scope.provinceMarks.push(scope.provinceMarkList[i]);
                                    }
                                }
                                scope.areas = scope.provinceMarks;
                            }
                        } else if (level == 2) {
                            scope.cityMarks = result;
                        } else {
                            scope.areaMarks = result;
                        }
                        // }
                        if (level > 1) {
                            selectedArea.push({
                                netName: netName,
                                netCode: code
                            });
                            selectedAreaCode.push(areaCode);
                            areaHistory.push(scope.areas);
                        }

                        if (level == 2) {
                            scope.areas = scope.cityMarks
                        } else if (level == 3) {
                            scope.areas = scope.areaMarks
                        }
                    });
                }
            };


            // 监听点击事件，单元素被点击，则弹出选择框
            element.on('click', scope.showModal);
            // 设置为只读
            element.attr('readonly', 'readonly');
            element.css('background-color', '#fff');

            // 当页面被销毁，则释放资源
            scope.$on('$destroy', function() {
                scope.modal.remove();
                element.off('click', scope.showModal);
            });
        }

    }

})();