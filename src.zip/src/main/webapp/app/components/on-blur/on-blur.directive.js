// /**
//  * Created by wangtiejun on 2018/3/14.
//  */
/*防止ios微信端点击日期控件出现软键盘现象*/
(function() {
    'use strict';

    angular
        .module('app')
        .directive('onBlur', onBlur);

    onBlur.$inject = [];
    /** @ngInject */
    function onBlur() {
        var directive = {
            restrict: 'A',
            require: '?ngModel',
            link: linkFunc
        };

        return directive;

        function linkFunc(scope, element, attr) {
            element.on('focus',function(e){
                this.blur();
            })
        }

    }

})();