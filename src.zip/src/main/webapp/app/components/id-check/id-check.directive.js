/*
 ** id check 身份证校验
 **
 ** 校验规则
 **
 ** 1、证件号码不能为空；
 ** 2、证件类型为居民身份证，证件号码必须满足身份证号码编码规范；
 ** 3、证件类型为非居民身份证，证件号码必须为8位以上字符；
 ** 4、字符类型，不允许输入汉字；
 ** 5、长度为30位；
 **
 */

(function() {
	'use strict';

	angular
		.module('app')
		.directive('idCheck', idCheck);

	idCheck.$inject = ['VALIDATION'];
	/** @ngInject */
	function idCheck(VALIDATION) {
		var directive = {
			restrict: 'A',
			require: 'ngModel',
			link: linkFunc
		};

		return directive;

		function linkFunc(scope, elem, attr, ngModel) {
			scope.$watch(attr.ngModel, function(value) {
				var typeArray = ['invalid', 'length', 'invalid2'];

                function setValidity(type) {
                    for (var i = 0; i < typeArray.length; i++) {
                        ngModel.$setValidity(typeArray[i], true);
                    }

                    if (type && typeArray.indexOf(type) != -1) {
                        ngModel.$setValidity(type, false);
                    }
                }

                if (!value) {
                    setValidity();
                    return;
                }

                // 中文检验
                if (VALIDATION.chineseCheck(value)) {
                    setValidity('invalid');
                    return;
                }

                // 长度校验
                if (!VALIDATION.stringLengthCheck(value, 20, 'lt')) {
                    setValidity('length');
                    return;
                }

                // 根据证件类型判断
                var idtype = attr.idtype;
                // 是否校验外国人永久居留证15位
				var checkN = attr.checkn;
				if (idtype != 'A') {
					if (checkN&& idtype == 'N') {
						// 非居民身份证，校验长度必须为8位以上
						if (!VALIDATION.stringLengthCheck(value, 15, 'gt')) {
							setValidity('invalid2');
							return;
						}
						if (!VALIDATION.stringLengthCheck(value, 15, 'lt')) {
							setValidity('invalid2');
							return;
						}
						if (!VALIDATION.wordCheck(value)) {
							setValidity('invalid2');
							return;
						}
					} else {
						// 非居民身份证，校验长度必须为8位以上
						if (!VALIDATION.stringLengthCheck(value, 8, 'gt')) {
							setValidity('invalid2');
							return;
						}
						if (!VALIDATION.wordCheck(value)) {
							setValidity('invalid2');
							return;
						}
					}
				} else {
	            	// 居民身份证做规范验证
	            	if (!VALIDATION.idCheck(value)) {
	                    setValidity('invalid2');
	                    return;
	                }
	            }

                setValidity();
			});
		}
	}

})();
