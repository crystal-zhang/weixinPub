/*
 ** repassword check 确认密码校验
 ** 
 ** 校验规则：
 ** 1、有数字和英文字母组成
 ** 2、长度不低于8位
 ** 3、必须和密码一致
 ** 
 */

(function() {
	'use strict';

	angular
		.module('app')
		.directive('repasswordCheck', repasswordCheck);

	repasswordCheck.$inject = ['VALIDATION'];
	/** @ngInject */
	function repasswordCheck(VALIDATION) {
		var directive = {
			restrict: 'A',
			require: 'ngModel',
			link: linkFunc
		};

		return directive;

		function linkFunc(scope, elem, attr, ngModel) {
			scope.$watch(attr.ngModel, function(value) {
				if (!value) {
					ngModel.$setValidity('invalid', true);
					ngModel.$setValidity('length', true);
					ngModel.$setValidity('same', true);
					ngModel.$setValidity('passwordFirst', true);
					return;
				}

				var confirmPassword = attr.password;
				if (confirmPassword) {
					ngModel.$setValidity('passwordFirst', true);
					if (confirmPassword != value) {
						// 确认密码校验
						ngModel.$setValidity('same', false);
					} else {
						ngModel.$setValidity('same', true);
						if (!VALIDATION.passwordCheck(value)) {
							// 非法字符校验
							ngModel.$setValidity('invalid', false);
						} else {
							ngModel.$setValidity('invalid', true);
							if (!VALIDATION.stringLengthCheck(value, 8, 'gt')) {
								// 长度校验
								ngModel.$setValidity('length', false);
							} else {
								ngModel.$setValidity('length', true);
							}
						}
					}
				} else {
					// 先输入密码
					ngModel.$setValidity('passwordFirst', false);
				}
			});
		}
	}

})();