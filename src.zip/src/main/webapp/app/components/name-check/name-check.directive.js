/*
 ** name check 姓名校验
 ** 
 ** 校验规则：
 ** 1、字符类型；
 ** 2、除“ ”外不允许输入其他特殊字符；
 ** 3、长度为60位字符；
 ** 
 */

(function() {
	'use strict';

	angular
		.module('app')
		.directive('nameCheck', nameCheck);

	nameCheck.$inject = ['VALIDATION'];
	/** @ngInject */
	function nameCheck(VALIDATION) {
		var directive = {
			restrict: 'A',
			require: 'ngModel',
			link: linkFunc
		};

		return directive;

		function linkFunc(scope, elem, attr, ngModel) {
			scope.$watch(attr.ngModel, function(value) {
				if (!value) {
					ngModel.$setValidity('invalid', true);
					ngModel.$setValidity('length', true);
					return;
				}

				if (!VALIDATION.stringCheck(value) || !VALIDATION.invalidStringCheck(value)) {
					// 非数字校验或非法字符校验
					ngModel.$setValidity('invalid', false);
				} else {
					ngModel.$setValidity('invalid', true);
					if (!VALIDATION.stringLengthCheck(value, 30, 'lt')) {
						// 长度校验
						ngModel.$setValidity('length', false);
					} else {
						ngModel.$setValidity('length', true);
					}
				}
			});
		}
	}

})();