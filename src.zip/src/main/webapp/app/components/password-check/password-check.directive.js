/*
 ** password check 密码校验
 ** 
 ** 校验规则：
 ** 1、有数字、英文字母和特殊字符组成
 ** 2、长度不低于8位，不大于16位
 ** 
 */

(function() {
	'use strict';

	angular
		.module('app')
		.directive('passwordCheck', passwordCheck);

	passwordCheck.$inject = ['VALIDATION'];
	/** @ngInject */
	function passwordCheck(VALIDATION) {
		var directive = {
			restrict: 'A',
			require: 'ngModel',
			link: linkFunc
		};

		return directive;

		function linkFunc(scope, elem, attr, ngModel) {
			scope.$watch(attr.ngModel, function(value) {
				if (!value) {
					ngModel.$setValidity('invalid', true);
					ngModel.$setValidity('length', true);
					return;
				}

				if (!VALIDATION.passwordCheck(value)) {
					// 非法字符校验
					ngModel.$setValidity('invalid', false);
				} else {
					ngModel.$setValidity('invalid', true);
					if (!VALIDATION.stringLengthCheck(value, 8, 'gt') || !VALIDATION.stringLengthCheck(value, 16, 'lt')) {
						// 长度校验
						ngModel.$setValidity('length', false);
					} else {
						ngModel.$setValidity('length', true);
					}
				}
			});
		}
	}

})();