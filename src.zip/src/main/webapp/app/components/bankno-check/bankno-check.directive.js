/*
** bankno check 银行账号校验
**
** 校验规则：
** 1、有数字组成
** 2、长度6-22位
**
*/

(function() {
	'use strict';

	angular
		.module('app')
		.directive('banknoCheck', banknoCheck);

	banknoCheck.$inject = ['VALIDATION'];
	/** @ngInject */
	function banknoCheck(VALIDATION) {
		var directive = {
			restrict: 'A',
			require: 'ngModel',
			link: linkFunc
		};

		return directive;

		function linkFunc(scope, elem, attr, ngModel) {
			scope.$watch(attr.ngModel, function(value) {
				var typeArray = ['invalid', 'length'];

                function setValidity(type) {
                    for (var i = 0; i < typeArray.length; i++) {
                        ngModel.$setValidity(typeArray[i], true);
                    }

                    if (type && typeArray.indexOf(type) != -1) {
                        ngModel.$setValidity(type, false);
                    }
                }

                if (!value) {
                    setValidity();
                    return;
                }

                // 非法字符校验
                if (!VALIDATION.banknoCheck(value)) {
                    setValidity('invalid');
                    return;
                }

                // 长度校验
                if (VALIDATION.stringLengthCheck(value, 11, 'lt') || VALIDATION.stringLengthCheck(value, 23, 'gt')) {
                    setValidity('length');
                    return;
                }

                setValidity();
			});
		}
	}

})();
