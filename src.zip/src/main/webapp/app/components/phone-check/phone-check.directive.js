/*
 ** phone check 手机号校验
 ** 
 ** 
 */

(function() {
	'use strict';

	angular
		.module('app')
		.directive('phoneCheck', phoneCheck);

	phoneCheck.$inject = ['VALIDATION'];
	/** @ngInject */
	function phoneCheck(VALIDATION) {
		var directive = {
			restrict: 'A',
			require: 'ngModel',
			link: linkFunc
		};

		return directive;

		function linkFunc(scope, elem, attr, ngModel) {
			scope.$watch(attr.ngModel, function(value) {
				if (!value) {
					ngModel.$setValidity('invalid', true);
					return;
				}

				if (!VALIDATION.phoneCheck(value)) {
					// 数字校验
					ngModel.$setValidity('invalid', false);
				} else {
					ngModel.$setValidity('invalid', true);
				}
			});
		}
	}

})();