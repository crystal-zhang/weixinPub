/*
 ** 上传文件
 **
 */

(function() {
	'use strict';

	angular
		.module('app')
		.directive('fileUpload', fileUpload);

	fileUpload.$inject = [];
	/** @ngInject */
	function fileUpload() {
		var directive = {
			restrict: 'A',
			require: 'ngModel',
			link: linkFunc
		};

		return directive;

		function linkFunc(scope, elem, attr, ngModel) {
			elem.bind('change', function(e) {
	            var files = e.target.files;

	            if (files.length) {
	                var file = files[0];
	                var reader = new FileReader();
	                if (/text\/\w+/.test(file.type)) {
	                    reader.onload = function() {
	                        angular.element(e.target).next('.upload-img').html('<pre>' + this.result + '</pre>');
	                    }
	                    reader.readAsText(file);
	                } else if(/image\/\w+/.test(file.type)) {
	                    reader.onload = function() {
	                        angular.element(e.target).next('.upload-img').html('<img src="' + this.result + '"/>');
	                    }
	                    reader.readAsDataURL(file);
	                }
	            }
	        });
		}
	}

})();