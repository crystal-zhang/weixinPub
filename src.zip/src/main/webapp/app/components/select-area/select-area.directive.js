// /**
//  * Created by zhang on 2016/4/25.
//  */
(function() {
    'use strict';

    angular
        .module('app')
        .directive('selectArea', selectArea);

    selectArea.$inject = ['$ionicModal', 'CommonRequest', 'CONFIG'];
    /** @ngInject */
    function selectArea($ionicModal, CommonRequest, CONFIG) {
        var directive = {
            restrict: 'A',
            require: '?ngModel',
            scope: {
                selectedArea: '=selectArea' // 用于存储被选择的区域
            },
            link: linkFunc
        };

        return directive;

        function linkFunc(scope, element, attr, ngModel) {
            var areaHistory = []; // 用于储层历史选项
            var selectedArea = []; // 用于存储被选择的区域
            var selectedAreaCode = []; // 用于存储被选择的区域Code
            $ionicModal.fromTemplateUrl('app/components/select-area/select-area.html', {
                scope: scope
            }).then(function(modal) {
                scope.modal = modal;

            });

            scope.hideModal = function() {
                // 清空存储的数据
                selectedArea = [];
                selectedAreaCode = [];
                areaHistory = [];
                scope.cities = [];
                scope.counties=[];
                scope.modal.hide();
            };

            // 所在地区
            scope.showModal = function() {
                scope.areas = scope.provinces;
                scope.modal.show();
            };

            // 返回到先前区域，如果已经无法返回，则关闭区域选择
            scope.returnPreArea = function() {
                if (areaHistory.length !== 0 && selectedArea.length !== 0) {
                    scope.areas = areaHistory.pop();
                    selectedArea.pop();
                    selectedAreaCode.pop();
                    scope.cities = [];
                    scope.counties=[];
                } else {
                    scope.hideModal();
                }
            };

            // 选择城市
            scope.selectArea = function(area) {
                var params = {},
                    level = 1;
                if (!area || !area.areaCode) {
                    params = {};
                } else {
                    level = parseInt(area.areaLevel) + 1;
                    params = {
                        parentAreaCode: area.areaCode,
                        areaLevel: level
                    }
                }
                CommonRequest.request(params, CONFIG.GET_AREA_SERVCIE, function(result) {
                    if (result.status == 1) {
                        if (!area) {
                            scope.provinces = result.data; //省
                        } else if (level == 2) {
                            scope.cities = result.data; //市
                        } else if (level == 3) {
                            scope.counties = result.data; //区/县
                        }
                    }

                    if (!area) {
                        return;
                    }

                    selectedArea.push(area);

                    areaHistory.push(scope.areas);

                    if (level == 2) {
                        scope.areas = scope.cities
                    } else if (level ==3){
                        scope.areas = scope.counties
                    } else {
                        if (ngModel) {
                            var areaNames = [];
                            var areaCodes = [];
                            angular.forEach(selectedArea, function(area) {
                                areaNames.push(area.areaName);
                            });
                            angular.forEach(selectedArea, function(area) {
                                areaCodes.push(area.areaCode);
                            });
                            ngModel.$setViewValue(areaNames.join('-'));
                            ngModel.$render();
                            scope.$emit('select-area-close', selectedArea);
                            scope.hideModal();
                        }
                    }
                });

            };
            scope.selectArea();

            // 监听点击事件，单元素被点击，则弹出选择框
            element.on('click', scope.showModal);
            // 设置为只读
            element.attr('readonly', 'readonly');
            element.css('background-color', '#fff');

            // 当页面被销毁，则释放资源
            scope.$on('$destroy', function() {
                scope.modal.remove();
                element.off('click', scope.showModal);
            });
        }

    }

})();