/*
** referralno check 推介人工号校验
**
** 校验规则：
** 1、字符组成
** 2、长度不超过30位
** 3、不含汉字
**
*/

(function() {
	'use strict';

	angular
		.module('app')
		.directive('referralnoCheck', referralnoCheck);

	referralnoCheck.$inject = ['VALIDATION'];
	/** @ngInject */
	function referralnoCheck(VALIDATION) {
		var directive = {
			restrict: 'A',
			require: 'ngModel',
			link: linkFunc
		};

		return directive;

		function linkFunc(scope, elem, attr, ngModel) {
			scope.$watch(attr.ngModel, function(value) {
				if (!value) {
					ngModel.$setValidity('invalid', true);
					return;
				}

				// 只能字母数字
				if (!VALIDATION.wordCheck(value)) {
					ngModel.$setValidity('invalid', false);
				} else {
					ngModel.$setValidity('invalid', true);
					if (!VALIDATION.stringLengthCheck(value, 30, 'lt')) {
						// 长度校验
						ngModel.$setValidity('length', false);
					} else {
						ngModel.$setValidity('length', true);
					}
				}
			});
		}
	}

})();
