/**
 * 获取手机验证码指令
 */
(function() {
    'use strict';

    angular
        .module('app')
        .directive('securityCode', securityCode);

    securityCode.$inject = ['$compile', '$timeout','CommonRequest', 'CONFIG','$rootScope'];
    /** @ngInject */
    function securityCode($compile, $timeout,CommonRequest, CONFIG,$rootScope) {
        var directive = {
            restrict: 'A',
            scope: {
                duration: '@' //绑定指令外部的duration属性,控制可重发消息的时间
            },
            link: linkFunc
        };

        return directive;

        function linkFunc(scope, elem, attrs) {
            var time;
            // 控制一定时间后可重新点击
            function timedCount() {
                // 还剩0秒时，解除禁用
                if (scope.duration == 0) {
                    clearTimeout(time);
                    elem.removeAttr('disabled');
                    // 清除后方的信息
                    elem.html('重新获取');
                } else {
                    // 保持禁用,倒计时
                    time = $timeout(function() {
                        scope.duration--;

                        angular.element(elem).html(scope.duration + '秒重发');

                        timedCount();
                    }, 1000);
                }
            }

            function countDown() {
                elem.attr('disabled', 'disabled');
                // 控制一定时间不能重新点击
                scope.duration = attrs.duration;

                timedCount();
            }
            // 给当前元素绑定click事件
            elem.bind('click', function() {
                var params = {
                    mobileNo: attrs.mobileno,
                    imageCode: attrs.imagecode,
                    random: attrs.random,
                    txCode: attrs.txcode
                };
                var flag;
                CommonRequest.request(params, CONFIG.SEND_FORGET_MSG_SERVICE, function(result) {
                    if (result) {
                        if (result.status == 1) {
                            countDown();
                            flag = true;
                        } else {
                            flag = false;
                        }
                        $rootScope.$broadcast('send-result', {
                            result: flag
                        });
                    }
                });
            });
        }
    }
})();