/*
** rebankno check 确认银行账户校验
**
** 校验规则：
** 1、有数字组成
** 2、长度6位-22位
** 3、必须和银行账户一致
**
*/

(function() {
	'use strict';

	angular
		.module('app')
		.directive('rebanknoCheck', rebanknoCheck);

	rebanknoCheck.$inject = ['VALIDATION'];
	/** @ngInject */
	function rebanknoCheck(VALIDATION) {
		var directive = {
			restrict: 'A',
			require: 'ngModel',
			link: linkFunc
		};

		return directive;

		function linkFunc(scope, elem, attr, ngModel) {
			attr.$observe('bankno',function(){
				//监控第一个input
				if(ngModel.$viewValue){
					var confirmBankNo = ngModel.$viewValue;
					var bankNo = attr.bankno;
					check(bankNo,confirmBankNo);
				}
				
			});
			scope.$watch(attr.ngModel, function(value) {
				if (!value) {
					ngModel.$setValidity('invalid', true);
					ngModel.$setValidity('length', true);
					ngModel.$setValidity('same', true);
					ngModel.$setValidity('banknoFirst', true);
					return;
				}
				check(attr.bankno,value);
			});

			function check(firstModel,confirmModel){
				var confirmPassword = firstModel;
				if (confirmPassword) {
					ngModel.$setValidity('banknoFirst', true);
					if (confirmPassword != confirmModel) {
						// 确认密码校验
						ngModel.$setValidity('same', false);
					} else {
						ngModel.$setValidity('same', true);
						if (!VALIDATION.banknoCheck(confirmModel)) {
							// 非法字符校验
							ngModel.$setValidity('invalid', false);
						} else {
							ngModel.$setValidity('invalid', true);
							if (VALIDATION.stringLengthCheck(confirmModel, 11, 'lt') || VALIDATION.stringLengthCheck(confirmModel, 23, 'gt')) {
								// 长度校验
								ngModel.$setValidity('length', false);
							} else {
								ngModel.$setValidity('length', true);
							}
						}
					}
				} else {
					// 先输入密码
					ngModel.$setValidity('banknoFirst', false);
				}
			}
		}
	}

})();
