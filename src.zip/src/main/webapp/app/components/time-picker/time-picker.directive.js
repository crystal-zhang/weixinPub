/*
 ** time-pick 时间滚动选择组件
 **
 */
(function() {
    'use strict';

    angular
        .module('app')
        .directive('timePicker', timePicker);
    timePicker.$inject = ['$filter', '$rootScope'];

    function timePicker($filter, $rootScope) {
        var directive = {
            restrict: 'A',
            require: '?ngModel',
            link: linkFunc
        };

        return directive;

        function linkFunc(scope, element, attr) {
            var rootScope = $rootScope;
            rootScope.$on('$stateChangeStart', function() {
                return;
            });
            var calendar = new lCalendar();

            var maxDate = attr.maxdate;
            var minDate = attr.mindate;

            var now = new Date();
            now = $filter('date')(now, 'yyyy-MM-dd');
            now = new Date(now);
            if (maxDate) {
                var maxlength = maxDate.split('.').length;
                if (maxlength == 2) {
                    var maxtime = $filter('date')(scope[maxDate.split('.')[0]][maxDate.split('.')[1]], 'yyyy-MM-dd');
                } else if (maxlength == 1) {
                    var maxtime = $filter('date')(scope[maxDate], 'yyyy-MM-dd');
                }

                var maxChooseTime = new Date(maxtime);
                if (maxChooseTime.getTime() < now.getTime()) {
                    now = maxChooseTime;
                }
            } else {
                var maxtime = "2099-12-31";
            }
            if (minDate) {
                var minlength = minDate.split('.').length;
                if (minlength == 2) {
                    var mintime = $filter('date')(scope[minDate.split('.')[0]][minDate.split('.')[1]], 'yyyy-MM-dd');
                } else if (minlength == 1) {
                    var mintime = $filter('date')(scope[minDate], 'yyyy-MM-dd');
                }
            } else {
                var mintime = "1900-01-01";
            }


            calendar.init({
                'trigger': element[0],
                'type': 'date',
                'max': maxtime,
                'min': mintime,
                'chooseTime': now
            });
            // 页面跳转事件监听
            var rootScope = $rootScope;
            rootScope.$on('$stateChangeStart', function(event, toState) {
                if (calendar.gearDate) {
                    calendar.gearDate.remove('.gearDate');
                }
            });
        }
    }
})();