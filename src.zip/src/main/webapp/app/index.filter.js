(function() {
    'use strict';

    angular
        .module('app')
        .filter('paymentFilter', paymentFilter)
        .filter('ageFilter', ageFilter)
        .filter('genderFilter', genderFilter)
        .filter('cerFilter', cerFilter)
        .filter('relationFilter', relationFilter)
        .filter('nationalFilter', nationalFilter)
        .filter('subStrFilter', subStrFilter)
        .filter('currencyFormat', currencyFormat)
        .filter('orderStatusFilter', orderStatusFilter)
        .filter('paywayFilter', paywayFilter)
        .filter('phoneFilter', phoneFilter)
        .filter('transferFilter', transferFilter)
        .filter('benefitFilter', benefitFilter)
        .filter('descriptionFilter', descriptionFilter)
        .filter('payFilter', payFilter)
        .filter('paystatusFilter', paystatusFilter)
        .filter('benefitaccountFilter', benefitaccountFilter)
        .filter('occupationFilter', occupationFilter)
        .filter('imageFix', imageFix)
        .filter('policyQueryFilter', policyQueryFilter)
        .filter('salachannalFilter', salachannalFilter)
        .filter('claimTypeFilter', claimTypeFilter)
        .filter('orderFilter', orderFilter)
        .filter('policyFilter', policyFilter)
        .filter('idFilter', idFilter)
        .filter('channalFilter', channalFilter)
        .filter('policyChangeFilter', policyChangeFilter)
        .filter('percentFilter', percentFilter)
        .filter('changeFormatFilter', changeFormatFilter)
        .filter('claimsAnsFilter', claimsAnsFilter)
        .filter('claimsMainStatusFilter', claimsMainStatusFilter)
        .filter('claimsDetailStatusFilter', claimsDetailStatusFilter)
        .filter('claimsReasonStatusFilter', claimsReasonStatusFilter)
        .filter('policyDetailStatusFilter', policyDetailStatusFilter)
        .filter('bankCodeFilter', bankCodeFilter)
        .filter('iframeFilter', iframeFilter)
        .filter('jsonFilter', jsonFilter)
        .filter('mateFilter', mateFilter)
        .filter('socialFilter', socialFilter)
        .filter('groupRelationFilter', groupRelationFilter);

    paymentFilter.$inject = ['COMMON'];
    ageFilter.$inject = ['COMMON'];
    genderFilter.$inject = ['COMMON'];
    cerFilter.$inject = ['COMMON'];
    relationFilter.$inject = ['COMMON'];
    nationalFilter.$inject = ['$rootScope'];
    currencyFormat.$inject = [];
    orderStatusFilter.$inject = ['COMMON'];
    paywayFilter.$inject = ['COMMON'];
    transferFilter.$inject = ['COMMON'];
    benefitFilter.$inject = ['COMMON'];
    paystatusFilter.$inject = ['COMMON'];
    benefitaccountFilter.$inject = ['COMMON'];
    occupationFilter.$inject = ['$rootScope'];
    imageFix.$inject = ['CONFIG'];
    policyQueryFilter.$inject = ['COMMON'];
    salachannalFilter.$inject = ['COMMON'];
    claimTypeFilter.$inject = ['COMMON'];
    channalFilter.$inject = ['COMMON'];
    policyChangeFilter.$inject = ['COMMON'];
    claimsAnsFilter.$inject = ['COMMON'];
    claimsMainStatusFilter.$inject = ['COMMON'];
    claimsDetailStatusFilter.$inject = ['COMMON'];
    policyDetailStatusFilter.$inject = ['COMMON'];
    claimsReasonStatusFilter.$inject = ['COMMON'];
    iframeFilter.$inject = ['CONFIG'];
    jsonFilter.$inject = ['CONFIG'];
    mateFilter.$inject = ['COMMON'];
    socialFilter.$inject = ['COMMON'];
    groupRelationFilter.$inject = ['COMMON'];
    /** @ngInject */

    // 缴费方式
    function paymentFilter(COMMON) {
        return function(data) {
            if (data) {
                var re = [];
                var result = [];
                var hash = {};
                //删除字符串中重复的字符
                for (var j = 0, el; j < data.length; j++) {
                    el = data[j];
                    if (!hash[el]) {
                        hash[el] = true;
                        re = re + el;
                    }
                }
                //将字符串组成数组
                re = re.split(',');
                var payments = COMMON.getCommonData().PAYMENTS;
                for (var i = 0; i < payments.length; i++) {
                    var payment = payments[i];
                    for (var k = 0; k < re.length; k++) {
                        if (re[k] && re[k] == payment.value) {
                            result.push(payment.label);

                        }
                    }
                }
                result = result.toString();
                return result;
            }
        };
    }

    // 年龄
    function ageFilter() {
        return function(data) {
            if (data) {
                if (data == 0) {
                    return '30天';
                } else {
                    return data + '周岁';
                }
            }

        };
    }

    // 性别
    function genderFilter(COMMON) {
        return function(data) {
            var genders = COMMON.getCommonData().GENDERS;
            for (var i = 0; i < genders.length; i++) {
                var gender = genders[i];
                if (data == gender.value) {
                    return gender.label;
                }
            }
        };
    }

    // 证件类型
    function cerFilter(COMMON) {
        return function(data) {
            var idtypes = COMMON.getCommonData().ID_TYPES;
            for (var i = 0; i < idtypes.length; i++) {
                var idtype = idtypes[i];
                if (data == idtype.value) {
                    return idtype.label;
                }
            }
        };
    }

    // 关系
    function relationFilter(COMMON) {
        return function(data) {
            var relations = COMMON.getCommonData().RELATIONS;
            for (var i = 0; i < relations.length; i++) {
                var relation = relations[i];
                if (data == relation.value) {
                    return relation.label;
                }
            }
        };
    }
    //团险关系
    function groupRelationFilter(COMMON) {
        return function(data) {
            var relations = COMMON.getCommonData().Mate_Child;
            for (var i = 0; i < relations.length; i++) {
                var relation = relations[i];
                if (data == relation.value) {
                    return relation.label;
                }
            }
        };
    }
    // 国籍
    function nationalFilter($rootScope) {
        return function(data) {
            var nationalities = $rootScope.COMMON_DATA.NATIONALITIES;
            for (var i = 0; i < nationalities.length; i++) {
                var nationality = nationalities[i];
                if (data == nationality.value) {
                    return nationality.label;
                }
            }
        };
    }

    // 支付方式
    function paywayFilter(COMMON) {
        return function(data) {
            var pays = COMMON.getCommonData().PAYWAYS;
            for (var i = 0; i < pays.length; i++) {
                var pay = pays[i];
                if (data == pay.value) {
                    return pay.label;
                }
            }
        };
    }

    // 截取字符串
    function subStrFilter() {
        return function(data) {
            if (data) {
                var cha = data.substr(data.length - 1, 1);
                return cha;
            }
        };
    }

    // 金额格式化为万元
    function currencyFormat() {
        return function(data) {
            if (data) {
                return Math.round((parseInt(data) / 10000) * 100) / 100;
            }
        };
    }

    // 订单状态过滤
    function orderStatusFilter(COMMON) {
        return function(data) {
            var orderStatus = COMMON.getCommonData().ORDER_STATUS;
            for (var i = 0; i < orderStatus.length; i++) {
                var status = orderStatus[i];
                if (data == status.value) {
                    return status.label;
                }
            }
        };
    }

    // 手机号敏感过滤
    function phoneFilter() {
        return function(data) {
            if (data) {
                var phone = data.substr(0, 3) + '****' + data.substr(7);
                return phone;
            }
        };
    }

    // 保险期限过滤
    function changeFormatFilter() {
        return function(data) {
            if (data) {
                var insuYear = data[0],
                    insuYearFlag = data[1];
                if (insuYearFlag == 'Y') {
                    if (insuYear) {
                        if (insuYear == '1000') {
                            return '终身';
                        } else {
                            return insuYear + '年';
                        }
                    }
                } else if (insuYearFlag == 'D') {
                    return insuYear + '天';
                } else if (insuYearFlag == 'M') {
                    return insuYear + '月';
                } else if (insuYearFlag == 'A') {
                    return insuYear + '岁';
                }
            }

        }
    }

    // 受益人过滤器
    // 0   生存金受益人
    // 1   身故受益人
    // 3   满期受益人
    // 5   年金受益人
    // 6   贺喜金受益人
    function transferFilter(COMMON) {
        return function(data) {
            var datas = COMMON.getCommonData().BENEFIT_CUST_TYPE;
            for (var i = 0; i < datas.length; i++) {
                if (data == datas[i].value) {
                    return datas[i].label;
                }
            }
        };
    }
    // 红利选择权
    function benefitFilter() {
        return function(data) {
            if (data == '1') {
                data = '现金';
            } else if (data == '2') {
                data = '抵交保险费';
            } else if (data == '4') {
                data = '累积生息';
            }
            return data;
        };
    }

    // 描述切取
    function descriptionFilter() {
        return function(data) {
            if (data) {
                var strArr = data.trim().split(' ');
                return strArr;
            }
        }
    }

    // 缴费方式
    function payFilter() {
        return function(data) {
            if (data) {
                var payAge = data[0],
                    paymentType = data[1];
                if (paymentType == '12') {
                    if (payAge) {
                        return payAge + '年交';
                    }
                } else if (paymentType == '0') {
                    if (payAge == '1') {
                        return '趸交';
                    }
                } else if (paymentType == '1') {
                    return '月交';
                } else if (paymentType == '3') {
                    return '季交';
                } else if (paymentType == '6') {
                    return '半年交';
                }
            }
        }
    }

    // 支付方式
    function paystatusFilter(COMMON) {
        return function(data) {
            var pays = COMMON.getCommonData().PAY_STATUS;
            for (var i = 0; i < pays.length; i++) {
                var pay = pays[i];
                if (data == pay.value) {
                    return pay.label;
                }
            }
        };
    }

    // 红利领取方式
    function benefitaccountFilter(COMMON) {
        return function(data) {
            var benefits = COMMON.getCommonData().BENEFIT_ACCOUNT;
            for (var i = 0; i < benefits.length; i++) {
                var benefit = benefits[i];
                if (data == benefit.value) {
                    return benefit.label;
                }
            }
        };
    }

    // 职业类型
    function occupationFilter($rootScope) {
        return function(data) {
            var jobcodes = $rootScope.COMMON_DATA.OCCUPATION_CODE;
            for (var i = 0; i < jobcodes.length; i++) {
                var jobcode = jobcodes[i];
                if (data == jobcode.value) {
                    return jobcode.label;
                }
            }
        };
    }
    // 开户银行
    function bankCodeFilter(COMMON) {
        return function(data) {
            var bankCodes = COMMON.getCommonData().BANK_CODE;
            for (var i = 0; i < bankCodes.length; i++) {
                var bankCode = bankCodes[i];
                if (data == bankCode.value) {
                    return bankCode.label;
                }
            }
        };
    }

    // 添加图片路径
    function imageFix(CONFIG) {
        return function(data) {
            return CONFIG.IMAGE_SERVICE_ADDRESS + data;
        }
    }

    // 保全变更状态
    function policyQueryFilter(COMMON) {
        return function(data) {
            var datas = COMMON.getCommonData().POLICY_QUERY;
            for (var i = 0; i < datas.length; i++) {
                if (data == datas[i].value) {
                    return datas[i].label;
                }
            }
        };
    }

    // 销售渠道-变更进度
    function salachannalFilter(COMMON) {
        return function(data) {
            var datas = COMMON.getCommonData().SALA_CHANNAL;
            for (var i = 0; i < datas.length; i++) {
                if (data == datas[i].value) {
                    return datas[i].label;
                }
            }
        };
    }

    // 变更名称映射
    function policyChangeFilter(COMMON) {
        return function(data) {
            var datas = COMMON.getCommonData().POLICYCHANGE_TYPE;
            for (var i = 0; i < datas.length; i++) {
                if (data == datas[i].value) {
                    return datas[i].label;
                }
            }
        };
    }

    // 理赔类型
    function claimTypeFilter(COMMON) {
        return function(data) {
            var datas = COMMON.getCommonData().CLAIMS_TYPE;
            for (var i = 0; i < datas.length; i++) {
                if (data == datas[i].value) {
                    return datas[i].label;
                }
            }
        };
    }

    // 订单筛选
    function orderFilter() {
        return function(data, no) {
            var list = [];
            if (!no) {
                return data;
            } else {
                for (var i = 0; i < data.length; i++) {
                    if (data[i].orderCode.indexOf(no) >= 0 || data[i].prdName.indexOf(no) >= 0) {
                        list.push(data[i]);
                    }
                }
                return list;
            }
        }
    }

    // 保单筛选
    function policyFilter() {
        return function(data, no) {
            var list = [];
            if (!no) {
                return data;
            } else {
                for (var i = 0; i < data.length; i++) {
                    if (data[i].mainClassName.indexOf(no) >= 0 || data[i].policyNo.indexOf(no) >= 0) {
                        list.push(data[i]);
                    }
                }
                return list;
            }
        }
    }

    // 证件号过滤
    function idFilter() {
        return function(data) {
            if (data) {
                var phone;
                if (data.length > 8) {
                    phone = data.substr(0, 4) + '****' + data.substr(data.length - 4, data.length - 1);
                } else {
                    phone = '****' + data.substr(data.length - 4, data.length - 1);
                }
                return phone;
            }
        };
    }

    // 渠道筛选
    function channalFilter(COMMON) {
        return function(data) {
            var datas = COMMON.getCommonData().CHANNAL_CODE;
            for (var i = 0; i < datas.length; i++) {
                if (data == datas[i].value) {
                    return datas[i].label;
                }
            }
        };
    }

    // 百分比格式化
    function percentFilter() {
        return function(data) {
            if (data && !isNaN(data)) {
                return data * 100 + '%';
            }
            return data;
        };
    }
    // 赔付结论过滤
    function claimsAnsFilter(COMMON) {
        return function(data) {
            var datas = COMMON.getCommonData().CLAIMS_ANS;
            for (var i = 0; i < datas.length; i++) {
                if (data == datas[i].value) {
                    return datas[i].label;
                }
            }
        };
    }
    // 理赔状态过滤
    function claimsMainStatusFilter(COMMON) {
        return function(data) {
            var datas = COMMON.getCommonData().CLAIMS_MAIN_STATUS;
            for (var i = 0; i < datas.length; i++) {
                if (data == datas[i].value) {
                    return datas[i].label;
                }
            }
        };
    }
    // 理赔状态过滤
    function claimsDetailStatusFilter(COMMON) {
        return function(data) {
            var datas = COMMON.getCommonData().CLAIMS_DETAIL_STATUS;
            for (var i = 0; i < datas.length; i++) {
                if (data == datas[i].value) {
                    return datas[i].label;
                }
            }
        };
    }
    // 保单状态过滤
    function policyDetailStatusFilter(COMMON) {
        return function(data) {
            var datas = COMMON.getCommonData().POLICY_DETAIL_STATUS;
            for (var i = 0; i < datas.length; i++) {
                if (data == datas[i].value) {
                    return datas[i].label;
                }
            }
        };
    }
    // 出险原因过滤
    function claimsReasonStatusFilter(COMMON) {
        return function(data) {
            var datas = COMMON.getCommonData().CLAIMS_REASON_STATUS;
            for (var i = 0; i < datas.length; i++) {
                if (data == datas[i].value) {
                    return datas[i].label;
                }
            }
        };
    }
    // iframe过滤jsonFilter
    function iframeFilter(CONFIG) {
        return function(data) {
            if (data) {
                return '../statics/product/' + CONFIG.SALE_CHANNEL + '/' + data + '/' + data + '.html';
            }
        };
    }
    // jsonFilter过滤
    function jsonFilter(CONFIG) {
        return function(data) {
            if (data) {
                return '../statics/product/' + CONFIG.SALE_CHANNEL + '/' + data + '/' + data + '.json';
            }
        };
    }
    // 配偶或子女
    function mateFilter(COMMON) {
        return function(data) {
            var mateChild = COMMON.getCommonData().Mate_Child;
            for (var i = 0; i < mateChild.length; i++) {
                var relation = mateChild[i];
                if (data == relation.value) {
                    return relation.label;
                }
            }
        };
    }
    //有无社保医疗
    function socialFilter(COMMON) {
        return function(data) {
            var socialStatus = COMMON.getCommonData().SOCIAL_STATUS;
            for (var i = 0; i < socialStatus.length; i++) {
                var relation = socialStatus[i];
                if (data == relation.value) {
                    return relation.label;
                }
            }
        };
    }
})();